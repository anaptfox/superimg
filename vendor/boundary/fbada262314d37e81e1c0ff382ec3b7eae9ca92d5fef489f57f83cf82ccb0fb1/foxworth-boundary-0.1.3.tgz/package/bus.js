import { createConnection } from "node:net";
//#region packages/discovery/bus/src/client.ts
/**
* TypeScript client for the per-user local bus.
*
* Line-delimited JSON over a Unix domain socket. The bus answers where a
* Binding can be reached and holds nothing else. Trust is the OS user via
* the socket directory's 0700 permissions, not a second Offer filter and
* not SO_PEERCRED.
*/
var MAX_LINE = 65536;
var BusError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "BusError";
	}
};
var BusClient = class BusClient {
	socket;
	leftover;
	constructor(socket, leftover) {
		this.socket = socket;
		this.leftover = leftover;
	}
	static connect(path) {
		return new Promise((resolve, reject) => {
			const socket = createConnection(path);
			socket.once("connect", () => {
				socket.setNoDelay?.(true);
				resolve(new BusClient(socket, Buffer.alloc(0)));
			});
			socket.once("error", reject);
		});
	}
	async register(record) {
		const response = await this.send({
			op: "register",
			record
		});
		this.expectOk(response);
	}
	async unregister(bindingDigest) {
		const response = await this.send({
			op: "unregister",
			binding_digest: bindingDigest
		});
		this.expectOk(response);
	}
	async list() {
		const response = await this.send({ op: "list" });
		this.expectOk(response);
		return response.records ?? [];
	}
	close() {
		this.socket.destroy();
	}
	expectOk(response) {
		if (response.status === "error") throw new BusError(`${response.code}: ${response.message}`);
	}
	send(request) {
		return new Promise((resolve, reject) => {
			const payload = `${JSON.stringify(request)}\n`;
			const onReadable = () => {
				try {
					const line = this.readLine();
					if (line === void 0) return;
					this.socket.off("readable", onReadable);
					this.socket.off("error", onError);
					resolve(JSON.parse(line));
				} catch (error) {
					this.socket.off("readable", onReadable);
					this.socket.off("error", onError);
					reject(error);
				}
			};
			const onError = (error) => {
				this.socket.off("readable", onReadable);
				reject(error);
			};
			this.socket.on("readable", onReadable);
			this.socket.once("error", onError);
			this.socket.write(payload, (error) => {
				if (error) {
					this.socket.off("readable", onReadable);
					this.socket.off("error", onError);
					reject(error);
				}
			});
		});
	}
	readLine() {
		const chunk = this.socket.read();
		if (chunk !== null) this.leftover = Buffer.concat([this.leftover, chunk]);
		const newline = this.leftover.indexOf(10);
		if (newline === -1) {
			if (this.leftover.length > MAX_LINE) throw new BusError(`bus line exceeds the ${MAX_LINE}-byte cap`);
			return;
		}
		if (newline > MAX_LINE) throw new BusError(`bus line exceeds the ${MAX_LINE}-byte cap`);
		const line = new TextDecoder().decode(this.leftover.subarray(0, newline));
		this.leftover = this.leftover.subarray(newline + 1);
		return line;
	}
};
//#endregion
export { BusClient, BusError };
