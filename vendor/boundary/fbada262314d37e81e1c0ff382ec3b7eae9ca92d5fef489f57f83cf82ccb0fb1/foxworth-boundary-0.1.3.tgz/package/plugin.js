import { BoundaryErrorBase, compareUtf8 } from "@foxworth/boundary/program";
import { createHash } from "node:crypto";
import { print } from "@bytecodealliance/jco";
import { Worker } from "node:worker_threads";
//#region packages/guests/plugin/src/name.ts
/**
* Interaction identifier to WIT identifier derivation.
*
* Interaction ids follow the Program v1 token grammar,
* `[A-Za-z0-9][A-Za-z0-9._~-]{0,127}`. WIT identifiers are lowercase kebab
* segments, `[a-z][a-z0-9]*(-[a-z0-9]+)*`, and a small keyword set is
* reserved. The two grammars do not correspond, so this module derives a name
* and reports an exact failure rather than guessing.
*
* Derivation never invents authority or identity: the interaction id remains
* the contract identity, and the derived name is only the WIT spelling of it.
* The projector records both, so a reader can always recover the id.
*
* This is a from-scratch TypeScript port of the algorithm in
* `crates/boundary-plugin/src/name.rs`. It must derive byte-identical WIT
* identifiers for the same interaction id; the shared conformance vector is the
* check, not this comment.
*/
/** Reserved WIT words that cannot be used as an identifier. */
var WIT_KEYWORDS = /* @__PURE__ */ new Set([
	"as",
	"bool",
	"borrow",
	"char",
	"constructor",
	"enum",
	"export",
	"f32",
	"f64",
	"flags",
	"from",
	"func",
	"future",
	"import",
	"include",
	"interface",
	"list",
	"option",
	"own",
	"package",
	"record",
	"resource",
	"result",
	"s16",
	"s32",
	"s64",
	"s8",
	"static",
	"stream",
	"string",
	"tuple",
	"type",
	"u16",
	"u32",
	"u64",
	"u8",
	"use",
	"variant",
	"with",
	"world"
]);
/** One interaction id that cannot be spelled as a WIT identifier. */
var NameError = class extends BoundaryErrorBase {
	/** The interaction id that failed. */
	interactionId;
	/** The derived name at the point of failure, when one existed. */
	derived;
	/** The offending segment, for `SEGMENT_START` and `SEGMENT_CHARACTER`. */
	segment;
	constructor(code, interactionId, message, options = {}) {
		super(code, `${interactionId}.witIdentifier`, message);
		this.name = "NameError";
		this.interactionId = interactionId;
		if (options.derived !== void 0) this.derived = options.derived;
		if (options.segment !== void 0) this.segment = options.segment;
	}
};
function isAsciiLower(character) {
	return character >= "a" && character <= "z";
}
function isAsciiUpper(character) {
	return character >= "A" && character <= "Z";
}
function isAsciiDigit(character) {
	return character >= "0" && character <= "9";
}
var SEPARATORS = /* @__PURE__ */ new Set([
	".",
	"_",
	"~",
	"-"
]);
/**
* Splits an interaction id into lowercase segments.
*
* Separators are `.`, `_`, `~`, and `-`. A lowercase-to-uppercase transition
* also starts a new segment, so `makeThumbnail` becomes `make` and
* `thumbnail`. A digit never starts a new segment, so `todos.v2` keeps `v2`
* intact rather than producing an invalid leading-digit segment.
*/
function segments(interactionId) {
	const out = [];
	let current = "";
	let previousLowerOrDigit = false;
	for (const character of interactionId) {
		if (SEPARATORS.has(character)) {
			if (current !== "") {
				out.push(current);
				current = "";
			}
			previousLowerOrDigit = false;
			continue;
		}
		if (isAsciiUpper(character) && previousLowerOrDigit && current !== "") {
			out.push(current);
			current = "";
		}
		previousLowerOrDigit = isAsciiLower(character) || isAsciiDigit(character);
		current += character.toLowerCase();
	}
	if (current !== "") out.push(current);
	return out;
}
/**
* Derives the WIT identifier for one interaction id.
*
* Returns a structured {@link NameError} rather than throwing, so a caller
* that must report every failing id (never just the first) can collect
* results across a whole Program before deciding what to do.
*/
function witIdentifier(interactionId) {
	const parts = segments(interactionId);
	if (parts.length === 0) return {
		ok: false,
		error: new NameError("EMPTY", interactionId, "derives no WIT identifier segments")
	};
	for (const segment of parts) {
		if (!isAsciiLower(segment.charAt(0))) return {
			ok: false,
			error: new NameError("SEGMENT_START", interactionId, `segment ${JSON.stringify(segment)} must begin with an ASCII lowercase letter`, {
				derived: parts.join("-"),
				segment
			})
		};
		for (let index = 1; index < segment.length; index += 1) {
			const character = segment.charAt(index);
			if (!isAsciiLower(character) && !isAsciiDigit(character)) return {
				ok: false,
				error: new NameError("SEGMENT_CHARACTER", interactionId, `segment ${JSON.stringify(segment)} must contain only ASCII lowercase letters and digits`, {
					derived: parts.join("-"),
					segment
				})
			};
		}
	}
	const derived = parts.join("-");
	if (WIT_KEYWORDS.has(derived)) return {
		ok: false,
		error: new NameError("RESERVED", interactionId, "derives a reserved WIT keyword", { derived })
	};
	return {
		ok: true,
		value: derived
	};
}
//#endregion
//#region packages/guests/plugin/src/wit.ts
/**
* Deterministic WIT world projection from a Program.
*
* The emitted world is a spelling of contracts the Program already owns. It
* carries no authority: an import listed here is a name the host *may* map to
* a function, never a grant. Binding checks that a component's actual imports
* are a subset of the host's map; this file only decides what the guest is
* allowed to ask for.
*
* Every interaction becomes one exported function taking canonical JSON and
* returning `result<string, string>`. The ok payload is the interaction
* output; the err payload is a declared interaction error. Anything else is a
* trap, and a trap is an infrastructure fault with unknown certainty, never a
* domain error. The JSON-string profile is deliberate: JSON Schema has no
* total mapping onto WIT records and variants, so lowering waits for an
* explicit opt-in profile.
*
* This is a from-scratch TypeScript port of
* `crates/boundary-plugin/src/wit.rs`. It must emit byte-identical WIT text
* for the same Program and options; the shared conformance vector is the
* check, not this comment.
*/
/** Generated-file banner. Present so a reader never edits the projection. */
var BANNER = "// Generated by Boundary. Do not edit.";
/** Default options: `boundary:guest@1.0.0`, world `guest`, interface `footprints`. */
var DEFAULT_WIT_PROJECTION_OPTIONS = Object.freeze({
	package: "boundary:guest",
	version: "1.0.0",
	world: "guest",
	importsInterface: "footprints"
});
/**
* A Program that has no valid WIT world. Exactly one of `errors`,
* (`witName`, `interactionIds`), or (`footprint`, `cause`) is populated,
* selected by `code`.
*/
var WitProjectionError = class WitProjectionError extends BoundaryErrorBase {
	/** Every interaction id that cannot be spelled in WIT, sorted. `NAMES_UNSPELLABLE` only. */
	errors;
	/** The colliding WIT identifier. `NAME_COLLISION` only. */
	witName;
	/** Every interaction id that derives `witName`, sorted. `NAME_COLLISION` only. */
	interactionIds;
	/** The offending footprint. `FOOTPRINT_UNSPELLABLE` only. */
	footprint;
	/** Every footprint that derives `witName`, sorted. `FOOTPRINT_COLLISION` only. */
	footprints;
	constructor(code, path, message, options = {}) {
		super(code, path, message, { cause: options.cause });
		this.name = "WitProjectionError";
		if (options.errors !== void 0) this.errors = options.errors;
		if (options.witName !== void 0) this.witName = options.witName;
		if (options.interactionIds !== void 0) this.interactionIds = options.interactionIds;
		if (options.footprint !== void 0) this.footprint = options.footprint;
		if (options.footprints !== void 0) this.footprints = options.footprints;
	}
	/** One or more interaction ids have no valid WIT spelling. Never just the first. */
	static names(errors) {
		return new WitProjectionError("NAMES_UNSPELLABLE", "program.interactions", `${errors.length} interaction id(s) cannot be spelled in WIT: ${errors.map((error) => error.message).join("; ")}`, { errors });
	}
	/** Two distinct interaction ids derive the same WIT identifier. */
	static collision(witName, interactionIds) {
		return new WitProjectionError("NAME_COLLISION", "program.interactions", `WIT identifier ${JSON.stringify(witName)} is derived by more than one interaction: ${interactionIds.join(", ")}`, {
			witName,
			interactionIds
		});
	}
	/** A footprint has no valid WIT spelling. */
	static footprint(footprint, cause) {
		return new WitProjectionError("FOOTPRINT_UNSPELLABLE", `program.footprints.${footprint}`, `footprint ${JSON.stringify(footprint)} cannot be spelled in WIT: ${cause.message}`, {
			cause,
			footprint
		});
	}
	/**
	* Two distinct footprints derive the same WIT identifier.
	*
	* The interaction-name collision has a footprint twin, because the same
	* derivation collapses distinct sources the same way. Rendering both would
	* emit two functions with one name in a single interface: invalid WIT, and
	* a WIT digest computed over text no toolchain would accept.
	*/
	static footprintCollision(witName, footprints) {
		return new WitProjectionError("FOOTPRINT_COLLISION", "program.footprints", `WIT identifier ${JSON.stringify(witName)} is derived by more than one footprint: ${footprints.join(", ")}`, {
			witName,
			footprints
		});
	}
};
function footprintList(values) {
	return values.length === 0 ? "(none)" : values.join(", ");
}
/** Renders the WIT text. Every loop here walks an already-sorted collection. */
function render(options, programDigest, interactions, footprintEntries) {
	let out = BANNER;
	out += "\n//\n";
	out += `// program: ${programDigest}\n`;
	out += `// interactions: ${interactions.length}\n`;
	out += "//\n";
	out += "// Each export takes canonical JSON input and returns canonical JSON output.\n";
	out += "// An `err` payload is a declared interaction error. A trap is an infrastructure\n";
	out += "// fault with unknown certainty, never a domain error.\n\n";
	out += `package ${options.package.trim()}@${options.version.trim()};\n\n`;
	out += "/// Host functions a guest may import. Listing a footprint here is not a\n";
	out += "/// grant: the host maps footprints to implementations at bind time, and a\n";
	out += "/// guest importing anything outside that map cannot be bound.\n";
	out += `interface ${options.importsInterface} {\n`;
	if (footprintEntries.length === 0) out += "  // This program declares no reads or changes.\n";
	for (const [footprint, name] of footprintEntries) {
		out += `  /// footprint: ${footprint}\n`;
		out += `  ${name}: func(request: string) -> result<string, string>;\n`;
	}
	out += "}\n\n";
	out += `world ${options.world} {\n`;
	out += `  import ${options.importsInterface};\n`;
	for (const { witName, descriptor } of interactions) {
		out += "\n";
		out += `  /// interaction: ${descriptor.contract.id}\n`;
		out += `  /// contract: ${descriptor.contractDigest}\n`;
		out += `  /// reads: ${footprintList(descriptor.contract.reads)}\n`;
		out += `  /// changes: ${footprintList(descriptor.contract.changes)}\n`;
		out += `  export ${witName}: func(input: string) -> result<string, string>;\n`;
	}
	out += "}\n";
	return out;
}
/**
* Projects a Program into a WIT world.
*
* The output is a pure function of the Program and the options: the same
* inputs always produce byte-identical text, which is what lets the Rust and
* TypeScript projectors be checked against one shared conformance vector.
*
* Throws {@link WitProjectionError} when an interaction id or footprint has no
* valid WIT spelling, or when two ids collide. The projector never resolves a
* collision by renaming; the host must supply an explicit alias.
*/
function projectWit(program, options = {}) {
	const resolved = {
		...DEFAULT_WIT_PROJECTION_OPTIONS,
		...options
	};
	const nameErrors = [];
	const byWitName = /* @__PURE__ */ new Map();
	const footprints = /* @__PURE__ */ new Map();
	const footprintNames = /* @__PURE__ */ new Map();
	for (const descriptor of program.interactions) {
		const id = descriptor.contract.id;
		const result = witIdentifier(id);
		if (result.ok) {
			const existing = byWitName.get(result.value);
			if (existing) existing.push(descriptor);
			else byWitName.set(result.value, [descriptor]);
		} else nameErrors.push(result.error);
		for (const footprint of [...descriptor.contract.reads, ...descriptor.contract.changes]) {
			if (footprints.has(footprint)) continue;
			const footprintResult = witIdentifier(footprint);
			if (!footprintResult.ok) throw WitProjectionError.footprint(footprint, footprintResult.error);
			const claimed = footprintNames.get(footprintResult.value);
			if (claimed) claimed.push(footprint);
			else footprintNames.set(footprintResult.value, [footprint]);
			footprints.set(footprint, footprintResult.value);
		}
	}
	if (nameErrors.length > 0) {
		nameErrors.sort((left, right) => compareUtf8(left.interactionId, right.interactionId));
		throw WitProjectionError.names(nameErrors);
	}
	for (const witName of [...footprintNames.keys()].sort(compareUtf8)) {
		const sources = footprintNames.get(witName);
		if (sources.length > 1) throw WitProjectionError.footprintCollision(witName, [...sources].sort(compareUtf8));
	}
	const witNames = [...byWitName.keys()].sort(compareUtf8);
	const renderInteractions = [];
	for (const witName of witNames) {
		const descriptors = byWitName.get(witName);
		if (descriptors.length > 1) {
			const interactionIds = descriptors.map((descriptor) => descriptor.contract.id).sort(compareUtf8);
			throw WitProjectionError.collision(witName, interactionIds);
		}
		renderInteractions.push({
			witName,
			descriptor: descriptors[0]
		});
	}
	const footprintEntries = [...footprints.keys()].sort(compareUtf8).map((original) => [original, footprints.get(original)]);
	const wit = render(resolved, program.programDigest, renderInteractions, footprintEntries);
	const interactions = renderInteractions.map(({ witName, descriptor }) => ({
		witName,
		interactionId: descriptor.contract.id,
		contractDigest: descriptor.contractDigest
	}));
	return Object.freeze({
		wit,
		interactions: Object.freeze(interactions),
		footprints: Object.freeze(footprintEntries.map(([, derived]) => derived)),
		programDigest: program.programDigest
	});
}
//#endregion
//#region packages/guests/plugin/src/imports.ts
/**
* Host-authored import offer and the bind-time subset check.
*
* Authority is absence: a guest reaches only the functions the host maps by
* name. The check does not enforce that a mapped host function honors its
* declared read or change class.
*/
function checkImports(interfaceName, offered, required) {
	const names = new Set(offered);
	const used = [];
	const unmapped = [];
	for (const imported of required) if (imported.instance === interfaceName && names.has(imported.name)) used.push(imported.name);
	else unmapped.push(qualifiedImport(imported));
	used.sort();
	unmapped.sort();
	return unmapped.length === 0 ? {
		status: "satisfied",
		used
	} : {
		status: "refused",
		unmapped,
		offered: [...offered]
	};
}
/** Internal capture: async inspection cannot observe later authority changes. */
function snapshotImportOffer(offer) {
	const interfaceName = offer.interface;
	const names = Object.freeze(offer.witNames());
	return Object.freeze({
		interface: interfaceName,
		witNames: () => [...names],
		check: (required) => checkImports(interfaceName, names, required)
	});
}
/** The complete set of imports a host offers one guest. */
var ImportOffer = class {
	interface;
	entries;
	constructor(interfaceName) {
		this.interface = interfaceName;
		this.entries = /* @__PURE__ */ new Map();
	}
	/**
	* Offers one footprint under its derived WIT name.
	*
	* Distinct footprints can derive one WIT name (`a.bC` and `a.b-c` both give
	* `a-b-c`). Overwriting the first would leave the host believing it offered
	* two capabilities while a guest reaches whichever was offered last — a
	* read-class footprint replaced by a change-class one, with nothing
	* reported. Mirrors `HostImports::provide` in Rust.
	*/
	offer(footprint) {
		const derived = witIdentifier(footprint);
		if (!derived.ok) throw derived.error;
		const claimed = this.entries.get(derived.value);
		if (claimed !== void 0 && claimed !== footprint) throw new Error(`footprint ${JSON.stringify(footprint)} derives the WIT name ${JSON.stringify(derived.value)}, already claimed by ${JSON.stringify(claimed)}`);
		this.entries.set(derived.value, footprint);
		return this;
	}
	contains(witName) {
		return this.entries.has(witName);
	}
	witNames() {
		return [...this.entries.keys()].sort((left, right) => left < right ? -1 : left > right ? 1 : 0);
	}
	check(required) {
		return checkImports(this.interface, this.witNames(), required);
	}
};
function qualifiedImport(imported) {
	return imported.instance === void 0 ? imported.name : `${imported.instance}#${imported.name}`;
}
//#endregion
//#region packages/guests/plugin/src/componentWat.ts
function fail(message) {
	throw new Error(`cannot inspect component imports: ${message}`);
}
/** Tokenize the printer's S-expressions, without interpreting Wasm grammar. */
function forms(wat) {
	const roots = [];
	const stack = [roots];
	const encoder = new TextEncoder();
	const decoder = new TextDecoder();
	let cursor = 0;
	const quoted = () => {
		cursor++;
		const bytes = [];
		while (cursor < wat.length) {
			const character = wat[cursor++];
			if (character === "\"") {
				const raw = new Uint8Array(bytes);
				return {
					value: decoder.decode(raw),
					quoted: true,
					bytes: raw
				};
			}
			if (character !== "\\") {
				const point = character.codePointAt(0);
				const text = point >= 55296 && point <= 56319 ? character + wat[cursor++] : character;
				bytes.push(...encoder.encode(text));
				continue;
			}
			const escape = wat[cursor++];
			const hex = escape + (wat[cursor] ?? "");
			if (/^[0-9a-fA-F]{2}$/.test(hex)) {
				bytes.push(Number.parseInt(hex, 16));
				cursor++;
			} else if (escape === "u" && wat[cursor] === "{") {
				const end = wat.indexOf("}", cursor);
				const digits = wat.slice(cursor + 1, end);
				const point = Number.parseInt(digits, 16);
				if (end < 0 || !/^[0-9a-fA-F]+$/.test(digits) || point > 1114111 || point >= 55296 && point <= 57343) fail("invalid printed Unicode escape");
				bytes.push(...encoder.encode(String.fromCodePoint(point)));
				cursor = end + 1;
			} else if (escape === "\"" || escape === "\\") bytes.push(escape.charCodeAt(0));
			else if (escape === "t") bytes.push(9);
			else if (escape === "n") bytes.push(10);
			else if (escape === "r") bytes.push(13);
			else fail("unsupported printed string escape");
		}
		return fail("unterminated printed string");
	};
	while (cursor < wat.length) {
		const character = wat[cursor];
		if (/\s/.test(character)) {
			cursor++;
			continue;
		}
		if (wat.startsWith(";;", cursor)) {
			const newline = wat.indexOf("\n", cursor);
			cursor = newline < 0 ? wat.length : newline + 1;
			continue;
		}
		if (wat.startsWith("(;", cursor)) {
			cursor += 2;
			let depth = 1;
			while (cursor < wat.length && depth > 0) if (wat.startsWith("(;", cursor)) {
				depth++;
				cursor += 2;
			} else if (wat.startsWith(";)", cursor)) {
				depth--;
				cursor += 2;
			} else cursor++;
			if (depth !== 0) fail("unterminated printed comment");
			continue;
		}
		const current = stack[stack.length - 1];
		if (character === "(") {
			const form = [];
			current.push(form);
			stack.push(form);
			cursor++;
		} else if (character === ")") {
			if (stack.length === 1) fail("unmatched printed parenthesis");
			stack.pop();
			cursor++;
		} else if (character === "\"") current.push(quoted());
		else if (wat.startsWith("$\"", cursor)) {
			cursor++;
			const id = quoted();
			current.push({
				value: `$${new TextDecoder("utf-8", { fatal: true }).decode(id.bytes)}`,
				quoted: false
			});
		} else {
			const start = cursor;
			while (cursor < wat.length && !/[\s()]/.test(wat[cursor])) cursor++;
			current.push({
				value: wat.slice(start, cursor),
				quoted: false
			});
		}
	}
	if (stack.length !== 1) fail("unclosed printed parenthesis");
	const root = roots[0];
	if (roots.length !== 1 || !Array.isArray(root) || atom(root[0]) !== "component") fail("expected a component binary");
	return root;
}
function atom(value) {
	return value !== void 0 && !Array.isArray(value) && !value.quoted ? value.value : void 0;
}
function name(form) {
	const value = form.find((item) => !Array.isArray(item) && item.quoted);
	if (value === void 0) fail("missing printed import or export name");
	return new TextDecoder("utf-8", { fatal: true }).decode(value.bytes);
}
function optionalDescriptor(form) {
	const definitions = form.filter((item) => Array.isArray(item) && !atom(item[0])?.startsWith("@"));
	if (definitions.length > 1) fail("ambiguous printed type or import descriptor");
	return definitions[0];
}
function descriptor(form) {
	return optionalDescriptor(form) ?? fail("missing printed type or import descriptor");
}
function identifier(form) {
	return form.map(atom).find((item) => item?.startsWith("$"));
}
//#endregion
//#region packages/guests/plugin/src/componentProjection.ts
/** Each component/type has its own indices; an instance export bag does not. */
var Scope = class {
	parent;
	id;
	typeContext;
	spaces = /* @__PURE__ */ new Map();
	imports = /* @__PURE__ */ new Map();
	exports = /* @__PURE__ */ new Map();
	constructor(parent, id, typeContext = false) {
		this.parent = parent;
		this.id = id;
		this.typeContext = typeContext;
	}
	add(kind, form, entry) {
		if (entry.kind !== kind) fail(`expected ${kind}, received ${entry.kind}`);
		const space = this.spaces.get(kind) ?? {
			entries: [],
			names: /* @__PURE__ */ new Map()
		};
		const id = identifier(form);
		if (id !== void 0) {
			if (space.names.has(id)) fail(`duplicate printed ${kind} identifier ${id}`);
			space.names.set(id, space.entries.length);
		}
		space.entries.push(entry);
		this.spaces.set(kind, space);
		return entry;
	}
	get(kind, reference) {
		const space = this.spaces.get(kind);
		const index = reference?.startsWith("$") ? space?.names.get(reference) : reference !== void 0 && /^\d+$/.test(reference) ? Number(reference) : void 0;
		return (index === void 0 ? void 0 : space?.entries[index]) ?? fail(`unresolved ${kind} ${String(reference)}`);
	}
	outer(reference) {
		if (reference?.startsWith("$")) {
			for (let scope = this; scope !== void 0; scope = scope.parent) if (scope.id === reference) return scope;
		} else if (reference !== void 0 && /^\d+$/.test(reference)) {
			let scope = this;
			for (let count = Number(reference); count > 0 && scope !== void 0; count--) scope = scope.parent;
			if (scope !== void 0) return scope;
		}
		return fail(`unresolved outer scope ${String(reference)}`);
	}
};
var kinds = /* @__PURE__ */ new Set([
	"type",
	"func",
	"instance",
	"component",
	"value",
	"core-type",
	"core-func",
	"core-instance",
	"core-module",
	"core-table",
	"core-memory",
	"core-global",
	"core-tag"
]);
function isKind(value) {
	return value !== void 0 && kinds.has(value);
}
function kind(form, core = false) {
	const first = atom(form[0]);
	const value = first === "core" ? `core-${atom(form[1])}` : core ? `core-${first}` : first;
	if (!isKind(value)) fail(`unsupported printed entity kind ${String(value)}`);
	return value;
}
function reference(form) {
	return form.slice(atom(form[0]) === "core" ? 2 : 1).map(atom).find((value) => value !== void 0);
}
function put(map, key, entry) {
	if (map.has(key)) fail(`duplicate printed import or export ${key}`);
	map.set(key, entry);
}
function shape(entry, expected) {
	if (entry.definition !== expected || entry.shape === void 0) fail(`expected ${expected} type shape`);
	return entry.shape;
}
function member(instance, key, expected) {
	const entry = instance.shape?.exports.get(key);
	if (entry === void 0) fail(`instance has no export ${key}`);
	if (entry.kind !== expected) fail(`instance export ${key} is ${entry.kind}, expected ${expected}`);
	return entry;
}
/** A descriptor creates a typed entity rather than referencing a runtime index. */
function typed(scope, form) {
	const entityKind = kind(form);
	const body = optionalDescriptor(form);
	if (entityKind === "type") {
		if (body === void 0) fail("missing imported or exported type bound");
		if (atom(body[0]) === "eq") {
			const source = scope.get("type", atom(body[1]));
			return {
				...source,
				source
			};
		}
		if (atom(body[0]) === "sub" && atom(body[1]) === "resource") return {
			kind: "type",
			definition: "resource"
		};
		return fail("unsupported imported or exported type bound");
	}
	if (entityKind === "value") return { kind: entityKind };
	if (body === void 0 || atom(body[0]) !== "type") fail(`missing ${entityKind} type reference`);
	const type = scope.get(entityKind === "core-module" ? "core-type" : "type", atom(body[1]));
	const expected = entityKind === "core-module" ? "module" : entityKind;
	if (type.definition !== expected) fail(`expected ${expected} type, received ${String(type.definition)}`);
	return {
		kind: entityKind,
		definition: expected,
		shape: type.shape,
		type
	};
}
function typeDefinition(scope, form, core = false) {
	const body = optionalDescriptor(form);
	const definition = body === void 0 ? form.slice(core ? 2 : 1).map(atom).find((value) => value !== void 0 && !value.startsWith("$")) : atom(body[0]);
	const entityKind = core ? "core-type" : "type";
	if (body !== void 0 && (definition === "instance" || definition === "component")) return {
		kind: entityKind,
		definition,
		shape: project(body, new Scope(scope, void 0, true))
	};
	if (body !== void 0 && core && definition === "module") return {
		kind: entityKind,
		definition,
		shape: coreModule(body, new Scope(scope, void 0, true))
	};
	return {
		kind: entityKind,
		definition
	};
}
function alias(scope, form, core = false) {
	const target = descriptor(form);
	const targetKind = kind(target, core);
	let entry;
	if (atom(form[1]) === "outer") {
		if (![
			"type",
			"component",
			"core-type",
			"core-module"
		].includes(targetKind)) fail("invalid outer alias kind");
		entry = scope.outer(atom(form[2])).get(targetKind, atom(form[3]));
	} else if (atom(form[1]) === "export") {
		if (![
			"type",
			"func",
			"instance",
			"component",
			"value",
			"core-module"
		].includes(targetKind)) fail("invalid instance alias kind");
		entry = member(scope.get("instance", atom(form[2])), name(form), targetKind);
	} else if (atom(form[1]) === "core" && atom(form[2]) === "export") {
		if (![
			"core-func",
			"core-table",
			"core-memory",
			"core-global",
			"core-tag"
		].includes(targetKind)) fail("invalid core instance alias kind");
		entry = member(scope.get("core-instance", atom(form[3])), name(form), targetKind);
	} else return fail("unsupported printed alias");
	scope.add(targetKind, target, entry);
}
function coreTypes(scope, form) {
	for (const item of form) {
		if (!Array.isArray(item) || atom(item[0]) !== "type") continue;
		scope.add("core-type", item, typeDefinition(scope, item, true));
	}
}
/** Match imported type identities to the actual argument's exported types. */
function substitutions(expected, actual, replacements) {
	if (expected.kind !== actual.kind) fail(`instantiation argument is ${actual.kind}, expected ${expected.kind}`);
	if (expected.kind === "type") replacements.set(expected, actual);
	if (expected.kind === "instance" && expected.shape !== void 0) {
		if (actual.shape === void 0) fail("unresolved instantiation argument shape");
		for (const [key, child] of expected.shape.exports) substitutions(child, actual.shape.exports.get(key) ?? fail(`instantiation argument has no export ${key}`), replacements);
	}
}
/** Rebuild exported shapes under the instantiation's type-identity substitution. */
function substituted(definition, replacements) {
	const memo = /* @__PURE__ */ new Map();
	const resolve = (entry) => {
		const replacement = replacements.get(entry);
		if (replacement !== void 0) return replacement;
		const cached = memo.get(entry);
		if (cached !== void 0) return cached;
		const source = entry.source === void 0 ? void 0 : resolve(entry.source);
		const type = entry.type === void 0 ? void 0 : resolve(entry.type);
		const originalShape = type?.shape ?? source?.shape ?? entry.shape;
		const result = {
			kind: entry.kind,
			definition: type?.definition ?? source?.definition ?? entry.definition,
			source,
			type,
			shape: originalShape === void 0 ? void 0 : transform(originalShape)
		};
		memo.set(entry, result);
		return result;
	};
	const transform = (original) => {
		const result = new Scope();
		for (const [key, entry] of original.exports) result.exports.set(key, resolve(entry));
		for (const [key, entry] of original.imports) result.imports.set(key, resolve(entry));
		return result;
	};
	return transform(definition);
}
function instance(scope, form, core = false) {
	const entityKind = core ? "core-instance" : "instance";
	const statements = form.filter((item) => Array.isArray(item));
	const instantiate = statements.find((item) => atom(item[0]) === "instantiate");
	if (instantiate !== void 0) {
		if (statements.length !== 1) fail("ambiguous printed instance definition");
		const definition = scope.get(core ? "core-module" : "component", atom(instantiate[1])).shape ?? fail("unresolved instantiated component or module shape");
		const args = /* @__PURE__ */ new Map();
		for (const item of instantiate.slice(2)) {
			if (!Array.isArray(item) || atom(item[0]) !== "with") fail("unsupported instantiation argument");
			const target = descriptor(item);
			const entity = scope.get(kind(target, core), reference(target));
			put(args, name(item), entity);
		}
		const replacements = /* @__PURE__ */ new Map();
		for (const [key, expected] of definition.imports) {
			const actual = args.get(key);
			if (actual === void 0 || actual.kind !== expected.kind) fail(`unresolved instantiation argument ${key}`);
			substitutions(expected, actual, replacements);
		}
		for (const key of args.keys()) if (!definition.imports.has(key)) fail(`unknown instantiation argument ${key}`);
		return {
			kind: entityKind,
			shape: substituted(definition, replacements)
		};
	}
	const definition = new Scope();
	for (const item of statements) {
		if (atom(item[0]) !== "export") fail("unsupported printed instance definition");
		const target = descriptor(item);
		put(definition.exports, name(item), scope.get(kind(target, core), reference(target)));
	}
	return {
		kind: entityKind,
		shape: definition
	};
}
/** Core code is opaque; only its static export bag is needed by core aliases. */
function coreModule(form, scope) {
	const exports = [];
	for (const item of form.slice(1)) {
		if (!Array.isArray(item)) continue;
		const head = atom(item[0]);
		if (head?.startsWith("@") || head === "data" || head === "elem" || head === "start") continue;
		if (head === "import") {
			const target = descriptor(item);
			const entityKind = kind(target, true);
			const entity = { kind: entityKind };
			scope.add(entityKind, target, entity);
			const moduleName = name(item);
			if (!scope.imports.has(moduleName)) scope.imports.set(moduleName, { kind: "core-instance" });
		} else if (head === "export") exports.push(item);
		else if (head === "alias") alias(scope, item, true);
		else if (head === "rec") coreTypes(scope, item);
		else {
			const entityKind = kind(item, true);
			scope.add(entityKind, item, { kind: entityKind });
		}
	}
	for (const item of exports) {
		const target = descriptor(item);
		const entityKind = kind(target, true);
		const entity = scope.typeContext ? { kind: entityKind } : scope.get(entityKind, reference(target));
		put(scope.exports, name(item), entity);
	}
	return scope;
}
function project(form, scope) {
	for (const item of form.slice(1)) {
		if (!Array.isArray(item)) continue;
		const head = atom(item[0]);
		if (head?.startsWith("@") || head === "start") continue;
		if (head === "type") scope.add("type", item, typeDefinition(scope, item));
		else if (head === "alias") alias(scope, item);
		else if (head === "import") {
			const target = descriptor(item);
			const entry = typed(scope, target);
			scope.add(entry.kind, target, entry);
			put(scope.imports, name(item), entry);
		} else if (head === "export") {
			const targets = item.filter((entry) => Array.isArray(entry) && !atom(entry[0])?.startsWith("@"));
			const target = targets[0] ?? fail("missing printed export descriptor");
			if (targets.length > 2) fail("ambiguous printed export descriptors");
			let entry = scope.typeContext ? typed(scope, target) : scope.get(kind(target), reference(target));
			const ascription = targets[1];
			if (ascription !== void 0) {
				if (scope.typeContext) fail("unexpected type-context export ascription");
				const ascribed = typed(scope, ascription);
				if (ascribed.kind !== entry.kind) fail("export ascription kind mismatch");
				entry = ascribed;
			}
			const exported = !scope.typeContext && entry.kind === "type" ? {
				...entry,
				source: entry
			} : entry;
			scope.add(exported.kind, item, exported);
			put(scope.exports, name(item), exported);
		} else if (head === "component") {
			const definition = project(item, new Scope(scope, identifier(item)));
			scope.add("component", item, {
				kind: "component",
				shape: definition
			});
		} else if (head === "instance") scope.add("instance", item, instance(scope, item));
		else if (head === "func" || head === "value") scope.add(kind(item), item, { kind: kind(item) });
		else if (head === "core") {
			if (atom(item[1]) === "rec") {
				coreTypes(scope, item);
				continue;
			}
			const entityKind = kind(item);
			if (entityKind === "core-type") scope.add(entityKind, item, typeDefinition(scope, item, true));
			else if (entityKind === "core-module") scope.add(entityKind, item, {
				kind: entityKind,
				shape: coreModule(item, new Scope(scope, identifier(item)))
			});
			else if (entityKind === "core-instance") scope.add(entityKind, item, instance(scope, item, true));
			else scope.add(entityKind, item, { kind: entityKind });
		} else fail(`unsupported printed component declaration ${String(head)}`);
	}
	return scope;
}
/** Only the enclosing component's imports can require authority from its host. */
function requiredImports(root) {
	const scope = project(root, new Scope(void 0, identifier(root)));
	const required = [];
	for (const [key, entry] of scope.imports) if (entry.kind === "instance") for (const memberName of shape(entry, "instance").exports.keys()) required.push({
		instance: key,
		name: memberName
	});
	else if (entry.kind === "func" || entry.kind === "core-func") required.push({
		instance: void 0,
		name: key
	});
	return required.sort((left, right) => {
		if (left.instance === void 0 && right.instance !== void 0) return -1;
		if (right.instance === void 0 && left.instance !== void 0) return 1;
		return compareUtf8(left.instance ?? "", right.instance ?? "") || compareUtf8(left.name, right.name);
	});
}
//#endregion
//#region packages/guests/plugin/src/component.ts
/** Jco decodes binary bytes; the projection resolves only static import shapes. */
/** Reads every root import member, retaining names and full interface versions. */
async function readRequiredImports(bytes) {
	return requiredImports(forms(await print(new Uint8Array(bytes))));
}
//#endregion
//#region packages/guests/plugin/src/host.ts
/**
* Plugin inspection: identity and the bind-time import check.
*
* Execution on Node is `loadPlugin` in `execute.ts` (jco transpile).
* This module is the shared law those hosts must apply before instantiate:
* the binary's actual imports are a subset of the host offer, compared by
* full instance name.
*/
var REALIZATION_DOMAIN = "boundary.wasm-realization/v1";
var AUTHORITY_DOMAIN = "boundary.wasm-authority/v1";
/**
* Digests an offer: the interface it is scoped to, then every WIT name it
* grants, sorted. The interface is included in full — package and version —
* because bind already treats `footprints@1.0.0` and `@9.9.9` as different
* interfaces.
*/
function authorityDigest(offer) {
	const hash = createHash("sha256");
	hash.update(AUTHORITY_DOMAIN);
	hash.update(Buffer.from([0]));
	hash.update(offer.interface);
	for (const witName of offer.witNames()) {
		hash.update(Buffer.from([0]));
		hash.update(witName);
	}
	return `sha256:${hash.digest("hex")}`;
}
function digestOf(bytes) {
	return `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
}
function realizationId(componentDigest, witDigest, lifetime) {
	const hash = createHash("sha256");
	hash.update(REALIZATION_DOMAIN);
	hash.update(Buffer.from([0]));
	hash.update(componentDigest);
	hash.update(Buffer.from([0]));
	hash.update(witDigest);
	hash.update(Buffer.from([0]));
	hash.update(lifetime);
	return `sha256:${hash.digest("hex")}`;
}
/**
* Inspects a plugin component against a host offer.
*
* Does not instantiate. Instantiation is a later host-runtime step and
* must not run when `check.status` is `refused`.
*/
async function inspectPlugin(bytesValue, offer, witDigest, lifetime = "per-call") {
	const bytes = new Uint8Array(bytesValue);
	const capturedOffer = snapshotImportOffer(offer);
	const componentDigest = digestOf(bytes);
	const required = await readRequiredImports(bytes);
	return {
		required,
		componentDigest,
		realizationId: realizationId(componentDigest, witDigest, lifetime),
		lifetime,
		authorityDigest: authorityDigest(capturedOffer),
		check: capturedOffer.check(required)
	};
}
//#endregion
//#region packages/guests/plugin/src/execution-types.ts
function fault(reason, certainty = "not-started") {
	return {
		status: "fault",
		certainty,
		reason
	};
}
//#endregion
//#region packages/guests/plugin/src/execute.ts
/** Node plugin loading: inspect and resolve authority before worker preparation. */
function resolveHost(host, witName) {
	const claimants = [];
	let found;
	const direct = host[witName];
	if (direct !== void 0) {
		claimants.push(witName);
		found = direct;
	}
	for (const [key, fn] of Object.entries(host)) {
		if (key === witName) continue;
		const derived = witIdentifier(key);
		if (derived.ok && derived.value === witName) {
			claimants.push(key);
			found ??= fn;
		}
	}
	if (claimants.length > 1) throw new Error(`host map entries ${claimants.sort().map((name) => JSON.stringify(name)).join(", ")} all derive the WIT name ${JSON.stringify(witName)}; the host must not offer two footprints under one name`);
	return found;
}
/** The executor owns compilation, worker capacity, deadlines, and cleanup. */
async function loadPlugin(args) {
	try {
		const executor = args.executor;
		executor.assertArtifactSize(args.bytes);
		const bytes = new Uint8Array(args.bytes);
		const suppliedHost = Object.freeze(Object.assign(Object.create(null), args.host));
		const offered = args.offer.witNames();
		const inspection = await inspectPlugin(bytes, args.offer, args.witDigest, args.lifetime);
		if (inspection.check.status === "refused") return {
			status: "refused",
			unmapped: inspection.check.unmapped,
			offered: inspection.check.offered
		};
		const host = Object.create(null);
		for (const imported of inspection.required) {
			const fn = resolveHost(suppliedHost, imported.name);
			if (typeof fn !== "function") return {
				status: "refused",
				unmapped: [imported.instance === void 0 ? imported.name : `${imported.instance}#${imported.name}`],
				offered
			};
			host[imported.name] = fn;
		}
		const instance = await executor.bind(bytes, inspection, host);
		if ("status" in instance) return instance;
		return {
			status: "ready",
			inspection,
			instance
		};
	} catch (error) {
		return fault(error instanceof Error ? error.message : String(error));
	}
}
//#endregion
//#region packages/guests/plugin/src/worker-protocol.ts
var DEFAULT_EXECUTOR_LIMITS = {
	maxWorkers: 4,
	maxInstances: 64,
	maxPending: 32,
	maxArtifactBytes: 67108864,
	maxPreparedBytes: 134217728,
	maxPayloadBytes: 1048576,
	prepareTimeoutMs: 6e4,
	callTimeoutMs: 3e4
};
//#endregion
//#region packages/guests/plugin/src/executor-worker.ts
/** One artifact's queue, capability bridge, and interruptible worker lifetime. */
var WorkerSlot = class {
	digest;
	limits;
	callbacks;
	bindings = /* @__PURE__ */ new Map();
	queue = [];
	active;
	alive = true;
	ready = false;
	preparedBytes = 0;
	/** Binds admitted by the cache that have not yet registered their handle. */
	reservations = 0;
	lastUsed = performance.now();
	sequence = 0;
	worker;
	prepareTimer;
	termination;
	constructor(digest, bytes, limits, resourceLimits, callbacks) {
		this.digest = digest;
		this.limits = limits;
		this.callbacks = callbacks;
		const copy = new Uint8Array(bytes);
		this.worker = new Worker(new URL(
			/* @vite-ignore */
			new URL("assets/plugin-worker-BFAcsuMN.js", import.meta.url).href,
			"" + import.meta.url
		), {
			workerData: {
				bytes: copy,
				maxPreparedBytes: limits.maxPreparedBytes,
				maxPayloadBytes: limits.maxPayloadBytes
			},
			transferList: [copy.buffer],
			resourceLimits
		});
		this.prepareTimer = setTimeout(() => {
			this.stop("plugin preparation deadline exceeded");
		}, limits.prepareTimeoutMs);
		this.worker.on("message", (event) => this.receive(event));
		this.worker.on("error", (error) => {
			this.stop(`plugin worker failed: ${error instanceof Error ? error.message : String(error)}`);
		});
		this.worker.on("exit", (code) => {
			if (this.alive) this.stop(`plugin worker exited (${code})`);
		});
	}
	enqueue(command, options = {}) {
		if (!this.alive || !this.bindings.has(command.binding)) return Promise.resolve(fault("plugin binding is closed"));
		if (options.signal?.aborted) return Promise.resolve(fault("plugin call aborted before execution"));
		const timeout = options.timeoutMs ?? this.limits.callTimeoutMs;
		if (!Number.isSafeInteger(timeout) || timeout <= 0 || timeout > 2147483647) return Promise.resolve(fault("plugin deadline must be a positive integer no greater than 2147483647 ms"));
		return new Promise((resolve) => {
			const job = {
				command: {
					...command,
					job: ++this.sequence
				},
				resolve,
				controller: new AbortController(),
				timer: setTimeout(() => this.cancel(job, "plugin call deadline exceeded"), timeout),
				signal: options.signal,
				abort: () => this.cancel(job, "plugin call aborted")
			};
			options.signal?.addEventListener("abort", job.abort, { once: true });
			this.queue.push(job);
			this.dispatch();
		});
	}
	settle(job, result) {
		clearTimeout(job.timer);
		job.signal?.removeEventListener("abort", job.abort);
		job.resolve(result);
	}
	cancel(job, reason) {
		if (this.active === job) {
			this.stop(reason);
			return;
		}
		const index = this.queue.indexOf(job);
		if (index < 0) return;
		this.queue.splice(index, 1);
		this.settle(job, fault(reason));
	}
	dispatch() {
		if (!this.alive || !this.ready || this.active !== void 0) return;
		const next = this.queue.shift();
		if (next === void 0) return;
		this.active = next;
		this.lastUsed = performance.now();
		try {
			this.worker.postMessage(next.command);
		} catch (error) {
			this.stop(`plugin dispatch failed: ${String(error)}`);
		}
	}
	receive(event) {
		if (!this.alive) return;
		if (event.type === "prepared") {
			clearTimeout(this.prepareTimer);
			if (!this.callbacks.prepared(this, event)) {
				this.stop("prepared plugin cache exceeds its byte limit");
				return;
			}
			this.preparedBytes = event.bytes;
			this.ready = true;
			this.dispatch();
		} else if (event.type === "prepare-failed") this.stop(event.reason);
		else if (event.type === "host") this.hostCall(event);
		else if (event.type === "result") {
			const job = this.active;
			if (job === void 0 || job.command.job !== event.job) return;
			this.active = void 0;
			this.lastUsed = performance.now();
			this.callbacks.result(event);
			this.settle(job, event.outcome);
			this.dispatch();
		}
	}
	async hostCall(event) {
		const job = this.active;
		if (job === void 0 || job.command.job !== event.job || job.command.binding !== event.binding) {
			this.stop("plugin worker requested a capability outside its active invocation");
			return;
		}
		let text;
		let status = 1;
		try {
			const fn = this.bindings.get(event.binding)?.[event.name];
			if (fn === void 0) throw new Error(`plugin capability ${event.name} is unavailable`);
			const reply = await fn(event.request, { signal: job.controller.signal });
			if (typeof reply !== "string" && (reply === null || typeof reply !== "object" || ![
				"ok",
				"err",
				"unknown"
			].includes(reply.tag) || typeof reply.val !== "string")) throw new Error("plugin capability returned an invalid reply");
			text = JSON.stringify(reply);
			if (Buffer.byteLength(text) > this.limits.maxPayloadBytes) throw new Error("plugin capability reply exceeds the payload limit");
		} catch (error) {
			status = 2;
			text = error instanceof Error ? error.message : String(error);
		}
		if (!this.alive || this.active !== job) return;
		const header = new Int32Array(event.shared, 0, 2);
		const output = new Uint8Array(event.shared, 8);
		const encoded = new TextEncoder().encode(text);
		const count = Math.min(output.length, encoded.byteLength);
		output.set(encoded.subarray(0, count));
		Atomics.store(header, 1, count);
		Atomics.store(header, 0, status);
		Atomics.notify(header, 0);
	}
	async closeBinding(binding) {
		if (!this.alive) {
			await this.stop("plugin binding is closed");
			return;
		}
		if (!this.bindings.delete(binding)) return;
		if (this.active?.command.binding === binding) {
			await this.stop("plugin binding closed during execution");
			return;
		}
		for (const job of [...this.queue]) if (job.command.binding === binding) this.cancel(job, "plugin binding is closed");
		if (this.alive) this.worker.postMessage({
			type: "close",
			binding
		});
		this.lastUsed = performance.now();
	}
	stop(reason) {
		if (this.termination !== void 0) return this.termination;
		this.alive = false;
		this.termination = this.worker.terminate().then(() => void 0);
		clearTimeout(this.prepareTimer);
		const active = this.active;
		this.active = void 0;
		if (active !== void 0) {
			active.controller.abort();
			this.settle(active, fault(reason, "unknown"));
		}
		for (const job of this.queue.splice(0)) this.settle(job, fault(reason));
		this.bindings.clear();
		this.callbacks.stopped(this);
		return this.termination;
	}
};
//#endregion
//#region packages/guests/plugin/src/executor.ts
var PluginExecutor = class {
	limits;
	resourceLimits;
	slots = /* @__PURE__ */ new Map();
	retiring = /* @__PURE__ */ new Set();
	closed = false;
	bindingSequence = 0;
	closePromise;
	totals = {
		preparations: 0,
		compilations: 0,
		cacheHits: 0,
		prepareMs: 0,
		compileMs: 0,
		instantiateMs: 0,
		invokeMs: 0
	};
	constructor(options = {}) {
		const { resourceLimits, ...overrides } = options;
		const limits = {
			...DEFAULT_EXECUTOR_LIMITS,
			...overrides
		};
		for (const [name, value] of Object.entries(limits)) if (!Number.isSafeInteger(value) || value <= 0) throw new RangeError(`${name} must be a positive safe integer`);
		for (const name of ["callTimeoutMs", "prepareTimeoutMs"]) if (limits[name] > 2147483647) throw new RangeError(`${name} exceeds the maximum timer duration`);
		if (resourceLimits !== void 0) {
			for (const [name, value] of Object.entries(resourceLimits)) if (!Number.isFinite(value) || value <= 0) throw new RangeError(`${name} must be a positive finite number`);
		}
		this.limits = Object.freeze(limits);
		this.resourceLimits = resourceLimits === void 0 ? void 0 : { ...resourceLimits };
	}
	/** Validate before copying or inspecting a component supplied to this executor. */
	assertArtifactSize(bytes) {
		if (bytes.byteLength > this.limits.maxArtifactBytes) throw new RangeError("plugin artifact exceeds the byte limit");
	}
	stats() {
		const slots = [...this.slots.values()];
		return {
			...this.totals,
			workers: slots.length + this.retiring.size,
			instances: slots.reduce((sum, slot) => sum + slot.bindings.size, 0),
			pending: slots.reduce((sum, slot) => sum + slot.queue.length, 0),
			active: slots.filter((slot) => slot.active !== void 0).length,
			preparedBytes: slots.reduce((sum, slot) => sum + slot.preparedBytes, 0)
		};
	}
	hasCapacity() {
		const stats = this.stats();
		return stats.pending + stats.active < this.limits.maxPending;
	}
	async artifact(bytes, digest) {
		if (this.closed) return fault("plugin executor is closed");
		const cached = this.slots.get(digest);
		if (cached !== void 0) {
			this.totals.cacheHits++;
			cached.reservations++;
			return cached;
		}
		if (this.slots.size + this.retiring.size >= this.limits.maxWorkers) {
			const idle = [...this.slots.values()].filter((slot) => slot.bindings.size === 0 && slot.reservations === 0 && slot.active === void 0 && slot.queue.length === 0).sort((a, b) => a.lastUsed - b.lastUsed)[0];
			if (idle === void 0) return fault("plugin executor worker capacity is exhausted");
			await idle.stop("idle plugin artifact evicted");
			return this.artifact(bytes, digest);
		}
		try {
			this.totals.preparations++;
			const slot = new WorkerSlot(digest, bytes, this.limits, this.resourceLimits, {
				prepared: (_slot, event) => {
					this.totals.compilations += event.modules;
					this.totals.prepareMs += event.prepareMs;
					this.totals.compileMs += event.compileMs;
					return this.stats().preparedBytes + event.bytes <= this.limits.maxPreparedBytes;
				},
				result: (event) => {
					this.totals.instantiateMs += event.instantiateMs;
					this.totals.invokeMs += event.invokeMs;
				},
				stopped: (stopped) => {
					if (this.slots.get(digest) === stopped) this.slots.delete(digest);
					this.retiring.add(stopped);
					stopped.stop("plugin worker stopped").finally(() => this.retiring.delete(stopped));
				}
			});
			this.slots.set(digest, slot);
			slot.reservations++;
			return slot;
		} catch (error) {
			return fault(`plugin worker could not start: ${error instanceof Error ? error.message : String(error)}`);
		}
	}
	async bind(bytes, inspection, host) {
		try {
			this.assertArtifactSize(bytes);
		} catch (error) {
			return fault(error instanceof Error ? error.message : String(error));
		}
		if (this.closed) return fault("plugin executor is closed");
		if (inspection.check.status !== "satisfied") return fault("plugin inspection did not admit the artifact");
		if (this.stats().instances >= this.limits.maxInstances) return fault("plugin executor instance capacity is exhausted");
		if (!this.hasCapacity()) return fault("plugin executor queue capacity is exhausted");
		const slot = await this.artifact(bytes, inspection.componentDigest);
		if (!(slot instanceof WorkerSlot)) return slot;
		slot.reservations--;
		if (this.closed || !slot.alive) return fault("plugin executor is closed");
		if (this.stats().instances >= this.limits.maxInstances) return fault("plugin executor instance capacity is exhausted");
		if (!this.hasCapacity()) return fault("plugin executor queue capacity is exhausted");
		const id = ++this.bindingSequence;
		slot.bindings.set(id, Object.freeze({ ...host }));
		const outcome = await slot.enqueue({
			type: "bind",
			binding: id,
			required: inspection.required,
			lifetime: inspection.lifetime
		}, { timeoutMs: this.limits.prepareTimeoutMs });
		if (outcome.status === "fault") {
			await slot.closeBinding(id);
			return outcome;
		}
		if (!slot.alive || !slot.bindings.has(id)) return fault("plugin binding closed before admission completed", "unknown");
		return {
			call: async (name, input, options) => {
				if (this.closed || !slot.alive || !slot.bindings.has(id)) return fault("plugin binding is closed");
				if (typeof input !== "string" || Buffer.byteLength(input) > this.limits.maxPayloadBytes) return fault("plugin input exceeds the payload limit");
				if (!this.hasCapacity()) return fault("plugin executor queue capacity is exhausted");
				return slot.enqueue({
					type: "call",
					binding: id,
					name,
					input
				}, options);
			},
			close: () => slot.closeBinding(id)
		};
	}
	close() {
		if (this.closePromise !== void 0) return this.closePromise;
		this.closed = true;
		this.closePromise = Promise.all([.../* @__PURE__ */ new Set([...this.slots.values(), ...this.retiring])].map((slot) => slot.stop("plugin executor is closed"))).then(() => void 0);
		return this.closePromise;
	}
};
function createPluginExecutor(options) {
	return new PluginExecutor(options);
}
//#endregion
export { DEFAULT_WIT_PROJECTION_OPTIONS, ImportOffer, NameError, PluginExecutor, WitProjectionError, authorityDigest, createPluginExecutor, inspectPlugin, loadPlugin, projectWit, qualifiedImport, readRequiredImports, witIdentifier };
