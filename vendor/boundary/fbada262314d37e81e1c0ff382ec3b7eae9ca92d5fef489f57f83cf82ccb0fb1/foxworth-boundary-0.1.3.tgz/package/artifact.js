import { canonicalJson, compareUtf8, contractChanges, normalizeJson } from "@foxworth/boundary/program";
import path from "node:path";
import { readFile, readdir, rm, stat, writeFile } from "node:fs/promises";
import { createHash } from "node:crypto";
//#region packages/core/artifact/src/integrity.ts
var CONTENT_MANIFEST_VERSION = 1;
var CONTENT_MANIFEST_FILE = "boundary-artifact.json";
var PACK_RECEIPT_VERSION = 1;
var PACK_RECEIPT_SUFFIX = ".receipt.json";
var SHA256_PATTERN = /^sha256:[0-9a-f]{64}$/u;
var CONTENT_DOMAIN = "boundary.package-content/v1\0";
function sha256(bytes) {
	return `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
}
function compareUtf8$1(left, right) {
	return Buffer.compare(Buffer.from(left, "utf8"), Buffer.from(right, "utf8"));
}
function fail$2(message) {
	throw new Error(`Invalid Boundary package artifact: ${message}`);
}
function exactObject$1(value, keys, pathName) {
	if (!value || typeof value !== "object" || Array.isArray(value)) fail$2(`${pathName} must be an object`);
	const actual = Object.keys(value).sort(compareUtf8$1);
	const expected = [...keys].sort(compareUtf8$1);
	if (actual.length !== expected.length || actual.some((key, index) => key !== expected[index])) fail$2(`${pathName} must contain exactly ${expected.join(", ")}`);
	return value;
}
function packageIdentity(value, pathName) {
	const identity = exactObject$1(value, ["name", "version"], pathName);
	if (typeof identity.name !== "string" || !identity.name.trim()) fail$2(`${pathName}.name must be a non-empty string`);
	if (typeof identity.version !== "string" || !identity.version.trim()) fail$2(`${pathName}.version must be a non-empty string`);
	return {
		name: identity.name,
		version: identity.version
	};
}
function portablePath(value, pathName) {
	if (typeof value !== "string" || !value || value === "boundary-artifact.json" || value.includes("\\") || value.includes("\0") || path.posix.isAbsolute(value) || value.split("/").some((piece) => piece === "" || piece === "." || piece === "..")) fail$2(`${pathName} must be a safe relative UTF-8 path`);
	return value;
}
function digest(value, pathName) {
	if (typeof value !== "string" || !SHA256_PATTERN.test(value)) fail$2(`${pathName} must be sha256:<64 lowercase hex>`);
	return value;
}
function contentPayload({ package: packageValue, files }) {
	return Buffer.from(`${CONTENT_DOMAIN}${JSON.stringify({
		version: 1,
		algorithm: "sha256",
		package: packageValue,
		files
	})}`, "utf8");
}
async function filesBelow(root, directory = root) {
	const files = [];
	for (const entry of await readdir(directory, { withFileTypes: true })) {
		if (directory === root && entry.name === "node_modules") continue;
		if (directory === root && (entry.name.endsWith(".tgz") || entry.name.endsWith(`.tgz.receipt.json`))) continue;
		const file = path.join(directory, entry.name);
		if (entry.isSymbolicLink()) fail$2(`package content must not contain a symbolic link: ${path.relative(root, file)}`);
		if (entry.isDirectory()) files.push(...await filesBelow(root, file));
		else if (entry.isFile()) {
			const relative = path.relative(root, file).split(path.sep).join("/");
			if (relative !== "boundary-artifact.json") files.push(relative);
		} else fail$2(`package content must contain only files and directories: ${path.relative(root, file)}`);
	}
	return files.sort(compareUtf8$1);
}
function parseContentManifest(value) {
	const manifest = exactObject$1(value, [
		"version",
		"algorithm",
		"package",
		"files",
		"aggregateDigest"
	], CONTENT_MANIFEST_FILE);
	if (manifest.version !== 1) fail$2(`${CONTENT_MANIFEST_FILE}.version must be 1`);
	if (manifest.algorithm !== "sha256") fail$2(`${CONTENT_MANIFEST_FILE}.algorithm must be sha256`);
	const packageValue = packageIdentity(manifest.package, `${CONTENT_MANIFEST_FILE}.package`);
	if (!Array.isArray(manifest.files)) fail$2(`${CONTENT_MANIFEST_FILE}.files must be an array`);
	const seen = /* @__PURE__ */ new Set();
	let previousPath;
	const files = manifest.files.map((candidate, index) => {
		const entry = exactObject$1(candidate, [
			"path",
			"bytes",
			"sha256"
		], `${CONTENT_MANIFEST_FILE}.files[${index}]`);
		const relative = portablePath(entry.path, `${CONTENT_MANIFEST_FILE}.files[${index}].path`);
		if (seen.has(relative)) fail$2(`duplicate package path: ${relative}`);
		if (previousPath !== void 0 && compareUtf8$1(previousPath, relative) >= 0) fail$2(`${CONTENT_MANIFEST_FILE}.files must be UTF-8 sorted`);
		previousPath = relative;
		seen.add(relative);
		if (!Number.isSafeInteger(entry.bytes) || Number(entry.bytes) < 0) fail$2(`${CONTENT_MANIFEST_FILE}.files[${index}].bytes must be a non-negative safe integer`);
		return {
			path: relative,
			bytes: entry.bytes,
			sha256: digest(entry.sha256, `${CONTENT_MANIFEST_FILE}.files[${index}].sha256`)
		};
	});
	const aggregateDigest = digest(manifest.aggregateDigest, `${CONTENT_MANIFEST_FILE}.aggregateDigest`);
	if (sha256(contentPayload({
		package: packageValue,
		files
	})) !== aggregateDigest) fail$2(`${CONTENT_MANIFEST_FILE}.aggregateDigest does not match its content list`);
	return {
		version: 1,
		algorithm: "sha256",
		package: packageValue,
		files,
		aggregateDigest
	};
}
async function readContentManifest(root) {
	let value;
	try {
		value = JSON.parse(await readFile(path.join(root, CONTENT_MANIFEST_FILE), "utf8"));
	} catch {
		fail$2(`${CONTENT_MANIFEST_FILE} is missing or is not valid JSON`);
	}
	return parseContentManifest(value);
}
async function writeContentManifest(root, packageValue) {
	await rm(path.join(root, CONTENT_MANIFEST_FILE), { force: true });
	const identity = packageIdentity(packageValue, "package");
	const files = [];
	for (const relative of await filesBelow(root)) {
		const bytes = await readFile(path.join(root, relative));
		files.push({
			path: relative,
			bytes: bytes.byteLength,
			sha256: sha256(bytes)
		});
	}
	const manifest = {
		version: 1,
		algorithm: "sha256",
		package: identity,
		files,
		aggregateDigest: sha256(contentPayload({
			package: identity,
			files
		}))
	};
	await writeFile(path.join(root, CONTENT_MANIFEST_FILE), `${JSON.stringify(manifest, null, 2)}\n`);
	return manifest;
}
async function verifyContentManifest(root, expected = {}) {
	const manifest = await readContentManifest(root);
	if (expected.name !== void 0 && manifest.package.name !== expected.name) fail$2(`package name is ${manifest.package.name}, expected ${expected.name}`);
	if (expected.version !== void 0 && manifest.package.version !== expected.version) fail$2(`package version is ${manifest.package.version}, expected ${expected.version}`);
	if (expected.aggregateDigest !== void 0 && manifest.aggregateDigest !== expected.aggregateDigest) fail$2("content aggregate digest does not match the receipt");
	const actualPaths = await filesBelow(root);
	const expectedPaths = manifest.files.map((entry) => entry.path);
	if (actualPaths.length !== expectedPaths.length || actualPaths.some((value, index) => value !== expectedPaths[index])) fail$2("package file set does not match the content manifest");
	for (const entry of manifest.files) {
		const bytes = await readFile(path.join(root, entry.path));
		if (bytes.byteLength !== entry.bytes || sha256(bytes) !== entry.sha256) fail$2(`package file does not match the content manifest: ${entry.path}`);
	}
	return manifest;
}
async function writePackReceipt(options) {
	const { tarballPath, packageName, packageVersion, contentDigest } = options;
	const filename = path.basename(tarballPath);
	const bytes = await readFile(tarballPath);
	const receipt = {
		version: 1,
		algorithm: "sha256",
		package: {
			name: packageName,
			version: packageVersion
		},
		tarball: {
			filename,
			bytes: bytes.byteLength,
			sha256: sha256(bytes)
		},
		contentDigest: digest(contentDigest, "receipt.contentDigest")
	};
	const receiptPath = `${tarballPath}${PACK_RECEIPT_SUFFIX}`;
	await writeFile(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`);
	return {
		receipt,
		receiptPath
	};
}
function parsePackReceipt(value) {
	const receipt = exactObject$1(value, [
		"version",
		"algorithm",
		"package",
		"tarball",
		"contentDigest"
	], "receipt");
	if (receipt.version !== 1) fail$2(`receipt.version must be 1`);
	if (receipt.algorithm !== "sha256") fail$2("receipt.algorithm must be sha256");
	const packageValue = packageIdentity(receipt.package, "receipt.package");
	const tarball = exactObject$1(receipt.tarball, [
		"filename",
		"bytes",
		"sha256"
	], "receipt.tarball");
	if (typeof tarball.filename !== "string" || !tarball.filename.endsWith(".tgz") || path.basename(tarball.filename) !== tarball.filename) fail$2("receipt.tarball.filename must name one adjacent .tgz file");
	if (!Number.isSafeInteger(tarball.bytes) || Number(tarball.bytes) < 0) fail$2("receipt.tarball.bytes must be a non-negative safe integer");
	const expectedFilename = `${packageValue.name.replace(/^@/u, "").replaceAll("/", "-")}-${packageValue.version}.tgz`;
	if (tarball.filename !== expectedFilename) fail$2(`receipt.tarball.filename must be ${expectedFilename}`);
	return {
		version: 1,
		algorithm: "sha256",
		package: packageValue,
		tarball: {
			filename: tarball.filename,
			bytes: tarball.bytes,
			sha256: digest(tarball.sha256, "receipt.tarball.sha256")
		},
		contentDigest: digest(receipt.contentDigest, "receipt.contentDigest")
	};
}
async function verifyPackReceipt(receiptPath, expected = {}) {
	let value;
	try {
		value = JSON.parse(await readFile(receiptPath, "utf8"));
	} catch {
		fail$2("receipt is missing or is not valid JSON");
	}
	const receipt = parsePackReceipt(value);
	if (path.basename(receiptPath) !== `${receipt.tarball.filename}.receipt.json`) fail$2("receipt filename must identify its adjacent tarball");
	if (expected.name !== void 0 && receipt.package.name !== expected.name) fail$2(`receipt package name is ${receipt.package.name}, expected ${expected.name}`);
	if (expected.version !== void 0 && receipt.package.version !== expected.version) fail$2(`receipt package version is ${receipt.package.version}, expected ${expected.version}`);
	const tarballPath = path.join(path.dirname(receiptPath), receipt.tarball.filename);
	let metadata;
	try {
		metadata = await stat(tarballPath);
	} catch {
		fail$2("the tarball named by the receipt is missing");
	}
	if (!metadata.isFile() || metadata.size !== receipt.tarball.bytes) fail$2("tarball byte length does not match the receipt");
	if (sha256(await readFile(tarballPath)) !== receipt.tarball.sha256) fail$2("tarball SHA-256 does not match the receipt");
	return {
		receipt,
		tarballPath
	};
}
//#endregion
//#region packages/core/artifact/src/metadata.ts
function freezeArtifact(value) {
	if (value !== null && typeof value === "object") {
		for (const child of Object.values(value)) freezeArtifact(child);
		Object.freeze(value);
	}
	return value;
}
function fail$1(message) {
	throw new Error(`Invalid Boundary package metadata: ${message}`);
}
function isObject(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}
function object(value, label) {
	if (!isObject(value)) fail$1(`${label} must be an object`);
	return value;
}
function exportTarget(value) {
	if (value === null) return;
	if (typeof value === "string") {
		if (!value.startsWith("./") || value.includes("\\") || value.includes("\0") || value.slice(2).split("/").some((part) => part === "." || part === ".." || part === "")) fail$1("exports targets must be package-relative paths");
		return;
	}
	if (Array.isArray(value)) {
		value.forEach(exportTarget);
		return;
	}
	for (const target of Object.values(object(value, "exports target"))) exportTarget(target);
}
function exportsOf(value) {
	if (value === void 0) return {};
	if (value === null || typeof value === "string" || Array.isArray(value)) {
		exportTarget(value);
		return { ".": value };
	}
	const fields = object(value, "exports");
	const keys = Object.keys(fields);
	const subpaths = keys.filter((key) => key.startsWith("."));
	if (subpaths.length !== 0 && subpaths.length !== keys.length) fail$1("exports must not mix subpath and condition keys");
	if (keys.length !== 0 && subpaths.length === 0) {
		exportTarget(fields);
		return { ".": fields };
	}
	const result = {};
	for (const key of keys.sort(compareUtf8)) {
		if (key !== "." && (!key.startsWith("./") || key.includes("\\") || key.slice(2).split("/").some((part) => part === "." || part === ".." || part === ""))) fail$1(`invalid export subpath: ${key}`);
		exportTarget(fields[key]);
		Object.defineProperty(result, key, {
			value: fields[key],
			enumerable: true
		});
	}
	return result;
}
function hasExportTarget(value) {
	if (typeof value === "string") return true;
	if (value === void 0 || value === null) return false;
	if (Array.isArray(value)) return value.some(hasExportTarget);
	return Object.values(object(value, "exports target")).some(hasExportTarget);
}
function requiredExportNames(values) {
	if (!Array.isArray(values)) fail$1("requiredExports must be an array");
	const result = /* @__PURE__ */ new Set();
	for (const value of values) {
		if (typeof value !== "string" || value !== "." && !value.startsWith("./") || value.includes("*") || value.includes("\\") || value.includes("\0") || value !== "." && value.slice(2).split("/").some((part) => !part || part === "." || part === "..")) fail$1("requiredExports must contain explicit package export names such as . or ./program");
		result.add(value);
	}
	return Object.freeze([...result].sort(compareUtf8));
}
async function readArtifactMetadata(root, content) {
	const entry = content.files.find((file) => file.path === "package.json");
	if (!entry) fail$1("the verified content must include package.json");
	const bytes = await readFile(path.join(root, "package.json"));
	const hash = `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
	if (bytes.byteLength !== entry.bytes || hash !== entry.sha256) fail$1("package.json changed after content verification");
	let value;
	try {
		value = normalizeJson(JSON.parse(new TextDecoder().decode(bytes)));
	} catch {
		fail$1("package.json must contain valid JSON");
	}
	const manifest = object(value, "package.json");
	if (manifest.name !== content.package.name || manifest.version !== content.package.version) fail$1("package.json identity does not match the verified content manifest");
	const engines = {};
	for (const [runtime, requirement] of Object.entries(manifest.engines === void 0 ? {} : object(manifest.engines, "engines")).sort(([left], [right]) => compareUtf8(left, right))) {
		if (typeof requirement !== "string" || requirement.trim().length === 0) fail$1(`engines.${runtime} must be a non-empty runtime requirement`);
		Object.defineProperty(engines, runtime, {
			value: requirement,
			enumerable: true
		});
	}
	return freezeArtifact({
		exports: exportsOf(manifest.exports),
		engines
	});
}
//#endregion
//#region packages/core/artifact/src/comparison.ts
function fail(message) {
	throw new Error(`Invalid Boundary artifact comparison: ${message}`);
}
async function verifySource(source) {
	if (!source || typeof source !== "object" || typeof source.root !== "string" || source.root.trim().length === 0) fail("each source requires an explicit package root");
	if (source.expected?.tarballDigest !== void 0 && source.receiptPath === void 0) fail("an expected tarball digest requires an explicit receiptPath");
	const packed = source.receiptPath === void 0 ? void 0 : await verifyPackReceipt(source.receiptPath, {
		name: source.expected?.name,
		version: source.expected?.version
	});
	if (packed && source.expected?.tarballDigest !== void 0 && packed.receipt.tarball.sha256 !== source.expected.tarballDigest) fail("tarball digest does not match the reviewed expected pin");
	const content = await verifyContentManifest(source.root, source.expected);
	if (packed && (packed.receipt.package.name !== content.package.name || packed.receipt.package.version !== content.package.version || packed.receipt.contentDigest !== content.aggregateDigest)) fail("the verified receipt does not identify the verified package content");
	const metadata = await readArtifactMetadata(source.root, content);
	return freezeArtifact({
		root: source.root,
		content,
		metadata,
		...packed === void 0 ? {} : { receipt: packed.receipt }
	});
}
function memberDiff(before, after) {
	const result = {
		added: [],
		removed: [],
		changed: [],
		unchanged: []
	};
	for (const name of [.../* @__PURE__ */ new Set([...before.keys(), ...after.keys()])].sort(compareUtf8)) if (!before.has(name)) result.added.push(name);
	else if (!after.has(name)) result.removed.push(name);
	else if (before.get(name) !== after.get(name)) result.changed.push(name);
	else result.unchanged.push(name);
	return result;
}
function metadataEntries(values) {
	return new Map(Object.entries(values).map(([name, value]) => [name, canonicalJson(value)]));
}
/**
* Read-only verification and comparison of explicit artifacts. Integrity checks
* fail closed; differences are reported for host review, never installed or
* treated as signing, publisher authentication, or realization equivalence.
*/
async function comparePackageArtifacts(options) {
	if (!options || typeof options !== "object") fail("options are required");
	const required = requiredExportNames(options.requiredExports ?? []);
	if (options.contracts !== void 0 && !Array.isArray(options.contracts)) fail("contracts must be an explicit list of before/after declarations");
	const before = await verifySource(options.before);
	const after = await verifySource(options.after);
	const sameName = before.content.package.name === after.content.package.name;
	const sameVersion = before.content.package.version === after.content.package.version;
	const sameContent = before.content.aggregateDigest === after.content.aggregateDigest;
	const deltas = (options.contracts ?? []).map((pair) => ({
		beforeId: pair.before.id,
		afterId: pair.after.id,
		delta: contractChanges(pair.before, pair.after)
	})).sort((left, right) => compareUtf8(left.beforeId, right.beforeId) || compareUtf8(left.afterId, right.afterId));
	return freezeArtifact({
		version: 1,
		before,
		after,
		identity: {
			sameName,
			sameVersion,
			sameContent,
			sameTarball: before.receipt === void 0 || after.receipt === void 0 ? null : before.receipt.tarball.sha256 === after.receipt.tarball.sha256,
			versionReusedWithDifferentContent: sameName && sameVersion && !sameContent
		},
		files: memberDiff(new Map(before.content.files.map((file) => [file.path, `${file.bytes}:${file.sha256}`])), new Map(after.content.files.map((file) => [file.path, `${file.bytes}:${file.sha256}`]))),
		exports: {
			...memberDiff(metadataEntries(before.metadata.exports), metadataEntries(after.metadata.exports)),
			required,
			missingBefore: required.filter((name) => !hasExportTarget(before.metadata.exports[name])),
			missingAfter: required.filter((name) => !hasExportTarget(after.metadata.exports[name]))
		},
		runtimes: memberDiff(metadataEntries(before.metadata.engines), metadataEntries(after.metadata.engines)),
		contracts: {
			source: "caller-supplied",
			deltas
		}
	});
}
//#endregion
export { CONTENT_MANIFEST_FILE, CONTENT_MANIFEST_VERSION, PACK_RECEIPT_SUFFIX, PACK_RECEIPT_VERSION, comparePackageArtifacts, readContentManifest, verifyContentManifest, verifyPackReceipt, writeContentManifest, writePackReceipt };
