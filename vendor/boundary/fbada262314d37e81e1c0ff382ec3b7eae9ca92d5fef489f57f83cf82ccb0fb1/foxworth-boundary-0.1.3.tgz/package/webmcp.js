import { BoundaryErrorBase } from "@foxworth/boundary/program";
import { RemoteInvocationError, compileBindingResolution, interactionKey, modeForHandle, snapshotProjectedHandle } from "@foxworth/boundary/handoff/adapter";
import { createCheckedHandoff, createHandoffInvocation, validateHandoffResponse, validateProjectionBindingManifest } from "@foxworth/boundary/handoff";
//#region packages/callers/webmcp/src/errors.ts
var WebMcpError = class extends BoundaryErrorBase {
	constructor(code, path, message) {
		super(code, path, message);
		this.name = "WebMcpError";
	}
};
//#endregion
//#region packages/callers/webmcp/src/host.ts
function documentModelContext() {
	const candidate = globalThis.document?.modelContext;
	if (candidate && typeof candidate.registerTool === "function") return candidate;
}
/** True when the current document exposes the WebMCP imperative API. Never throws. */
function isWebMcpAvailable(port) {
	const resolved = port ?? documentModelContext();
	return Boolean(resolved && typeof resolved.registerTool === "function");
}
function resolveModelContext(port) {
	return port ?? documentModelContext();
}
//#endregion
//#region packages/callers/webmcp/src/schema.ts
var SAFE_ANNOTATION_KEYS = /* @__PURE__ */ new Set([
	"title",
	"description",
	"examples",
	"deprecated",
	"readOnly",
	"writeOnly"
]);
function isPlainObject(value) {
	return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}
function snapshot(value) {
	return JSON.parse(JSON.stringify(value));
}
/** Recursively overlay safe JSON Schema annotations. Drops `role` and `control`. */
function overlayInputSchema(contract, annotations) {
	if (!isPlainObject(contract)) return snapshot(contract);
	const result = {};
	for (const [key, value] of Object.entries(contract)) result[key] = snapshot(value);
	if (!isPlainObject(annotations)) return result;
	for (const key of SAFE_ANNOTATION_KEYS) if (key in annotations && annotations[key] !== void 0) result[key] = snapshot(annotations[key]);
	if (isPlainObject(contract.properties)) {
		const annotationProperties = isPlainObject(annotations.properties) ? annotations.properties : {};
		result.properties = Object.fromEntries(Object.entries(contract.properties).map(([name, schema]) => [name, overlayInputSchema(schema, annotationProperties[name])]));
	}
	if ("items" in contract && contract.items !== void 0) result.items = overlayInputSchema(contract.items, isPlainObject(annotations) ? annotations.items : void 0);
	if (isPlainObject(contract.additionalProperties)) result.additionalProperties = overlayInputSchema(contract.additionalProperties, isPlainObject(annotations.additionalProperties) ? annotations.additionalProperties : void 0);
	return result;
}
function isObjectInputSchema(schema) {
	return isPlainObject(schema) && schema.type === "object";
}
function stableJson(value) {
	return JSON.stringify(value);
}
//#endregion
//#region packages/callers/webmcp/src/register.ts
var TOOL_NAME = /^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/u;
var NEVER_ABORTED = new AbortController().signal;
var toolDeclarations = /* @__PURE__ */ new WeakSet();
function fail(code, path, message) {
	throw new WebMcpError(code, path, message);
}
function snapshotExposedTo(origins, path) {
	if (origins === void 0) return void 0;
	if (!Array.isArray(origins)) fail("INVALID_TOOL", path, "exposedTo must be an array of origin strings");
	return Object.freeze(origins.map((origin, index) => {
		if (typeof origin !== "string" || !origin.trim()) fail("INVALID_TOOL", `${path}[${index}]`, "exposedTo entries must be non-empty origin strings");
		return origin.trim();
	}));
}
function webMcpTool(handleValue, options = {}) {
	const handle = snapshotProjectedHandle(handleValue, "webMcpTool.handle");
	const mode = modeForHandle(handle, options.mode, "webMcpTool.mode");
	for (const [key, value] of [
		["name", options.name],
		["title", options.title],
		["description", options.description]
	]) if (value !== void 0 && !value.trim()) fail("INVALID_TOOL", `webMcpTool.${key}`, `${key} must not be empty`);
	for (const [key, value] of [
		["consequentialHint", options.consequentialHint],
		["debugging", options.debugging],
		["untrustedContentHint", options.untrustedContentHint]
	]) if (value !== void 0 && typeof value !== "boolean") fail("INVALID_TOOL", `webMcpTool.${key}`, `${key} must be a boolean`);
	const exposedTo = snapshotExposedTo(options.exposedTo, "webMcpTool.exposedTo");
	const declaration = Object.freeze({
		handle,
		mode,
		...options.name === void 0 ? {} : { name: options.name },
		...options.title === void 0 ? {} : { title: options.title },
		...options.description === void 0 ? {} : { description: options.description },
		...options.consequentialHint === void 0 ? {} : { consequentialHint: options.consequentialHint },
		...options.debugging === void 0 ? {} : { debugging: options.debugging },
		...options.untrustedContentHint === void 0 ? {} : { untrustedContentHint: options.untrustedContentHint },
		...exposedTo === void 0 ? {} : { exposedTo }
	});
	toolDeclarations.add(declaration);
	return declaration;
}
/** One WebMCP tool per projected handle. Optional extras are keyed by alias. */
function webMcpTools(projection, extras = {}) {
	return Object.entries(projection.handles).map(([alias, handle]) => webMcpTool(handle, extras[alias] ?? {}));
}
function inputAnnotations(descriptor) {
	const annotations = descriptor.annotations;
	if (annotations === void 0 || annotations === null || typeof annotations !== "object" || Array.isArray(annotations)) return;
	const schemas = annotations.schemas;
	if (schemas === void 0 || schemas === null || typeof schemas !== "object" || Array.isArray(schemas)) return;
	return schemas.input;
}
function isBindingSync(options) {
	return "binding" in options;
}
async function handoffFromTransport(transport) {
	if (!transport || typeof transport.inspect !== "function" || typeof transport.invoke !== "function") fail("INVALID_TOOL", "transport", "transport must provide inspect() and invoke()");
	let inspected;
	try {
		inspected = await transport.inspect();
	} catch {
		fail("INVALID_TOOL", "transport.inspect", "the Binding handshake failed");
	}
	const manifest = await validateProjectionBindingManifest(inspected);
	return Object.freeze({
		manifest,
		async invoke(invocation, _context, framing) {
			let outcome;
			try {
				outcome = await transport.invoke(invocation, framing);
			} catch {
				throw new RemoteInvocationError("transport", "the remote request may have started but no outcome was received");
			}
			try {
				return await validateHandoffResponse(manifest, invocation, outcome);
			} catch {
				throw new RemoteInvocationError("response", "the remote response is invalid; its consequence is unknown");
			}
		}
	});
}
async function prepareCatalog(syncOptions) {
	for (const [index, declaration] of syncOptions.tools.entries()) if (!toolDeclarations.has(declaration)) fail("INVALID_TOOL", `tools[${index}]`, "tools must be created by webMcpTool()");
	const handoff = isBindingSync(syncOptions) ? await createCheckedHandoff(syncOptions.binding) : await handoffFromTransport(syncOptions.transport);
	const compiled = await compileBindingResolution(handoff, syncOptions.tools.map((declaration) => ({
		handle: declaration.handle,
		mode: declaration.mode
	})));
	const prepared = [];
	const names = /* @__PURE__ */ new Set();
	for (const [index, declaration] of syncOptions.tools.entries()) {
		const interactionId = declaration.handle.interactionId;
		const resolution = compiled.interactions.get(interactionKey(interactionId, declaration.mode));
		const name = declaration.name ?? interactionId;
		const path = `tools[${index}]`;
		if (!TOOL_NAME.test(name)) fail("INVALID_TOOL", `${path}.name`, declaration.name === void 0 ? "interaction ID is not a valid WebMCP tool name; supply webMcpTool({ name })" : "tool name must start with a letter or digit and contain only letters, digits, dot, dash, or underscore");
		if (names.has(name)) fail("DUPLICATE_NAME", `${path}.name`, `duplicate WebMCP tool name: ${name}`);
		names.add(name);
		const description = declaration.description ?? resolution.expected.docs.description ?? resolution.expected.docs.summary;
		if (typeof description !== "string" || !description.trim()) fail("INVALID_TOOL", `${path}.description`, "tool description is required (declaration, interaction description, or summary)");
		const inputSchema = overlayInputSchema(resolution.handle.inputArity === 0 ? {
			type: "object",
			properties: {},
			additionalProperties: false
		} : resolution.expected.contract.inputSchema, inputAnnotations(resolution.expected));
		if (!isObjectInputSchema(inputSchema)) fail("INVALID_TOOL", `${path}.inputSchema`, "WebMCP tools require an object-shaped one-input contract");
		const readOnlyHint = resolution.expected.contract.changes.length === 0;
		const consequentialHint = declaration.consequentialHint ?? (resolution.mode === "direct" && !readOnlyHint);
		const summary = Object.freeze({
			interactionId,
			name,
			...declaration.title === void 0 ? {} : { title: declaration.title },
			description,
			mode: resolution.mode,
			readOnlyHint,
			consequentialHint,
			...declaration.debugging === void 0 ? {} : { debugging: declaration.debugging },
			...declaration.untrustedContentHint === void 0 ? {} : { untrustedContentHint: declaration.untrustedContentHint },
			...declaration.exposedTo === void 0 ? {} : { exposedTo: declaration.exposedTo }
		});
		const identity = stableJson({
			name,
			contractDigest: resolution.binding.expectedContractDigest,
			mode: resolution.mode,
			inputSchema,
			exposedTo: declaration.exposedTo ?? null,
			title: declaration.title ?? null,
			description,
			consequentialHint,
			debugging: declaration.debugging ?? null,
			untrustedContentHint: declaration.untrustedContentHint ?? null
		});
		prepared.push(Object.freeze({
			interactionId,
			name,
			...declaration.title === void 0 ? {} : { title: declaration.title },
			description,
			readOnlyHint,
			consequentialHint,
			...declaration.debugging === void 0 ? {} : { debugging: declaration.debugging },
			...declaration.untrustedContentHint === void 0 ? {} : { untrustedContentHint: declaration.untrustedContentHint },
			...declaration.exposedTo === void 0 ? {} : { exposedTo: declaration.exposedTo },
			mode: resolution.mode,
			inputArity: resolution.handle.inputArity,
			inputSchema,
			identity,
			summary,
			handoff,
			manifest: compiled.manifest,
			resolution
		}));
	}
	return prepared;
}
function hostNameConflict(error) {
	if (!error || typeof error !== "object") return false;
	const name = "name" in error ? String(error.name) : "";
	const message = error instanceof Error ? error.message : String(error);
	return name === "InvalidStateError" || /already (registered|exists)|duplicate/iu.test(message);
}
function failureOutcome(prepared, certainty, cause) {
	return Object.freeze({
		version: 1,
		bindingDigest: prepared.manifest.bindingDigest,
		installationId: prepared.manifest.installationId,
		interactionId: prepared.resolution.binding.interactionId,
		expectedContractDigest: prepared.resolution.binding.expectedContractDigest,
		actualContractDigest: prepared.resolution.binding.actualContractDigest,
		mode: prepared.resolution.binding.mode,
		realizationId: prepared.resolution.binding.realizationId,
		certainty,
		result: Object.freeze({
			kind: "fault",
			cause
		})
	});
}
async function executeTool(live, context, input, signal, frame, claims) {
	const invocationSignal = signal ?? NEVER_ABORTED;
	const prepared = live.prepared;
	if (invocationSignal.aborted) return failureOutcome(prepared, "not-started", "invalid-invocation");
	let invocation;
	try {
		invocation = await createHandoffInvocation(prepared.manifest, prepared.interactionId, prepared.mode, prepared.inputArity === 0 ? null : input);
	} catch {
		return failureOutcome(prepared, "not-started", "invalid-input");
	}
	const request = Object.freeze({
		interactionId: prepared.interactionId,
		mode: prepared.mode,
		signal: invocationSignal,
		...claims === void 0 ? {} : { claims }
	});
	let resolvedContext;
	if (context) try {
		resolvedContext = await context(request);
	} catch {
		return failureOutcome(prepared, "not-started", "invalid-invocation");
	}
	let framing;
	if (frame) try {
		framing = await frame(request);
	} catch {
		return failureOutcome(prepared, "not-started", "invalid-invocation");
	}
	if (invocationSignal.aborted) return failureOutcome(prepared, "not-started", "invalid-invocation");
	try {
		const invoke = prepared.handoff.invoke;
		return await invoke(invocation, resolvedContext, framing);
	} catch (error) {
		if (prepared.mode === "request") throw error instanceof RemoteInvocationError ? error : new RemoteInvocationError("transport", "the request outcome is unknown");
		return failureOutcome(prepared, "unknown", "realization-failed");
	}
}
function requireModelContext(modelContext) {
	const resolvedPort = resolveModelContext(modelContext);
	if (!resolvedPort || !isWebMcpAvailable(resolvedPort)) fail("UNSUPPORTED_HOST", "modelContext", "document.modelContext.registerTool is not available");
	return resolvedPort;
}
async function openWebMcpRegistration(port, initial, context, frame, onActivity) {
	const live = /* @__PURE__ */ new Map();
	let tools = Object.freeze([]);
	let disposed = false;
	let generation = 0;
	let queue = Promise.resolve();
	const pending = /* @__PURE__ */ new Set();
	const listen = Boolean(onActivity && port.addEventListener && port.removeEventListener);
	function activity(event) {
		if (disposed || !live.has(event.toolName)) return;
		onActivity?.(Object.freeze({
			toolName: event.toolName,
			state: event.type === "toolcancel" ? "cancelled" : "started"
		}));
	}
	function setTools(next) {
		tools = Object.freeze(next.map((entry) => Object.freeze({ ...entry })));
	}
	function dispose() {
		if (disposed) return;
		disposed = true;
		if (listen) {
			port.removeEventListener("toolactivated", activity);
			port.removeEventListener("toolcancel", activity);
		}
		generation += 1;
		for (const controller of pending) controller.abort();
		pending.clear();
		for (const entry of live.values()) entry.controller.abort();
		live.clear();
		setTools([]);
	}
	async function apply(syncOptions) {
		if (disposed) fail("DISPOSED_REGISTRATION", "sync", "this WebMCP registration has been disposed");
		const assigned = generation;
		const desired = await prepareCatalog(syncOptions);
		if (disposed || assigned !== generation) return;
		await publish(desired, assigned);
		if (!disposed && assigned === generation);
	}
	async function publish(desired, assigned) {
		const desiredByName = new Map(desired.map((entry) => [entry.name, entry]));
		const retained = /* @__PURE__ */ new Set();
		for (const [name, entry] of live) {
			const next = desiredByName.get(name);
			if (next && next.identity === entry.prepared.identity) {
				entry.prepared = next;
				retained.add(name);
			}
		}
		const removals = [];
		for (const [name, entry] of live) if (!retained.has(name)) removals.push(entry);
		for (const entry of removals) {
			live.delete(entry.prepared.name);
			entry.controller.abort();
		}
		const additions = desired.filter((entry) => !retained.has(entry.name));
		const added = [];
		try {
			for (const prepared of additions) {
				const controller = new AbortController();
				const entry = {
					prepared,
					controller
				};
				pending.add(controller);
				try {
					await port.registerTool({
						name: prepared.name,
						...prepared.title === void 0 ? {} : { title: prepared.title },
						description: prepared.description,
						inputSchema: prepared.inputSchema,
						annotations: {
							readOnlyHint: prepared.readOnlyHint,
							consequentialHint: prepared.consequentialHint,
							...prepared.debugging === void 0 ? {} : { debugging: prepared.debugging },
							...prepared.untrustedContentHint === void 0 ? {} : { untrustedContentHint: prepared.untrustedContentHint }
						},
						execute: (input, executeOptions) => executeTool(entry, context, input, executeOptions?.signal, frame, executeOptions?.claims)
					}, {
						signal: controller.signal,
						...prepared.exposedTo === void 0 ? {} : { exposedTo: prepared.exposedTo }
					});
				} catch (error) {
					pending.delete(controller);
					controller.abort();
					if (disposed || assigned !== generation) {
						for (const addedEntry of added) {
							live.delete(addedEntry.prepared.name);
							addedEntry.controller.abort();
						}
						return;
					}
					if (hostNameConflict(error)) fail("INCOMPATIBLE_LIVE_REPLACEMENT", `tools.${prepared.interactionId}.name`, `tool name ${prepared.name} is already registered and cannot be replaced until reload`);
					fail("REGISTRATION_FAILED", `tools.${prepared.interactionId}`, error instanceof Error ? error.message : "tool registration failed");
				}
				pending.delete(controller);
				if (disposed || assigned !== generation) {
					controller.abort();
					for (const addedEntry of added) {
						live.delete(addedEntry.prepared.name);
						addedEntry.controller.abort();
					}
					return;
				}
				live.set(prepared.name, entry);
				added.push(entry);
			}
		} catch (error) {
			for (const entry of added) {
				live.delete(entry.prepared.name);
				entry.controller.abort();
			}
			throw error;
		}
		setTools(desired.map((entry) => entry.summary));
	}
	function enqueue(path, runApply) {
		const assigned = ++generation;
		for (const controller of pending) controller.abort();
		const run = queue.then(async () => {
			if (disposed) fail("DISPOSED_REGISTRATION", path, "this WebMCP registration has been disposed");
			if (assigned !== generation) return;
			await runApply();
		});
		queue = run.then(() => void 0, () => void 0);
		return run;
	}
	function sync(syncOptions) {
		return enqueue("sync", () => apply(syncOptions));
	}
	const registration = {
		get tools() {
			return tools;
		},
		sync,
		dispose
	};
	try {
		await sync(initial);
		if (listen) {
			port.addEventListener("toolactivated", activity);
			port.addEventListener("toolcancel", activity);
		}
	} catch (error) {
		dispose();
		throw error;
	}
	return Object.freeze(registration);
}
async function registerWebMcpBinding(options) {
	if (typeof options.context !== "function") fail("INVALID_TOOL", "registerWebMcpBinding.context", "context must resolve invocation-scoped host context");
	return openWebMcpRegistration(requireModelContext(options.modelContext), {
		binding: options.binding,
		tools: options.tools
	}, options.context, void 0, options.onActivity);
}
/** Present one already-pinned remote Binding on `document.modelContext`. */
async function registerWebMcpTransport(options) {
	return openWebMcpRegistration(requireModelContext(options.modelContext), {
		transport: options.transport,
		tools: options.tools
	}, void 0, options.frame, options.onActivity);
}
//#endregion
export { WebMcpError, isWebMcpAvailable, overlayInputSchema, registerWebMcpBinding, registerWebMcpTransport, webMcpTool, webMcpTools };
