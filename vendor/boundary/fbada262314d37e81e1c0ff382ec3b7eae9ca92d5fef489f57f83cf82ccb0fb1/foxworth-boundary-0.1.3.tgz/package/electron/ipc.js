export { t as allowElectronSender, n as createElectronIpcFetch, r as electronIpcTransport, i as installElectronIpcBridge, a as ipcFetchChannel } from "../chunks/ipc-2ZpSg71u.js";
