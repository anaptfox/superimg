import { a as controlError, i as ControlError, n as controlRecordProposalId, r as snapshotControlReaderScope, t as controlReaderScopeIncludes } from "./readerScope-D1JnbSm8.js";
import { INTERACTION_ID_PATTERN, cloneJson, compareUtf8, exactObject, hashJson, isInteractionId, isSha256Digest, jsonEquals, portableSchema, validateSchemaValue } from "@foxworth/boundary/program";
//#region packages/core/control/src/recordSnapshot.ts
function snapshot(value, path) {
	return cloneJson(value, path);
}
function requiredString(value) {
	return typeof value === "string" && value.trim().length > 0;
}
function isObject(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}
function projectionSourceSnapshot(value, path) {
	try {
		return snapshot(value, path);
	} catch (error) {
		throw controlError("CONTROL_INVALID_RECORD", path, error instanceof Error ? error.message : "record must be portable data", error);
	}
}
function requireExactFields(value, allowed, required, path) {
	const unexpected = Object.keys(value).find((field) => !allowed.has(field));
	if (unexpected !== void 0) throw controlError("CONTROL_INVALID_RECORD", `${path}.${unexpected}`, `unexpected record field: ${unexpected}`);
	const missing = required.find((field) => !Object.hasOwn(value, field));
	if (missing !== void 0) throw controlError("CONTROL_INVALID_RECORD", `${path}.${missing}`, `required record field is missing: ${missing}`);
}
//#endregion
//#region packages/core/control/src/types.ts
var CONTROL_RECORD_VERSION = 1;
//#endregion
//#region packages/core/control/src/approvalRecords.ts
var APPROVAL_RECORD_FIELDS = Object.freeze([
	"version",
	"id",
	"proposalId",
	"proposalDigest",
	"bindingDigest",
	"projectionDigest",
	"installationId",
	"installationDigest",
	"expectedProgramDigest",
	"actualProgramDigest",
	"programDigest",
	"controlDigest",
	"interactionId",
	"expectedContractDigest",
	"contractDigest",
	"requestRealizationId",
	"executionRealizationId",
	"controlRealizationDigest",
	"approvedBy",
	"approvedAt",
	"preview"
]);
var APPROVAL_RECORD_FIELD_SET = new Set(APPROVAL_RECORD_FIELDS);
function approvalMatchesProposal(approval, proposal) {
	return approval.version === 1 && requiredString(approval.id) && approval.proposalId === proposal.id && approval.proposalDigest === proposal.proposalDigest && approval.bindingDigest === proposal.bindingDigest && approval.projectionDigest === proposal.projectionDigest && approval.installationId === proposal.installationId && approval.installationDigest === proposal.installationDigest && approval.expectedProgramDigest === proposal.expectedProgramDigest && approval.actualProgramDigest === proposal.actualProgramDigest && approval.programDigest === proposal.programDigest && approval.controlDigest === proposal.controlDigest && approval.interactionId === proposal.interactionId && approval.expectedContractDigest === proposal.expectedContractDigest && approval.contractDigest === proposal.contractDigest && approval.requestRealizationId === proposal.requestRealizationId && approval.executionRealizationId === proposal.executionRealizationId && approval.controlRealizationDigest === proposal.controlRealizationDigest && requiredString(approval.approvedBy) && Number.isFinite(approval.approvedAt) && jsonEquals(approval.preview, proposal.preview);
}
/** Snapshot and validate the complete durable approval list at a journal boundary. */
function snapshotApprovalRecords(value, path) {
	const approvals = projectionSourceSnapshot(value, path);
	if (!Array.isArray(approvals)) throw controlError("CONTROL_INVALID_RECORD", path, "approval list must be an array");
	const approvalIds = /* @__PURE__ */ new Set();
	const approvingActors = /* @__PURE__ */ new Set();
	for (let index = 0; index < approvals.length; index += 1) {
		const itemPath = `${path}[${index}]`;
		const approval = approvals[index];
		if (!isObject(approval)) throw controlError("CONTROL_INVALID_RECORD", itemPath, "approval must be an object");
		requireExactFields(approval, APPROVAL_RECORD_FIELD_SET, APPROVAL_RECORD_FIELDS, itemPath);
		if (approval["version"] !== 1) throw controlError("CONTROL_INVALID_RECORD", `${itemPath}.version`, `approval version must be 1`);
		for (const field of [
			"id",
			"proposalId",
			"installationId",
			"requestRealizationId",
			"executionRealizationId",
			"approvedBy"
		]) if (!requiredString(approval[field])) throw controlError("CONTROL_INVALID_RECORD", `${itemPath}.${field}`, `approval ${field} is required`);
		for (const field of [
			"proposalDigest",
			"bindingDigest",
			"projectionDigest",
			"installationDigest",
			"expectedProgramDigest",
			"actualProgramDigest",
			"programDigest",
			"controlDigest",
			"expectedContractDigest",
			"contractDigest",
			"controlRealizationDigest"
		]) if (!isSha256Digest(approval[field])) throw controlError("CONTROL_INVALID_RECORD", `${itemPath}.${field}`, `approval ${field} is invalid`);
		if (!isInteractionId(approval["interactionId"])) throw controlError("CONTROL_INVALID_RECORD", `${itemPath}.interactionId`, "approval interactionId is invalid");
		if (!Number.isFinite(approval["approvedAt"])) throw controlError("CONTROL_INVALID_RECORD", `${itemPath}.approvedAt`, "approval approvedAt must be finite");
		const approvalId = approval["id"];
		if (approvalIds.has(approvalId)) throw controlError("CONTROL_INVALID_RECORD", `${itemPath}.id`, `duplicate approval id: ${approvalId}`);
		approvalIds.add(approvalId);
		const approvedBy = approval["approvedBy"];
		if (approvingActors.has(approvedBy)) throw controlError("CONTROL_INVALID_RECORD", `${itemPath}.approvedBy`, `duplicate approving actor: ${approvedBy}`);
		approvingActors.add(approvedBy);
	}
	return approvals;
}
/** Snapshot and validate one complete durable approval at a journal boundary. */
function snapshotApprovalRecord(value, path = "approval") {
	return snapshotApprovalRecords([value], path)[0];
}
//#endregion
//#region packages/core/control/src/proposalRecords.ts
var CONTROL_PROPOSAL_DOMAIN = "boundary.control-proposal/v1";
var NON_BLANK_STRING_SCHEMA = Object.freeze({
	type: "string",
	pattern: "\\S"
});
var DIGEST_SCHEMA = Object.freeze({
	type: "string",
	pattern: "^sha256:[0-9a-f]{64}$"
});
var SUBJECT_SCHEMA = Object.freeze({
	type: "object",
	properties: {
		kind: NON_BLANK_STRING_SCHEMA,
		id: NON_BLANK_STRING_SCHEMA
	},
	required: ["kind", "id"],
	additionalProperties: false
});
var EFFECT_SCHEMA = Object.freeze({
	type: "object",
	properties: {
		kind: NON_BLANK_STRING_SCHEMA,
		action: NON_BLANK_STRING_SCHEMA,
		resource: NON_BLANK_STRING_SCHEMA,
		description: { type: "string" },
		details: { type: "object" }
	},
	required: [
		"kind",
		"action",
		"resource"
	],
	additionalProperties: false
});
/** JSON Schema used by every projected public-proposal surface. */
var PUBLIC_PROPOSAL_SCHEMA = cloneJson({
	type: "object",
	properties: {
		version: { const: 1 },
		id: NON_BLANK_STRING_SCHEMA,
		proposalDigest: DIGEST_SCHEMA,
		bindingDigest: DIGEST_SCHEMA,
		projectionDigest: DIGEST_SCHEMA,
		installationId: NON_BLANK_STRING_SCHEMA,
		installationDigest: DIGEST_SCHEMA,
		expectedProgramDigest: DIGEST_SCHEMA,
		actualProgramDigest: DIGEST_SCHEMA,
		programDigest: DIGEST_SCHEMA,
		controlDigest: DIGEST_SCHEMA,
		interactionId: {
			type: "string",
			pattern: INTERACTION_ID_PATTERN
		},
		expectedContractDigest: DIGEST_SCHEMA,
		contractDigest: DIGEST_SCHEMA,
		requestRealizationId: NON_BLANK_STRING_SCHEMA,
		executionRealizationId: NON_BLANK_STRING_SCHEMA,
		controlRealizationDigest: DIGEST_SCHEMA,
		requestedBy: NON_BLANK_STRING_SCHEMA,
		subject: SUBJECT_SCHEMA,
		baselineSummary: NON_BLANK_STRING_SCHEMA,
		effects: {
			type: "array",
			items: EFFECT_SCHEMA,
			minItems: 1
		},
		preview: {},
		createdAt: { type: "number" }
	},
	required: [
		"version",
		"id",
		"proposalDigest",
		"bindingDigest",
		"projectionDigest",
		"installationId",
		"installationDigest",
		"expectedProgramDigest",
		"actualProgramDigest",
		"programDigest",
		"controlDigest",
		"interactionId",
		"expectedContractDigest",
		"contractDigest",
		"requestRealizationId",
		"executionRealizationId",
		"controlRealizationDigest",
		"requestedBy",
		"subject",
		"baselineSummary",
		"effects",
		"preview",
		"createdAt"
	],
	additionalProperties: false
}, "PUBLIC_PROPOSAL_SCHEMA");
var PROPOSAL_RECORD_FIELDS = Object.freeze([
	"version",
	"id",
	"proposalDigest",
	"bindingDigest",
	"projectionDigest",
	"installationId",
	"installationDigest",
	"expectedProgramDigest",
	"actualProgramDigest",
	"programDigest",
	"controlDigest",
	"interactionId",
	"expectedContractDigest",
	"contractDigest",
	"requestRealizationId",
	"executionRealizationId",
	"controlRealizationDigest",
	"requestedBy",
	"input",
	"subject",
	"baseline",
	"baselineSummary",
	"effects",
	"state",
	"preview",
	"createdAt"
]);
var PROPOSAL_RECORD_FIELD_SET = new Set(PROPOSAL_RECORD_FIELDS);
/** Snapshot and enforce the exact public proposal contract owned by Control. */
function normalizePublicProposal(value, path) {
	let normalized;
	try {
		normalized = cloneJson(value, path);
	} catch (error) {
		throw controlError("CONTROL_INVALID_RECORD", path, error instanceof Error ? error.message : "proposal must be portable JSON", error);
	}
	const first = validateSchemaValue(PUBLIC_PROPOSAL_SCHEMA, normalized, path)[0];
	if (first) throw controlError("CONTROL_INVALID_RECORD", first.path, first.message);
	const proposal = normalized;
	if (!isInteractionId(proposal.interactionId)) throw controlError("CONTROL_INVALID_RECORD", `${path}.interactionId`, "interactionId must be a stable ASCII token of at most 128 characters");
	return proposal;
}
function proposalShapeIssue(value) {
	if (!isObject(value)) return "proposal must be an object";
	const unexpected = Object.keys(value).find((field) => !PROPOSAL_RECORD_FIELD_SET.has(field));
	if (unexpected !== void 0) return `proposal has unexpected field: ${unexpected}`;
	const missing = PROPOSAL_RECORD_FIELDS.find((field) => !Object.hasOwn(value, field));
	if (missing !== void 0) return `proposal ${missing} is required`;
	if (value["version"] !== 1) return `proposal version must be 1`;
	for (const field of [
		"id",
		"installationId",
		"interactionId",
		"requestRealizationId",
		"executionRealizationId",
		"requestedBy",
		"baselineSummary"
	]) if (!requiredString(value[field])) return `proposal ${field} is required`;
	if (!isInteractionId(value["interactionId"])) return "proposal interactionId is invalid";
	for (const field of [
		"proposalDigest",
		"bindingDigest",
		"projectionDigest",
		"installationDigest",
		"expectedProgramDigest",
		"actualProgramDigest",
		"programDigest",
		"controlDigest",
		"expectedContractDigest",
		"contractDigest",
		"controlRealizationDigest"
	]) if (!isSha256Digest(value[field])) return `proposal ${field} is invalid`;
	if (!Number.isFinite(value["createdAt"])) return "proposal createdAt must be finite";
	const subject = value["subject"];
	if (!isObject(subject) || !requiredString(subject["kind"]) || !requiredString(subject["id"]) || Object.keys(subject).some((field) => field !== "kind" && field !== "id")) return "proposal subject kind and id are required";
	if (!Array.isArray(value["effects"]) || value["effects"].length === 0) return "proposal effects are required";
	for (const effect of value["effects"]) if (!isObject(effect) || !requiredString(effect["kind"]) || !requiredString(effect["action"]) || !requiredString(effect["resource"]) || Object.keys(effect).some((field) => field !== "kind" && field !== "action" && field !== "resource" && field !== "description" && field !== "details") || effect["description"] !== void 0 && typeof effect["description"] !== "string" || effect["details"] !== void 0 && !isObject(effect["details"])) return "proposal effect kind, action, and resource are required";
	for (const field of [
		"input",
		"baseline",
		"state",
		"preview"
	]) if (!(field in value)) return `proposal ${field} is required`;
}
function requireProposalProjectionSource(value) {
	const proposal = projectionSourceSnapshot(value, "proposal");
	if (!isObject(proposal)) throw controlError("CONTROL_INVALID_RECORD", "proposal", "proposal must be an object");
	if (proposal["version"] !== 1) throw controlError("CONTROL_INVALID_RECORD", "proposal.version", `proposal version must be 1`);
	requireExactFields(proposal, PROPOSAL_RECORD_FIELD_SET, PROPOSAL_RECORD_FIELDS, "proposal");
	const issue = proposalShapeIssue(proposal);
	if (issue) throw controlError("CONTROL_INVALID_RECORD", "proposal", issue);
	return proposal;
}
async function proposalDigest(proposal) {
	return hashJson(CONTROL_PROPOSAL_DOMAIN, snapshot(proposal, "proposal"));
}
async function verifyProposalIntegrity(value) {
	try {
		const proposal = snapshot(value, "proposal");
		const issue = proposalShapeIssue(proposal);
		if (issue) return Object.freeze({
			status: "invalid",
			reason: issue
		});
		const { proposalDigest: actual, ...identity } = proposal;
		if (actual !== await proposalDigest(identity)) return Object.freeze({
			status: "invalid",
			reason: "proposal digest does not match its content"
		});
		return Object.freeze({
			status: "valid",
			proposal
		});
	} catch (error) {
		return Object.freeze({
			status: "invalid",
			reason: error instanceof Error ? error.message : "proposal is not portable JSON"
		});
	}
}
async function requireValidProposal(value) {
	const integrity = await verifyProposalIntegrity(value);
	if (integrity.status === "invalid") throw controlError("CONTROL_INTEGRITY_MISMATCH", "proposal.proposalDigest", integrity.reason);
	return integrity.proposal;
}
var projectedPublicProposals = /* @__PURE__ */ new WeakMap();
function publicProposal(proposal) {
	const cached = projectedPublicProposals.get(proposal);
	if (cached) return cached;
	const source = requireProposalProjectionSource(proposal);
	const cachedSource = projectedPublicProposals.get(source);
	if (cachedSource) {
		projectedPublicProposals.set(proposal, cachedSource);
		return cachedSource;
	}
	const projected = Object.freeze({
		version: 1,
		id: source.id,
		proposalDigest: source.proposalDigest,
		bindingDigest: source.bindingDigest,
		projectionDigest: source.projectionDigest,
		installationId: source.installationId,
		installationDigest: source.installationDigest,
		expectedProgramDigest: source.expectedProgramDigest,
		actualProgramDigest: source.actualProgramDigest,
		programDigest: source.programDigest,
		controlDigest: source.controlDigest,
		interactionId: source.interactionId,
		expectedContractDigest: source.expectedContractDigest,
		contractDigest: source.contractDigest,
		requestRealizationId: source.requestRealizationId,
		executionRealizationId: source.executionRealizationId,
		controlRealizationDigest: source.controlRealizationDigest,
		requestedBy: source.requestedBy,
		subject: source.subject,
		baselineSummary: source.baselineSummary,
		effects: source.effects,
		preview: source.preview,
		createdAt: source.createdAt
	});
	projectedPublicProposals.set(proposal, projected);
	if (source !== proposal) projectedPublicProposals.set(source, projected);
	return projected;
}
function publicHandleMatches(handle, record) {
	try {
		return handle.id === record.id && handle.proposalDigest === record.proposalDigest && jsonEquals(handle, publicProposal(record));
	} catch {
		return false;
	}
}
function grantMatchesProposal(grant, proposal) {
	return grant.version === 1 && requiredString(grant.id) && grant.proposalId === proposal.id && grant.proposalDigest === proposal.proposalDigest && grant.bindingDigest === proposal.bindingDigest && grant.projectionDigest === proposal.projectionDigest && grant.installationId === proposal.installationId && grant.installationDigest === proposal.installationDigest && grant.expectedProgramDigest === proposal.expectedProgramDigest && grant.actualProgramDigest === proposal.actualProgramDigest && grant.programDigest === proposal.programDigest && grant.controlDigest === proposal.controlDigest && grant.interactionId === proposal.interactionId && grant.expectedContractDigest === proposal.expectedContractDigest && grant.contractDigest === proposal.contractDigest && grant.requestRealizationId === proposal.requestRealizationId && grant.executionRealizationId === proposal.executionRealizationId && grant.controlRealizationDigest === proposal.controlRealizationDigest && grant.requestedBy === proposal.requestedBy && jsonEquals(grant.subject, proposal.subject) && jsonEquals(grant.preview, proposal.preview) && requiredString(grant.issuedBy) && Number.isFinite(grant.issuedAt) && (grant.expiresAt === void 0 || Number.isFinite(grant.expiresAt)) && Array.isArray(grant.approvedBy) && grant.approvedBy.length > 0 && grant.approvedBy.every(requiredString);
}
//#endregion
//#region packages/core/control/src/records.ts
var ATTEMPT_RECORD_FIELDS = Object.freeze([
	"version",
	"id",
	"recordRevision",
	"proposalId",
	"proposalDigest",
	"bindingDigest",
	"projectionDigest",
	"installationId",
	"installationDigest",
	"expectedProgramDigest",
	"actualProgramDigest",
	"programDigest",
	"grantId",
	"controlDigest",
	"interactionId",
	"expectedContractDigest",
	"contractDigest",
	"requestRealizationId",
	"executionRealizationId",
	"controlRealizationDigest",
	"execution",
	"verification",
	"lease",
	"createdAt",
	"updatedAt",
	"output",
	"evidence",
	"message"
]);
var ATTEMPT_RECORD_FIELD_SET = new Set(ATTEMPT_RECORD_FIELDS);
var ATTEMPT_REQUIRED_FIELDS = Object.freeze([
	"version",
	"id",
	"recordRevision",
	"proposalId",
	"proposalDigest",
	"bindingDigest",
	"projectionDigest",
	"installationId",
	"installationDigest",
	"expectedProgramDigest",
	"actualProgramDigest",
	"programDigest",
	"grantId",
	"controlDigest",
	"interactionId",
	"expectedContractDigest",
	"contractDigest",
	"requestRealizationId",
	"executionRealizationId",
	"controlRealizationDigest",
	"execution",
	"verification",
	"lease",
	"createdAt",
	"updatedAt"
]);
var RECEIPT_RECORD_FIELDS = Object.freeze([
	"version",
	"id",
	"attemptId",
	"proposalId",
	"proposalDigest",
	"bindingDigest",
	"projectionDigest",
	"installationId",
	"installationDigest",
	"expectedProgramDigest",
	"actualProgramDigest",
	"programDigest",
	"grantId",
	"controlDigest",
	"interactionId",
	"expectedContractDigest",
	"contractDigest",
	"requestRealizationId",
	"executionRealizationId",
	"controlRealizationDigest",
	"output",
	"evidence",
	"completedAt"
]);
var RECEIPT_RECORD_FIELD_SET = new Set(RECEIPT_RECORD_FIELDS);
var RECEIPT_REQUIRED_FIELDS = Object.freeze([
	"version",
	"id",
	"attemptId",
	"proposalId",
	"proposalDigest",
	"bindingDigest",
	"projectionDigest",
	"installationId",
	"installationDigest",
	"expectedProgramDigest",
	"actualProgramDigest",
	"programDigest",
	"grantId",
	"controlDigest",
	"interactionId",
	"expectedContractDigest",
	"contractDigest",
	"requestRealizationId",
	"executionRealizationId",
	"controlRealizationDigest",
	"output",
	"completedAt"
]);
function attemptMatches(attempt, proposal, grant) {
	return attempt.version === 1 && requiredString(attempt.id) && Number.isInteger(attempt.recordRevision) && attempt.recordRevision > 0 && attempt.proposalId === proposal.id && attempt.proposalDigest === proposal.proposalDigest && attempt.bindingDigest === proposal.bindingDigest && attempt.projectionDigest === proposal.projectionDigest && attempt.installationId === proposal.installationId && attempt.installationDigest === proposal.installationDigest && attempt.expectedProgramDigest === proposal.expectedProgramDigest && attempt.actualProgramDigest === proposal.actualProgramDigest && attempt.programDigest === proposal.programDigest && attempt.programDigest === grant.programDigest && attempt.grantId === grant.id && attempt.controlDigest === proposal.controlDigest && attempt.interactionId === proposal.interactionId && attempt.expectedContractDigest === proposal.expectedContractDigest && attempt.contractDigest === proposal.contractDigest && attempt.requestRealizationId === proposal.requestRealizationId && attempt.executionRealizationId === proposal.executionRealizationId && attempt.controlRealizationDigest === proposal.controlRealizationDigest && Number.isFinite(attempt.createdAt) && Number.isFinite(attempt.updatedAt) && requiredString(attempt.lease.owner) && Number.isFinite(attempt.lease.expiresAt) && Number.isInteger(attempt.lease.fence) && attempt.lease.fence > 0;
}
function requireAttemptProjectionSource(value) {
	const attempt = projectionSourceSnapshot(value, "attempt");
	if (!isObject(attempt)) throw controlError("CONTROL_INVALID_RECORD", "attempt", "attempt must be an object");
	if (attempt["version"] !== 1) throw controlError("CONTROL_INVALID_RECORD", "attempt.version", `attempt version must be 1`);
	requireExactFields(attempt, ATTEMPT_RECORD_FIELD_SET, ATTEMPT_REQUIRED_FIELDS, "attempt");
	for (const field of [
		"id",
		"proposalId",
		"grantId",
		"installationId",
		"requestRealizationId",
		"executionRealizationId"
	]) if (!requiredString(attempt[field])) throw controlError("CONTROL_INVALID_RECORD", `attempt.${field}`, `attempt ${field} is required`);
	for (const field of [
		"proposalDigest",
		"bindingDigest",
		"projectionDigest",
		"installationDigest",
		"expectedProgramDigest",
		"actualProgramDigest",
		"programDigest",
		"controlDigest",
		"expectedContractDigest",
		"contractDigest",
		"controlRealizationDigest"
	]) if (!isSha256Digest(attempt[field])) throw controlError("CONTROL_INVALID_RECORD", `attempt.${field}`, `attempt ${field} is invalid`);
	if (!isInteractionId(attempt["interactionId"])) throw controlError("CONTROL_INVALID_RECORD", "attempt.interactionId", "attempt interactionId is invalid");
	if (!Number.isInteger(attempt["recordRevision"]) || attempt["recordRevision"] <= 0) throw controlError("CONTROL_INVALID_RECORD", "attempt.recordRevision", "attempt recordRevision must be a positive integer");
	if (attempt["execution"] !== "started" && attempt["execution"] !== "uncertain" && attempt["execution"] !== "not-applied" && attempt["execution"] !== "completed") throw controlError("CONTROL_INVALID_RECORD", "attempt.execution", "attempt execution state is invalid");
	if (attempt["verification"] !== "pending" && attempt["verification"] !== "verified" && attempt["verification"] !== "failed") throw controlError("CONTROL_INVALID_RECORD", "attempt.verification", "attempt verification state is invalid");
	if (!Number.isFinite(attempt["createdAt"]) || !Number.isFinite(attempt["updatedAt"])) throw controlError("CONTROL_INVALID_RECORD", "attempt.updatedAt", "attempt timestamps must be finite");
	const lease = attempt["lease"];
	if (!isObject(lease)) throw controlError("CONTROL_INVALID_RECORD", "attempt.lease", "attempt lease must be an object");
	requireExactFields(lease, /* @__PURE__ */ new Set([
		"owner",
		"expiresAt",
		"fence"
	]), [
		"owner",
		"expiresAt",
		"fence"
	], "attempt.lease");
	if (!requiredString(lease["owner"]) || !Number.isFinite(lease["expiresAt"]) || !Number.isInteger(lease["fence"]) || lease["fence"] <= 0) throw controlError("CONTROL_INVALID_RECORD", "attempt.lease", "attempt lease owner, expiration, and fence are invalid");
	if (attempt["message"] !== void 0 && typeof attempt["message"] !== "string") throw controlError("CONTROL_INVALID_RECORD", "attempt.message", "attempt message must be a string");
	return attempt;
}
/** Snapshot and validate one complete durable attempt at a journal boundary. */
function snapshotAttemptRecord(value) {
	return requireAttemptProjectionSource(value);
}
/** Durable projection has no native output-type evidence. */
function publicAttempt(attempt) {
	const source = requireAttemptProjectionSource(attempt);
	return Object.freeze({
		version: 1,
		id: source.id,
		proposalId: source.proposalId,
		bindingDigest: source.bindingDigest,
		projectionDigest: source.projectionDigest,
		installationId: source.installationId,
		installationDigest: source.installationDigest,
		expectedProgramDigest: source.expectedProgramDigest,
		actualProgramDigest: source.actualProgramDigest,
		programDigest: source.programDigest,
		interactionId: source.interactionId,
		expectedContractDigest: source.expectedContractDigest,
		contractDigest: source.contractDigest,
		requestRealizationId: source.requestRealizationId,
		executionRealizationId: source.executionRealizationId,
		controlRealizationDigest: source.controlRealizationDigest,
		controlDigest: source.controlDigest
	});
}
function attemptRefMatches(reference, attempt) {
	return reference.version === 1 && reference.id === attempt.id && reference.proposalId === attempt.proposalId && reference.bindingDigest === attempt.bindingDigest && reference.projectionDigest === attempt.projectionDigest && reference.installationId === attempt.installationId && reference.installationDigest === attempt.installationDigest && reference.expectedProgramDigest === attempt.expectedProgramDigest && reference.actualProgramDigest === attempt.actualProgramDigest && reference.programDigest === attempt.programDigest && reference.interactionId === attempt.interactionId && reference.expectedContractDigest === attempt.expectedContractDigest && reference.contractDigest === attempt.contractDigest && reference.requestRealizationId === attempt.requestRealizationId && reference.executionRealizationId === attempt.executionRealizationId && reference.controlRealizationDigest === attempt.controlRealizationDigest && reference.controlDigest === attempt.controlDigest;
}
function receiptMatches(receipt, attempt, proposal, grant) {
	try {
		return receipt.version === 1 && requiredString(receipt.id) && receipt.attemptId === attempt.id && receipt.proposalId === proposal.id && receipt.proposalDigest === proposal.proposalDigest && receipt.bindingDigest === proposal.bindingDigest && receipt.projectionDigest === proposal.projectionDigest && receipt.installationId === proposal.installationId && receipt.installationDigest === proposal.installationDigest && receipt.expectedProgramDigest === proposal.expectedProgramDigest && receipt.actualProgramDigest === proposal.actualProgramDigest && receipt.programDigest === proposal.programDigest && receipt.programDigest === attempt.programDigest && receipt.programDigest === grant.programDigest && receipt.grantId === grant.id && receipt.controlDigest === proposal.controlDigest && receipt.interactionId === proposal.interactionId && receipt.expectedContractDigest === proposal.expectedContractDigest && receipt.contractDigest === proposal.contractDigest && receipt.requestRealizationId === proposal.requestRealizationId && receipt.executionRealizationId === proposal.executionRealizationId && receipt.controlRealizationDigest === proposal.controlRealizationDigest && Number.isFinite(receipt.completedAt) && attempt.execution === "completed" && attempt.verification === "verified" && attempt.output !== void 0 && jsonEquals(receipt.output, attempt.output) && (attempt.evidence === void 0 ? receipt.evidence === void 0 : receipt.evidence !== void 0 && jsonEquals(receipt.evidence, attempt.evidence));
	} catch {
		return false;
	}
}
/** Snapshot and validate one complete durable receipt at a journal boundary. */
function snapshotReceiptRecord(value, path = "receipt") {
	const receipt = projectionSourceSnapshot(value, path);
	if (!isObject(receipt)) throw controlError("CONTROL_INVALID_RECORD", path, "receipt must be an object");
	requireExactFields(receipt, RECEIPT_RECORD_FIELD_SET, RECEIPT_REQUIRED_FIELDS, path);
	if (receipt["version"] !== 1) throw controlError("CONTROL_INVALID_RECORD", `${path}.version`, `receipt version must be 1`);
	for (const field of [
		"id",
		"attemptId",
		"proposalId",
		"grantId",
		"installationId",
		"requestRealizationId",
		"executionRealizationId"
	]) if (!requiredString(receipt[field])) throw controlError("CONTROL_INVALID_RECORD", `${path}.${field}`, `receipt ${field} is required`);
	for (const field of [
		"proposalDigest",
		"bindingDigest",
		"projectionDigest",
		"installationDigest",
		"expectedProgramDigest",
		"actualProgramDigest",
		"programDigest",
		"controlDigest",
		"expectedContractDigest",
		"contractDigest",
		"controlRealizationDigest"
	]) if (!isSha256Digest(receipt[field])) throw controlError("CONTROL_INVALID_RECORD", `${path}.${field}`, `receipt ${field} is invalid`);
	if (!isInteractionId(receipt["interactionId"])) throw controlError("CONTROL_INVALID_RECORD", `${path}.interactionId`, "receipt interactionId is invalid");
	if (!Number.isFinite(receipt["completedAt"])) throw controlError("CONTROL_INVALID_RECORD", `${path}.completedAt`, "receipt completedAt must be finite");
	return receipt;
}
//#endregion
//#region packages/core/control/src/realization.ts
var CONTROL_REALIZATION_DOMAIN = "boundary.control-realization/v1";
var controlHookSnapshots = /* @__PURE__ */ new WeakMap();
var resolvedControls = /* @__PURE__ */ new WeakSet();
var CONTROL_HOOK_FIELDS = Object.freeze([
	"realizationDigest",
	"state",
	"preview",
	"plan",
	"apply",
	"verify",
	"reconcile"
]);
function snapshotInteractionIdentity(value) {
	let candidate;
	try {
		candidate = cloneJson(value, "control.identity");
	} catch (error) {
		throw controlError("CONTROL_INVALID_REALIZATION", "control.identity", error instanceof Error ? error.message : "control interaction identity must be portable data", error);
	}
	if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) throw controlError("CONTROL_INVALID_REALIZATION", "control.identity", "control interaction identity must be an object");
	const object = exactObject(candidate, {
		path: "control.identity",
		keys: ["interactionId", "contractDigest"],
		fail: (failure) => {
			throw controlError("CONTROL_INVALID_REALIZATION", failure.path, failure.message);
		}
	});
	if (!isInteractionId(object.interactionId)) throw controlError("CONTROL_INVALID_REALIZATION", "control.identity.interactionId", "interactionId must be a stable ASCII token of at most 128 characters");
	if (!isSha256Digest(object.contractDigest)) throw controlError("CONTROL_INVALID_REALIZATION", "control.identity.contractDigest", "contractDigest must be sha256:<64 lowercase hex>");
	return Object.freeze({
		interactionId: object.interactionId,
		contractDigest: object.contractDigest
	});
}
function requireResolvedControl(control) {
	if (!control || typeof control !== "object" || !resolvedControls.has(control)) throw controlError("CONTROL_INVALID_REALIZATION", "control", "an authentic digested controlled realization is required");
	return control;
}
function snapshotRuntimeIdentity(value) {
	let candidate;
	try {
		candidate = cloneJson(value, "control.runtimeIdentity");
	} catch (error) {
		throw controlError("CONTROL_INVALID_REALIZATION", "control.runtimeIdentity", error instanceof Error ? error.message : "runtime identity must be portable data", error);
	}
	const object = exactObject(candidate, {
		path: "control.runtimeIdentity",
		keys: [
			"bindingDigest",
			"projectionDigest",
			"installationId",
			"installationDigest",
			"expectedProgramDigest",
			"actualProgramDigest",
			"programDigest",
			"interactionId",
			"expectedContractDigest",
			"contractDigest",
			"requestRealizationId",
			"executionRealizationId"
		],
		fail: (failure) => {
			throw controlError("CONTROL_INVALID_REALIZATION", failure.path, failure.message);
		}
	});
	for (const field of [
		"bindingDigest",
		"projectionDigest",
		"installationDigest",
		"expectedProgramDigest",
		"actualProgramDigest",
		"programDigest",
		"expectedContractDigest",
		"contractDigest"
	]) if (!isSha256Digest(object[field])) throw controlError("CONTROL_INVALID_REALIZATION", `control.runtimeIdentity.${field}`, `${field} must be sha256:<64 lowercase hex>`);
	if (!isInteractionId(object.interactionId)) throw controlError("CONTROL_INVALID_REALIZATION", "control.runtimeIdentity.interactionId", "interactionId is invalid");
	for (const field of [
		"installationId",
		"requestRealizationId",
		"executionRealizationId"
	]) if (typeof object[field] !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u.test(object[field])) throw controlError("CONTROL_INVALID_REALIZATION", `control.runtimeIdentity.${field}`, `${field} must be a stable non-empty ASCII token`);
	return Object.freeze(object);
}
function targetForControl(control, identity) {
	const resolved = requireResolvedControl(control);
	const runtime = snapshotRuntimeIdentity(identity);
	if (runtime.interactionId !== resolved.identity.interactionId || runtime.contractDigest !== resolved.identity.contractDigest) throw controlError("CONTROL_INTEGRITY_MISMATCH", "control.runtimeIdentity", "runtime interaction does not match the static controlled realization");
	return Object.freeze({
		...runtime,
		controlRealizationDigest: resolved.hook.realizationDigest,
		controlDigest: resolved.controlDigest
	});
}
function snapshotSchemaContract(compilation, path) {
	if (!compilation || typeof compilation !== "object") throw controlError("CONTROL_INVALID_REALIZATION", path, "schema compiler must return a contract object");
	if (!Object.prototype.propertyIsEnumerable.call(compilation, "contract")) throw controlError("CONTROL_INVALID_REALIZATION", path, "compiled schema contract must be an enumerable data property");
	let contract;
	try {
		contract = cloneJson(compilation.contract, path);
	} catch (error) {
		throw controlError("CONTROL_INVALID_REALIZATION", path, error instanceof Error ? error.message : "compiled schema contract must be portable data", error);
	}
	if (!contract || typeof contract !== "object" || Array.isArray(contract)) throw controlError("CONTROL_INVALID_REALIZATION", path, "compiled schema contract must be an object");
	return contract;
}
function requiredFunction(value, path) {
	if (typeof value !== "function") throw controlError("CONTROL_INVALID_REALIZATION", path, "control realization must provide plan, apply, verify, and reconcile functions");
}
function validateControlHook(value, path) {
	if (!value || typeof value !== "object" || Array.isArray(value)) throw controlError("CONTROL_INVALID_REALIZATION", path, "controlled change must provide a control realization object");
	const existing = controlHookSnapshots.get(value);
	if (existing) return existing;
	const fields = exactObject(value, {
		path,
		keys: CONTROL_HOOK_FIELDS,
		fail: (failure) => {
			throw failure.code === "SNAPSHOT_INVALID_PROPERTY" ? controlError("CONTROL_INVALID_REALIZATION", failure.path, "control fields must be enumerable data properties") : controlError("CONTROL_INVALID_REALIZATION", path, "control realization must contain exactly realizationDigest, state, preview, plan, apply, verify, and reconcile");
		}
	});
	requiredFunction(fields.plan, `${path}.plan`);
	requiredFunction(fields.apply, `${path}.apply`);
	requiredFunction(fields.verify, `${path}.verify`);
	requiredFunction(fields.reconcile, `${path}.reconcile`);
	if (!isSha256Digest(fields.realizationDigest)) throw controlError("CONTROL_INVALID_REALIZATION", `${path}.realizationDigest`, "realizationDigest must be sha256:<64 lowercase hex>");
	const snapshot = Object.freeze({
		realizationDigest: fields.realizationDigest,
		state: fields.state,
		preview: fields.preview,
		plan: fields.plan,
		apply: fields.apply,
		verify: fields.verify,
		reconcile: fields.reconcile
	});
	controlHookSnapshots.set(value, snapshot);
	controlHookSnapshots.set(snapshot, snapshot);
	return snapshot;
}
/** Type and freeze one author-facing control realization. */
function controlled(hook) {
	return validateControlHook(hook, "controlled");
}
async function digestControlRealization(compiler, identity, control) {
	const exactIdentity = snapshotInteractionIdentity(identity);
	const hook = validateControlHook(control, `${exactIdentity.interactionId}.control`);
	const stateSchema = snapshotSchemaContract(compiler.compileSchema(hook.state, {
		role: "input",
		path: `${exactIdentity.interactionId}.control.state`
	}), `${exactIdentity.interactionId}.control.state.contract`);
	const previewSchema = snapshotSchemaContract(compiler.compileSchema(hook.preview, {
		role: "output",
		path: `${exactIdentity.interactionId}.control.preview`
	}), `${exactIdentity.interactionId}.control.preview.contract`);
	const digestIdentity = Object.freeze({
		interactionId: exactIdentity.interactionId,
		interactionContractDigest: exactIdentity.contractDigest,
		realizationDigest: hook.realizationDigest,
		stateSchema,
		previewSchema
	});
	const resolved = Object.freeze({
		identity: exactIdentity,
		hook,
		controlDigest: await hashJson(CONTROL_REALIZATION_DOMAIN, digestIdentity),
		stateSchema,
		previewSchema
	});
	resolvedControls.add(resolved);
	return resolved;
}
function normalizeSubject(subject, path) {
	if (!subject?.kind?.trim() || !subject?.id?.trim()) throw controlError("CONTROL_INVALID_PLAN", `${path}.subject`, "subject kind and id are required");
	return Object.freeze({
		kind: subject.kind,
		id: subject.id
	});
}
function normalizeEffect(effect, path) {
	if (!effect?.kind?.trim() || !effect?.action?.trim() || !effect?.resource?.trim()) throw controlError("CONTROL_INVALID_PLAN", path, "effect kind, action, and resource are required");
	return Object.freeze({
		kind: effect.kind,
		action: effect.action,
		resource: effect.resource,
		...effect.description === void 0 ? {} : { description: effect.description },
		...effect.details === void 0 ? {} : { details: cloneJson(effect.details, `${path}.details`) }
	});
}
function normalizeControlPlan(plan, path) {
	if (!plan || typeof plan !== "object" || Array.isArray(plan)) throw controlError("CONTROL_INVALID_PLAN", path, "plan must be an object");
	if (!plan.baselineSummary?.trim()) throw controlError("CONTROL_INVALID_PLAN", `${path}.baselineSummary`, "baselineSummary is required");
	if (!Array.isArray(plan.effects) || plan.effects.length === 0) throw controlError("CONTROL_INVALID_PLAN", `${path}.effects`, "at least one effect is required");
	return Object.freeze({
		subject: normalizeSubject(plan.subject, path),
		baseline: cloneJson(plan.baseline, `${path}.baseline`),
		baselineSummary: plan.baselineSummary,
		effects: Object.freeze(plan.effects.map((effect, index) => normalizeEffect(effect, `${path}.effects[${index}]`))),
		state: cloneJson(plan.state, `${path}.state`),
		preview: cloneJson(plan.preview, `${path}.preview`)
	});
}
//#endregion
//#region packages/core/control/src/kernelShared.ts
function snapshotCreateResult(value, path) {
	const result = snapshot(value, path);
	const keys = Object.keys(result).sort(compareUtf8);
	if (keys.length !== 2 || keys[0] !== "kind" || keys[1] !== "record" || result["kind"] !== "created" && result["kind"] !== "existing") throw controlError("CONTROL_JOURNAL_CONFLICT", path, "journal create result must contain exactly kind and record");
	return result;
}
function messageOf(error, fallback) {
	return error instanceof Error ? error.message : fallback;
}
function beforeAttempt(error, path, fallback) {
	return error instanceof ControlError ? error : controlError("CONTROL_JOURNAL_CONFLICT", path, messageOf(error, fallback), error);
}
function clockNow(runtime, path) {
	let value;
	try {
		value = runtime.clock.now();
	} catch (error) {
		throw controlError("CONTROL_INVALID_CLOCK", path, messageOf(error, "control clock failed"), error);
	}
	if (!Number.isFinite(value)) throw controlError("CONTROL_INVALID_CLOCK", path, "control clock must return a finite timestamp");
	return value;
}
async function nextId(runtime, kind) {
	let value;
	try {
		value = await runtime.journal.nextId(kind);
	} catch (error) {
		throw controlError("CONTROL_INVALID_ID", `${kind}.id`, messageOf(error, `failed to allocate ${kind} id`), error);
	}
	if (!value.trim()) throw controlError("CONTROL_INVALID_ID", `${kind}.id`, `${kind} id must be non-empty`);
	return value;
}
function actorId(runtime, actor) {
	let value;
	try {
		value = runtime.policy.identify(actor);
	} catch (error) {
		throw controlError("CONTROL_POLICY_DENIED", "control.actor", messageOf(error, "policy could not identify actor"), error);
	}
	if (!value.trim()) throw controlError("CONTROL_POLICY_DENIED", "control.actor", "policy actor identity must be non-empty");
	return value;
}
function requireDecision(decision, path) {
	if (!decision || typeof decision !== "object" || typeof decision.allow !== "boolean") throw controlError("CONTROL_POLICY_DENIED", path, "policy must return an explicit allow decision");
	if (!decision.allow) throw controlError("CONTROL_POLICY_DENIED", path, decision.reason || "policy denied control action");
	if (decision.expiresAt !== void 0 && !Number.isFinite(decision.expiresAt)) throw controlError("CONTROL_POLICY_DENIED", path, "policy expiration must be a finite timestamp");
}
function targetOf(proposal) {
	return Object.freeze({
		bindingDigest: proposal.bindingDigest,
		projectionDigest: proposal.projectionDigest,
		installationId: proposal.installationId,
		installationDigest: proposal.installationDigest,
		expectedProgramDigest: proposal.expectedProgramDigest,
		actualProgramDigest: proposal.actualProgramDigest,
		programDigest: proposal.programDigest,
		interactionId: proposal.interactionId,
		expectedContractDigest: proposal.expectedContractDigest,
		contractDigest: proposal.contractDigest,
		requestRealizationId: proposal.requestRealizationId,
		executionRealizationId: proposal.executionRealizationId,
		controlRealizationDigest: proposal.controlRealizationDigest,
		controlDigest: proposal.controlDigest
	});
}
function targetMatches(left, right) {
	return left.bindingDigest === right.bindingDigest && left.projectionDigest === right.projectionDigest && left.installationId === right.installationId && left.installationDigest === right.installationDigest && left.expectedProgramDigest === right.expectedProgramDigest && left.actualProgramDigest === right.actualProgramDigest && left.programDigest === right.programDigest && left.interactionId === right.interactionId && left.expectedContractDigest === right.expectedContractDigest && left.contractDigest === right.contractDigest && left.requestRealizationId === right.requestRealizationId && left.executionRealizationId === right.executionRealizationId && left.controlRealizationDigest === right.controlRealizationDigest && left.controlDigest === right.controlDigest;
}
function requireTarget(target, path) {
	if (!target || typeof target !== "object" || !isSha256Digest(target.bindingDigest) || !isSha256Digest(target.projectionDigest) || typeof target.installationId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u.test(target.installationId) || !isSha256Digest(target.installationDigest) || !isSha256Digest(target.expectedProgramDigest) || !isSha256Digest(target.actualProgramDigest) || !isSha256Digest(target.programDigest) || !isInteractionId(target.interactionId) || !isSha256Digest(target.expectedContractDigest) || !isSha256Digest(target.contractDigest) || typeof target.requestRealizationId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u.test(target.requestRealizationId) || typeof target.executionRealizationId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u.test(target.executionRealizationId) || !isSha256Digest(target.controlRealizationDigest) || !isSha256Digest(target.controlDigest)) throw controlError("CONTROL_INVALID_RECORD", path, "control target must contain exact Installation, Program, interaction, realization, and control identity");
	return Object.freeze({ ...target });
}
function requireBindingFunction(value, path) {
	if (typeof value !== "function") throw controlError("CONTROL_INVALID_REALIZATION", path, "control binding must provide portable input, state, preview, and output parsers");
}
async function requireCurrentInstallation(host, expected, path) {
	try {
		const current = await host.inspect();
		if (current.installationId !== expected.installationId || current.installationDigest !== expected.installationDigest || current.programDigest !== expected.programDigest) throw new Error("stored authority targets a different Installation");
	} catch (error) {
		throw controlError("CONTROL_INTEGRITY_MISMATCH", path, messageOf(error, "current Installation could not be inspected"), error);
	}
}
async function resolveCurrentBinding(host, targetValue, path) {
	const target = requireTarget(targetValue, `${path}.target`);
	await requireCurrentInstallation(host, target, `${path}.installation`);
	let candidate;
	try {
		candidate = await host.resolve(target);
	} catch (error) {
		if (error instanceof ControlError) throw error;
		throw controlError("CONTROL_NOT_CONFIGURED", path, messageOf(error, "exact controlled realization could not be resolved"), error);
	}
	if (!candidate || typeof candidate !== "object" || !candidate.target || !targetMatches(candidate.target, target)) throw controlError("CONTROL_INTEGRITY_MISMATCH", `${path}.target`, "host resolved a different controlled target");
	requireBindingFunction(candidate.parseInput, `${path}.parseInput`);
	requireBindingFunction(candidate.parseState, `${path}.parseState`);
	requireBindingFunction(candidate.parsePreview, `${path}.parsePreview`);
	requireBindingFunction(candidate.parseOutput, `${path}.parseOutput`);
	const hook = validateControlHook(candidate.hook, `${target.interactionId}.control`);
	if (hook.realizationDigest !== target.controlRealizationDigest) throw controlError("CONTROL_INTEGRITY_MISMATCH", `${path}.controlRealizationDigest`, "host resolved a different packaged control realization");
	return Object.freeze({
		target,
		hook,
		parseInput: candidate.parseInput,
		parseState: candidate.parseState,
		parsePreview: candidate.parsePreview,
		parseOutput: candidate.parseOutput
	});
}
async function loadProposalRecord(runtime, handle) {
	const id = typeof handle === "string" ? handle : handle.id;
	let stored;
	try {
		stored = await runtime.journal.getProposal(id);
	} catch (error) {
		throw beforeAttempt(error, `proposal.${id}`, "proposal lookup failed");
	}
	if (!stored) throw controlError("CONTROL_UNKNOWN_PROPOSAL", `proposal.${id}`, `unknown proposal: ${id}`);
	const proposal = await requireValidProposal(stored);
	if (proposal.id !== id) throw controlError("CONTROL_INTEGRITY_MISMATCH", `proposal.${id}`, "journal proposal id does not match its requested key");
	if (typeof handle !== "string" && !publicHandleMatches(handle, proposal)) throw controlError("CONTROL_INTEGRITY_MISMATCH", `proposal.${id}`, "proposal handle does not match its durable record");
	return proposal;
}
async function loadProposal(runtime, handle) {
	const proposal = await loadProposalRecord(runtime, handle);
	await resolveCurrentBinding(runtime.host, targetOf(proposal), "proposal");
	return proposal;
}
async function parsePrivateProposal(binding, proposal) {
	const input = await binding.parseInput(proposal.input);
	const state = await binding.parseState(proposal.state);
	const preview = await binding.parsePreview(proposal.preview);
	return Object.freeze({
		input,
		state: cloneJson(state, `${proposal.interactionId}.control.state`),
		preview: cloneJson(preview, `${proposal.interactionId}.control.preview`)
	});
}
//#endregion
//#region packages/core/control/src/kernelRequest.ts
async function requestControl(runtime, request) {
	const target = requireTarget(request.target, "control.request.target");
	const control = await resolveCurrentBinding(runtime.host, target, "control.request");
	let input;
	try {
		input = await control.parseInput(request.input);
	} catch (error) {
		throw controlError("CONTROL_INVALID_REALIZATION", `${target.interactionId}.input`, messageOf(error, "control input did not match its portable contract"), error);
	}
	let rawPlan;
	try {
		rawPlan = await control.hook.plan({
			input,
			context: request.context
		});
	} catch (error) {
		throw controlError("CONTROL_INVALID_PLAN", `${target.interactionId}.control.plan`, messageOf(error, "control plan failed"), error);
	}
	const plan = normalizeControlPlan(rawPlan, `${target.interactionId}.control.plan`);
	let parsedState;
	let parsedPreview;
	try {
		parsedState = await control.parseState(plan.state);
		parsedPreview = await control.parsePreview(plan.preview);
	} catch (error) {
		throw controlError("CONTROL_INVALID_PLAN", `${target.interactionId}.control.plan`, messageOf(error, "control plan did not match its portable contracts"), error);
	}
	const id = await nextId(runtime, "proposal");
	const createdAt = clockNow(runtime, "proposal.createdAt");
	const withoutDigest = Object.freeze({
		version: 1,
		id,
		...target,
		requestedBy: actorId(runtime, request.actor),
		input: cloneJson(input, `${target.interactionId}.input`),
		subject: plan.subject,
		baseline: plan.baseline,
		baselineSummary: plan.baselineSummary,
		effects: plan.effects,
		state: cloneJson(parsedState, `${target.interactionId}.control.state`),
		preview: cloneJson(parsedPreview, `${target.interactionId}.control.preview`),
		createdAt
	});
	const proposal = Object.freeze({
		...withoutDigest,
		proposalDigest: await proposalDigest(withoutDigest)
	});
	let decision;
	try {
		decision = await runtime.policy.request({
			actor: request.actor,
			proposal
		});
	} catch (error) {
		throw controlError("CONTROL_POLICY_DENIED", "control.request", messageOf(error, "request policy failed"), error);
	}
	requireDecision(decision, "control.request");
	await resolveCurrentBinding(runtime.host, target, "control.request");
	try {
		const created = snapshotCreateResult(await runtime.journal.createProposal(proposal), `proposal.${id}.create`);
		if (!jsonEquals(created.record, proposal)) throw controlError("CONTROL_JOURNAL_CONFLICT", `proposal.${id}`, created.kind === "created" ? "journal proposal does not match the exact proposal candidate" : "proposal digest is already bound to different content");
		await resolveCurrentBinding(runtime.host, target, "control.request");
		return publicProposal(created.record);
	} catch (error) {
		throw beforeAttempt(error, `proposal.${id}`, "proposal write failed");
	}
}
async function approveControl(runtime, actor, handle) {
	const proposal = await loadProposal(runtime, handle);
	const approvedBy = actorId(runtime, actor);
	let decision;
	try {
		decision = await runtime.policy.approve({
			actor,
			proposal
		});
	} catch (error) {
		throw controlError("CONTROL_POLICY_DENIED", "control.approve", messageOf(error, "approval policy failed"), error);
	}
	requireDecision(decision, "control.approve");
	await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.approve");
	const approval = Object.freeze({
		version: 1,
		id: await nextId(runtime, "approval"),
		proposalId: proposal.id,
		proposalDigest: proposal.proposalDigest,
		...targetOf(proposal),
		approvedBy,
		approvedAt: clockNow(runtime, "approval.approvedAt"),
		preview: snapshot(proposal.preview, "approval.preview")
	});
	try {
		const durableApproval = snapshotCreateResult(await runtime.journal.createApproval(approval), `approval.${approval.id}.create`).record;
		if (!jsonEquals(durableApproval, approval)) throw controlError("CONTROL_JOURNAL_CONFLICT", `approval.${approval.id}`, "journal approval does not match the exact approval candidate");
		await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.approve");
		return durableApproval;
	} catch (error) {
		throw beforeAttempt(error, `approval.${approval.id}`, "approval write failed");
	}
}
async function grantControl(runtime, actor, handle) {
	const proposal = await loadProposal(runtime, handle);
	let listedApprovals;
	try {
		listedApprovals = await runtime.journal.listApprovals(proposal.proposalDigest);
	} catch (error) {
		throw beforeAttempt(error, "control.grant", "approval lookup failed");
	}
	let approvals;
	try {
		approvals = snapshotApprovalRecords(listedApprovals, "control.grant.approvals");
	} catch (error) {
		throw controlError("CONTROL_INTEGRITY_MISMATCH", "control.grant", messageOf(error, "stored approvals are invalid"), error);
	}
	if (approvals.length === 0 || approvals.some((approval) => !approvalMatchesProposal(approval, proposal))) throw controlError(approvals.length === 0 ? "CONTROL_POLICY_DENIED" : "CONTROL_INTEGRITY_MISMATCH", "control.grant", approvals.length === 0 ? "at least one exact approval is required" : "stored approval does not match the proposal");
	const issuedBy = actorId(runtime, actor);
	let decision;
	try {
		decision = await runtime.policy.grant({
			actor,
			proposal,
			approvals
		});
	} catch (error) {
		throw controlError("CONTROL_POLICY_DENIED", "control.grant", messageOf(error, "grant policy failed"), error);
	}
	requireDecision(decision, "control.grant");
	await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.grant");
	const issuedAt = clockNow(runtime, "grant.issuedAt");
	if (decision.expiresAt !== void 0 && decision.expiresAt <= issuedAt) throw controlError("CONTROL_EXPIRED_GRANT", "grant.expiresAt", "policy issued an already-expired grant");
	const approvedBy = Object.freeze([...new Set(approvals.map((approval) => approval.approvedBy))].sort(compareUtf8));
	const grant = Object.freeze({
		version: 1,
		id: await nextId(runtime, "grant"),
		proposalId: proposal.id,
		proposalDigest: proposal.proposalDigest,
		...targetOf(proposal),
		requestedBy: proposal.requestedBy,
		approvedBy,
		subject: snapshot(proposal.subject, "grant.subject"),
		preview: snapshot(proposal.preview, "grant.preview"),
		issuedBy,
		issuedAt,
		...decision.expiresAt === void 0 ? {} : { expiresAt: decision.expiresAt }
	});
	try {
		const created = snapshotCreateResult(await runtime.journal.createGrant(grant), `grant.${grant.id}.create`);
		const exactCreated = jsonEquals(created.record, grant);
		const validExisting = grantMatchesProposal(created.record, proposal) && jsonEquals(created.record.approvedBy, approvedBy) && created.record.issuedBy === grant.issuedBy && created.record.expiresAt === grant.expiresAt;
		if (created.kind === "created" && !exactCreated || created.kind === "existing" && !validExisting) throw controlError("CONTROL_JOURNAL_CONFLICT", `grant.${grant.id}`, created.kind === "created" ? "journal grant does not match the exact grant candidate" : "existing grant does not match exact authority");
		await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.grant");
		return created.record;
	} catch (error) {
		throw beforeAttempt(error, `grant.${grant.id}`, "grant write failed");
	}
}
//#endregion
//#region packages/core/control/src/kernelEffect.ts
var DEFAULT_LEASE_MS = 3e4;
function leaseDuration(runtime) {
	const value = runtime.lease?.durationMs ?? DEFAULT_LEASE_MS;
	if (!Number.isFinite(value) || value <= 0) throw controlError("CONTROL_INVALID_LEASE", "control.lease.durationMs", "lease duration must be a positive finite number");
	return value;
}
function uncertain(attempt) {
	return Object.freeze({
		status: "uncertain",
		attempt: publicAttempt(attempt)
	});
}
function notApplied(reason) {
	return Object.freeze({
		status: "not-applied",
		reason
	});
}
async function completed(binding, receipt) {
	const durableReceipt = snapshotReceiptRecord(receipt);
	const value = await binding.parseOutput(durableReceipt.output);
	return Object.freeze({
		status: "completed",
		value,
		receipt: durableReceipt
	});
}
async function loadAuthority(runtime, grantHandle) {
	const grantId = typeof grantHandle === "string" ? grantHandle : grantHandle.id;
	let grant;
	try {
		const loaded = await runtime.journal.getGrant(grantId);
		grant = loaded === void 0 ? void 0 : snapshot(loaded, "grant");
	} catch (error) {
		throw beforeAttempt(error, `grant.${grantId}`, "grant lookup failed");
	}
	if (!grant) throw controlError("CONTROL_UNKNOWN_GRANT", `grant.${grantId}`, `unknown grant: ${grantId}`);
	if (grant.id !== grantId) throw controlError("CONTROL_INTEGRITY_MISMATCH", `grant.${grantId}`, "journal grant id does not match its requested key");
	if (typeof grantHandle !== "string" && !jsonEquals(grantHandle, grant)) throw controlError("CONTROL_INTEGRITY_MISMATCH", `grant.${grantId}`, "grant handle does not match its durable record");
	const proposal = await loadProposalRecord(runtime, grant.proposalId);
	if (!grantMatchesProposal(grant, proposal)) throw controlError("CONTROL_INTEGRITY_MISMATCH", `grant.${grant.id}`, "grant does not bind the exact proposal");
	return {
		proposal,
		grant: snapshot(grant, "grant")
	};
}
async function bindPrivateProposal(runtime, proposal, path) {
	const binding = await resolveCurrentBinding(runtime.host, targetOf(proposal), path);
	const parsed = await parsePrivateProposal(binding, proposal);
	return {
		binding,
		input: parsed.input,
		state: parsed.state
	};
}
async function findExistingAttempt(runtime, proposal) {
	try {
		const attempt = await runtime.journal.findAttemptByProposalDigest(proposal.proposalDigest);
		return attempt === void 0 ? void 0 : snapshotAttemptRecord(attempt);
	} catch (error) {
		throw beforeAttempt(error, "attempt", "attempt lookup failed");
	}
}
async function findExistingReceipt(runtime, proposal) {
	try {
		const receipt = await runtime.journal.findReceiptByProposalDigest(proposal.proposalDigest);
		return receipt === void 0 ? void 0 : snapshotReceiptRecord(receipt);
	} catch (error) {
		throw beforeAttempt(error, "receipt", "receipt lookup failed");
	}
}
async function publishReceipt(runtime, proposal, grant, attempt) {
	let binding;
	try {
		binding = await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.receipt");
	} catch {
		return uncertain(attempt);
	}
	if (attempt.execution !== "completed" || attempt.verification !== "verified" || attempt.output === void 0) return uncertain(attempt);
	let existing;
	try {
		const found = await runtime.journal.findReceiptByProposalDigest(proposal.proposalDigest);
		existing = found === void 0 ? void 0 : snapshotReceiptRecord(found);
	} catch {
		return uncertain(attempt);
	}
	if (existing) {
		if (!receiptMatches(existing, attempt, proposal, grant)) return uncertain(attempt);
		try {
			binding = await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.receipt");
			return await completed(binding, existing);
		} catch {
			return uncertain(attempt);
		}
	}
	let receipt;
	try {
		receipt = Object.freeze({
			version: 1,
			id: await nextId(runtime, "receipt"),
			attemptId: attempt.id,
			proposalId: proposal.id,
			proposalDigest: proposal.proposalDigest,
			grantId: grant.id,
			...targetOf(proposal),
			output: snapshot(attempt.output, "receipt.output"),
			...attempt.evidence === void 0 ? {} : { evidence: snapshot(attempt.evidence, "receipt.evidence") },
			completedAt: clockNow(runtime, "receipt.completedAt")
		});
		const created = snapshotCreateResult(await runtime.journal.createReceipt(receipt), `receipt.${receipt.id}.create`);
		const durableReceipt = snapshotReceiptRecord(created.record, `receipt.${receipt.id}`);
		if (created.kind === "created" && !jsonEquals(durableReceipt, receipt) || !receiptMatches(durableReceipt, attempt, proposal, grant)) return uncertain(attempt);
		binding = await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.receipt");
		return await completed(binding, durableReceipt);
	} catch {
		try {
			const found = await runtime.journal.findReceiptByProposalDigest(proposal.proposalDigest);
			const recovered = found === void 0 ? void 0 : snapshotReceiptRecord(found);
			if (recovered && receiptMatches(recovered, attempt, proposal, grant)) {
				binding = await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.receipt");
				return await completed(binding, recovered);
			}
		} catch {}
		return uncertain(attempt);
	}
}
function verification(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("verification must return {ok:true} or {ok:false,message}");
	const result = value;
	if (result["ok"] === true) return Object.freeze({
		ok: true,
		...result["evidence"] === void 0 ? {} : { evidence: cloneJson(result["evidence"], "verification.evidence") }
	});
	if (result["ok"] === false && typeof result["message"] === "string") return Object.freeze({
		ok: false,
		message: result["message"],
		...result["evidence"] === void 0 ? {} : { evidence: cloneJson(result["evidence"], "verification.evidence") }
	});
	throw new Error("verification must return {ok:true} or {ok:false,message}");
}
function createAttemptSession(runtime, initial) {
	let current = initial;
	const transition = async (patch) => {
		const next = Object.freeze({
			...current,
			...patch,
			recordRevision: current.recordRevision + 1
		});
		const ok = await runtime.journal.compareAndSwapAttempt(next, current.recordRevision);
		if (ok) current = next;
		return ok;
	};
	const lease = Object.freeze({
		get owner() {
			return current.lease.owner;
		},
		get expiresAt() {
			return current.lease.expiresAt;
		},
		get fence() {
			return current.lease.fence;
		},
		async renew() {
			const now = clockNow(runtime, "attempt.lease.renewedAt");
			if (current.lease.owner !== runtime.executor.owner) throw controlError("CONTROL_INVALID_LEASE", "attempt.lease.owner", "only the current executor may renew a lease");
			if (now >= current.lease.expiresAt) throw controlError("CONTROL_INVALID_LEASE", "attempt.lease.expiresAt", "an expired lease cannot be renewed");
			const renewed = Object.freeze({
				owner: runtime.executor.owner,
				expiresAt: now + leaseDuration(runtime),
				fence: current.lease.fence + 1
			});
			if (!await transition({
				lease: renewed,
				updatedAt: now
			})) throw controlError("CONTROL_JOURNAL_CONFLICT", "attempt.lease", "lease renewal lost its compare-and-swap");
			return renewed;
		}
	});
	return Object.freeze({
		current: () => current,
		transition,
		lease
	});
}
async function containFailure(runtime, session, message, verificationState = "pending") {
	const now = (() => {
		try {
			return clockNow(runtime, "attempt.updatedAt");
		} catch {
			return session.current().updatedAt;
		}
	})();
	const local = Object.freeze({
		...session.current(),
		execution: "uncertain",
		verification: verificationState,
		message,
		updatedAt: now,
		recordRevision: session.current().recordRevision + 1
	});
	try {
		if (await runtime.journal.compareAndSwapAttempt(local, session.current().recordRevision)) return uncertain(local);
	} catch {}
	return uncertain(session.current());
}
async function runVerification(runtime, session, proposal, binding, input, state, output, context) {
	return verification(await binding.hook.verify({
		input,
		state,
		proposal: publicProposal(proposal),
		lease: session.lease,
		output,
		context
	}));
}
async function loadAttemptRecord(runtime, handle) {
	const id = typeof handle === "string" ? handle : handle.id;
	let attempt;
	try {
		const loaded = await runtime.journal.getAttempt(id);
		attempt = loaded === void 0 ? void 0 : snapshotAttemptRecord(loaded);
	} catch (error) {
		throw beforeAttempt(error, `attempt.${id}`, "attempt lookup failed");
	}
	if (!attempt) throw controlError("CONTROL_UNKNOWN_ATTEMPT", `attempt.${id}`, `unknown attempt: ${id}`);
	if (attempt.id !== id) throw controlError("CONTROL_INTEGRITY_MISMATCH", `attempt.${id}`, "journal attempt id does not match its requested key");
	if (typeof handle !== "string" && !attemptRefMatches(handle, attempt)) throw controlError("CONTROL_INTEGRITY_MISMATCH", `attempt.${attempt.id}`, "attempt handle does not match its durable record");
	return attempt;
}
async function loadAttemptAuthority(runtime, attempt) {
	const loaded = await loadAuthority(runtime, attempt.grantId);
	if (!attemptMatches(attempt, loaded.proposal, loaded.grant)) throw controlError("CONTROL_INTEGRITY_MISMATCH", `attempt.${attempt.id}`, "attempt does not match exact authority");
	return loaded;
}
//#endregion
//#region packages/core/control/src/kernelExecute.ts
async function executeControl(runtime, grantHandle, actor, context) {
	const { proposal, grant } = await loadAuthority(runtime, grantHandle);
	let decision;
	try {
		decision = await runtime.policy.execute({
			actor,
			proposal,
			grant
		});
	} catch (error) {
		throw controlError("CONTROL_POLICY_DENIED", "control.execute", messageOf(error, "execution policy failed"), error);
	}
	requireDecision(decision, "control.execute");
	const existingAttempt = await findExistingAttempt(runtime, proposal);
	if (existingAttempt) {
		if (!attemptMatches(existingAttempt, proposal, grant)) throw controlError("CONTROL_INTEGRITY_MISMATCH", `attempt.${existingAttempt.id}`, "existing attempt does not match exact authority");
		if (existingAttempt.execution === "completed") return publishReceipt(runtime, proposal, grant, existingAttempt);
		if (existingAttempt.execution === "not-applied") return notApplied(existingAttempt.message ?? "effect was not applied");
		return uncertain(existingAttempt);
	}
	const existingReceipt = await findExistingReceipt(runtime, proposal);
	if (existingReceipt) throw controlError("CONTROL_INTEGRITY_MISMATCH", `receipt.${existingReceipt.id}`, "receipt exists without its exact attempt");
	const { binding, input, state } = await bindPrivateProposal(runtime, proposal, "control.execute");
	const start = clockNow(runtime, "control.execute.startedAt");
	if (grant.expiresAt !== void 0 && start >= grant.expiresAt) throw controlError("CONTROL_EXPIRED_GRANT", `grant.${grant.id}.expiresAt`, "grant expired before execution began");
	try {
		await runtime.policy.preflight({
			proposal,
			grant
		});
	} catch (error) {
		throw controlError("CONTROL_PREFLIGHT_FAILED", "control.execute.preflight", messageOf(error, "preflight failed"), error);
	}
	await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.execute");
	const attemptAt = clockNow(runtime, "attempt.createdAt");
	if (grant.expiresAt !== void 0 && attemptAt >= grant.expiresAt) throw controlError("CONTROL_EXPIRED_GRANT", `grant.${grant.id}.expiresAt`, "grant expired before the attempt boundary");
	if (!runtime.executor.owner.trim()) throw controlError("CONTROL_INVALID_LEASE", "control.executor.owner", "executor owner must be non-empty");
	const candidate = Object.freeze({
		version: 1,
		id: await nextId(runtime, "attempt"),
		recordRevision: 1,
		proposalId: proposal.id,
		proposalDigest: proposal.proposalDigest,
		grantId: grant.id,
		...targetOf(proposal),
		execution: "started",
		verification: "pending",
		lease: Object.freeze({
			owner: runtime.executor.owner,
			expiresAt: attemptAt + leaseDuration(runtime),
			fence: 1
		}),
		createdAt: attemptAt,
		updatedAt: attemptAt
	});
	let attempt;
	try {
		const claimed = snapshotCreateResult(await runtime.journal.createAttempt(candidate), `attempt.${candidate.id}.create`);
		attempt = claimed.record;
		if (claimed.kind === "created") {
			if (!jsonEquals(attempt, candidate)) return uncertain(candidate);
		} else if (!attemptMatches(attempt, proposal, grant)) return uncertain(candidate);
		if (claimed.kind === "existing") {
			if (attempt.execution === "completed") return publishReceipt(runtime, proposal, grant, attempt);
			if (attempt.execution === "not-applied") return notApplied(attempt.message ?? "effect was not applied");
			return uncertain(attempt);
		}
	} catch {
		return uncertain(candidate);
	}
	try {
		await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.execute");
	} catch {
		return uncertain(attempt);
	}
	const session = createAttemptSession(runtime, attempt);
	let applyBoundaryAt;
	try {
		applyBoundaryAt = clockNow(runtime, "control.execute.applyBoundaryAt");
	} catch (error) {
		return containFailure(runtime, session, messageOf(error, "lease state is uncertain before apply"));
	}
	if (applyBoundaryAt >= session.lease.expiresAt) return containFailure(runtime, session, "lease expired before apply began");
	const hookContext = Object.freeze({
		input,
		state,
		proposal: publicProposal(proposal),
		lease: session.lease,
		context
	});
	let output;
	try {
		output = await binding.hook.apply(hookContext);
		output = await binding.parseOutput(output);
		output = cloneJson(output, `${proposal.interactionId}.output`);
		const now = clockNow(runtime, "attempt.updatedAt");
		if (!await session.transition({
			execution: "uncertain",
			verification: "pending",
			output,
			message: "effect applied; verification pending",
			updatedAt: now
		})) return uncertain(session.current());
	} catch (error) {
		return containFailure(runtime, session, messageOf(error, "effect outcome is uncertain"));
	}
	let checked;
	try {
		checked = await runVerification(runtime, session, proposal, binding, input, state, output, context);
	} catch (error) {
		return containFailure(runtime, session, messageOf(error, "verification outcome is uncertain"), "failed");
	}
	if (!checked.ok) {
		try {
			const now = clockNow(runtime, "attempt.updatedAt");
			await session.transition({
				execution: "uncertain",
				verification: "failed",
				...checked.evidence === void 0 ? {} : { evidence: checked.evidence },
				message: checked.message,
				updatedAt: now
			});
		} catch {}
		return uncertain(session.current());
	}
	try {
		const now = clockNow(runtime, "attempt.updatedAt");
		if (!await session.transition({
			execution: "completed",
			verification: "verified",
			...checked.evidence === void 0 ? {} : { evidence: checked.evidence },
			message: "verified",
			updatedAt: now
		})) return uncertain(session.current());
	} catch {
		return uncertain(session.current());
	}
	return publishReceipt(runtime, proposal, grant, session.current());
}
//#endregion
//#region packages/core/control/src/kernelReconcile.ts
async function reconcileControl(runtime, handle, actor, context) {
	let attempt = await loadAttemptRecord(runtime, handle);
	let recovery;
	try {
		recovery = await loadAttemptAuthority(runtime, attempt);
	} catch (error) {
		if (error instanceof ControlError && error.code === "CONTROL_JOURNAL_CONFLICT") return uncertain(attempt);
		throw error;
	}
	const { proposal, grant } = recovery;
	let decision;
	try {
		decision = await runtime.policy.reconcile({
			actor,
			proposal,
			grant,
			attempt
		});
	} catch (error) {
		throw controlError("CONTROL_POLICY_DENIED", "control.reconcile", messageOf(error, "reconciliation policy failed"), error);
	}
	requireDecision(decision, "control.reconcile");
	if (attempt.execution === "completed") return publishReceipt(runtime, proposal, grant, attempt);
	if (attempt.execution === "not-applied") return notApplied(attempt.message ?? "effect was not applied");
	let binding;
	let input;
	let state;
	try {
		({binding, input, state} = await bindPrivateProposal(runtime, proposal, "control.reconcile"));
	} catch {
		return uncertain(attempt);
	}
	try {
		await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.reconcile");
	} catch {
		return uncertain(attempt);
	}
	let now;
	let leaseExpiresAt;
	try {
		now = clockNow(runtime, "control.reconcile.startedAt");
		if (attempt.lease.expiresAt > now) return uncertain(attempt);
		leaseExpiresAt = now + leaseDuration(runtime);
	} catch {
		return uncertain(attempt);
	}
	const claimed = Object.freeze({
		...attempt,
		recordRevision: attempt.recordRevision + 1,
		execution: "uncertain",
		lease: Object.freeze({
			owner: runtime.executor.owner,
			expiresAt: leaseExpiresAt,
			fence: attempt.lease.fence + 1
		}),
		message: "expired attempt claimed for reconciliation",
		updatedAt: now
	});
	try {
		if (!await runtime.journal.compareAndSwapAttempt(claimed, attempt.recordRevision)) {
			const loaded = await runtime.journal.getAttempt(attempt.id);
			const concurrent = loaded === void 0 ? void 0 : snapshotAttemptRecord(loaded);
			if (concurrent !== void 0 && concurrent.id !== attempt.id) throw controlError("CONTROL_INTEGRITY_MISMATCH", `attempt.${attempt.id}`, "journal attempt id does not match its requested key");
			return uncertain(concurrent ?? attempt);
		}
		attempt = claimed;
	} catch {
		return uncertain(attempt);
	}
	try {
		binding = await resolveCurrentBinding(runtime.host, targetOf(proposal), "control.reconcile");
	} catch {
		return uncertain(attempt);
	}
	const session = createAttemptSession(runtime, attempt);
	if (attempt.output !== void 0) try {
		const output = await binding.parseOutput(attempt.output);
		const checked = await runVerification(runtime, session, proposal, binding, input, state, output, context);
		if (checked.ok) {
			const updatedAt = clockNow(runtime, "attempt.updatedAt");
			if (await session.transition({
				execution: "completed",
				verification: "verified",
				...checked.evidence === void 0 ? {} : { evidence: checked.evidence },
				message: "verified during reconciliation",
				updatedAt
			})) return publishReceipt(runtime, proposal, grant, session.current());
			return uncertain(session.current());
		}
	} catch {}
	let result;
	try {
		result = await binding.hook.reconcile({
			input,
			state,
			proposal: publicProposal(proposal),
			lease: session.lease,
			context
		});
	} catch (error) {
		return containFailure(runtime, session, messageOf(error, "reconciliation outcome is uncertain"));
	}
	if (!result || typeof result !== "object" || Array.isArray(result)) return containFailure(runtime, session, "reconciliation returned an invalid result");
	const classified = result;
	if (classified["status"] === "not-applied") {
		if (typeof classified["reason"] !== "string" || !classified["reason"].trim()) return containFailure(runtime, session, "reconciliation returned not-applied without a reason");
		const reason = classified["reason"];
		try {
			const updatedAt = clockNow(runtime, "attempt.updatedAt");
			await session.transition({
				execution: "not-applied",
				verification: "pending",
				message: reason,
				updatedAt
			});
		} catch {
			return uncertain(session.current());
		}
		return session.current().execution === "not-applied" ? notApplied(reason) : uncertain(session.current());
	}
	if (classified["status"] === "uncertain") return containFailure(runtime, session, "reconciliation remains uncertain");
	if (classified["status"] !== "completed" || !("value" in classified)) return containFailure(runtime, session, "reconciliation returned an invalid result");
	let output;
	try {
		output = await binding.parseOutput(classified["value"]);
		output = cloneJson(output, `${proposal.interactionId}.output`);
		const checked = await runVerification(runtime, session, proposal, binding, input, state, output, context);
		if (!checked.ok) return containFailure(runtime, session, checked.message, "failed");
		const updatedAt = clockNow(runtime, "attempt.updatedAt");
		if (!await session.transition({
			execution: "completed",
			verification: "verified",
			output,
			...checked.evidence === void 0 ? {} : { evidence: checked.evidence },
			message: "reconciled and verified",
			updatedAt
		})) return uncertain(session.current());
	} catch (error) {
		return containFailure(runtime, session, messageOf(error, "reconciled output could not be verified"), "failed");
	}
	return publishReceipt(runtime, proposal, grant, session.current());
}
//#endregion
//#region packages/core/control/src/interactionSchemas.ts
var NON_BLANK = Object.freeze({
	type: "string",
	pattern: "\\S"
});
var DIGEST = Object.freeze({
	type: "string",
	pattern: "^sha256:[0-9a-f]{64}$"
});
var INTERACTION_ID = Object.freeze({
	type: "string",
	pattern: INTERACTION_ID_PATTERN
});
var SUBJECT = Object.freeze({
	type: "object",
	properties: {
		kind: NON_BLANK,
		id: NON_BLANK
	},
	required: ["kind", "id"],
	additionalProperties: false
});
var CONTROL_REQUEST_INPUT_SCHEMA = portableSchema({
	type: "object",
	properties: {
		interactionId: INTERACTION_ID,
		input: {},
		contractDigest: DIGEST,
		controlDigest: DIGEST
	},
	required: ["interactionId", "input"],
	additionalProperties: false
});
var CONTROL_APPROVE_INPUT_SCHEMA = portableSchema({
	type: "object",
	properties: {
		proposalId: NON_BLANK,
		decision: {
			type: "object",
			properties: { allow: { const: true } },
			required: ["allow"],
			additionalProperties: false
		}
	},
	required: ["proposalId", "decision"],
	additionalProperties: false
});
var CONTROL_STATUS_ERROR_SCHEMA = portableSchema({
	type: "object",
	properties: {
		code: { const: "CONTROL_NOT_FOUND" },
		proposalId: NON_BLANK
	},
	required: ["code", "proposalId"],
	additionalProperties: false
});
var CONTROL_PROPOSAL_ID_INPUT_SCHEMA = portableSchema({
	type: "object",
	properties: { proposalId: NON_BLANK },
	required: ["proposalId"],
	additionalProperties: false
});
var CONTROL_GRANT_ID_INPUT_SCHEMA = portableSchema({
	type: "object",
	properties: { grantId: NON_BLANK },
	required: ["grantId"],
	additionalProperties: false
});
var CONTROL_ATTEMPT_ID_INPUT_SCHEMA = portableSchema({
	type: "object",
	properties: { attemptId: NON_BLANK },
	required: ["attemptId"],
	additionalProperties: false
});
var CONTROL_LIST_INPUT_SCHEMA = portableSchema({
	type: "object",
	properties: { filter: {
		type: "object",
		properties: {
			interactionId: INTERACTION_ID,
			proposalId: NON_BLANK
		},
		additionalProperties: false
	} },
	additionalProperties: false
});
var PUBLIC_PROPOSAL_OUTPUT_SCHEMA = portableSchema(PUBLIC_PROPOSAL_SCHEMA, "control.PublicProposal");
var PUBLIC_GRANT_SCHEMA = portableSchema({
	type: "object",
	properties: {
		version: { const: 1 },
		id: NON_BLANK,
		proposalId: NON_BLANK,
		proposalDigest: DIGEST,
		bindingDigest: DIGEST,
		projectionDigest: DIGEST,
		installationId: NON_BLANK,
		installationDigest: DIGEST,
		expectedProgramDigest: DIGEST,
		actualProgramDigest: DIGEST,
		programDigest: DIGEST,
		controlDigest: DIGEST,
		interactionId: INTERACTION_ID,
		expectedContractDigest: DIGEST,
		contractDigest: DIGEST,
		requestRealizationId: NON_BLANK,
		executionRealizationId: NON_BLANK,
		controlRealizationDigest: DIGEST,
		requestedBy: NON_BLANK,
		approvedBy: {
			type: "array",
			items: NON_BLANK,
			minItems: 1
		},
		subject: SUBJECT,
		preview: {},
		issuedBy: NON_BLANK,
		issuedAt: { type: "number" },
		expiresAt: { type: "number" }
	},
	required: [
		"version",
		"id",
		"proposalId",
		"proposalDigest",
		"bindingDigest",
		"projectionDigest",
		"installationId",
		"installationDigest",
		"expectedProgramDigest",
		"actualProgramDigest",
		"programDigest",
		"controlDigest",
		"interactionId",
		"expectedContractDigest",
		"contractDigest",
		"requestRealizationId",
		"executionRealizationId",
		"controlRealizationDigest",
		"requestedBy",
		"approvedBy",
		"subject",
		"preview",
		"issuedBy",
		"issuedAt"
	],
	additionalProperties: false
});
var ATTEMPT_REF_SCHEMA = Object.freeze({
	type: "object",
	properties: {
		version: { const: 1 },
		id: NON_BLANK,
		proposalId: NON_BLANK,
		bindingDigest: DIGEST,
		projectionDigest: DIGEST,
		installationId: NON_BLANK,
		installationDigest: DIGEST,
		expectedProgramDigest: DIGEST,
		actualProgramDigest: DIGEST,
		programDigest: DIGEST,
		interactionId: INTERACTION_ID,
		expectedContractDigest: DIGEST,
		contractDigest: DIGEST,
		requestRealizationId: NON_BLANK,
		executionRealizationId: NON_BLANK,
		controlRealizationDigest: DIGEST,
		controlDigest: DIGEST
	},
	required: [
		"version",
		"id",
		"proposalId",
		"bindingDigest",
		"projectionDigest",
		"installationId",
		"installationDigest",
		"expectedProgramDigest",
		"actualProgramDigest",
		"programDigest",
		"interactionId",
		"expectedContractDigest",
		"contractDigest",
		"requestRealizationId",
		"executionRealizationId",
		"controlRealizationDigest",
		"controlDigest"
	],
	additionalProperties: false
});
var RECEIPT_SCHEMA = Object.freeze({
	type: "object",
	properties: {
		version: { const: 1 },
		id: NON_BLANK,
		attemptId: NON_BLANK,
		proposalId: NON_BLANK,
		proposalDigest: DIGEST,
		bindingDigest: DIGEST,
		projectionDigest: DIGEST,
		installationId: NON_BLANK,
		installationDigest: DIGEST,
		expectedProgramDigest: DIGEST,
		actualProgramDigest: DIGEST,
		programDigest: DIGEST,
		grantId: NON_BLANK,
		controlDigest: DIGEST,
		interactionId: INTERACTION_ID,
		expectedContractDigest: DIGEST,
		contractDigest: DIGEST,
		requestRealizationId: NON_BLANK,
		executionRealizationId: NON_BLANK,
		controlRealizationDigest: DIGEST,
		output: {},
		evidence: {},
		completedAt: { type: "number" }
	},
	required: [
		"version",
		"id",
		"attemptId",
		"proposalId",
		"proposalDigest",
		"bindingDigest",
		"projectionDigest",
		"installationId",
		"installationDigest",
		"expectedProgramDigest",
		"actualProgramDigest",
		"programDigest",
		"grantId",
		"controlDigest",
		"interactionId",
		"expectedContractDigest",
		"contractDigest",
		"requestRealizationId",
		"executionRealizationId",
		"controlRealizationDigest",
		"output",
		"completedAt"
	],
	additionalProperties: false
});
var PUBLIC_EFFECT_RESULT_SCHEMA = portableSchema({ oneOf: [
	{
		type: "object",
		properties: {
			status: { const: "completed" },
			value: {},
			receipt: RECEIPT_SCHEMA
		},
		required: [
			"status",
			"value",
			"receipt"
		],
		additionalProperties: false
	},
	{
		type: "object",
		properties: {
			status: { const: "uncertain" },
			attempt: ATTEMPT_REF_SCHEMA
		},
		required: ["status", "attempt"],
		additionalProperties: false
	},
	{
		type: "object",
		properties: {
			status: { const: "not-applied" },
			reason: NON_BLANK
		},
		required: ["status", "reason"],
		additionalProperties: false
	}
] });
var PUBLIC_CONTROL_STATUS_SCHEMA = portableSchema({
	type: "object",
	properties: {
		proposal: PUBLIC_PROPOSAL_SCHEMA,
		grant: PUBLIC_GRANT_SCHEMA,
		attempt: ATTEMPT_REF_SCHEMA,
		receipt: RECEIPT_SCHEMA
	},
	required: ["proposal"],
	additionalProperties: false
});
var PUBLIC_CONTROL_STATUS_LIST_SCHEMA = portableSchema({
	type: "array",
	items: PUBLIC_CONTROL_STATUS_SCHEMA
});
/** Snapshot and validate one complete durable grant at a journal boundary. */
function snapshotGrantRecord(value, path = "grant") {
	let normalized;
	try {
		normalized = cloneJson(value, path);
	} catch (error) {
		throw controlError("CONTROL_INVALID_RECORD", path, error instanceof Error ? error.message : "grant must be portable JSON", error);
	}
	const issue = validateSchemaValue(PUBLIC_GRANT_SCHEMA, normalized, path)[0];
	if (issue) throw controlError("CONTROL_INVALID_RECORD", issue.path, issue.message);
	return normalized;
}
function publicGrant(grant) {
	const source = snapshotGrantRecord(grant);
	return Object.freeze({
		version: source.version,
		id: source.id,
		proposalId: source.proposalId,
		proposalDigest: source.proposalDigest,
		bindingDigest: source.bindingDigest,
		projectionDigest: source.projectionDigest,
		installationId: source.installationId,
		installationDigest: source.installationDigest,
		expectedProgramDigest: source.expectedProgramDigest,
		actualProgramDigest: source.actualProgramDigest,
		programDigest: source.programDigest,
		controlDigest: source.controlDigest,
		interactionId: source.interactionId,
		expectedContractDigest: source.expectedContractDigest,
		contractDigest: source.contractDigest,
		requestRealizationId: source.requestRealizationId,
		executionRealizationId: source.executionRealizationId,
		controlRealizationDigest: source.controlRealizationDigest,
		requestedBy: source.requestedBy,
		approvedBy: source.approvedBy,
		subject: source.subject,
		preview: source.preview,
		issuedBy: source.issuedBy,
		issuedAt: source.issuedAt,
		...source.expiresAt === void 0 ? {} : { expiresAt: source.expiresAt }
	});
}
//#endregion
//#region packages/core/control/src/kernelStatus.ts
function invalidStatus(path, message) {
	throw controlError("CONTROL_INTEGRITY_MISMATCH", path, message);
}
async function statusControl(journal, proposalId, scopeValue) {
	const scope = snapshotControlReaderScope(scopeValue);
	const rawProposal = await journal.getProposal(proposalId);
	if (!rawProposal || !controlReaderScopeIncludes(scope, rawProposal)) throw controlError("CONTROL_UNKNOWN_PROPOSAL", "control.reader.status", "proposal was not found");
	const proposal = await requireValidProposal(rawProposal);
	if (proposal.id !== proposalId) invalidStatus("status.proposal.id", "journal proposal id does not match its requested key");
	return statusForValidatedProposal(journal, proposal);
}
async function statusForValidatedProposal(journal, proposal) {
	const [rawGrant, rawAttempt, rawReceipt] = await Promise.all([
		journal.findGrantByProposalDigest(proposal.proposalDigest),
		journal.findAttemptByProposalDigest(proposal.proposalDigest),
		journal.findReceiptByProposalDigest(proposal.proposalDigest)
	]);
	return statusFromChain(proposal, {
		proposalDigest: proposal.proposalDigest,
		...rawGrant === void 0 ? {} : { grant: rawGrant },
		...rawAttempt === void 0 ? {} : { attempt: rawAttempt },
		...rawReceipt === void 0 ? {} : { receipt: rawReceipt }
	});
}
function statusFromChain(proposal, chain) {
	if (chain.proposalDigest !== proposal.proposalDigest) invalidStatus("status.chain", "batch key mismatch");
	const { grant: rawGrant, attempt: rawAttempt, receipt: rawReceipt } = chain;
	const grant = rawGrant === void 0 ? void 0 : snapshotGrantRecord(rawGrant, "status.grant");
	if (grant && !grantMatchesProposal(grant, proposal)) invalidStatus("status.grant", "grant does not match the exact proposal identity");
	const attempt = rawAttempt === void 0 ? void 0 : snapshotAttemptRecord(rawAttempt);
	if (attempt && (!grant || !attemptMatches(attempt, proposal, grant))) invalidStatus("status.attempt", "attempt does not match an exact proposal and grant");
	const receipt = rawReceipt === void 0 ? void 0 : snapshotReceiptRecord(rawReceipt, "status.receipt");
	if (receipt && (!grant || !attempt || !receiptMatches(receipt, attempt, proposal, grant))) invalidStatus("status.receipt", "receipt does not match an exact completed and verified attempt");
	return Object.freeze({
		proposal: publicProposal(proposal),
		...grant === void 0 ? {} : { grant: publicGrant(grant) },
		...attempt === void 0 ? {} : { attempt: publicAttempt(attempt) },
		...receipt === void 0 ? {} : { receipt }
	});
}
async function listControl(journal, filter, scopeValue) {
	const scope = snapshotControlReaderScope(scopeValue);
	const found = filter?.proposalId === void 0 ? void 0 : await journal.getProposal(filter.proposalId);
	if (found && found.id !== filter?.proposalId) invalidStatus("list.proposal.id", "journal key mismatch");
	const rawProposals = filter?.proposalId === void 0 ? await journal.listProposals() : found === void 0 ? [] : [found];
	if (!Array.isArray(rawProposals)) throw controlError("CONTROL_INVALID_RECORD", "control.list", "proposal list must be an array");
	const selected = (await Promise.all(rawProposals.filter((proposal) => controlReaderScopeIncludes(scope, proposal)).map((proposal) => requireValidProposal(proposal)))).filter((proposal) => {
		if (filter?.proposalId !== void 0 && proposal.id !== filter.proposalId) return false;
		if (filter?.interactionId !== void 0 && proposal.interactionId !== filter.interactionId) return false;
		return true;
	});
	selected.sort((left, right) => compareUtf8(left.id, right.id));
	const statuses = [];
	for (let offset = 0; offset < selected.length; offset += 16) {
		const batch = selected.slice(offset, offset + 16);
		if (journal.readStatusChains) {
			const chains = await journal.readStatusChains(batch.map((proposal) => proposal.proposalDigest));
			if (!Array.isArray(chains) || chains.length !== batch.length) invalidStatus("list.chains", "batch length mismatch");
			statuses.push(...batch.map((proposal, index) => {
				const chain = chains[index];
				if (!chain || typeof chain !== "object" || Array.isArray(chain)) invalidStatus("list.chains", "batch entry must be an object");
				return statusFromChain(proposal, chain);
			}));
		} else statuses.push(...await Promise.all(batch.map((proposal) => statusForValidatedProposal(journal, proposal))));
	}
	return Object.freeze(statuses);
}
/** Bounded native reader query. A cursor is an exclusive id, not a snapshot token. */
async function pageControl(journal, query, scopeValue) {
	const scope = snapshotControlReaderScope(scopeValue);
	query = cloneJson(query, "control.page.query");
	if (!query || typeof query !== "object" || Array.isArray(query) || Object.keys(query).some((key) => ![
		"limit",
		"afterId",
		"interactionId"
	].includes(key))) throw controlError("CONTROL_INVALID_RECORD", "control.page.query", "query must contain only limit, afterId and interactionId");
	if (!Number.isInteger(query.limit) || query.limit < 1 || query.limit > 100 || query.afterId !== void 0 && typeof query.afterId !== "string" || query.interactionId !== void 0 && typeof query.interactionId !== "string") throw controlError("CONTROL_INVALID_RECORD", "control.page", "limit must be 1..100 and cursor must be a string");
	if (!journal.queryProposals || !journal.readStatusChains) throw controlError("CONTROL_NOT_CONFIGURED", "control.page", "journal must support bounded queries and batch reads");
	if (query.interactionId !== void 0 && !scope.interactionIds.includes(query.interactionId)) return Object.freeze({ items: Object.freeze([]) });
	const rows = await journal.queryProposals(Object.freeze({
		...query,
		scope,
		limit: query.limit + 1
	}));
	if (!Array.isArray(rows) || rows.length > query.limit + 1) invalidStatus("page.rows", "journal exceeded page bound");
	let previous = query.afterId;
	const proposals = [];
	for (const row of rows) {
		if (!controlReaderScopeIncludes(scope, row) || query.interactionId !== void 0 && row.interactionId !== query.interactionId) invalidStatus("page.scope", "journal returned a row outside requested scope");
		const proposal = await requireValidProposal(row);
		if (previous !== void 0 && compareUtf8(previous, proposal.id) >= 0) invalidStatus("page.cursor", "journal rows must strictly advance cursor");
		previous = proposal.id;
		proposals.push(proposal);
	}
	const selected = proposals.slice(0, query.limit);
	const chains = await journal.readStatusChains(selected.map((proposal) => proposal.proposalDigest));
	if (!Array.isArray(chains) || chains.length !== selected.length) invalidStatus("page.chains", "batch length mismatch");
	const items = Object.freeze(selected.map((proposal, index) => statusFromChain(proposal, chains[index])));
	return Object.freeze({
		items,
		...proposals.length > query.limit ? { nextAfterId: selected.at(-1).id } : {}
	});
}
//#endregion
//#region packages/core/control/src/controller.ts
var controlOptions = /* @__PURE__ */ new WeakMap();
var controlRequesters = /* @__PURE__ */ new WeakMap();
function assertOptions(options) {
	if (!options || typeof options !== "object") throw new TypeError("control options are required");
	if (!options.journal || typeof options.journal !== "object") throw new TypeError("control journal is required");
	if (!options.policy || typeof options.policy !== "object") throw new TypeError("control policy is required");
	if (!options.clock || typeof options.clock.now !== "function") throw new TypeError("control clock is required");
	if (!options.executor?.owner?.trim()) throw new TypeError("control executor owner is required");
}
function assertHost(host) {
	if (!host || typeof host !== "object") throw new TypeError("control host is required");
	if (typeof host.inspect !== "function") throw new TypeError("control host inspect is required");
	if (typeof host.resolve !== "function") throw new TypeError("control host resolve is required");
}
async function publicControlAction(code, path, action) {
	try {
		return await action();
	} catch (error) {
		if (error instanceof ControlError) throw error;
		throw controlError(code, path, error instanceof Error ? error.message : "control action failed", error);
	}
}
function runtimeFor(options, host) {
	assertOptions(options);
	assertHost(host);
	return Object.freeze({
		...options,
		host
	});
}
function createControlRequester(options, host) {
	const runtime = runtimeFor(options, host);
	const request = ((value) => publicControlAction("CONTROL_INVALID_REALIZATION", "control.request", () => requestControl(runtime, value)));
	const requester = Object.freeze({ request });
	controlRequesters.set(requester, request);
	return requester;
}
/** @internal Authenticate and snapshot proposal-creation authority. */
function requestForControlRequester(requester) {
	if (!requester || typeof requester !== "object") throw new TypeError("an authentic ControlRequester is required");
	const request = controlRequesters.get(requester);
	if (!request) throw new TypeError("an authentic ControlRequester is required");
	return request;
}
function createControlAdmin(options, host) {
	const runtime = runtimeFor(options, host);
	const approve = ((proposal, actor) => publicControlAction("CONTROL_INVALID_RECORD", "control.approve", () => approveControl(runtime, actor, proposal)));
	const grant = ((proposal, actor) => publicControlAction("CONTROL_INVALID_RECORD", "control.grant", () => grantControl(runtime, actor, proposal)));
	const execute = ((grantValue, actor, context) => publicControlAction("CONTROL_INVALID_RECORD", "control.execute", () => executeControl(runtime, grantValue, actor, context)));
	const reconcile = ((attempt, actor, context) => publicControlAction("CONTROL_INVALID_RECORD", "control.reconcile", () => reconcileControl(runtime, attempt, actor, context)));
	return Object.freeze({
		approve,
		grant,
		execute,
		reconcile
	});
}
async function getRecord(options, scope, reference) {
	if (!reference || typeof reference !== "object" || !reference.id?.trim()) throw controlError("CONTROL_INVALID_RECORD", "control.reader.reference", "record reference requires a kind and non-empty id");
	const requireRequestedId = (actual, path) => {
		if (actual !== reference.id) throw controlError("CONTROL_INTEGRITY_MISMATCH", path, "journal record id does not match its requested key");
	};
	const proposalFor = async (value) => {
		const proposalId = controlRecordProposalId(value);
		if (proposalId === void 0) return void 0;
		const record = await options.journal.getProposal(proposalId);
		if (record === void 0 || !controlReaderScopeIncludes(scope, record)) return;
		return requireValidProposal(record);
	};
	switch (reference.kind) {
		case "proposal": {
			const record = await options.journal.getProposal(reference.id);
			if (record === void 0) return void 0;
			if (!controlReaderScopeIncludes(scope, record)) return void 0;
			const proposal = await requireValidProposal(record);
			requireRequestedId(proposal.id, "control.reader.proposal.id");
			return publicProposal(proposal);
		}
		case "approval": {
			const raw = await options.journal.getApproval(reference.id);
			if (raw === void 0) return void 0;
			const proposal = await proposalFor(raw);
			if (proposal === void 0) return void 0;
			const approval = snapshotApprovalRecord(raw);
			requireRequestedId(approval.id, "control.reader.approval.id");
			if (!approvalMatchesProposal(approval, proposal)) throw controlError("CONTROL_INTEGRITY_MISMATCH", "control.reader.approval", "approval does not match the exact proposal identity");
			return approval;
		}
		case "grant": {
			const raw = await options.journal.getGrant(reference.id);
			if (raw === void 0) return void 0;
			const proposal = await proposalFor(raw);
			if (proposal === void 0) return void 0;
			const grant = snapshotGrantRecord(raw);
			requireRequestedId(grant.id, "control.reader.grant.id");
			if (!grantMatchesProposal(grant, proposal)) throw controlError("CONTROL_INTEGRITY_MISMATCH", "control.reader.grant", "grant does not match the exact proposal identity");
			return publicGrant(grant);
		}
		case "attempt": {
			const raw = await options.journal.getAttempt(reference.id);
			if (raw === void 0) return void 0;
			const proposal = await proposalFor(raw);
			if (proposal === void 0) return void 0;
			const attempt = snapshotAttemptRecord(raw);
			requireRequestedId(attempt.id, "control.reader.attempt.id");
			const rawGrant = await options.journal.getGrant(attempt.grantId);
			if (rawGrant === void 0) throw controlError("CONTROL_INTEGRITY_MISMATCH", "control.reader.attempt", "attempt references a missing proposal or grant");
			const grant = snapshotGrantRecord(rawGrant);
			if (!grantMatchesProposal(grant, proposal) || !attemptMatches(attempt, proposal, grant)) throw controlError("CONTROL_INTEGRITY_MISMATCH", "control.reader.attempt", "attempt does not match the exact proposal and grant identity");
			return publicAttempt(attempt);
		}
		case "receipt": {
			const raw = await options.journal.getReceipt(reference.id);
			if (raw === void 0) return void 0;
			const proposal = await proposalFor(raw);
			if (proposal === void 0) return void 0;
			const receipt = snapshotReceiptRecord(raw);
			requireRequestedId(receipt.id, "control.reader.receipt.id");
			const [rawGrant, rawAttempt] = await Promise.all([options.journal.getGrant(receipt.grantId), options.journal.getAttempt(receipt.attemptId)]);
			if (rawGrant === void 0 || rawAttempt === void 0) throw controlError("CONTROL_INTEGRITY_MISMATCH", "control.reader.receipt", "receipt references a missing proposal, grant, or attempt");
			const grant = snapshotGrantRecord(rawGrant);
			const attempt = snapshotAttemptRecord(rawAttempt);
			if (!grantMatchesProposal(grant, proposal) || !attemptMatches(attempt, proposal, grant) || !receiptMatches(receipt, attempt, proposal, grant)) throw controlError("CONTROL_INTEGRITY_MISMATCH", "control.reader.receipt", "receipt does not match the exact completed proposal chain");
			return receipt;
		}
		default: throw controlError("CONTROL_INVALID_RECORD", "control.reader.reference.kind", "record kind is invalid");
	}
}
function createControlReader(options, scopeValue) {
	if (!options?.journal || typeof options.journal !== "object") throw new TypeError("control journal is required");
	const scope = snapshotControlReaderScope(scopeValue);
	return Object.freeze({
		get(reference) {
			return publicControlAction("CONTROL_INVALID_RECORD", "control.reader.get", () => getRecord(options, scope, reference));
		},
		status(reference) {
			const proposalId = typeof reference === "string" ? reference : reference.id;
			return publicControlAction("CONTROL_INVALID_RECORD", "control.reader.status", () => statusControl(options.journal, proposalId, scope));
		},
		page(query) {
			return publicControlAction("CONTROL_INVALID_RECORD", "control.reader.page", () => pageControl(options.journal, query, scope));
		},
		list(query) {
			return publicControlAction("CONTROL_INVALID_RECORD", "control.reader.list", () => listControl(options.journal, query, scope));
		}
	});
}
function createControlCapabilities(options, host, readerScope) {
	return Object.freeze({
		requester: createControlRequester(options, host),
		reader: createControlReader(options, readerScope),
		admin: createControlAdmin(options, host)
	});
}
/** Configure Control without importing or assuming an application model. */
function control(options) {
	assertOptions(options);
	const part = Object.freeze({ kind: "boundary.control" });
	controlOptions.set(part, options);
	return part;
}
function isControlPart(value) {
	return value !== null && typeof value === "object" && controlOptions.has(value);
}
function controlPartOptions(part) {
	const options = controlOptions.get(part);
	if (!options) throw new TypeError("unknown control part");
	return options;
}
function installControlPart(part, host, readerScope) {
	const options = controlOptions.get(part);
	if (!options) throw new TypeError("unknown control part");
	return createControlCapabilities(options, host, readerScope);
}
//#endregion
export { targetForControl as A, PUBLIC_GRANT_SCHEMA as C, controlled as D, CONTROL_REALIZATION_DOMAIN as E, normalizePublicProposal as F, proposalDigest as I, publicProposal as L, publicAttempt as M, CONTROL_PROPOSAL_DOMAIN as N, digestControlRealization as O, PUBLIC_PROPOSAL_SCHEMA as P, verifyProposalIntegrity as R, PUBLIC_EFFECT_RESULT_SCHEMA as S, publicGrant as T, CONTROL_PROPOSAL_ID_INPUT_SCHEMA as _, createControlReader as a, PUBLIC_CONTROL_STATUS_LIST_SCHEMA as b, isControlPart as c, pageControl as d, statusControl as f, CONTROL_LIST_INPUT_SCHEMA as g, CONTROL_GRANT_ID_INPUT_SCHEMA as h, createControlCapabilities as i, validateControlHook as j, requireResolvedControl as k, requestForControlRequester as l, CONTROL_ATTEMPT_ID_INPUT_SCHEMA as m, controlPartOptions as n, createControlRequester as o, CONTROL_APPROVE_INPUT_SCHEMA as p, createControlAdmin as r, installControlPart as s, control as t, listControl as u, CONTROL_REQUEST_INPUT_SCHEMA as v, PUBLIC_PROPOSAL_OUTPUT_SCHEMA as w, PUBLIC_CONTROL_STATUS_SCHEMA as x, CONTROL_STATUS_ERROR_SCHEMA as y, CONTROL_RECORD_VERSION as z };
