import { o as AdapterError, r as interactionKey, t as compileBindingResolution } from "./resolution-DipfP_4a.js";
import { createHandoffInvocation, validateHandoffOutcome, validateHandoffOutcomeAgainstManifest } from "@foxworth/boundary/handoff";
//#region packages/core/handoff/src/adapter/remote.ts
async function compileExposure(handoff, selected) {
	return compileBindingResolution(handoff, selected);
}
async function compileHandoffExposure(handoff) {
	const manifest = handoff.manifest;
	const expected = new Map(manifest.expectedProgram.interactions.map((descriptor) => [descriptor.contract.id, descriptor]));
	const modesById = /* @__PURE__ */ new Map();
	for (const interaction of manifest.interactions) {
		const modes = modesById.get(interaction.interactionId) ?? [];
		modes.push(interaction.mode);
		modesById.set(interaction.interactionId, modes);
	}
	const selected = manifest.interactions.map((interaction) => {
		const descriptor = expected.get(interaction.interactionId);
		return Object.freeze({
			handle: Object.freeze({
				interactionId: interaction.interactionId,
				contractDigest: descriptor.contractDigest,
				inputArity: interaction.inputArity,
				modes: Object.freeze(modesById.get(interaction.interactionId))
			}),
			mode: interaction.mode
		});
	});
	return compileBindingResolution(handoff, selected);
}
function outcomeFor(exposure, exposed, certainty, result) {
	return validateHandoffOutcome({
		version: 1,
		bindingDigest: exposure.manifest.bindingDigest,
		installationId: exposure.manifest.installationId,
		interactionId: exposed.binding.interactionId,
		expectedContractDigest: exposed.binding.expectedContractDigest,
		actualContractDigest: exposed.binding.actualContractDigest,
		mode: exposed.binding.mode,
		realizationId: exposed.binding.realizationId,
		certainty,
		result
	});
}
/** Preserve exact Binding pins while sanitizing a failure outside Handoff. */
function sanitizedInternalResult(exposure, exposed) {
	return outcomeFor(exposure, exposed, "unknown", {
		kind: "fault",
		cause: "realization-failed"
	});
}
function faultResult(exposure, exposed, cause, issues) {
	return outcomeFor(exposure, exposed, "not-started", {
		kind: "fault",
		cause,
		...issues === void 0 ? {} : { issues }
	});
}
async function executeExposedInteraction(args) {
	const prepared = await prepareExposedInteraction(args);
	return invokePreparedInteraction(args.exposure, prepared.invocation, args.context);
}
/** Validate and serialize locally, before the consequential dispatch boundary. */
async function prepareExposedInteraction(args) {
	const exposed = args.exposure.interactions.get(interactionKey(args.handle.interactionId, args.mode));
	if (!exposed) throw new AdapterError("INTERACTION_NOT_EXPOSED", args.handle.interactionId, `${args.handle.interactionId} ${args.mode} was not selected for this adapter`);
	const invocation = await createHandoffInvocation(args.exposure.manifest, exposed.binding.interactionId, exposed.binding.mode, args.input);
	return Object.freeze({
		exposed,
		invocation
	});
}
/** The only adapter step that crosses into host dispatch. */
function invokePreparedInteraction(exposure, invocation, context) {
	return exposure.handoff.invoke(invocation, context);
}
async function executeSerializedInvocation(args) {
	const outcome = await args.handoff.invoke(args.invocation, args.context);
	return validateHandoffOutcomeAgainstManifest(args.handoff.manifest, outcome);
}
function statusForRemoteResult(result) {
	if (result.result.kind === "returned") return 200;
	if (result.result.kind === "proposed") return 202;
	if (result.result.kind === "declared-error") return 422;
	if (result.result.kind === "denied") return 403;
	if (result.result.cause === "invalid-input" || result.result.cause === "invalid-invocation") return 400;
	if (result.result.cause === "revoked") return 409;
	return 500;
}
//#endregion
export { faultResult as a, sanitizedInternalResult as c, executeSerializedInvocation as i, statusForRemoteResult as l, compileHandoffExposure as n, invokePreparedInteraction as o, executeExposedInteraction as r, prepareExposedInteraction as s, compileExposure as t };
