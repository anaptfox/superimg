import { c as isInteractionDefinition, f as failHost, n as declaredErrorSchema } from "./definitions-CFjJCGn-.js";
import { compileSchema, composePrograms, createInteractionDescriptor, createProgram, diffPrograms, isPortableSchema, portableSchema } from "@foxworth/boundary/program";
import { zodSchemaAdapter } from "@foxworth/boundary/program/zod";
//#region packages/core/host/src/compile.ts
var compiledMetadata = /* @__PURE__ */ new WeakMap();
var handleMetadata = /* @__PURE__ */ new WeakMap();
var portableAuthoringSchemaAdapter = Object.freeze({
	supports: isPortableSchema,
	compile(schema) {
		return { contract: schema };
	}
});
var builtinSchemaAdapters = Object.freeze([portableAuthoringSchemaAdapter, zodSchemaAdapter]);
function schemaAdapters(value) {
	if (value === void 0) return builtinSchemaAdapters;
	if (value === null || typeof value !== "object" || Array.isArray(value)) return failHost("INVALID_DECLARATION", "compileInteractions.options", "compile options must be an object");
	const unexpected = Reflect.ownKeys(value).find((key) => key !== "schemas");
	if (unexpected !== void 0) return failHost("INVALID_DECLARATION", `compileInteractions.options.${String(unexpected)}`, "compile options support only schema adapters");
	if (value.schemas === void 0) return builtinSchemaAdapters;
	if (!Array.isArray(value.schemas)) return failHost("INVALID_DECLARATION", "compileInteractions.options.schemas", "schema adapters must be an array");
	const explicit = value.schemas.map((adapter, index) => {
		if (adapter === null || typeof adapter !== "object" || typeof adapter.supports !== "function" || typeof adapter.compile !== "function") return failHost("INVALID_DECLARATION", `compileInteractions.options.schemas[${index}]`, "each schema adapter must expose supports and compile functions");
		const supports = adapter.supports;
		const compile = adapter.compile;
		return Object.freeze({
			supports(value) {
				return supports.call(adapter, value);
			},
			compile(schema, context) {
				return compile.call(adapter, schema, context);
			}
		});
	});
	return Object.freeze([...explicit, ...builtinSchemaAdapters.filter((builtin) => !value.schemas.includes(builtin))]);
}
function compileAuthoringSchema(adapters, schema, role, path) {
	let adapter;
	for (const candidate of adapters) {
		let supported;
		try {
			supported = candidate.supports(schema);
		} catch (cause) {
			return failHost("INVALID_DECLARATION", path, "schema adapter support detection failed", cause);
		}
		if (supported) {
			adapter = candidate;
			break;
		}
	}
	if (!adapter) return failHost("INVALID_DECLARATION", path, "no schema adapter supports this authoring schema");
	return compileSchema(schema, adapter, {
		role,
		path
	});
}
function descriptorAnnotations(definition, schemas) {
	const schemaAnnotations = {};
	if (Object.keys(schemas.input).length > 0) schemaAnnotations.input = schemas.input;
	if (Object.keys(schemas.output).length > 0) schemaAnnotations.output = schemas.output;
	if (Object.keys(schemas.errors).length > 0) schemaAnnotations.errors = schemas.errors;
	if (definition.annotations === void 0 && Object.keys(schemaAnnotations).length === 0) return;
	return Object.freeze({
		...definition.annotations ?? {},
		...Object.keys(schemaAnnotations).length === 0 ? {} : { schemas: Object.freeze(schemaAnnotations) }
	});
}
function plainRecord(value, path) {
	if (value === null || typeof value !== "object" || Array.isArray(value)) return failHost("INVALID_DEFINITION_COLLECTION", path, "interactions must be a plain record");
	let prototype;
	try {
		prototype = Object.getPrototypeOf(value);
	} catch (cause) {
		return failHost("INVALID_DEFINITION_COLLECTION", path, "interactions could not be inspected", cause);
	}
	if (prototype !== Object.prototype && prototype !== null) return failHost("INVALID_DEFINITION_COLLECTION", path, "interactions must use a plain-object prototype");
	return value;
}
function dataEntries(value, path) {
	const record = plainRecord(value, path);
	let keys;
	try {
		keys = Reflect.ownKeys(record);
	} catch (cause) {
		return failHost("INVALID_DEFINITION_COLLECTION", path, "interaction keys could not be inspected", cause);
	}
	const entries = [];
	for (const key of keys) {
		if (typeof key !== "string" || !/^[A-Za-z_$][A-Za-z0-9_$]*$/u.test(key)) failHost("INVALID_DEFINITION_COLLECTION", `${path}.${String(key)}`, "interaction aliases must be JavaScript identifier-like strings");
		const descriptor = Object.getOwnPropertyDescriptor(record, key);
		if (!descriptor || !("value" in descriptor) || !descriptor.enumerable) failHost("INVALID_DEFINITION_COLLECTION", `${path}.${key}`, "interaction entries must be enumerable data properties");
		entries.push([key, descriptor.value]);
	}
	return entries;
}
function snapshotDefinitions(value, path = "interactions") {
	const result = {};
	for (const [alias, definition] of dataEntries(value, path)) {
		if (!isInteractionDefinition(definition)) failHost("FORGED_DEFINITION", `${path}.${alias}`, "interaction collections may contain only authentic defineInteraction values");
		Object.defineProperty(result, alias, {
			value: definition,
			enumerable: true,
			writable: false,
			configurable: false
		});
	}
	return Object.freeze(result);
}
async function compileSnapshot(definitions, nativeTargets, adapters) {
	const aliases = Object.keys(definitions);
	const compiledDefinitions = await Promise.all(aliases.map(async (alias) => {
		const definition = definitions[alias];
		const input = compileAuthoringSchema(adapters, definition.input, "input", `${definition.id}.input`);
		const output = compileAuthoringSchema(adapters, definition.output, "output", `${definition.id}.output`);
		const errors = {};
		const errorAnnotations = {};
		for (const [code, source] of Object.entries(definition.errors)) {
			const compiled = compileAuthoringSchema(adapters, source, "error", `${definition.id}.errors.${code}`);
			errors[code] = portableSchema(compiled.contract, `${definition.id}.errors.${code}`);
			if (Object.keys(compiled.annotations).length > 0) errorAnnotations[code] = compiled.annotations;
		}
		const errorSchemas = Object.freeze(errors);
		const annotations = descriptorAnnotations(definition, {
			input: input.annotations,
			output: output.annotations,
			errors: Object.freeze(errorAnnotations)
		});
		const descriptor = await createInteractionDescriptor({
			contract: {
				version: 1,
				id: definition.id,
				inputSchema: input.contract,
				outputSchema: output.contract,
				...Object.keys(errorSchemas).length === 0 ? {} : { errorSchema: declaredErrorSchema(definition.id, errorSchemas) },
				reads: definition.reads,
				changes: definition.changes
			},
			...definition.summary === void 0 && definition.description === void 0 ? {} : { docs: {
				...definition.summary === void 0 ? {} : { summary: definition.summary },
				...definition.description === void 0 ? {} : { description: definition.description }
			} },
			...annotations === void 0 ? {} : { annotations }
		});
		return Object.freeze({
			descriptor,
			errorSchemas
		});
	}));
	const descriptors = compiledDefinitions.map((entry) => entry.descriptor);
	const errorSchemas = new Map(compiledDefinitions.map((entry) => [entry.descriptor.contract.id, entry.errorSchemas]));
	const ids = /* @__PURE__ */ new Set();
	for (const descriptor of descriptors) {
		if (ids.has(descriptor.contract.id)) failHost("DUPLICATE_INTERACTION_ID", `interactions.${descriptor.contract.id}`, `duplicate interaction id: ${descriptor.contract.id}`);
		ids.add(descriptor.contract.id);
	}
	return assembleCompiled(definitions, nativeTargets, await createProgram(descriptors), errorSchemas);
}
function assembleCompiled(definitions, nativeTargets, program, errorSchemas) {
	const aliases = Object.keys(definitions);
	const descriptorsById = new Map(program.interactions.map((descriptor) => [descriptor.contract.id, descriptor]));
	const handles = {};
	const aliasesByDefinition = /* @__PURE__ */ new Map();
	const handlesByDefinition = /* @__PURE__ */ new Map();
	const compiled = {
		program,
		handles
	};
	for (const alias of aliases) {
		const definition = definitions[alias];
		const descriptor = descriptorsById.get(definition.id);
		const handle = Object.freeze({
			interactionId: definition.id,
			contractDigest: descriptor.contractDigest,
			inputArity: definition.inputArity
		});
		Object.defineProperty(handles, alias, {
			value: handle,
			enumerable: true,
			writable: false,
			configurable: false
		});
		aliasesByDefinition.set(definition, alias);
		handlesByDefinition.set(definition, handle);
		handleMetadata.set(handle, {
			compiled,
			alias,
			definition,
			descriptor
		});
	}
	Object.freeze(handles);
	Object.freeze(compiled);
	compiledMetadata.set(compiled, {
		definitions,
		descriptors: descriptorsById,
		aliasesByDefinition,
		handlesByDefinition,
		nativeTargets,
		errorSchemas
	});
	return compiled;
}
async function compileInteractions(source, loweringOrOptions, options) {
	const entries = dataEntries(source, "interactions");
	const lowering = loweringOrOptions !== void 0 && loweringOrOptions !== null && typeof loweringOrOptions === "object" && "lower" in loweringOrOptions && typeof loweringOrOptions.lower === "function" ? loweringOrOptions : void 0;
	if (lowering === void 0) return compileSnapshot(snapshotDefinitions(source), /* @__PURE__ */ new Map(), schemaAdapters(loweringOrOptions));
	if (lowering === null || typeof lowering !== "object" || typeof lowering.lower !== "function") failHost("INVALID_DECLARATION", "lowering", "interaction lowering must expose a lower function");
	const definitions = {};
	const nativeTargets = /* @__PURE__ */ new Map();
	for (const [alias, native] of entries) {
		let definition;
		try {
			definition = await lowering.lower(native, Object.freeze({ alias }));
		} catch (cause) {
			failHost("INVALID_DECLARATION", `lowering.${alias}`, "native interaction lowering failed", cause);
		}
		if (!isInteractionDefinition(definition)) failHost("FORGED_DEFINITION", `lowering.${alias}`, "interaction lowering must return an authentic interaction definition");
		definitions[alias] = definition;
		nativeTargets.set(alias, native);
	}
	return compileSnapshot(Object.freeze(definitions), nativeTargets, schemaAdapters(options));
}
/**
* Compose already-compiled closed records without weakening their typed
* handles. Alias collisions are rejected before Program composition; interaction
* identity conflicts retain Program's structured diagnostics.
*/
async function composeCompiledInteractions(...inputs) {
	const definitions = {};
	const nativeTargets = /* @__PURE__ */ new Map();
	const errorSchemas = /* @__PURE__ */ new Map();
	for (const compiled of inputs) {
		const metadata = metadataForCompiled(compiled);
		for (const [alias, definition] of Object.entries(metadata.definitions)) {
			if (Object.hasOwn(definitions, alias)) failHost("DUPLICATE_INTERACTION_ALIAS", `interactions.${alias}`, `compiled interaction alias is duplicated: ${alias}`);
			definitions[alias] = definition;
			if (metadata.nativeTargets.has(alias)) nativeTargets.set(alias, metadata.nativeTargets.get(alias));
			errorSchemas.set(definition.id, metadata.errorSchemas.get(definition.id) ?? Object.freeze({}));
		}
	}
	const program = await composePrograms(inputs.map((input) => input.program));
	return assembleCompiled(Object.freeze(definitions), nativeTargets, program, errorSchemas);
}
/** Compare portable interaction identity without conflating docs or annotations. */
function diffCompiledInteractions(previous, next) {
	metadataForCompiled(previous);
	metadataForCompiled(next);
	return diffPrograms(previous.program, next.program);
}
function metadataForCompiled(value) {
	if (value === null || typeof value !== "object") return failHost("INVALID_INSTALLATION", "compiled", "an authentic CompiledInteractions value is required");
	const metadata = compiledMetadata.get(value);
	if (!metadata) return failHost("INVALID_INSTALLATION", "compiled", "an authentic CompiledInteractions value is required");
	return metadata;
}
function metadataForHandle(value) {
	if (value === null || typeof value !== "object") return void 0;
	return handleMetadata.get(value);
}
//#endregion
export { metadataForHandle as a, metadataForCompiled as i, composeCompiledInteractions as n, snapshotDefinitions as o, diffCompiledInteractions as r, compileInteractions as t };
