import { f as failHost } from "./definitions-CFjJCGn-.js";
import { a as metadataForHandle, i as metadataForCompiled } from "./compile-Dpp86NdO.js";
import { cloneJson, isSha256Digest, validatePortableSchema } from "@foxworth/boundary/program";
//#region packages/core/host/src/control.ts
var contributionMetadata = /* @__PURE__ */ new WeakMap();
/**
* @internal Support seam consumed by `@foxworth/boundary/control/host`.
*
* JavaScript package exports cannot authenticate which package called a
* function. A direct caller of this support seam is therefore part of the Host
* TCB; artifact authenticity means module-minted and mutation-safe, not that
* arbitrary in-process request code has been proven effect-free.
*/
function createControlRequestContributions(compiled, sources) {
	metadataForCompiled(compiled);
	if (sources === null || typeof sources !== "object" || Array.isArray(sources)) return failHost("INVALID_REQUEST_BINDING", "control.requests", "control request contributions must be a record");
	const entries = /* @__PURE__ */ new Map();
	for (const alias of Reflect.ownKeys(sources)) {
		if (typeof alias !== "string") failHost("INVALID_REQUEST_BINDING", `control.requests.${String(alias)}`, "control request contribution aliases must be strings");
		const property = Object.getOwnPropertyDescriptor(sources, alias);
		if (!property || !("value" in property) || !property.enumerable) failHost("INVALID_REQUEST_BINDING", `control.requests.${alias}`, "control request contributions must be enumerable data properties");
		const source = property.value;
		if (source === null || typeof source !== "object") failHost("INVALID_REQUEST_BINDING", `control.requests.${alias}`, "control request contribution must be an object");
		const interaction = source.interaction;
		const handle = metadataForHandle(interaction);
		if (!handle || handle.compiled !== compiled || handle.alias !== alias) failHost("FOREIGN_HANDLE", `control.requests.${alias}.interaction`, "control request contribution requires this compilation's handle under the same alias");
		const controlDigest = source.controlDigest;
		if (!isSha256Digest(controlDigest)) failHost("INVALID_REQUEST_BINDING", `control.requests.${alias}.controlDigest`, "control request contribution requires an exact control digest");
		const previewSchema = cloneJson(source.previewSchema, `control.requests.${alias}.previewSchema`);
		validatePortableSchema(previewSchema, `control.requests.${alias}.previewSchema`);
		const request = source.request;
		if (typeof request !== "function") failHost("INVALID_REQUEST_BINDING", `control.requests.${alias}.request`, "control request contribution must expose proposal creation");
		entries.set(alias, Object.freeze({
			interaction,
			controlDigest,
			previewSchema,
			request(input, context, policy) {
				return request.call(void 0, input, context, policy);
			}
		}));
	}
	const artifact = Object.freeze({});
	contributionMetadata.set(artifact, Object.freeze({ entries }));
	return artifact;
}
/** @internal Host installation authenticity check. */
function metadataForControlRequestContributions(value) {
	if (value === null || typeof value !== "object") return failHost("INVALID_REQUEST_BINDING", "requests", "an authentic Host request contribution artifact is required");
	const metadata = contributionMetadata.get(value);
	if (!metadata) return failHost("INVALID_REQUEST_BINDING", "requests", "an authentic Host request contribution artifact is required");
	return metadata;
}
//#endregion
export { metadataForControlRequestContributions as n, createControlRequestContributions as t };
