import { BoundaryErrorBase, cloneJson, compareUtf8, isInteractionId } from "@foxworth/boundary/program";
//#region packages/core/control/src/errors.ts
/** Stable pre-attempt failure. Once an attempt exists, failures are contained. */
var ControlError = class extends BoundaryErrorBase {
	constructor(code, path, message, options = {}) {
		super(code, path, message, options);
		this.name = "ControlError";
	}
};
function controlError(code, path, message, cause) {
	return new ControlError(code, path, message, { cause });
}
//#endregion
//#region packages/core/control/src/readerScope.ts
function invalidScope(path, message) {
	throw new TypeError(`${path}: ${message}`);
}
function portableSnapshot(value, path) {
	try {
		return cloneJson(value, path);
	} catch {
		return invalidScope(path, "scope must be exact portable data");
	}
}
function exactKeys(value, expected, path) {
	const unexpected = Object.keys(value).find((key) => !expected.includes(key));
	if (unexpected !== void 0) invalidScope(`${path}.${unexpected}`, "unexpected scope field");
	const missing = expected.find((key) => !Object.hasOwn(value, key));
	if (missing !== void 0) invalidScope(`${path}.${missing}`, "required scope field is missing");
}
function subject(value, path) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return invalidScope(path, "tenant must be an exact subject");
	const raw = value;
	exactKeys(raw, ["kind", "id"], path);
	if (typeof raw.kind !== "string" || raw.kind.trim().length === 0) invalidScope(`${path}.kind`, "tenant kind must be a non-empty string");
	if (typeof raw.id !== "string" || raw.id.trim().length === 0) invalidScope(`${path}.id`, "tenant id must be a non-empty string");
	return Object.freeze({
		kind: raw.kind,
		id: raw.id
	});
}
/** Snapshot caller-owned scope data so later mutation cannot widen observation. */
function snapshotControlReaderScope(value) {
	const owned = portableSnapshot(value, "control.reader.scope");
	if (!owned || typeof owned !== "object" || Array.isArray(owned)) return invalidScope("control.reader.scope", "scope is required");
	const raw = owned;
	exactKeys(raw, ["interactionIds", "tenant"], "control.reader.scope");
	if (!Array.isArray(raw.interactionIds) || raw.interactionIds.length === 0) invalidScope("control.reader.scope.interactionIds", "at least one interaction id is required");
	const interactionIds = raw.interactionIds.map((interactionId, index) => {
		if (!isInteractionId(interactionId)) return invalidScope(`control.reader.scope.interactionIds[${index}]`, "interaction id is invalid");
		return interactionId;
	});
	if (new Set(interactionIds).size !== interactionIds.length) invalidScope("control.reader.scope.interactionIds", "interaction ids must be unique");
	interactionIds.sort(compareUtf8);
	return Object.freeze({
		interactionIds: Object.freeze(interactionIds),
		tenant: subject(raw.tenant, "control.reader.scope.tenant")
	});
}
function scopedProposalIdentity(value) {
	let owned;
	try {
		owned = cloneJson(value, "control.reader.record");
	} catch {
		return;
	}
	if (!owned || typeof owned !== "object" || Array.isArray(owned)) return;
	const raw = owned;
	if (!isInteractionId(raw.interactionId)) return void 0;
	const rawSubject = raw.subject;
	if (!rawSubject || typeof rawSubject !== "object" || Array.isArray(rawSubject)) return;
	const candidate = rawSubject;
	if (typeof candidate.kind !== "string" || typeof candidate.id !== "string") return;
	return Object.freeze({
		interactionId: raw.interactionId,
		subject: Object.freeze({
			kind: candidate.kind,
			id: candidate.id
		})
	});
}
function controlReaderScopeIncludes(scope, proposal) {
	const identity = scopedProposalIdentity(proposal);
	return identity !== void 0 && scope.interactionIds.includes(identity.interactionId) && identity.subject.kind === scope.tenant.kind && identity.subject.id === scope.tenant.id;
}
function controlRecordProposalId(value) {
	let owned;
	try {
		owned = cloneJson(value, "control.reader.record");
	} catch {
		return;
	}
	if (!owned || typeof owned !== "object" || Array.isArray(owned)) return;
	const proposalId = owned.proposalId;
	return typeof proposalId === "string" && proposalId.trim().length > 0 ? proposalId : void 0;
}
//#endregion
export { controlError as a, ControlError as i, controlRecordProposalId as n, snapshotControlReaderScope as r, controlReaderScopeIncludes as t };
