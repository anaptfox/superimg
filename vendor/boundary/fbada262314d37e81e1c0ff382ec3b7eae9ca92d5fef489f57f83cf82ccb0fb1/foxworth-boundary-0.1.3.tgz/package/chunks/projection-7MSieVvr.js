import { f as failHost } from "./definitions-CFjJCGn-.js";
import { a as metadataForHandle, i as metadataForCompiled } from "./compile-Dpp86NdO.js";
import { compareUtf8, createProgram, hashJson } from "@foxworth/boundary/program";
//#region packages/core/host/src/direct.ts
/** Closed projection selection for one compiled handle in direct mode. */
function direct(handle) {
	return Object.freeze({
		interaction: handle,
		modes: Object.freeze(["direct"])
	});
}
/**
* Host-owned direct realization IDs keyed by compiled alias and release revision.
* The host still passes this record into `installInteractions`.
*/
function directRealizationIds(compiled, revision) {
	metadataForCompiled(compiled);
	if (typeof revision !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,127}$/u.test(revision)) return failHost("INVALID_REALIZATION_ID", "revision", "an explicit host-issued realization revision is required");
	const ids = {};
	for (const [alias, handle] of Object.entries(compiled.handles)) {
		const id = `${handle.interactionId}:direct:${revision}`;
		if (!/^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u.test(id)) return failHost("INVALID_REALIZATION_ID", `realizationIds.${alias}`, "interaction and revision must form a valid realization ID; supply explicit IDs for other interaction names");
		ids[alias] = Object.freeze({ direct: id });
	}
	return Object.freeze(ids);
}
//#endregion
//#region packages/core/host/src/projection.ts
var PROJECTION_DOMAIN = "boundary.projection/v1";
var projectionMetadata = /* @__PURE__ */ new WeakMap();
var projectedHandleMetadata = /* @__PURE__ */ new WeakMap();
function normalizeModes(value, path) {
	if (!Array.isArray(value) || value.length === 0) return failHost("INVALID_PROJECTION", path, "projection modes must be a non-empty array");
	const modes = [...new Set(value)];
	if (modes.some((mode) => mode !== "direct" && mode !== "request")) return failHost("INVALID_PROJECTION", path, "projection modes may contain only \"direct\" and \"request\"");
	return Object.freeze(modes.sort(compareUtf8));
}
async function projectInteractions(compiled, selections) {
	metadataForCompiled(compiled);
	if (selections === null || typeof selections !== "object" || Array.isArray(selections)) return failHost("INVALID_PROJECTION", "selections", "projection selections must be a closed record");
	const lowered = Object.create(null);
	for (const alias of Reflect.ownKeys(selections)) {
		const property = Object.getOwnPropertyDescriptor(selections, alias);
		if (typeof alias !== "string" || !property.enumerable || !("value" in property)) return failHost("INVALID_PROJECTION", "selections", "selection aliases must be enumerable data properties");
		const value = property.value;
		if (typeof value === "string") {
			const handle = Object.getOwnPropertyDescriptor(compiled.handles, alias)?.value;
			if (handle === void 0 || value !== "direct" && value !== "request") return failHost("INVALID_PROJECTION", `selections.${alias}`, "shorthand requires a compiled alias and an explicit mode");
			lowered[alias] = Object.freeze({
				interaction: handle,
				modes: Object.freeze([value])
			});
		} else lowered[alias] = value;
	}
	return projectExplicit(compiled, lowered);
}
async function projectExplicit(compiled, selections) {
	const compiledMeta = metadataForCompiled(compiled);
	if (selections === null || typeof selections !== "object" || Array.isArray(selections)) return failHost("INVALID_PROJECTION", "selections", "projection selections must be a closed record");
	const selectionKeys = Reflect.ownKeys(selections);
	const handles = {};
	const byAlias = /* @__PURE__ */ new Map();
	const selectedIds = /* @__PURE__ */ new Set();
	for (const alias of selectionKeys) {
		if (typeof alias !== "string" || !/^[A-Za-z_$][A-Za-z0-9_$]*$/u.test(alias)) failHost("INVALID_PROJECTION", `selections.${String(alias)}`, "projection aliases must be JavaScript identifier-like strings");
		const property = Object.getOwnPropertyDescriptor(selections, alias);
		if (!property || !("value" in property) || !property.enumerable) failHost("INVALID_PROJECTION", `selections.${alias}`, "projection selections must be enumerable data properties");
		const selection = property.value;
		if (selection === null || typeof selection !== "object" || Array.isArray(selection)) failHost("INVALID_PROJECTION", `selections.${alias}`, "each projection selection must be an object");
		const source = selection.interaction;
		const sourceMeta = metadataForHandle(source);
		if (!sourceMeta || sourceMeta.compiled !== compiled) failHost("FOREIGN_HANDLE", `selections.${alias}.interaction`, "projection selections require handles from this compilation");
		if (selectedIds.has(sourceMeta.definition.id)) failHost("DUPLICATE_PROJECTION_INTERACTION", `selections.${alias}.interaction`, "one Projection may select an interaction only once");
		selectedIds.add(sourceMeta.definition.id);
		const modes = normalizeModes(selection.modes, `selections.${alias}.modes`);
		const handle = Object.freeze({
			interactionId: source.interactionId,
			contractDigest: source.contractDigest,
			inputArity: source.inputArity,
			modes
		});
		const interaction = Object.freeze({
			alias,
			interactionId: source.interactionId,
			expectedContractDigest: source.contractDigest,
			inputArity: source.inputArity,
			modes
		});
		Object.defineProperty(handles, alias, {
			value: handle,
			enumerable: true,
			writable: false,
			configurable: false
		});
		byAlias.set(alias, {
			alias,
			handle,
			interaction
		});
	}
	const descriptors = [...selectedIds].map((id) => compiledMeta.descriptors.get(id));
	const program = await createProgram(descriptors);
	const interactions = Object.freeze([...byAlias.values()].map((entry) => entry.interaction).sort((left, right) => compareUtf8(left.alias, right.alias)));
	const identity = Object.freeze({
		program: program.programDigest,
		interactions: Object.freeze(interactions.map((interaction) => Object.freeze({
			alias: interaction.alias,
			interaction: interaction.interactionId,
			contract: interaction.expectedContractDigest,
			arity: interaction.inputArity === 0 ? "zero" : "one",
			modes: interaction.modes.length === 2 ? "direct-and-request" : interaction.modes[0]
		})))
	});
	const projectionDigest = await hashJson(PROJECTION_DOMAIN, identity);
	const manifest = Object.freeze({
		version: 1,
		program,
		interactions,
		projectionDigest
	});
	Object.freeze(handles);
	const projection = Object.freeze({
		program,
		interactions,
		projectionDigest,
		handles,
		manifest
	});
	projectionMetadata.set(projection, {
		compiled,
		aliases: byAlias
	});
	for (const entry of byAlias.values()) projectedHandleMetadata.set(entry.handle, {
		projection,
		alias: entry.alias,
		source: selections[entry.alias].interaction
	});
	return projection;
}
function metadataForProjection(value) {
	if (value === null || typeof value !== "object") return failHost("INVALID_PROJECTION", "projection", "an authentic Projection value is required");
	const metadata = projectionMetadata.get(value);
	if (!metadata) return failHost("INVALID_PROJECTION", "projection", "an authentic Projection value is required");
	return metadata;
}
function metadataForProjectedHandle(value) {
	if (value === null || typeof value !== "object") return void 0;
	return projectedHandleMetadata.get(value);
}
/** Project every compiled handle in direct mode. */
async function projectAllDirect(compiled) {
	metadataForCompiled(compiled);
	return projectInteractions(compiled, Object.fromEntries(Object.entries(compiled.handles).map(([alias, handle]) => [alias, direct(handle)])));
}
function resolvePickEntry(aliases, key) {
	const byAlias = aliases.get(key);
	if (byAlias) return byAlias;
	for (const entry of aliases.values()) if (entry.handle.interactionId === key) return entry;
}
async function pickProjection(projection, ...keys) {
	const meta = metadataForProjection(projection);
	if (new Set(keys).size !== keys.length) return failHost("INVALID_PROJECTION", "pickProjection", "pickProjection aliases must be unique");
	const selections = {};
	const seen = /* @__PURE__ */ new Set();
	for (const key of keys) {
		const entry = resolvePickEntry(meta.aliases, key);
		const source = metadataForProjectedHandle(entry?.handle)?.source;
		if (!entry || source === void 0 || typeof source !== "object") return failHost("INVALID_PROJECTION", `pickProjection.${key}`, "alias is not in this Projection");
		if (seen.has(entry.alias)) return failHost("INVALID_PROJECTION", "pickProjection", "pickProjection aliases must be unique");
		seen.add(entry.alias);
		selections[entry.alias] = Object.freeze({
			interaction: source,
			modes: entry.handle.modes
		});
	}
	return projectInteractions(meta.compiled, selections);
}
//#endregion
export { projectInteractions as a, projectAllDirect as i, metadataForProjection as n, direct as o, pickProjection as r, directRealizationIds as s, metadataForProjectedHandle as t };
