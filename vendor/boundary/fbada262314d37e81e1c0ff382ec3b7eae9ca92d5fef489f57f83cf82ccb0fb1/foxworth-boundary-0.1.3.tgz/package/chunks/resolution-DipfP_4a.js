import { BoundaryErrorBase, bindingDescriptions, isInteractionId, isSha256Digest, snapshotJson } from "@foxworth/boundary/program";
//#region packages/core/handoff/src/adapter/errors.ts
var AdapterError = class extends BoundaryErrorBase {
	constructor(code, path, message, options = {}) {
		super(code, path, message, options);
		Object.defineProperty(this, "cause", { enumerable: false });
		this.name = "AdapterError";
	}
};
/** A validated server diagnostic proving dispatch did not begin. */
var RemoteProtocolRejection = class extends AdapterError {
	certainty = "not-started";
	status;
	remoteCode;
	constructor(status, remoteCode, path) {
		super(status === 409 ? "STALE_BINDING" : "INVALID_REQUEST", path, `the remote protocol rejected the invocation: ${remoteCode}`);
		this.name = "RemoteProtocolRejection";
		this.status = status;
		this.remoteCode = remoteCode;
	}
};
var RemoteDomainError = class extends BoundaryErrorBase {
	interactionId;
	expectedContractDigest;
	value;
	constructor(interactionId, expectedContractDigest, value) {
		super("REMOTE_DOMAIN_ERROR", `${interactionId}.error`, "the interaction returned a declared domain error");
		this.name = "RemoteDomainError";
		this.interactionId = interactionId;
		this.expectedContractDigest = expectedContractDigest;
		this.value = value;
	}
};
function isDomainErrorFor(handle, error) {
	return error instanceof RemoteDomainError && error.interactionId === handle.interactionId && error.expectedContractDigest === handle.contractDigest;
}
/** The invocation crossed the dispatch boundary, so its consequence is unknown. */
var RemoteInvocationError = class extends BoundaryErrorBase {
	certainty = "unknown";
	phase;
	constructor(phase, message, options = {}) {
		super("REMOTE_INVOCATION_FAILED", "transport.invoke", message, options);
		Object.defineProperty(this, "cause", { enumerable: false });
		this.name = "RemoteInvocationError";
		this.phase = phase;
	}
};
var RemoteProtocolError = class extends BoundaryErrorBase {
	certainty;
	constructor(code, path, message, certainty = "not-started") {
		super(code, path, message);
		this.name = "RemoteProtocolError";
		this.certainty = certainty;
	}
};
var RemoteExecutionError = class extends BoundaryErrorBase {
	certainty;
	cause;
	issues;
	constructor(path, certainty, cause, issues) {
		super("REMOTE_EXECUTION_FAILED", path, "the interaction could not be completed");
		this.name = "RemoteExecutionError";
		this.certainty = certainty;
		this.cause = cause;
		if (issues !== void 0) this.issues = Object.freeze(issues.map((issue) => Object.freeze({
			path: issue.path,
			message: issue.message
		})));
	}
};
//#endregion
//#region packages/core/handoff/src/adapter/resolution.ts
function fail(code, path, message) {
	throw new AdapterError(code, path, message);
}
function interactionKey(interactionId, mode) {
	return `${interactionId}\u0000${mode}`;
}
/** Snapshot the public data carried by a projected handle. */
var projectedHandles = /* @__PURE__ */ new WeakSet();
function snapshotProjectedHandle(value, path = "interaction") {
	if (!value || typeof value !== "object" || Array.isArray(value)) return fail("INVALID_DECLARATION", path, "a projected interaction handle is required");
	if (projectedHandles.has(value)) return value;
	const owned = snapshotJson(value, {
		path,
		fail: (failure) => fail("INVALID_DECLARATION", failure.path, failure.message)
	});
	const interactionId = owned.interactionId;
	const contractDigest = owned.contractDigest;
	const inputArity = owned.inputArity;
	const modes = owned.modes;
	if (!isInteractionId(interactionId)) return fail("INVALID_DECLARATION", `${path}.interactionId`, "interactionId is invalid");
	if (!isSha256Digest(contractDigest)) return fail("INVALID_DECLARATION", `${path}.contractDigest`, "contractDigest is invalid");
	if (inputArity !== 0 && inputArity !== 1) return fail("INVALID_DECLARATION", `${path}.inputArity`, "inputArity must be 0 or 1");
	if (!Array.isArray(modes) || modes.length === 0 || modes.some((mode) => mode !== "direct" && mode !== "request") || new Set(modes).size !== modes.length) return fail("INVALID_DECLARATION", `${path}.modes`, "modes must be a non-empty unique direct/request list");
	const snapshot = Object.freeze({
		interactionId,
		contractDigest,
		inputArity,
		modes: Object.freeze([...modes])
	});
	projectedHandles.add(snapshot);
	return snapshot;
}
function modeForHandle(handle, requested, path) {
	if (requested !== void 0) {
		if (!handle.modes.includes(requested)) return fail("INTERACTION_NOT_EXPOSED", path, `${requested} mode is not selected by this handle`);
		return requested;
	}
	if (handle.modes.length !== 1) return fail("INVALID_DECLARATION", path, "mode is required when a handle exposes both direct and request");
	return handle.modes[0];
}
async function compileBindingResolution(handoff, selected) {
	const manifest = handoff.manifest;
	const descriptions = bindingDescriptions(manifest);
	const interactions = /* @__PURE__ */ new Map();
	for (const [index, declaration] of selected.entries()) {
		const handle = snapshotProjectedHandle(declaration.handle, `interactions[${index}].handle`);
		if (!handle.modes.includes(declaration.mode)) fail("INTERACTION_NOT_EXPOSED", `interactions[${index}].mode`, "mode is absent from the projected handle");
		const description = descriptions.find((candidate) => candidate.interactionId === handle.interactionId && candidate.mode === declaration.mode);
		if (!description) fail("INTERACTION_NOT_EXPOSED", `interactions[${index}]`, `${handle.interactionId} ${declaration.mode} is absent from this Binding`);
		const { expected: expectedDescriptor, actual: actualDescriptor, ...binding } = description;
		if (handle.contractDigest !== binding.expectedContractDigest || handle.inputArity !== binding.inputArity) fail("STALE_REFERENCE", `interactions[${index}]`, "projected handle does not match the Binding's expected contract and arity");
		const key = interactionKey(handle.interactionId, declaration.mode);
		if (interactions.has(key)) continue;
		interactions.set(key, Object.freeze({
			handle,
			mode: declaration.mode,
			expected: expectedDescriptor,
			actual: actualDescriptor,
			binding
		}));
	}
	return Object.freeze({
		handoff,
		manifest,
		interactions
	});
}
async function compileProjectionResolution(projection, selected) {
	if (!projection || typeof projection !== "object" || !projection.manifest) return fail("INVALID_DECLARATION", "projection", "an authentic Projection is required");
	const descriptors = new Map(projection.program.interactions.map((descriptor) => [descriptor.contract.id, descriptor]));
	const projectionInteractions = new Map(projection.interactions.map((interaction) => [interaction.interactionId, interaction]));
	const authenticHandles = new Set(Object.values(projection.handles));
	const interactions = /* @__PURE__ */ new Map();
	for (const [index, declaration] of selected.entries()) {
		if (!authenticHandles.has(declaration.handle)) fail("INVALID_DECLARATION", `interactions[${index}].handle`, "handle must belong to this Projection");
		const handle = snapshotProjectedHandle(declaration.handle, `interactions[${index}].handle`);
		const interaction = projectionInteractions.get(handle.interactionId);
		const descriptor = descriptors.get(handle.interactionId);
		if (!interaction || !descriptor || interaction.expectedContractDigest !== handle.contractDigest || interaction.inputArity !== handle.inputArity || !interaction.modes.includes(declaration.mode)) fail("INTERACTION_NOT_EXPOSED", `interactions[${index}]`, "handle and mode are absent from this Projection");
		const key = interactionKey(handle.interactionId, declaration.mode);
		if (interactions.has(key)) continue;
		interactions.set(key, Object.freeze({
			handle,
			mode: declaration.mode,
			descriptor
		}));
	}
	return Object.freeze({
		projection,
		interactions
	});
}
//#endregion
export { snapshotProjectedHandle as a, RemoteExecutionError as c, RemoteProtocolRejection as d, isDomainErrorFor as f, modeForHandle as i, RemoteInvocationError as l, compileProjectionResolution as n, AdapterError as o, interactionKey as r, RemoteDomainError as s, compileBindingResolution as t, RemoteProtocolError as u };
