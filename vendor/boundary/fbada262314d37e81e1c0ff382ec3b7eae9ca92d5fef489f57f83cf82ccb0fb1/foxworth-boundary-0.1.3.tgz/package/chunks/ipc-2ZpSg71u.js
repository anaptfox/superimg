import { fetchTransport } from "@foxworth/boundary/http/protocol";
//#region packages/adapters/electron/src/dispatch.ts
function headersFrom(entries) {
	const headers = new Headers();
	for (const [name, value] of entries) headers.append(name, value);
	return headers;
}
/** Resolve a renderer fetch input against the in-process projection origin. */
function projectionRequest(input, origin, init) {
	if (input instanceof Request) return init === void 0 ? input : new Request(input, init);
	return new Request(new URL(String(input), origin), init);
}
async function serializeFetchRequest(request) {
	return Object.freeze({
		url: request.url,
		method: request.method,
		headers: Object.freeze([...request.headers.entries()]),
		body: request.method === "GET" || request.method === "HEAD" ? null : await request.text()
	});
}
function deserializeFetchRequest(wire) {
	const method = wire.method || "GET";
	const hasBody = method !== "GET" && method !== "HEAD" && wire.body !== null;
	return new Request(wire.url, {
		method,
		headers: headersFrom(wire.headers),
		...hasBody ? { body: wire.body } : {}
	});
}
async function serializeFetchResponse(response) {
	return Object.freeze({
		status: response.status,
		statusText: response.statusText,
		headers: Object.freeze([...response.headers.entries()]),
		body: response.body === null ? null : await response.text()
	});
}
function deserializeFetchResponse(wire) {
	return new Response(wire.body, {
		status: wire.status,
		statusText: wire.statusText,
		headers: headersFrom(wire.headers)
	});
}
function internalError() {
	return new Response("Internal Server Error", {
		status: 500,
		headers: { "content-type": "text/plain; charset=utf-8" }
	});
}
/** Run one injected handler and never leak thrown values. */
async function dispatchHandler(handler, request) {
	try {
		return await handler(request);
	} catch {
		return internalError();
	}
}
//#endregion
//#region packages/adapters/electron/src/ipc.ts
function ipcFetchChannel(channel) {
	if (!channel.trim()) throw new TypeError("@foxworth/boundary/electron: IPC channel must be non-empty");
	return `${channel}:fetch`;
}
/** Main-process IPC door: reconstruct a Request and call the same handler. */
function installElectronIpcBridge(ipc, handler, channel, options) {
	const fetchChannel = ipcFetchChannel(channel);
	ipc.handle(fetchChannel, async (event, payload) => {
		try {
			if (!await options.validateSender(event)) return await serializeFetchResponse(new Response("Forbidden", { status: 403 }));
			return await serializeFetchResponse(await dispatchHandler(options.ipcHandler !== void 0 && options.createContext !== void 0 ? async (request) => {
				const context = await options.createContext(event);
				if (!await options.validateSender(event)) return new Response("Forbidden", { status: 403 });
				return options.ipcHandler(request, context);
			} : handler, deserializeFetchRequest(payload)));
		} catch {
			return serializeFetchResponse(internalError());
		}
	});
	return () => {
		ipc.removeHandler?.(fetchChannel);
	};
}
/** Validate one exact WebContents and main frame pair; URL alone is insufficient. */
function allowElectronSender(expected) {
	const sender = expected.sender;
	const frame = expected.frame;
	const url = expected.url;
	return (event) => event.sender === sender && event.senderFrame === frame && !sender.isDestroyed() && !frame.isDestroyed() && sender.mainFrame === frame && frame.parent === null && frame.url === url;
}
/**
* Preload/renderer fetch that posts through `ipcRenderer.invoke`.
* Relative URLs resolve against the host-owned `baseUrl`.
*/
function createElectronIpcFetch(invoke, options) {
	const fetchChannel = ipcFetchChannel(options.channel);
	return async (input, init) => {
		const payload = await serializeFetchRequest(projectionRequest(input, options.baseUrl, init));
		return deserializeFetchResponse(await invoke(fetchChannel, payload));
	};
}
/** Typed projection client transport over the IPC fetch bridge. */
function electronIpcTransport(options) {
	return fetchTransport({
		baseUrl: options.baseUrl,
		fetch: createElectronIpcFetch(options.invoke, {
			channel: options.channel,
			baseUrl: options.baseUrl
		}),
		...options.headers === void 0 ? {} : { headers: options.headers }
	});
}
//#endregion
export { ipcFetchChannel as a, dispatchHandler as c, serializeFetchResponse as d, installElectronIpcBridge as i, projectionRequest as l, createElectronIpcFetch as n, deserializeFetchRequest as o, electronIpcTransport as r, deserializeFetchResponse as s, allowElectronSender as t, serializeFetchRequest as u };
