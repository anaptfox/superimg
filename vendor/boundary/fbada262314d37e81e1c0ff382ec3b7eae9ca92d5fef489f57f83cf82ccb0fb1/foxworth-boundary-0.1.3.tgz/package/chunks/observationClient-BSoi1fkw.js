import { invalidateReadsForObservation, refreshReadsForClient } from "../client/cache.js";
//#region packages/callers/client/src/observationParser.ts
/** Internal SSE framing; reconnect and observation authority belong to the caller. */
function createObservationParser() {
	const limit = 65536;
	const fragments = [];
	const data = [];
	let pendingLength = 0;
	let size = 0;
	let event = "";
	let skipLf = false;
	let failed = false;
	const append = (fragment) => {
		if (size + pendingLength + fragment.length > limit) {
			failed = true;
			fragments.length = 0;
			data.length = 0;
			event = "";
			throw new Error("observation event exceeds size limit");
		}
		fragments.push(fragment);
		pendingLength += fragment.length;
	};
	const line = () => {
		const value = fragments.join("");
		fragments.length = 0;
		size += pendingLength;
		pendingLength = 0;
		if (value === "") {
			const result = data.length > 0 ? {
				event: event || "message",
				data: data.join("\n")
			} : void 0;
			data.length = 0;
			event = "";
			size = 0;
			return result;
		}
		if (value.startsWith(":")) return;
		const colon = value.indexOf(":");
		const field = colon < 0 ? value : value.slice(0, colon);
		let content = colon < 0 ? "" : value.slice(colon + 1);
		if (content.startsWith(" ")) content = content.slice(1);
		if (field === "event") event = content;
		else if (field === "data") data.push(content);
	};
	function* feed(chunk) {
		if (failed) throw new Error("observation event exceeds size limit");
		let start = 0;
		if (skipLf && chunk.length > 0) {
			skipLf = false;
			if (chunk.charCodeAt(0) === 10) start = 1;
		}
		for (let cursor = start; cursor < chunk.length; cursor += 1) {
			const code = chunk.charCodeAt(cursor);
			if (code !== 10 && code !== 13) continue;
			if (cursor > start) append(chunk.slice(start, cursor));
			const result = line();
			if (code === 13) {
				if (chunk.charCodeAt(cursor + 1) === 10) cursor += 1;
				else if (cursor === chunk.length - 1) skipLf = true;
			}
			start = cursor + 1;
			if (result) yield result;
		}
		if (start < chunk.length) append(chunk.slice(start));
	}
	return { feed };
}
//#endregion
//#region packages/callers/client/src/observationClient.ts
/** Subscribe to host-selected observations. Never invokes or retries a change. */
function subscribeToObservations(client, options) {
	const fetcher = options.fetch ?? globalThis.fetch;
	const headers = new Headers(options.headers);
	headers.set("accept", "text/event-stream");
	let generation = 0;
	let state = "disconnected";
	let active;
	let activeReader;
	let cancelReady;
	const stop = () => {
		generation += 1;
		active?.abort();
		active = void 0;
		const reader = activeReader;
		activeReader = void 0;
		reader?.cancel().catch(() => {});
		cancelReady?.();
		cancelReady = void 0;
		if (state !== "disposed") state = "disconnected";
	};
	const start = () => {
		if (state === "disposed") return Promise.reject(/* @__PURE__ */ new Error("observation subscription is disposed"));
		stop();
		const mine = generation;
		const abort = new AbortController();
		active = abort;
		state = "connecting";
		let resolve;
		let reject;
		const ready = new Promise((yes, no) => {
			resolve = yes;
			reject = no;
		});
		ready.catch(() => {});
		cancelReady = () => reject(/* @__PURE__ */ new Error("observation subscription disconnected before readiness"));
		(async () => {
			let reader;
			try {
				const response = await fetcher(options.url, {
					headers,
					credentials: options.credentials ?? "same-origin",
					signal: abort.signal
				});
				if (mine !== generation) {
					await response.body?.cancel();
					return;
				}
				if (!response.ok || !response.headers.get("content-type")?.toLowerCase().startsWith("text/event-stream") || !response.body) {
					await response.body?.cancel();
					throw new Error(`observation subscription rejected (${response.status})`);
				}
				reader = response.body.getReader();
				activeReader = reader;
				const decoder = new TextDecoder();
				const parser = createObservationParser();
				let readySeen = false;
				const dispatch = async ({ event, data }) => {
					if (mine !== generation) return;
					if (event === "ready" && !readySeen) {
						readySeen = true;
						await refreshReadsForClient(client, options.scope);
						if (mine !== generation) return;
						state = "connected";
						cancelReady = void 0;
						resolve();
					} else if (event === "observation") await invalidateReadsForObservation(JSON.parse(data), options.scope);
				};
				while (mine === generation) {
					const chunk = await reader.read();
					if (mine !== generation) break;
					const text = chunk.done ? decoder.decode() : decoder.decode(chunk.value, { stream: true });
					for (const frame of parser.feed(text)) {
						await dispatch(frame);
						if (mine !== generation) break;
					}
					if (chunk.done) throw new Error("observation stream disconnected; reconnect to refresh reads");
				}
			} catch (caught) {
				if (mine !== generation) return;
				state = "disconnected";
				cancelReady = void 0;
				const error = caught instanceof Error ? caught : new Error(String(caught));
				reject(error);
				try {
					options.onError?.(error);
				} catch {}
			} finally {
				await reader?.cancel().catch(() => {});
				reader?.releaseLock();
				if (activeReader === reader) activeReader = void 0;
				if (mine === generation) active = void 0;
			}
		})();
		return ready;
	};
	const ready = start();
	return Object.freeze({
		ready,
		get state() {
			return state;
		},
		disconnect: stop,
		reconnect: start,
		dispose() {
			stop();
			state = "disposed";
		}
	});
}
//#endregion
export { subscribeToObservations as t };
