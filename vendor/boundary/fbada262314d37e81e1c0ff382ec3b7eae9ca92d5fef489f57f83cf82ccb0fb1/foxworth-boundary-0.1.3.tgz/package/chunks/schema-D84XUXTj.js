//#region packages/core/program/src/errors.ts
/**
* One error base for the Boundary production libraries. Every stable diagnostic
* class is a thin subclass: it owns its own diagnostic code union and any
* extra fields, but shares this message template and cause plumbing.
*/
var BoundaryErrorBase = class extends Error {
	code;
	path;
	cause;
	constructor(code, path, message, options = {}) {
		super(`${code} at ${path}: ${message}`);
		this.code = code;
		this.path = path;
		if (options.cause !== void 0) this.cause = options.cause;
	}
};
//#endregion
//#region packages/core/program/src/json.ts
var ownedJson = /* @__PURE__ */ new WeakSet();
var ownedObjectKeys = /* @__PURE__ */ new WeakMap();
function isOwnedJson(value) {
	return ownedJson.has(value);
}
var JsonError = class extends BoundaryErrorBase {
	constructor(code, path, message) {
		super(code, path, message);
		this.name = "JsonError";
	}
};
var encoder = new TextEncoder();
var unpairedSurrogate = /[\ud800-\udfff]/u;
function fail$1(code, path, message) {
	throw new JsonError(code, path, message);
}
/** Compare strings by UTF-8 bytes, independent of locale and runtime. */
function compareUtf8(left, right) {
	if (left === right) return 0;
	const units = Math.min(left.length, right.length);
	for (let index = 0; index < units; index += 1) {
		const a = left.charCodeAt(index);
		const b = right.charCodeAt(index);
		if (a >= 128 || b >= 128) break;
		if (a !== b) return a - b;
	}
	const a = encoder.encode(left);
	const b = encoder.encode(right);
	const length = Math.min(a.length, b.length);
	for (let index = 0; index < length; index += 1) {
		const difference = a[index] - b[index];
		if (difference !== 0) return difference;
	}
	return a.length - b.length;
}
function propertyPath$2(path, key) {
	return /^[A-Za-z_$][A-Za-z0-9_$]*$/u.test(key) ? `${path}.${key}` : `${path}[${JSON.stringify(key)}]`;
}
function assertUnicodeScalarString(value, path) {
	if (unpairedSurrogate.test(value)) fail$1("JSON_INVALID_UNICODE", path, "strings must not contain an unpaired UTF-16 surrogate");
}
function prototypeOf(value, path) {
	try {
		return Object.getPrototypeOf(value);
	} catch {
		return fail$1("JSON_INSPECTION_FAILED", path, "object prototype could not be inspected");
	}
}
function ownKeys(value, path) {
	try {
		return Reflect.ownKeys(value);
	} catch {
		return fail$1("JSON_INSPECTION_FAILED", path, "object properties could not be inspected");
	}
}
function descriptorOf(value, key, path) {
	try {
		const descriptor = Object.getOwnPropertyDescriptor(value, key);
		if (descriptor) return descriptor;
	} catch {}
	return fail$1("JSON_INSPECTION_FAILED", path, "object property could not be inspected");
}
function assertDataProperty(descriptor, path) {
	if (!("value" in descriptor)) fail$1("JSON_ACCESSOR_PROPERTY", path, "JSON properties must be data properties, not getters or setters");
	if (!descriptor.enumerable) fail$1("JSON_NON_ENUMERABLE_PROPERTY", path, "JSON properties must be enumerable");
}
function normalizeArray(value, path, active) {
	if (prototypeOf(value, path) !== Array.prototype) fail$1("JSON_NON_PLAIN_OBJECT", path, "JSON arrays must use the built-in Array prototype");
	const keys = ownKeys(value, path);
	const elementKeys = /* @__PURE__ */ new Set();
	for (const key of keys) {
		if (typeof key === "symbol") fail$1("JSON_SYMBOL_KEY", path, "JSON arrays must not have symbol-keyed properties");
		if (key === "length") continue;
		if (!/^(0|[1-9][0-9]*)$/u.test(key) || Number(key) >= value.length) fail$1("JSON_UNSUPPORTED_PROPERTY", propertyPath$2(path, key), "JSON arrays must not have properties other than their elements");
		elementKeys.add(key);
	}
	const result = [];
	for (let index = 0; index < value.length; index += 1) {
		const itemPath = `${path}[${index}]`;
		if (!elementKeys.has(String(index))) fail$1("JSON_ARRAY_HOLE", itemPath, "JSON arrays must not contain holes");
		const descriptor = descriptorOf(value, String(index), itemPath);
		assertDataProperty(descriptor, itemPath);
		result.push(normalize(descriptor.value, itemPath, active));
	}
	Object.freeze(result);
	ownedJson.add(result);
	return result;
}
function normalizeObject(value, path, active) {
	const prototype = prototypeOf(value, path);
	if (prototype !== Object.prototype && prototype !== null) fail$1("JSON_NON_PLAIN_OBJECT", path, "JSON objects must be plain objects");
	const keys = ownKeys(value, path);
	for (const key of keys) {
		if (typeof key === "symbol") fail$1("JSON_SYMBOL_KEY", path, "JSON objects must not have symbol-keyed properties");
		assertUnicodeScalarString(key, propertyPath$2(path, key));
	}
	const sortedKeys = Object.freeze([...keys].sort(compareUtf8));
	const result = {};
	for (const key of sortedKeys) {
		const itemPath = propertyPath$2(path, key);
		const descriptor = descriptorOf(value, key, itemPath);
		assertDataProperty(descriptor, itemPath);
		Object.defineProperty(result, key, {
			value: normalize(descriptor.value, itemPath, active),
			enumerable: true,
			configurable: false,
			writable: false
		});
	}
	Object.freeze(result);
	ownedJson.add(result);
	ownedObjectKeys.set(result, sortedKeys);
	return result;
}
/** Copy data proved by this module without changing fresh-copy semantics. */
function copyOwned(value) {
	if (value === null || typeof value !== "object") return value;
	if (Array.isArray(value)) {
		const result = [];
		for (let index = 0; index < value.length; index += 1) result.push(copyOwned(value[index]));
		Object.freeze(result);
		ownedJson.add(result);
		return result;
	}
	const object = value;
	const keys = ownedObjectKeys.get(object);
	const result = {};
	for (const key of keys) Object.defineProperty(result, key, {
		value: copyOwned(object[key]),
		enumerable: true,
		configurable: false,
		writable: false
	});
	Object.freeze(result);
	ownedJson.add(result);
	ownedObjectKeys.set(result, keys);
	return result;
}
function normalize(value, path, active) {
	if (value === null || typeof value === "boolean") return value;
	if (typeof value === "string") {
		assertUnicodeScalarString(value, path);
		return value;
	}
	if (typeof value === "number") {
		if (!Number.isFinite(value)) fail$1("JSON_NON_FINITE_NUMBER", path, "JSON numbers must be finite");
		return value === 0 ? 0 : value;
	}
	if (value === void 0) return fail$1("JSON_UNDEFINED", path, "undefined is not a JSON value");
	if (typeof value !== "object") return fail$1("JSON_UNSUPPORTED_TYPE", path, `${typeof value} is not a JSON value`);
	if (ownedJson.has(value)) return copyOwned(value);
	if (active.has(value)) return fail$1("JSON_CYCLIC_REFERENCE", path, "cyclic references are not JSON values");
	active.add(value);
	try {
		return Array.isArray(value) ? normalizeArray(value, path, active) : normalizeObject(value, path, active);
	} finally {
		active.delete(value);
	}
}
/**
* Validate, canonicalize, clone, and deeply freeze one portable JSON value.
* Optional data is absent; explicit `undefined` is rejected.
*/
function normalizeJson(value, path = "$") {
	return normalize(value, path, /* @__PURE__ */ new WeakSet());
}
function canonical(value) {
	if (value === null) return "null";
	if (typeof value === "string") return JSON.stringify(value);
	if (typeof value === "boolean") return value ? "true" : "false";
	if (typeof value === "number") return JSON.stringify(value);
	if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
	const object = value;
	return `{${ownedObjectKeys.get(object).map((key) => `${JSON.stringify(key)}:${canonical(object[key])}`).join(",")}}`;
}
/** Stable JSON for identity and language-neutral conformance vectors. */
function canonicalJson(value) {
	return canonical(value !== null && typeof value === "object" && ownedJson.has(value) ? value : normalizeJson(value));
}
function cloneJson(value, path = "$") {
	return normalizeJson(value, path);
}
function isSha256Digest(value) {
	return typeof value === "string" && /^sha256:[0-9a-f]{64}$/u.test(value);
}
/** Hash canonical JSON in an explicit domain separated by a NUL byte. */
async function hashJson(domain, value) {
	if (!domain.trim() || domain.includes("\0")) fail$1("HASH_INVALID_DOMAIN", "domain", "hash domain must be non-empty and cannot contain NUL");
	const subtle = globalThis.crypto?.subtle;
	if (!subtle) fail$1("HASH_SHA256_UNAVAILABLE", "crypto.subtle", "Web Crypto SHA-256 is unavailable");
	const bytes = encoder.encode(`${domain}\0${canonicalJson(value)}`);
	const digest = await subtle.digest("SHA-256", bytes);
	return `sha256:${Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}
/** Generic canonical-JSON hash; Boundary protocol identities use explicit domains. */
function sha256(value) {
	return hashJson("canonical-json/v1", value);
}
//#endregion
//#region packages/core/program/src/snapshot.ts
function propertyPath$1(path, key) {
	return `${path}.${key}`;
}
/**
* Walk an own-enumerable-data-only object. Rejects accessors, symbols, extra
* keys, and prototype pollution. `keys` are required (or `"discover"`);
* `optionalKeys` may be absent but, if present, must be exact data properties
* like every other key.
*/
function exactObject(value, options) {
	const { path, keys, fail } = options;
	const discover = keys === "discover";
	const optionalKeys = options.optionalKeys ?? [];
	if (value === null || typeof value !== "object" || Array.isArray(value)) return fail({
		code: "SNAPSHOT_NOT_OBJECT",
		path,
		message: "value must be a plain object"
	});
	let prototype;
	let ownKeys;
	try {
		prototype = Object.getPrototypeOf(value);
		ownKeys = Reflect.ownKeys(value);
	} catch {
		return fail({
			code: "SNAPSHOT_INSPECTION_FAILED",
			path,
			message: "object could not be inspected"
		});
	}
	if (prototype !== Object.prototype && prototype !== null) return fail({
		code: "SNAPSHOT_NOT_OBJECT",
		path,
		message: "value must be a plain object"
	});
	const allowed = discover ? void 0 : /* @__PURE__ */ new Set([...keys, ...optionalKeys]);
	for (const key of ownKeys) {
		if (typeof key === "symbol") return fail({
			code: "SNAPSHOT_SYMBOL_KEY",
			path,
			message: "object must not have symbol-keyed properties"
		});
		const stringKey = key;
		if (allowed !== void 0 && !allowed.has(stringKey)) return fail({
			code: "SNAPSHOT_UNEXPECTED_KEY",
			path: propertyPath$1(path, stringKey),
			message: `unexpected property: ${stringKey}`
		});
	}
	if (!discover) {
		for (const key of keys) if (!ownKeys.includes(key)) return fail({
			code: "SNAPSHOT_MISSING_KEY",
			path: propertyPath$1(path, key),
			message: `required property is missing: ${key}`
		});
	}
	const result = {};
	for (const key of ownKeys) {
		const keyPath = propertyPath$1(path, key);
		let descriptor;
		try {
			descriptor = Object.getOwnPropertyDescriptor(value, key);
		} catch {
			return fail({
				code: "SNAPSHOT_INSPECTION_FAILED",
				path: keyPath,
				message: "property could not be inspected"
			});
		}
		if (!descriptor?.enumerable || !("value" in descriptor)) return fail({
			code: "SNAPSHOT_INVALID_PROPERTY",
			path: keyPath,
			message: "property must be an enumerable data property"
		});
		Object.defineProperty(result, key, {
			value: descriptor.value,
			enumerable: true,
			configurable: true,
			writable: true
		});
	}
	return result;
}
/**
* Deep-copy a value into owned, frozen, plain JSON data. Throws via `fail`
* on non-JSON shapes. Delegates to the workspace's one JSON walker so the
* accessor/symbol/prototype rules stay in exactly one place.
*/
function snapshotJson(value, options) {
	try {
		return normalizeJson(value, options.path);
	} catch (error) {
		if (error instanceof JsonError) {
			const prefix = `${error.code} at ${error.path}: `;
			return options.fail({
				code: error.code,
				path: error.path,
				message: error.message.startsWith(prefix) ? error.message.slice(prefix.length) : error.message
			});
		}
		throw error;
	}
}
/** Structural JSON equality by canonical form. */
function jsonEquals(a, b) {
	return canonicalJson(a) === canonicalJson(b);
}
//#endregion
//#region packages/core/program/src/validation.ts
var KEYWORDS = /* @__PURE__ */ new Set([
	"type",
	"properties",
	"required",
	"additionalProperties",
	"items",
	"enum",
	"const",
	"anyOf",
	"oneOf",
	"allOf",
	"not",
	"minimum",
	"maximum",
	"exclusiveMinimum",
	"exclusiveMaximum",
	"minLength",
	"maxLength",
	"pattern",
	"minItems",
	"maxItems",
	"uniqueItems"
]);
var TYPES = /* @__PURE__ */ new Set([
	"null",
	"boolean",
	"object",
	"array",
	"number",
	"integer",
	"string"
]);
var PortableSchemaError = class extends BoundaryErrorBase {
	constructor(code, path, message) {
		super(code, path, message);
		this.name = "PortableSchemaError";
	}
};
var portableSchemas = /* @__PURE__ */ new WeakSet();
/** Only validated, owned immutable snapshots are trusted by identity. */
var validatedSchemas = /* @__PURE__ */ new WeakSet();
/** Recognize only schemas returned by portableSchema(), without branding JSON. */
function isPortableSchema(value) {
	return value !== null && typeof value === "object" && portableSchemas.has(value);
}
function fail(code, path, message) {
	throw new PortableSchemaError(code, path, message);
}
function isObject(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}
function propertyPath(path, key) {
	return /^[A-Za-z_$][A-Za-z0-9_$]*$/u.test(key) ? `${path}.${key}` : `${path}[${JSON.stringify(key)}]`;
}
function expectObject(value, path, label) {
	if (value === void 0 || !isObject(value)) fail("SCHEMA_CONTRACT_INVALID", path, `${label} must be a schema object`);
	return value;
}
function expectArray(value, path, label) {
	if (!Array.isArray(value)) fail("SCHEMA_CONTRACT_INVALID", path, `${label} must be an array`);
	return value;
}
function expectNonnegativeInteger(value, path) {
	if (typeof value !== "number" || !Number.isInteger(value) || value < 0) fail("SCHEMA_CONTRACT_INVALID", path, "keyword value must be a non-negative integer");
	return value;
}
function validateAlternatives(value, path, keyword) {
	const alternatives = expectArray(value, path, keyword);
	if (alternatives.length === 0) fail("SCHEMA_CONTRACT_INVALID", path, `${keyword} must contain at least one schema`);
	alternatives.forEach((alternative, index) => {
		validatePortableSchema(expectObject(alternative, `${path}[${index}]`, keyword), `${path}[${index}]`);
	});
}
/** Validate Boundary' bounded, executable JSON Schema profile. */
function validatePortableSchema(schema, path = "schema") {
	if (validatedSchemas.has(schema)) return;
	if (!isOwnedJson(schema)) {
		validatePortableSchema(normalizeJson(schema, path), path);
		return;
	}
	for (const keyword of Object.keys(schema)) if (!KEYWORDS.has(keyword)) fail("SCHEMA_UNSUPPORTED_KEYWORD", propertyPath(path, keyword), `${keyword} is not in Boundary' portable schema profile`);
	if (schema.type !== void 0) {
		if (typeof schema.type !== "string" || !TYPES.has(schema.type)) fail("SCHEMA_CONTRACT_INVALID", `${path}.type`, "type must be one supported JSON type name");
	}
	if (schema.properties !== void 0) {
		const properties = expectObject(schema.properties, `${path}.properties`, "properties");
		for (const [name, property] of Object.entries(properties)) {
			const itemPath = propertyPath(`${path}.properties`, name);
			validatePortableSchema(expectObject(property, itemPath, "property"), itemPath);
		}
	}
	if (schema.required !== void 0) {
		const required = expectArray(schema.required, `${path}.required`, "required");
		const seen = /* @__PURE__ */ new Set();
		for (const [index, name] of required.entries()) {
			if (typeof name !== "string" || seen.has(name)) fail("SCHEMA_CONTRACT_INVALID", `${path}.required[${index}]`, "required entries must be unique strings");
			seen.add(name);
		}
	}
	if (schema.additionalProperties !== void 0) {
		if (typeof schema.additionalProperties !== "boolean") validatePortableSchema(expectObject(schema.additionalProperties, `${path}.additionalProperties`, "additionalProperties"), `${path}.additionalProperties`);
	}
	if (schema.items !== void 0) validatePortableSchema(expectObject(schema.items, `${path}.items`, "items"), `${path}.items`);
	if (schema.uniqueItems !== void 0 && typeof schema.uniqueItems !== "boolean") fail("SCHEMA_CONTRACT_INVALID", `${path}.uniqueItems`, "uniqueItems must be a boolean");
	if (schema.enum !== void 0) {
		const values = expectArray(schema.enum, `${path}.enum`, "enum");
		if (values.length === 0) fail("SCHEMA_CONTRACT_INVALID", `${path}.enum`, "enum must not be empty");
		const seen = /* @__PURE__ */ new Set();
		for (const [index, value] of values.entries()) {
			const key = canonicalJson(value);
			if (seen.has(key)) fail("SCHEMA_CONTRACT_INVALID", `${path}.enum[${index}]`, "enum values must be unique");
			seen.add(key);
		}
	}
	for (const keyword of [
		"anyOf",
		"oneOf",
		"allOf"
	]) if (schema[keyword] !== void 0) validateAlternatives(schema[keyword], `${path}.${keyword}`, keyword);
	if (schema.not !== void 0) validatePortableSchema(expectObject(schema.not, `${path}.not`, "not"), `${path}.not`);
	for (const keyword of [
		"minimum",
		"maximum",
		"exclusiveMinimum",
		"exclusiveMaximum"
	]) if (schema[keyword] !== void 0 && typeof schema[keyword] !== "number") fail("SCHEMA_CONTRACT_INVALID", `${path}.${keyword}`, `${keyword} must be a finite number`);
	for (const keyword of [
		"minLength",
		"maxLength",
		"minItems",
		"maxItems"
	]) if (schema[keyword] !== void 0) expectNonnegativeInteger(schema[keyword], `${path}.${keyword}`);
	if (schema.pattern !== void 0) {
		if (typeof schema.pattern !== "string") fail("SCHEMA_CONTRACT_INVALID", `${path}.pattern`, "pattern must be a string");
		try {
			new RegExp(schema.pattern, "u");
		} catch {
			fail("SCHEMA_CONTRACT_INVALID", `${path}.pattern`, "pattern must be a valid Unicode ECMAScript regular expression");
		}
	}
	if (typeof schema.minLength === "number" && typeof schema.maxLength === "number" && schema.minLength > schema.maxLength) fail("SCHEMA_CONTRACT_INVALID", path, "minLength must not exceed maxLength");
	if (typeof schema.minItems === "number" && typeof schema.maxItems === "number" && schema.minItems > schema.maxItems) fail("SCHEMA_CONTRACT_INVALID", path, "minItems must not exceed maxItems");
	validatedSchemas.add(schema);
}
/** Whether `schema` has already passed validatePortableSchema by identity. */
function hasValidatedSchema(schema) {
	return validatedSchemas.has(schema);
}
/**
* Author a literal schema without a runtime-specific adapter. The returned
* schema is normalized portable JSON and deeply frozen.
*/
function portableSchema(schema, path = "schema") {
	const normalized = normalizeJson(schema, path);
	if (!isObject(normalized)) fail("SCHEMA_CONTRACT_INVALID", path, "schema must be an object");
	validatePortableSchema(normalized, path);
	portableSchemas.add(normalized);
	return normalized;
}
//#endregion
//#region packages/core/program/src/schema.ts
var SchemaAdapterError = class extends BoundaryErrorBase {
	constructor(code, path, message, options = {}) {
		super(code, path, message, options);
		this.name = "SchemaAdapterError";
	}
};
function isStableSchemaDiagnostic(error) {
	if (!(error instanceof Error) || !("code" in error) || !("path" in error)) return false;
	return typeof error.code === "string" && /^SCHEMA_[A-Z0-9_]+$/u.test(error.code) && typeof error.path === "string";
}
function isJsonObject(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}
/**
* Compile through an explicit schema adapter, then enforce Boundary' strict
* portable JSON seam. Core never has to know an adapter's internal format.
*/
function compileSchema(schema, adapter, context) {
	let compiled;
	try {
		compiled = adapter.compile(schema, context);
	} catch (error) {
		if (isStableSchemaDiagnostic(error)) throw error;
		throw new SchemaAdapterError("SCHEMA_ADAPTER_COMPILE_FAILED", context.path, "schema adapter could not compile the schema", { cause: error });
	}
	const contract = normalizeJson(compiled.contract, context.path);
	if (!isJsonObject(contract)) throw new SchemaAdapterError("SCHEMA_ADAPTER_CONTRACT_NOT_OBJECT", context.path, "compiled contract schema must be a JSON object");
	validatePortableSchema(contract, context.path);
	const annotationPath = `${context.path}.annotations`;
	const annotations = normalizeJson(compiled.annotations ?? {}, annotationPath);
	if (!isJsonObject(annotations)) throw new SchemaAdapterError("SCHEMA_ADAPTER_ANNOTATIONS_NOT_OBJECT", annotationPath, "compiled schema annotations must be a JSON object");
	return Object.freeze({
		contract,
		annotations
	});
}
//#endregion
export { hashJson as _, isObject as a, sha256 as b, propertyPath as c, jsonEquals as d, snapshotJson as f, compareUtf8 as g, cloneJson as h, hasValidatedSchema as i, validatePortableSchema as l, canonicalJson as m, compileSchema as n, isPortableSchema as o, JsonError as p, PortableSchemaError as r, portableSchema as s, SchemaAdapterError as t, exactObject as u, isSha256Digest as v, BoundaryErrorBase as x, normalizeJson as y };
