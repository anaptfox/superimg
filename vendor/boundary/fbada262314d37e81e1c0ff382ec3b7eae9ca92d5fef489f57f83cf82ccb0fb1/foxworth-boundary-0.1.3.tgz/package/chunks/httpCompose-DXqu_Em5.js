import { a as snapshotProjectedHandle, i as modeForHandle, o as AdapterError, r as interactionKey } from "./resolution-DipfP_4a.js";
import { a as faultResult, c as sanitizedInternalResult, l as statusForRemoteResult, o as invokePreparedInteraction, s as prepareExposedInteraction, t as compileExposure } from "./remote-BuX2MHpJ.js";
import { openapi } from "../http/openapi.js";
import { createProtocolHandler } from "../http/protocol.js";
import { createCheckedHandoff } from "@foxworth/boundary/handoff";
//#region packages/adapters/http/src/http.ts
var routeRuntimes = /* @__PURE__ */ new WeakMap();
var requestFailures = /* @__PURE__ */ new WeakMap();
var PATH_SEGMENT = /^[A-Za-z][A-Za-z0-9_-]*$/u;
function requestFailure(path, message) {
	const error = new AdapterError("INVALID_REQUEST", path, message);
	requestFailures.set(error, Object.freeze({
		path,
		message
	}));
	return error;
}
function fail(path, message) {
	throw new AdapterError("INVALID_DECLARATION", path, message);
}
function pathPattern(path) {
	if (!path.startsWith("/") || path.includes("?") || path.includes("#")) fail("route.path", "route paths must be absolute pathnames without query or fragment");
	const parameters = [];
	const pieces = path.split("/").filter(Boolean).map((segment) => {
		if (segment.startsWith("{") && segment.endsWith("}")) {
			const name = segment.slice(1, -1);
			if (!PATH_SEGMENT.test(name) || parameters.includes(name)) fail("route.path", `invalid or duplicate route parameter: ${name}`);
			parameters.push(name);
			return "([^/]+)";
		}
		if (segment.includes("{") || segment.includes("}")) fail("route.path", "route parameters must occupy a complete path segment");
		return segment.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
	});
	return {
		pattern: new RegExp(`^/${pieces.join("/")}${path.endsWith("/") && pieces.length > 0 ? "/" : ""}$`, "u"),
		parameters: Object.freeze(parameters)
	};
}
function route(handleValue, options) {
	const handle = snapshotProjectedHandle(handleValue, "route.handle");
	const mode = modeForHandle(handle, options.mode, "route.mode");
	const method = options.method?.toUpperCase();
	if (![
		"GET",
		"POST",
		"PUT",
		"PATCH",
		"DELETE"
	].includes(method)) fail("route.method", `unsupported HTTP method: ${String(options.method)}`);
	const parsedPath = pathPattern(options.path);
	if (handle.inputArity === 0 && parsedPath.parameters.length > 0) fail("route.path", `${handle.interactionId} takes no input and cannot bind path parameters`);
	if (handle.inputArity === 0 && options.input !== void 0) fail("route.input", `${handle.interactionId} takes no input and cannot declare an input mapping`);
	if (options.successStatus !== void 0 && (!Number.isInteger(options.successStatus) || options.successStatus < 200 || options.successStatus > 299 || options.successStatus === 204 || options.successStatus === 205)) fail("route.successStatus", "successStatus must be a body-bearing 2xx integer");
	if (options.input !== void 0 && typeof options.input !== "function") fail("route.input", "input must be a function");
	const headers = Object.freeze({ ...options.headers ?? {} });
	const declaration = Object.freeze({
		handle: handleValue,
		mode,
		method,
		path: options.path,
		inputMapping: options.input === void 0 ? "default" : "custom",
		...options.successStatus === void 0 ? {} : { successStatus: options.successStatus },
		...Object.keys(headers).length === 0 ? {} : { headers }
	});
	routeRuntimes.set(declaration, Object.freeze({
		handle,
		mode,
		method,
		path: options.path,
		...parsedPath,
		...options.input === void 0 ? {} : { input: options.input },
		...options.successStatus === void 0 ? {} : { successStatus: options.successStatus },
		headers
	}));
	return declaration;
}
function queryObject(url) {
	const values = {};
	for (const key of new Set(url.searchParams.keys())) {
		const all = url.searchParams.getAll(key);
		values[key] = all.length === 1 ? all[0] : Object.freeze(all);
	}
	return Object.freeze(values);
}
async function requestBody(request) {
	const text = await request.text();
	if (!text) return {};
	try {
		return JSON.parse(text);
	} catch {
		throw requestFailure("request.body", "request body must be valid JSON");
	}
}
function matchRoute(routes, request) {
	const url = new URL(request.url);
	for (const route of routes) {
		if (route.method !== request.method) continue;
		const match = route.pattern.exec(url.pathname);
		if (!match) continue;
		const params = {};
		for (const [index, name] of route.parameters.entries()) try {
			params[name] = decodeURIComponent(match[index + 1]);
		} catch {
			throw requestFailure(`request.params.${name}`, "path parameter is not valid URI encoding");
		}
		return Object.freeze({
			route,
			params: Object.freeze(params)
		});
	}
}
function mergePathInput(body, params) {
	if (Object.keys(params).length === 0) return body;
	if (body === null || typeof body !== "object" || Array.isArray(body)) throw requestFailure("request.body", "a route with path parameters requires an object input");
	return Object.freeze({
		...body,
		...params
	});
}
async function routeInput(route, context) {
	if (route.handle.inputArity === 0) {
		if (Object.keys(context.params).length > 0 || Object.keys(context.query).length > 0) throw requestFailure(`${route.handle.interactionId}.input`, "this interaction takes no input");
		if (route.method !== "GET") {
			const body = await context.body();
			if (!body || typeof body !== "object" || Array.isArray(body) || Object.keys(body).length > 0) throw requestFailure(`${route.handle.interactionId}.input`, "a no-input interaction accepts only an empty JSON object");
		}
		return null;
	}
	if (route.input) return route.input(context);
	if (route.method === "GET") return Object.freeze({
		...context.query,
		...context.params
	});
	return mergePathInput(await context.body(), context.params);
}
function json(body, status, headers = {}) {
	return new Response(JSON.stringify(body), {
		status,
		headers: {
			"content-type": "application/json; charset=utf-8",
			...Object.fromEntries(new Headers(headers).entries())
		}
	});
}
function compileRoutes(routes) {
	const seen = /* @__PURE__ */ new Set();
	return Object.freeze(routes.map((declaration, index) => {
		const runtime = routeRuntimes.get(declaration);
		if (!runtime) fail(`routes[${index}]`, "routes must be created by route()");
		const key = `${runtime.method} ${runtime.path}`;
		if (seen.has(key)) throw new AdapterError("DUPLICATE_DECLARATION", `routes[${index}]`, `duplicate route: ${key}`);
		seen.add(key);
		return runtime;
	}));
}
/** Build a Fetch-native adapter over one exact live Binding. */
function createHttpHandler(options) {
	if (!options || typeof options.context !== "function") fail("createHttpHandler.context", "context must resolve one invocation-scoped host value");
	const routes = compileRoutes(options.routes);
	const exposure = createCheckedHandoff(options.binding).then((handoff) => compileExposure(handoff, routes.map((entry) => ({
		handle: entry.handle,
		mode: entry.mode
	}))));
	return async (request) => {
		let matched;
		try {
			matched = matchRoute(routes, request);
		} catch {
			return json({ error: {
				kind: "protocol",
				code: "INVALID_REQUEST",
				message: "The request path is invalid."
			} }, 400);
		}
		if (!matched) return json({ error: {
			kind: "protocol",
			code: "ROUTE_NOT_FOUND",
			message: "No route matched."
		} }, 404);
		let compiled;
		try {
			compiled = await exposure;
		} catch {
			return json({
				certainty: "not-started",
				error: {
					kind: "internal",
					code: "ADAPTER_INITIALIZATION_FAILED",
					message: "The HTTP adapter could not initialize its declared exposure."
				}
			}, 500);
		}
		const exposed = compiled.interactions.get(interactionKey(matched.route.handle.interactionId, matched.route.mode));
		if (!exposed) return json({
			certainty: "not-started",
			error: {
				kind: "internal",
				code: "ADAPTER_INITIALIZATION_FAILED",
				message: "The HTTP adapter could not resolve its declared route."
			}
		}, 500);
		const url = new URL(request.url);
		let bodyPromise;
		const inputContext = Object.freeze({
			request,
			params: matched.params,
			query: queryObject(url),
			body() {
				return bodyPromise ??= requestBody(request);
			}
		});
		let prepared;
		let context;
		try {
			context = await options.context(request);
			prepared = await prepareExposedInteraction({
				exposure: compiled,
				handle: matched.route.handle,
				mode: matched.route.mode,
				input: await routeInput(matched.route, inputContext)
			});
		} catch (error) {
			const issue = error instanceof AdapterError ? requestFailures.get(error) : void 0;
			const result = issue === void 0 ? faultResult(compiled, exposed, "realization-failed") : faultResult(compiled, exposed, "invalid-input", [issue]);
			return json(result, statusForRemoteResult(result), matched.route.headers);
		}
		let result;
		try {
			result = await invokePreparedInteraction(compiled, prepared.invocation, context);
		} catch {
			result = sanitizedInternalResult(compiled, prepared.exposed);
		}
		const status = result.result.kind === "returned" || result.result.kind === "proposed" ? matched.route.successStatus ?? statusForRemoteResult(result) : statusForRemoteResult(result);
		return json(result, status, matched.route.headers);
	};
}
//#endregion
//#region packages/adapters/http/src/httpCompose.ts
/** One REST + browser-protocol + OpenAPI door. Applications keep their routes and title. */
function createCompositeHttpHandler(options) {
	const protocolPath = normalizeOwnedPath(options.protocolPath, "createCompositeHttpHandler.protocolPath");
	if (protocolPath === "/openapi.json") throw new AdapterError("DUPLICATE_DECLARATION", "createCompositeHttpHandler.protocolPath", "protocol path collides with /openapi.json");
	for (const [index, route] of options.routes.entries()) if (routeCanMatchOwnedPrefix(route.path, protocolPath)) throw new AdapterError("DUPLICATE_DECLARATION", `routes[${index}].path`, `REST route collides with protocol path: ${protocolPath}`);
	const rest = createHttpHandler({
		binding: options.binding,
		context: options.context,
		routes: options.routes
	});
	const protocol = createProtocolHandler({
		binding: options.binding,
		context: options.context,
		path: protocolPath
	});
	const openapiDocument = openapi({
		binding: options.binding,
		routes: options.routes,
		title: options.title,
		version: options.version
	}).then((specification) => {
		return {
			body: JSON.stringify(specification),
			etag: `"${options.binding.manifest.bindingDigest}"`
		};
	});
	return async (request) => {
		const pathname = new URL(request.url).pathname;
		if (pathname === "/openapi.json") {
			if (request.method !== "GET") return new Response("Method Not Allowed", { status: 405 });
			const { body, etag } = await openapiDocument;
			if (request.headers.get("if-none-match") === etag) return new Response(null, {
				status: 304,
				headers: { etag }
			});
			return new Response(body, {
				status: 200,
				headers: {
					"content-type": "application/json; charset=utf-8",
					etag,
					"cache-control": "no-cache"
				}
			});
		}
		if (pathname === protocolPath || pathname.startsWith(`${protocolPath}/`)) return protocol(request);
		return rest(request);
	};
}
function normalizeOwnedPath(path, label) {
	if (!path.startsWith("/") || path.includes("?") || path.includes("#")) throw new AdapterError("INVALID_DECLARATION", label, "mount path must be an absolute pathname");
	const normalized = path.length > 1 ? path.replace(/\/+$/u, "") : path;
	if (normalized === "/") throw new AdapterError("INVALID_DECLARATION", label, "mount path must not claim the application root");
	return normalized;
}
function routeCanMatchOwnedPrefix(routePath, ownedPrefix) {
	const routeSegments = routePath.split("/").filter(Boolean);
	const prefixSegments = ownedPrefix.split("/").filter(Boolean);
	if (routeSegments.length < prefixSegments.length) return false;
	return prefixSegments.every((segment, index) => {
		const routeSegment = routeSegments[index];
		return routeSegment === segment || routeSegment.startsWith("{") && routeSegment.endsWith("}");
	});
}
/** Dispatch one handler across non-overlapping explicit path prefixes. */
function mountHandlers(mounts) {
	if (mounts.length === 0) throw new AdapterError("INVALID_DECLARATION", "mountHandlers", "at least one mount is required");
	const normalized = mounts.map((mount, index) => {
		return {
			path: normalizeOwnedPath(mount.path, `mounts[${index}].path`),
			fetch: mount.fetch
		};
	});
	const paths = normalized.map((mount) => mount.path);
	if (new Set(paths).size !== paths.length) throw new AdapterError("INVALID_DECLARATION", "mountHandlers", "mount paths must be unique");
	for (let left = 0; left < paths.length; left += 1) for (let right = left + 1; right < paths.length; right += 1) {
		const a = paths[left];
		const b = paths[right];
		if (a.startsWith(`${b}/`) || b.startsWith(`${a}/`)) throw new AdapterError("INVALID_DECLARATION", "mountHandlers", `mount paths must not overlap: ${a} and ${b}`);
	}
	return {
		paths: Object.freeze([...paths]),
		handler: async (request) => {
			const pathname = new URL(request.url).pathname;
			for (const mount of normalized) if (pathname === mount.path || pathname.startsWith(`${mount.path}/`)) return mount.fetch(request);
			return new Response(null, { status: 404 });
		}
	};
}
//#endregion
export { route as i, mountHandlers as n, createHttpHandler as r, createCompositeHttpHandler as t };
