import { BoundaryErrorBase, normalizeJson, portableSchema } from "@foxworth/boundary/program";
//#region packages/core/host/src/errors.ts
var HostError = class extends BoundaryErrorBase {
	constructor(code, path, message, options = {}) {
		super(code, path, message, options);
		this.name = "HostError";
	}
};
var InteractionFault = class extends Error {
	certainty;
	cause;
	details;
	constructor(cause, certainty, message, details) {
		super(message);
		this.name = "InteractionFault";
		this.cause = cause;
		this.certainty = certainty;
		this.details = details;
	}
};
function failHost(code, path, message, cause) {
	throw new HostError(code, path, message, cause === void 0 ? {} : { cause });
}
//#endregion
//#region packages/core/host/src/definitions.ts
var definitions = /* @__PURE__ */ new WeakSet();
var absentInputSchema = portableSchema(Object.freeze({ type: "null" }), "defineInteraction.input");
function ownData(source, key) {
	let descriptor;
	try {
		descriptor = Object.getOwnPropertyDescriptor(source, key);
	} catch (cause) {
		return failHost("INVALID_DECLARATION", `defineInteraction.${key}`, "interaction declaration could not be inspected", cause);
	}
	if (!descriptor) return void 0;
	if (!("value" in descriptor) || !descriptor.enumerable) return failHost("INVALID_DECLARATION", `defineInteraction.${key}`, "interaction declaration fields must be enumerable data properties");
	return descriptor.value;
}
function stringList(value, path) {
	if (value === void 0) return Object.freeze([]);
	if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) return failHost("INVALID_DECLARATION", path, "interaction footprints must be arrays of strings");
	return Object.freeze([...value]);
}
function errorSchemas(value) {
	if (value === void 0) return Object.freeze({});
	if (value === null || typeof value !== "object" || Array.isArray(value)) return failHost("INVALID_DECLARATION", "defineInteraction.errors", "declared errors must be a record of authoring schemas");
	const result = {};
	for (const key of Object.keys(value).sort()) {
		if (!/^[A-Za-z][A-Za-z0-9_-]{0,63}$/u.test(key)) failHost("INVALID_DECLARATION", `defineInteraction.errors.${key}`, "declared error codes must be stable ASCII tokens");
		const schema = ownData(value, key);
		Object.defineProperty(result, key, {
			value: schema,
			enumerable: true,
			writable: false,
			configurable: false
		});
	}
	return Object.freeze(result);
}
function definitionAnnotations(explicit) {
	if (explicit !== void 0) {
		const normalized = normalizeJson(explicit, "defineInteraction.annotations");
		if (normalized === null || typeof normalized !== "object" || Array.isArray(normalized)) failHost("INVALID_DECLARATION", "defineInteraction.annotations", "annotations must be a portable JSON object");
		const interaction = normalized;
		if (Object.hasOwn(interaction, "schemas")) failHost("INVALID_DECLARATION", "defineInteraction.annotations.schemas", "schemas is reserved for compiler-produced schema annotations");
		return interaction;
	}
}
function defineInteraction(source) {
	if (source === null || typeof source !== "object" || Array.isArray(source)) return failHost("INVALID_DECLARATION", "defineInteraction", "interaction declaration must be an object");
	const allowed = /* @__PURE__ */ new Set([
		"id",
		"input",
		"output",
		"errors",
		"reads",
		"changes",
		"summary",
		"description",
		"annotations"
	]);
	const unexpected = Reflect.ownKeys(source).find((key) => typeof key !== "string" || !allowed.has(key));
	if (unexpected !== void 0) failHost("INVALID_DECLARATION", "defineInteraction", `unsupported interaction declaration field: ${String(unexpected)}`);
	const id = ownData(source, "id");
	const output = ownData(source, "output");
	const hasInput = Object.hasOwn(source, "input");
	const input = hasInput ? ownData(source, "input") : absentInputSchema;
	if (typeof id !== "string") failHost("INVALID_DECLARATION", "defineInteraction.id", "id must be a string");
	const summary = ownData(source, "summary");
	const description = ownData(source, "description");
	const rawAnnotations = ownData(source, "annotations");
	const authoredErrors = errorSchemas(ownData(source, "errors"));
	if (summary !== void 0 && typeof summary !== "string") failHost("INVALID_DECLARATION", "defineInteraction.summary", "summary must be a string");
	if (description !== void 0 && typeof description !== "string") failHost("INVALID_DECLARATION", "defineInteraction.description", "description must be a string");
	const annotations = definitionAnnotations(rawAnnotations);
	const definition = Object.freeze({
		id,
		input,
		output,
		errors: authoredErrors,
		reads: stringList(ownData(source, "reads"), "defineInteraction.reads"),
		changes: stringList(ownData(source, "changes"), "defineInteraction.changes"),
		...summary === void 0 ? {} : { summary },
		...description === void 0 ? {} : { description },
		...annotations === void 0 ? {} : { annotations },
		inputArity: hasInput ? 1 : 0
	});
	definitions.add(definition);
	return definition;
}
function isInteractionDefinition(value) {
	return value !== null && typeof value === "object" && definitions.has(value);
}
function declaredErrorSchema(interactionId, errorSchemas) {
	const entries = Object.entries(errorSchemas);
	if (entries.length === 0) return void 0;
	const variants = entries.map(([code, schema]) => ({
		type: "object",
		properties: {
			code: { const: code },
			details: schema
		},
		required: ["code", "details"],
		additionalProperties: false
	}));
	return portableSchema(variants.length === 1 ? variants[0] : { oneOf: variants }, `${interactionId}.errors`);
}
var declaredErrors = /* @__PURE__ */ new WeakSet();
var declaredErrorDefinitions = /* @__PURE__ */ new WeakMap();
var declaredErrorContractDigests = /* @__PURE__ */ new WeakMap();
var DeclaredInteractionError = class extends Error {
	interactionId;
	code;
	details;
	constructor(interactionId, code, details) {
		super(`interaction returned declared error ${code}`);
		this.name = "DeclaredInteractionError";
		this.interactionId = interactionId;
		this.code = code;
		this.details = details;
		Object.freeze(this);
	}
};
function declaredInteractionError(definition, code, details) {
	if (!isInteractionDefinition(definition)) return failHost("FORGED_DEFINITION", "declaredInteractionError.definition", "declared errors require an authentic interaction definition");
	if (!Object.hasOwn(definition.errors, code)) return failHost("INVALID_DECLARED_ERROR", `declaredInteractionError.${definition.id}.${code}`, "the interaction does not declare this error code");
	let portable;
	try {
		portable = normalizeJson(details, `${definition.id}.errors.${code}`);
	} catch (cause) {
		return failHost("INVALID_DECLARED_ERROR", `${definition.id}.errors.${code}`, "declared error details must be portable JSON", cause);
	}
	const error = new DeclaredInteractionError(definition.id, code, portable);
	declaredErrors.add(error);
	declaredErrorDefinitions.set(error, definition);
	return error;
}
/** Reconstructs a validated declared error for a typed local caller. */
function restoreDeclaredInteractionError(interactionId, contractDigest, code, details) {
	const error = new DeclaredInteractionError(interactionId, code, details);
	declaredErrors.add(error);
	declaredErrorContractDigests.set(error, contractDigest);
	return error;
}
function isDeclaredInteractionError(error, handle, code) {
	return error instanceof DeclaredInteractionError && declaredErrors.has(error) && error.interactionId === handle.interactionId && declaredErrorContractDigests.get(error) === handle.contractDigest && error.code === code;
}
function isAuthenticDeclaredError(value) {
	return value instanceof DeclaredInteractionError && declaredErrors.has(value) && declaredErrorDefinitions.has(value);
}
function definitionForDeclaredError(value) {
	return declaredErrorDefinitions.get(value);
}
//#endregion
export { definitionForDeclaredError as a, isInteractionDefinition as c, InteractionFault as d, failHost as f, defineInteraction as i, restoreDeclaredInteractionError as l, declaredErrorSchema as n, isAuthenticDeclaredError as o, declaredInteractionError as r, isDeclaredInteractionError as s, DeclaredInteractionError as t, HostError as u };
