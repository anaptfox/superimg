import { a as definitionForDeclaredError, d as InteractionFault, f as failHost, l as restoreDeclaredInteractionError, o as isAuthenticDeclaredError } from "./definitions-CFjJCGn-.js";
import { a as metadataForHandle, i as metadataForCompiled, o as snapshotDefinitions } from "./compile-Dpp86NdO.js";
import { t as installObservedRead } from "./integration-BFeEWs9s.js";
import { n as metadataForControlRequestContributions } from "./control-BazjVrj2.js";
import { n as metadataForProjection, t as metadataForProjectedHandle } from "./projection-7MSieVvr.js";
import { bindingDescriptions, compareUtf8, contractCompatibility, createCatalog, createProgram, hashJson, interactionContractIdentity, isInvocationFaultLegal, isSha256Digest, normalizeJson, validateCatalog, validateInvocationObservation, validateSchemaValue } from "@foxworth/boundary/program";
//#region packages/core/host/src/implement.ts
var implementationMetadata = /* @__PURE__ */ new WeakMap();
function implementInteractions(definitions, implementations) {
	const snapshot = snapshotDefinitions(definitions);
	if (implementations === null || typeof implementations !== "object" || Array.isArray(implementations)) return failHost("INVALID_IMPLEMENTATION", "implementations", "implementations must be a plain closed record");
	const implementationKeys = Reflect.ownKeys(implementations);
	const definitionKeys = Object.keys(snapshot);
	if (implementationKeys.find((key) => typeof key !== "string") !== void 0) failHost("INVALID_IMPLEMENTATION", "implementations", "implementation keys must be strings");
	const actualKeys = implementationKeys;
	const missing = definitionKeys.filter((key) => !actualKeys.includes(key));
	const extra = actualKeys.filter((key) => !definitionKeys.includes(key));
	if (missing.length > 0 || extra.length > 0) failHost("IMPLEMENTATION_COVERAGE_MISMATCH", "implementations", `implementation coverage mismatch (missing: ${missing.join(", ") || "none"}; extra: ${extra.join(", ") || "none"})`);
	const functions = /* @__PURE__ */ new Map();
	for (const key of definitionKeys) {
		const descriptor = Object.getOwnPropertyDescriptor(implementations, key);
		if (!descriptor || !("value" in descriptor) || !descriptor.enumerable) failHost("INVALID_IMPLEMENTATION", `implementations.${key}`, "implementations must be enumerable data properties");
		if (typeof descriptor.value !== "function") failHost("INVALID_IMPLEMENTATION", `implementations.${key}`, "each interaction implementation must be a function");
		functions.set(key, descriptor.value);
	}
	const value = Object.freeze({});
	implementationMetadata.set(value, {
		definitions: snapshot,
		functions
	});
	return value;
}
function metadataForImplementations(value) {
	if (value === null || typeof value !== "object") return failHost("FOREIGN_IMPLEMENTATIONS", "implementations", "an authentic InteractionImplementations value is required");
	const metadata = implementationMetadata.get(value);
	if (!metadata) return failHost("FOREIGN_IMPLEMENTATIONS", "implementations", "an authentic InteractionImplementations value is required");
	return metadata;
}
//#endregion
//#region packages/core/host/src/native-outcome.ts
var issuedRecords = /* @__PURE__ */ new WeakMap();
var capturedRecords = /* @__PURE__ */ new WeakMap();
function issue(factory, record) {
	const outcome = Object.freeze({});
	issuedRecords.set(outcome, Object.freeze({
		factory,
		record
	}));
	return outcome;
}
function createNativeDispatchOutcomes() {
	const outcomes = {
		returned(value) {
			return issue(outcomes, Object.freeze({
				kind: "returned",
				value
			}));
		},
		declared(code, details) {
			return issue(outcomes, Object.freeze({
				kind: "declared-error",
				code,
				details
			}));
		},
		denied(code) {
			return issue(outcomes, Object.freeze({
				kind: "denied",
				code
			}));
		},
		notStarted() {
			return issue(outcomes, Object.freeze({
				kind: "fault",
				certainty: "not-started"
			}));
		},
		notCompleted() {
			return issue(outcomes, Object.freeze({
				kind: "fault",
				certainty: "not-completed"
			}));
		},
		unknown() {
			return issue(outcomes, Object.freeze({
				kind: "fault",
				certainty: "unknown"
			}));
		}
	};
	return Object.freeze(outcomes);
}
function nativeDispatchOutcomeRecord(value) {
	return value !== null && typeof value === "object" ? capturedRecords.get(value) : void 0;
}
/**
* Captures an outcome only when the native dispatcher returned a token issued
* by this exact request's factory. The captured token is private to the
* installation boundary; a retained token from another call becomes ordinary
* output and cannot carry denial or certainty across an invocation.
*/
function captureNativeDispatchOutcome(value, outcomes) {
	if (value === null || typeof value !== "object") return void 0;
	const issued = issuedRecords.get(value);
	if (!issued || issued.factory !== outcomes) return void 0;
	const captured = Object.freeze({});
	capturedRecords.set(captured, issued.record);
	return captured;
}
//#endregion
//#region packages/core/host/src/install.ts
var INSTALLATION_DOMAIN = "boundary.installation/v1";
var installationMetadata = /* @__PURE__ */ new WeakMap();
function validOpaqueId(value) {
	return typeof value === "string" && /^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u.test(value);
}
function requireInstallationId(value) {
	if (!validOpaqueId(value)) return failHost("INVALID_INSTALLATION_ID", "installationId", "installationId must be a non-empty stable ASCII token");
	return value;
}
function requireRealizationId(value, path) {
	if (!validOpaqueId(value)) return failHost("INVALID_REALIZATION_ID", path, "realizationId must be a non-empty stable ASCII token");
	return value;
}
function realizationRecord(value) {
	if (value === null || typeof value !== "object" || Array.isArray(value)) return failHost("INVALID_REALIZATION_ID", "realizationIds", "realizationIds must be a record keyed by compiled alias");
	return value;
}
function implementationExecutor(definition, implementation) {
	return async (input, context) => {
		if (definition.inputArity === 0) return context === void 0 ? implementation() : implementation(context);
		return context === void 0 ? implementation(input) : implementation(input, context);
	};
}
function aliasForHandle(compiled, handle, path) {
	const metadata = metadataForHandle(handle);
	if (!metadata || metadata.compiled !== compiled) return failHost("FOREIGN_HANDLE", path, "installation entries require a handle from this compilation");
	return metadata.alias;
}
function requestEntries(requests) {
	const result = /* @__PURE__ */ new Map();
	if (requests === void 0) return result;
	const metadata = metadataForControlRequestContributions(requests);
	for (const [alias, contribution] of metadata.entries) result.set(alias, contribution);
	return result;
}
async function installInteractions(compiled, options) {
	const compiledMeta = metadataForCompiled(compiled);
	if (options === null || typeof options !== "object") return failHost("INVALID_INSTALLATION", "installInteractions.options", "installation options must be an object");
	const installationId = requireInstallationId(options.installationId);
	const ids = realizationRecord(options.realizationIds);
	const requests = requestEntries(options.requests);
	const observedExecutors = [];
	const direct = /* @__PURE__ */ new Map();
	if ("implementations" in options && options.implementations !== void 0) {
		const implementationMeta = metadataForImplementations(options.implementations);
		for (const [alias, definition] of Object.entries(implementationMeta.definitions)) {
			const compiledAlias = compiledMeta.aliasesByDefinition.get(definition);
			if (compiledAlias === void 0 || compiledAlias !== alias) failHost("FOREIGN_IMPLEMENTATIONS", `implementations.${alias}`, "implementation definitions must be members of this compilation under the same alias");
			const implementation = implementationMeta.functions.get(alias);
			const observed = installObservedRead(implementation, definition, compiledMeta.descriptors.get(definition.id).contract, {
				installationId,
				realizationId: ids[alias]?.direct ?? ""
			});
			if (observed) observedExecutors.push(observed);
			direct.set(alias, observed?.execute ?? implementationExecutor(definition, implementation));
		}
	} else if ("bindings" in options && options.bindings !== void 0) {
		if (!Array.isArray(options.bindings)) failHost("INVALID_INSTALLATION", "bindings", "native bindings must be an array");
		for (let index = 0; index < options.bindings.length; index += 1) {
			const binding = options.bindings[index];
			const interaction = binding?.interaction;
			const target = binding?.target;
			const dispatch = binding?.dispatch;
			if (binding === null || typeof binding !== "object" || typeof dispatch !== "function") failHost("INVALID_INSTALLATION", `bindings[${index}]`, "native binding requires interaction, target, and dispatch");
			const alias = aliasForHandle(compiled, interaction, `bindings[${index}].interaction`);
			if (direct.has(alias)) failHost("DUPLICATE_REALIZATION", `bindings[${index}]`, `duplicate direct realization for ${alias}`);
			const invoke = dispatch.bind(binding);
			direct.set(alias, async (input, context) => {
				const outcomes = createNativeDispatchOutcomes();
				const result = await invoke(Object.freeze({
					interaction,
					target,
					input,
					context,
					outcomes
				}));
				return captureNativeDispatchOutcome(result, outcomes) ?? result;
			});
		}
	} else failHost("INVALID_INSTALLATION", "installInteractions.options", "installation requires implementations or native bindings");
	const expectedIdKeys = /* @__PURE__ */ new Set([...direct.keys(), ...requests.keys()]);
	const extraIds = Object.keys(ids).filter((key) => !expectedIdKeys.has(key));
	if (extraIds.length > 0) failHost("REALIZATION_COVERAGE_MISMATCH", "realizationIds", `realization IDs name unavailable interactions: ${extraIds.join(", ")}`);
	const interactions = /* @__PURE__ */ new Map();
	const availability = [];
	for (const [alias, definition] of Object.entries(compiledMeta.definitions)) {
		const descriptor = compiledMeta.descriptors.get(definition.id);
		const directExecution = direct.get(alias);
		const requestBinding = requests.get(alias);
		const idEntry = ids[alias];
		if (directExecution && idEntry?.direct === void 0) failHost("REALIZATION_COVERAGE_MISMATCH", `realizationIds.${alias}.direct`, "direct realization requires a host-issued realization ID");
		if (!directExecution && idEntry?.direct !== void 0) failHost("REALIZATION_COVERAGE_MISMATCH", `realizationIds.${alias}.direct`, "direct realization ID has no direct implementation");
		if (requestBinding && idEntry?.request === void 0) failHost("REALIZATION_COVERAGE_MISMATCH", `realizationIds.${alias}.request`, "request realization requires a host-issued realization ID");
		if (!requestBinding && idEntry?.request !== void 0) failHost("REALIZATION_COVERAGE_MISMATCH", `realizationIds.${alias}.request`, "request realization ID has no Control contribution");
		const directResolution = directExecution ? Object.freeze({
			realizationId: requireRealizationId(idEntry.direct, `realizationIds.${alias}.direct`),
			execute: directExecution
		}) : void 0;
		const requestResolution = requestBinding ? (() => {
			const controlDigest = requestBinding.controlDigest;
			const previewSchema = requestBinding.previewSchema;
			const request = requestBinding.request;
			return Object.freeze({
				realizationId: requireRealizationId(idEntry.request, `realizationIds.${alias}.request`),
				controlDigest,
				previewSchema,
				async execute(input, context, policy) {
					return request(input, context, policy);
				}
			});
		})() : void 0;
		availability.push({
			interactionId: definition.id,
			...directResolution === void 0 ? {} : { direct: { realizationId: directResolution.realizationId } },
			...requestResolution === void 0 ? {} : { request: {
				realizationId: requestResolution.realizationId,
				controlDigest: requestResolution.controlDigest,
				previewSchema: requestResolution.previewSchema
			} }
		});
		interactions.set(definition.id, Object.freeze({
			alias,
			definition,
			descriptor,
			contract: descriptor.contract,
			errorSchemas: compiledMeta.errorSchemas.get(definition.id) ?? Object.freeze({}),
			inputArity: definition.inputArity,
			...directResolution === void 0 ? {} : { direct: directResolution },
			...requestResolution === void 0 ? {} : { request: requestResolution }
		}));
	}
	const catalog = createCatalog(compiled.program, availability);
	const installationDigest = await hashJson(INSTALLATION_DOMAIN, Object.freeze({
		version: 1,
		program: compiled.program,
		catalog
	}));
	const manifest = Object.freeze({
		version: 1,
		installationId,
		program: compiled.program,
		catalog,
		installationDigest
	});
	const state = { revoked: false };
	const installation = Object.freeze({
		handles: compiled.handles,
		manifest,
		installationId
	});
	const controller = Object.freeze({
		get revoked() {
			return state.revoked;
		},
		revoke() {
			if (state.revoked) return false;
			state.revoked = true;
			for (const executor of observedExecutors) executor.clear();
			return true;
		}
	});
	installationMetadata.set(installation, {
		compiled,
		interactions,
		state
	});
	return Object.freeze({
		installation,
		controller
	});
}
function metadataForInstallation(value) {
	const metadata = installationMetadata.get(value);
	if (!metadata) return failHost("INVALID_INSTALLATION", "installation", "an authentic InteractionInstallation value is required");
	return metadata;
}
//#endregion
//#region packages/core/host/src/assessment.ts
/** Data-only check shared by live construction and candidate assessment. */
function assessInteraction(selection, expected, actual, revoked = false) {
	const issue = (reason, message) => Object.freeze({
		alias: selection.alias,
		interactionId: selection.interactionId,
		reason,
		message
	});
	if (revoked) return [issue("installation-revoked", "the Installation has been revoked")];
	if (!actual) return [issue("missing-interaction", "the Installation does not realize this interaction")];
	const compatibility = contractCompatibility(expected, actual.contract);
	if (!compatibility.compatible) return [issue("incompatible-contract", `${compatibility.reason} at ${compatibility.path}`)];
	if (actual.inputArity !== void 0 && selection.inputArity !== actual.inputArity) return [issue("incompatible-arity", "expected and actual input arities differ")];
	return selection.modes.flatMap((mode) => actual[mode] ? [] : [Object.freeze({
		...issue(mode === "direct" ? "missing-direct" : "missing-request", `the Installation does not realize ${mode} mode`),
		mode
	})]);
}
function validateCandidateProgram(program) {
	if (program.version !== 1 || !isSha256Digest(program.programDigest) || !Array.isArray(program.interactions)) throw new TypeError("Candidate Program must have version 1, a digest, and interactions");
	const ids = /* @__PURE__ */ new Set();
	for (const descriptor of program.interactions) {
		if (descriptor.version !== 1 || !isSha256Digest(descriptor.contractDigest)) throw new TypeError("Candidate descriptor must have version 1 and a contract digest");
		interactionContractIdentity(descriptor.contract);
		if (ids.has(descriptor.contract.id)) throw new TypeError("Duplicate candidate interaction ID");
		ids.add(descriptor.contract.id);
	}
}
/**
* Compare the declarations and availability claimed by candidate manifests.
* This does not authenticate artifacts, construct a Binding, or grant a call.
*/
function assessProjection(projection, installation) {
	const desired = normalizeJson(projection);
	const candidate = normalizeJson(installation);
	if (desired.version !== 1 || candidate.version !== 1 || !isSha256Digest(desired.projectionDigest) || !isSha256Digest(candidate.installationDigest) || typeof candidate.installationId !== "string" || candidate.installationId.length === 0 || !Array.isArray(desired.interactions)) throw new TypeError("Candidate manifests require version 1, identities, and projection interactions");
	validateCandidateProgram(desired.program);
	validateCandidateProgram(candidate.program);
	validateCatalog(candidate.program, candidate.catalog);
	const aliases = /* @__PURE__ */ new Set();
	const selectedIds = /* @__PURE__ */ new Set();
	for (const selection of desired.interactions) {
		if (typeof selection.alias !== "string" || selection.alias.length === 0 || aliases.has(selection.alias) || selectedIds.has(selection.interactionId) || !isSha256Digest(selection.expectedContractDigest) || selection.inputArity !== 0 && selection.inputArity !== 1 || !Array.isArray(selection.modes) || selection.modes.length === 0 || new Set(selection.modes).size !== selection.modes.length || selection.modes.some((mode) => mode !== "direct" && mode !== "request")) throw new TypeError("Invalid or duplicate candidate Projection selection");
		aliases.add(selection.alias);
		selectedIds.add(selection.interactionId);
	}
	const expected = new Map(desired.program.interactions.map((item) => [item.contract.id, item]));
	const actual = new Map(candidate.program.interactions.map((item) => [item.contract.id, item]));
	const availability = new Map(candidate.catalog.interactions.map((item) => [item.interactionId, item]));
	const issues = desired.interactions.flatMap((selection) => {
		const declared = expected.get(selection.interactionId);
		if (!declared) throw new TypeError(`Projection has no declaration for ${selection.interactionId}`);
		if (selection.expectedContractDigest !== declared.contractDigest) throw new TypeError("Projection selection digest differs from its declaration");
		const realized = actual.get(selection.interactionId);
		const modes = availability.get(selection.interactionId);
		return assessInteraction(selection, declared.contract, realized && modes ? {
			contract: realized.contract,
			direct: modes.direct !== void 0,
			request: modes.request !== void 0
		} : void 0);
	});
	return Object.freeze({
		status: issues.length === 0 ? "fit" : "mismatch",
		issues: Object.freeze(issues),
		missingEvidence: Object.freeze([
			"artifact-authenticity",
			"actual-input-arity",
			"live-revocation",
			"admission"
		])
	});
}
//#endregion
//#region packages/core/host/src/coordination.ts
function keys(value, required) {
	if (Object.keys(value).length !== required.length || required.some((key) => !Object.hasOwn(value, key))) throw new TypeError("invalid coordinated outcome fields");
}
/** Check a host-retained outcome without accepting native request-owned factory tokens. */
function checkedCoordinatedOutcome(value, request) {
	const outcome = normalizeJson(value);
	if (outcome === null || typeof outcome !== "object" || Array.isArray(outcome)) throw new TypeError("invalid coordinated outcome");
	keys(outcome, [
		...Object.keys(request.policy),
		"certainty",
		"result"
	]);
	for (const key of Object.keys(request.policy)) if (outcome[key] !== request.policy[key]) throw new TypeError(`coordinated outcome changed ${key}`);
	const { result, ...identity } = outcome;
	if (result === null || typeof result !== "object" || Array.isArray(result)) throw new TypeError("invalid coordinated result");
	validateInvocationObservation({
		version: 1,
		...identity,
		resultKind: result.kind,
		reads: [],
		changes: []
	});
	const { expected, actual } = request.interaction;
	const conforms = (schema, data) => validateSchemaValue(schema, data).length === 0;
	switch (result.kind) {
		case "returned":
			keys(result, ["kind", "value"]);
			if (!conforms(expected.contract.outputSchema, result.value) || !conforms(actual.contract.outputSchema, result.value)) throw new TypeError("invalid retained output");
			break;
		case "declared-error": {
			keys(result, [
				"kind",
				"code",
				"details"
			]);
			const declared = {
				code: result.code,
				details: result.details
			};
			if (!expected.contract.errorSchema || !actual.contract.errorSchema || !conforms(expected.contract.errorSchema, declared) || !conforms(actual.contract.errorSchema, declared)) throw new TypeError("invalid retained declared error");
			break;
		}
		case "proposed":
			keys(result, ["kind", "proposal"]);
			if (!request.interaction.request || !conforms(request.interaction.request.previewSchema, result.proposal)) throw new TypeError("invalid retained proposal");
			break;
		case "denied":
			keys(result, ["kind", "code"]);
			if (typeof result.code !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u.test(result.code)) throw new TypeError("invalid retained denial");
			break;
		case "fault":
			keys(result, ["kind", "cause"]);
			if (!isInvocationFaultLegal(outcome.mode, result.cause, outcome.certainty)) throw new TypeError("invalid retained fault certainty");
	}
	return outcome;
}
//#endregion
//#region packages/core/host/src/observation.ts
function snapshotObserver(observer) {
	if (observer === void 0) return void 0;
	const { publish, correlate } = observer;
	if (typeof publish !== "function" || correlate !== void 0 && typeof correlate !== "function") throw new TypeError("invalid invocation observer");
	return Object.freeze({
		publish: publish.bind(observer),
		...correlate === void 0 ? {} : { correlate: correlate.bind(observer) }
	});
}
function observationCorrelation(observer, context) {
	try {
		return observer?.correlate === void 0 ? void 0 : normalizeJson(observer.correlate(context));
	} catch {
		return;
	}
}
async function publishObservation(observer, outcome, reads, changes, correlation) {
	if (observer === void 0) return;
	const { result, ...identity } = outcome;
	try {
		await observer.publish(validateInvocationObservation({
			version: 1,
			...identity,
			resultKind: result.kind,
			reads,
			changes,
			...correlation === void 0 ? {} : { correlation }
		}));
	} catch {}
}
//#endregion
//#region packages/core/host/src/binding.ts
var PROJECTION_BINDING_DOMAIN = "boundary.projection-binding/v1";
var bindingMetadata = /* @__PURE__ */ new WeakMap();
var resolvedMetadata = /* @__PURE__ */ new WeakMap();
function bindingRevoked(metadata) {
	let current = metadata;
	while (current !== void 0) {
		if (current.state.revoked || current.installationState.revoked) return true;
		current = current.parent;
	}
	return false;
}
function assertProjectionBinding(value) {
	if (value === null || typeof value !== "object" || !bindingMetadata.has(value)) failHost("INVALID_ARTIFACT", "binding", "an authentic successful ProjectionBinding is required");
}
function portableInput(value, resolution) {
	let input;
	try {
		input = normalizeJson(value, `${resolution.actual.contract.id}.input`);
	} catch {
		throw new InteractionFault("invalid-input", "not-started", "interaction input is not portable JSON");
	}
	const actualIssues = validateSchemaValue(resolution.actual.contract.inputSchema, input, `${resolution.actual.contract.id}.input`);
	if ((resolution.sameContract ? actualIssues : validateSchemaValue(resolution.expected.contract.inputSchema, input, `${resolution.actual.contract.id}.input`)).length > 0 || actualIssues.length > 0) throw new InteractionFault("invalid-input", "not-started", "interaction input does not match the bound contract");
	return input;
}
function outcomeBase(metadata, manifest) {
	return {
		bindingDigest: metadata.manifest.bindingDigest,
		projectionDigest: metadata.manifest.projectionDigest,
		installationId: metadata.installation.installationId,
		installationDigest: metadata.manifest.installationDigest,
		interactionId: manifest.interactionId,
		expectedContractDigest: manifest.expectedContractDigest,
		actualContractDigest: manifest.actualContractDigest,
		mode: manifest.mode,
		realizationId: manifest.realizationId
	};
}
function requestInvocationPolicy(metadata, resolution) {
	return Object.freeze({
		mode: "request",
		bindingDigest: metadata.manifest.bindingDigest,
		projectionDigest: metadata.manifest.projectionDigest,
		installationId: metadata.manifest.installationId,
		installationDigest: metadata.manifest.installationDigest,
		expectedProgramDigest: metadata.manifest.expectedProgramDigest,
		actualProgramDigest: metadata.manifest.actualProgramDigest,
		installationProgramDigest: metadata.installation.manifest.program.programDigest,
		interactionId: resolution.manifest.interactionId,
		expectedContractDigest: resolution.manifest.expectedContractDigest,
		actualContractDigest: resolution.manifest.actualContractDigest,
		realizationId: resolution.manifest.realizationId
	});
}
function notStartedFault(metadata, manifest, cause) {
	return Object.freeze({
		...outcomeBase(metadata, manifest),
		certainty: "not-started",
		result: Object.freeze({
			kind: "fault",
			cause
		})
	});
}
async function admitted(metadata, resolution, input, context) {
	const lineage = [];
	let current = metadata;
	while (current !== void 0) {
		lineage.push(current);
		current = current.parent;
	}
	for (const stage of lineage.reverse()) {
		if (bindingRevoked(metadata)) return { decision: "allow" };
		const stageResolution = stage.interactions.get(resolution.manifest.interactionId)?.byMode.get(resolution.manifest.mode);
		if (stageResolution === void 0) return void 0;
		const decision = await admitOne(stage, stageResolution, input, context);
		if (decision?.decision !== "allow") return decision;
	}
	return { decision: "allow" };
}
async function admitOne(metadata, resolution, input, context) {
	try {
		const decision = await metadata.admission(Object.freeze({
			context,
			handle: Object.freeze({
				interactionId: resolution.manifest.interactionId,
				expectedContractDigest: resolution.manifest.expectedContractDigest,
				actualContractDigest: resolution.manifest.actualContractDigest,
				reads: resolution.expected.contract.reads,
				changes: resolution.expected.contract.changes
			}),
			mode: resolution.manifest.mode,
			input,
			policy: Object.freeze({
				installationId: metadata.installation.installationId,
				realizationId: resolution.manifest.realizationId
			})
		}));
		if (decision === null || typeof decision !== "object" || decision.decision !== "allow" && decision.decision !== "deny") return;
		return decision;
	} catch {
		return;
	}
}
function modeResolution(metadata, binding, interaction, mode) {
	const resolved = resolvedMetadata.get(interaction);
	if (!resolved || resolved.binding !== binding) return void 0;
	return metadata.interactions.get(resolved.interactionId)?.byMode.get(mode);
}
async function rawInvoke(binding, interaction, mode, input, context) {
	const metadata = bindingMetadata.get(binding);
	if (metadata?.observer === void 0) return rawInvokeUnobserved(binding, interaction, mode, input, context);
	const correlation = observationCorrelation(metadata.observer, context);
	const outcome = await rawInvokeUnobserved(binding, interaction, mode, input, context);
	const descriptor = metadata?.interactions.get(outcome.interactionId)?.byMode.get(mode)?.actual.contract;
	await publishObservation(metadata.observer, outcome, descriptor?.reads ?? [], descriptor?.changes ?? [], correlation);
	return outcome;
}
async function rawInvokeUnobserved(binding, interaction, mode, rawInput, context) {
	const metadata = bindingMetadata.get(binding);
	if (!metadata) return failHost("INVALID_INVOCATION", "binding", "an authentic ProjectionBinding is required");
	const resolution = modeResolution(metadata, binding, interaction, mode);
	if (!resolution) throw new InteractionFault("invalid-invocation", "not-started", "resolved interaction or mode does not belong to this Binding");
	if (bindingRevoked(metadata)) return notStartedFault(metadata, resolution.manifest, "revoked");
	let input;
	try {
		input = portableInput(rawInput, resolution);
	} catch (error) {
		return notStartedFault(metadata, resolution.manifest, error instanceof InteractionFault ? error.cause : "invalid-input");
	}
	const decision = await admitted(metadata, resolution, input, context);
	if (!decision) return notStartedFault(metadata, resolution.manifest, "admission-failed");
	if (decision.decision === "deny") return Object.freeze({
		...outcomeBase(metadata, resolution.manifest),
		certainty: "not-started",
		result: Object.freeze({
			kind: "denied",
			code: "CALL_NOT_ADMITTED"
		})
	});
	if (bindingRevoked(metadata)) return notStartedFault(metadata, resolution.manifest, "revoked");
	if (metadata.coordinator !== void 0) {
		const request = Object.freeze({
			policy: Object.freeze(outcomeBase(metadata, resolution.manifest)),
			interaction: bindingDescriptions(metadata.manifest).find((entry) => entry.interactionId === resolution.manifest.interactionId && entry.mode === mode),
			input,
			context
		});
		let closed = false;
		let execution;
		const proceed = () => {
			if (closed) return Promise.reject(/* @__PURE__ */ new TypeError("coordination continuation has expired"));
			execution ??= Promise.resolve().then(() => bindingRevoked(metadata) ? notStartedFault(metadata, resolution.manifest, "revoked") : dispatchInvocation(metadata, resolution, mode, input, context));
			return execution;
		};
		try {
			const returned = metadata.coordinator(request, proceed);
			if (!(returned !== null && typeof returned === "object" && "then" in returned)) closed = true;
			const coordinated = await returned;
			closed = true;
			if (execution === void 0 && bindingRevoked(metadata)) return notStartedFault(metadata, resolution.manifest, "revoked");
			return checkedCoordinatedOutcome(coordinated, request);
		} catch {
			closed = true;
			return Object.freeze({
				...request.policy,
				certainty: "unknown",
				result: Object.freeze({
					kind: "fault",
					cause: "realization-failed"
				})
			});
		}
	}
	return dispatchInvocation(metadata, resolution, mode, input, context);
}
async function dispatchInvocation(metadata, resolution, mode, input, context) {
	if (mode === "request") try {
		const proposal = normalizeJson(await resolution.actual.request.execute(input, context, requestInvocationPolicy(metadata, resolution)), `${resolution.actual.contract.id}.proposal`);
		if (validateSchemaValue(resolution.actual.request.previewSchema, proposal, `${resolution.actual.contract.id}.proposal`).length > 0) return notStartedFault(metadata, resolution.manifest, "request-failed");
		return Object.freeze({
			...outcomeBase(metadata, resolution.manifest),
			certainty: "not-started",
			result: Object.freeze({
				kind: "proposed",
				proposal
			})
		});
	} catch {
		return notStartedFault(metadata, resolution.manifest, "request-failed");
	}
	try {
		const raw = await resolution.actual.direct.execute(input, context);
		const native = nativeDispatchOutcomeRecord(raw);
		if (native?.kind === "denied") return Object.freeze({
			...outcomeBase(metadata, resolution.manifest),
			certainty: "not-started",
			result: Object.freeze({
				kind: "denied",
				code: native.code
			})
		});
		if (native?.kind === "fault") return Object.freeze({
			...outcomeBase(metadata, resolution.manifest),
			certainty: native.certainty,
			result: Object.freeze({
				kind: "fault",
				cause: "realization-failed"
			})
		});
		if (native?.kind === "declared-error") {
			const actualSchema = resolution.actual.errorSchemas[native.code];
			if (actualSchema !== void 0 && validateSchemaValue(actualSchema, native.details, `${resolution.actual.contract.id}.errors.${native.code}`).length === 0) return Object.freeze({
				...outcomeBase(metadata, resolution.manifest),
				certainty: "completed",
				result: Object.freeze({
					kind: "declared-error",
					code: native.code,
					details: native.details
				})
			});
			return Object.freeze({
				...outcomeBase(metadata, resolution.manifest),
				certainty: "unknown",
				result: Object.freeze({
					kind: "fault",
					cause: "invalid-realization-outcome"
				})
			});
		}
		const outputValue = native?.kind === "returned" ? native.value : raw;
		let output;
		try {
			output = normalizeJson(outputValue, `${resolution.actual.contract.id}.output`);
		} catch {
			return Object.freeze({
				...outcomeBase(metadata, resolution.manifest),
				certainty: "unknown",
				result: Object.freeze({
					kind: "fault",
					cause: "invalid-realization-outcome"
				})
			});
		}
		const actualIssues = validateSchemaValue(resolution.actual.contract.outputSchema, output, `${resolution.actual.contract.id}.output`);
		const expectedIssues = resolution.sameContract ? actualIssues : validateSchemaValue(resolution.expected.contract.outputSchema, output, `${resolution.actual.contract.id}.output`);
		if (actualIssues.length > 0 || expectedIssues.length > 0) return Object.freeze({
			...outcomeBase(metadata, resolution.manifest),
			certainty: "unknown",
			result: Object.freeze({
				kind: "fault",
				cause: "invalid-realization-outcome"
			})
		});
		return Object.freeze({
			...outcomeBase(metadata, resolution.manifest),
			certainty: "completed",
			result: Object.freeze({
				kind: "returned",
				value: output
			})
		});
	} catch (error) {
		if (isAuthenticDeclaredError(error)) {
			const definition = definitionForDeclaredError(error);
			const actualSchema = resolution.actual.errorSchemas[error.code];
			if (definition === resolution.actual.definition && actualSchema !== void 0 && error.interactionId === resolution.manifest.interactionId && validateSchemaValue(actualSchema, error.details, `${error.interactionId}.errors.${error.code}`).length === 0) return Object.freeze({
				...outcomeBase(metadata, resolution.manifest),
				certainty: "completed",
				result: Object.freeze({
					kind: "declared-error",
					code: error.code,
					details: error.details
				})
			});
			return Object.freeze({
				...outcomeBase(metadata, resolution.manifest),
				certainty: "unknown",
				result: Object.freeze({
					kind: "fault",
					cause: "invalid-realization-outcome"
				})
			});
		}
		return Object.freeze({
			...outcomeBase(metadata, resolution.manifest),
			certainty: "unknown",
			result: Object.freeze({
				kind: "fault",
				cause: "realization-failed"
			})
		});
	}
}
function throwTyped(outcome) {
	if (outcome.result.kind === "declared-error") throw restoreDeclaredInteractionError(outcome.interactionId, outcome.expectedContractDigest, outcome.result.code, outcome.result.details);
	if (outcome.result.kind === "denied") throw new InteractionFault("denied", "not-started", "interaction admission was denied");
	const rawCause = outcome.result.kind === "fault" ? outcome.result.cause : "invalid-invocation";
	throw new InteractionFault(rawCause === "admission-failed" || rawCause === "invalid-realization-outcome" || rawCause === "revoked" || rawCause === "invalid-input" || rawCause === "request-failed" || rawCause === "realization-failed" || rawCause === "invalid-invocation" ? rawCause : "realization-failed", outcome.certainty === "completed" ? "unknown" : outcome.certainty, "interaction invocation failed");
}
function argsForTyped(handle, args) {
	if (handle.inputArity === 0) return {
		input: null,
		context: args[0]
	};
	return {
		input: args[0],
		context: args[1]
	};
}
function createCaller(binding) {
	const metadata = bindingMetadata.get(binding);
	const caller = {
		async call(handle, ...args) {
			const projected = metadataForProjectedHandle(handle);
			if (!projected || projected.projection !== metadata.projection) throw new InteractionFault("invalid-invocation", "not-started", "caller requires a handle from its Projection");
			const { input, context } = argsForTyped(handle, args);
			const resolved = binding.resolve(handle.interactionId);
			if (!resolved) throw new InteractionFault("invalid-invocation", "not-started", "projected interaction is not bound");
			const outcome = await rawInvoke(binding, resolved, "direct", input, context);
			if (outcome.result.kind === "returned") return outcome.result.value;
			return throwTyped(outcome);
		},
		async callRaw(interaction, input, context) {
			return rawInvoke(binding, interaction, "direct", input, context);
		}
	};
	if ([...metadata.interactions.values()].some((interaction) => interaction.byMode.has("request"))) {
		caller.request = async (handle, ...args) => {
			const projected = metadataForProjectedHandle(handle);
			if (!projected || projected.projection !== metadata.projection) throw new InteractionFault("invalid-invocation", "not-started", "caller requires a handle from its Projection");
			const { input, context } = argsForTyped(handle, args);
			const outcome = await rawInvoke(binding, binding.resolve(handle.interactionId), "request", input, context);
			if (outcome.result.kind === "proposed") return outcome.result.proposal;
			return throwTyped(outcome);
		};
		caller.requestRaw = async (interaction, input, context) => rawInvoke(binding, interaction, "request", input, context);
	}
	return Object.freeze(caller);
}
var admitAll = Object.freeze(() => Object.freeze({ decision: "allow" }));
/** Admit when `allow(context)` is true; otherwise deny with `reason`. */
function admitWhen(allow, reason = "denied") {
	return (request) => allow(request.context) ? { decision: "allow" } : {
		decision: "deny",
		reason: typeof reason === "function" ? reason(request.context) : reason
	};
}
async function bindProjection(projection, installation, options) {
	const projectionMeta = metadataForProjection(projection);
	const installationMeta = metadataForInstallation(installation);
	const admission = options?.admit;
	const observer = snapshotObserver(options?.observation);
	const coordinator = options?.coordinate;
	if (coordinator !== void 0 && typeof coordinator !== "function") throw new TypeError("Binding coordinator must be a function");
	if (typeof admission !== "function") return failHost("INVALID_ADMISSION", "bindProjection.admit", "Binding requires an explicit admission function");
	const issues = [];
	const modeEntries = [];
	const expectedById = new Map(projection.program.interactions.map((descriptor) => [descriptor.contract.id, descriptor]));
	for (const entry of projectionMeta.aliases.values()) {
		const expected = expectedById.get(entry.interaction.interactionId);
		const actual = installationMeta.interactions.get(entry.interaction.interactionId);
		const assessment = assessInteraction(entry.interaction, expected.contract, actual && {
			contract: actual.contract,
			inputArity: actual.inputArity,
			direct: actual.direct !== void 0,
			request: actual.request !== void 0
		}, installationMeta.state.revoked);
		issues.push(...assessment);
		if (assessment.length > 0 || !actual) continue;
		for (const mode of entry.interaction.modes) {
			const realization = mode === "direct" ? actual.direct : actual.request;
			modeEntries.push(Object.freeze({
				alias: entry.alias,
				expected,
				actual,
				mode,
				realizationId: realization.realizationId
			}));
		}
	}
	if (issues.length > 0) return Object.freeze({
		status: "unrealized",
		report: Object.freeze({
			projection: projection.manifest,
			installationId: installation.installationId,
			issues: Object.freeze(issues)
		})
	});
	return constructBinding(projection, installation, admission, observer, modeEntries, void 0, coordinator);
}
/** Derive a caller capability without discarding its inherited admission or revocation. */
async function restrictBinding(parent, options) {
	assertProjectionBinding(parent);
	const metadata = bindingMetadata.get(parent);
	const projection = options.projection;
	const admission = options.admit;
	const projectionMeta = metadataForProjection(projection);
	if (typeof admission !== "function") return failHost("INVALID_ADMISSION", "restrictBinding.admit", "Binding requires an explicit admission function");
	const issues = [];
	const modeEntries = [];
	for (const entry of [...projectionMeta.aliases.values()].sort((left, right) => compareUtf8(left.alias, right.alias))) {
		const selected = entry.interaction;
		const source = metadata.interactions.get(selected.interactionId);
		const issue = (reason, message, mode) => {
			issues.push(Object.freeze({
				alias: entry.alias,
				interactionId: selected.interactionId,
				reason,
				message,
				...mode === void 0 ? {} : { mode }
			}));
		};
		if (metadata.installationState.revoked) issue("installation-revoked", "the Installation was revoked before binding");
		else if (bindingRevoked(metadata)) issue("binding-revoked", "the parent Binding was revoked before restriction");
		if (source === void 0) {
			issue("interaction-not-selected", "the parent Binding does not select this interaction");
			continue;
		}
		const first = [...source.byMode.values()][0];
		if (selected.expectedContractDigest !== first.manifest.expectedContractDigest) issue("contract-not-selected", "the child must retain the parent's exact expected contract");
		if (selected.inputArity !== source.public.inputArity) issue("arity-not-selected", "the child must retain the parent's exact input arity");
		for (const mode of selected.modes) {
			const resolution = source.byMode.get(mode);
			if (resolution === void 0) {
				issue("mode-not-selected", "the parent Binding does not select this mode", mode);
				continue;
			}
			modeEntries.push(Object.freeze({
				alias: entry.alias,
				expected: resolution.expected,
				actual: resolution.actual,
				mode,
				realizationId: resolution.manifest.realizationId
			}));
		}
	}
	if (issues.length > 0 || bindingRevoked(metadata)) return Object.freeze({
		status: "unrealized",
		report: Object.freeze({
			projection: projection.manifest,
			installationId: metadata.installation.installationId,
			issues: Object.freeze(issues)
		})
	});
	return constructBinding(projection, metadata.installation, admission, metadata.observer, modeEntries, metadata);
}
async function constructBinding(projection, installation, admission, observer, modeEntries, parent, coordinator = parent?.coordinator) {
	const projectionMeta = metadataForProjection(projection);
	const installationMeta = metadataForInstallation(installation);
	const actualDescriptors = [...new Map(modeEntries.map((entry) => [entry.actual.descriptor.contract.id, entry.actual.descriptor])).values()];
	const actualProgram = await createProgram(actualDescriptors);
	const actualAvailability = [];
	for (const descriptor of actualProgram.interactions) {
		const entries = modeEntries.filter((entry) => entry.actual.contract.id === descriptor.contract.id);
		const direct = entries.find((entry) => entry.mode === "direct");
		const request = entries.find((entry) => entry.mode === "request");
		actualAvailability.push({
			interactionId: descriptor.contract.id,
			...direct === void 0 ? {} : { direct: { realizationId: direct.realizationId } },
			...request === void 0 ? {} : { request: {
				realizationId: request.realizationId,
				controlDigest: request.actual.request.controlDigest,
				previewSchema: request.actual.request.previewSchema
			} }
		});
	}
	const actualCatalog = createCatalog(actualProgram, actualAvailability);
	const manifestInteractions = modeEntries.map((entry) => Object.freeze({
		alias: entry.alias,
		interactionId: entry.actual.contract.id,
		expectedContractDigest: entry.expected.contractDigest,
		actualContractDigest: entry.actual.descriptor.contractDigest,
		inputArity: entry.actual.inputArity,
		mode: entry.mode,
		realizationId: entry.realizationId,
		...entry.mode === "request" ? { request: Object.freeze({
			controlDigest: entry.actual.request.controlDigest,
			previewSchema: entry.actual.request.previewSchema
		}) } : {}
	})).sort((left, right) => {
		const alias = compareUtf8(left.alias, right.alias);
		return alias === 0 ? compareUtf8(left.mode, right.mode) : alias;
	});
	const identity = Object.freeze({
		version: 1,
		projectionDigest: projection.projectionDigest,
		installationId: installation.installationId,
		installationDigest: installation.manifest.installationDigest,
		expectedProgramDigest: projection.program.programDigest,
		actualProgramDigest: actualProgram.programDigest,
		expectedProgram: projection.program,
		actualProgram,
		actualCatalog,
		interactions: Object.freeze(manifestInteractions)
	});
	const bindingDigest = await hashJson(PROJECTION_BINDING_DOMAIN, identity);
	const manifest = Object.freeze({
		...identity,
		version: 1,
		bindingDigest
	});
	if (installationMeta.state.revoked || parent !== void 0 && bindingRevoked(parent)) {
		const reason = installationMeta.state.revoked ? "installation-revoked" : "binding-revoked";
		const message = installationMeta.state.revoked ? "the Installation was revoked before binding" : "the parent Binding was revoked before restriction";
		return Object.freeze({
			status: "unrealized",
			report: Object.freeze({
				projection: projection.manifest,
				installationId: installation.installationId,
				issues: Object.freeze(projection.manifest.interactions.map((selected) => Object.freeze({
					alias: selected.alias,
					interactionId: selected.interactionId,
					reason,
					message
				})))
			})
		});
	}
	const interactionResolutions = /* @__PURE__ */ new Map();
	let binding;
	const state = { revoked: false };
	binding = Object.freeze({
		manifest,
		connect() {
			return createCaller(binding);
		},
		resolve(interactionId) {
			return interactionResolutions.get(interactionId)?.public;
		},
		async invoke(invocation, context) {
			if (!invocation || typeof invocation !== "object" || invocation.mode !== "direct" && invocation.mode !== "request") return failHost("INVALID_INVOCATION", "invocation", "raw invocation requires a resolved interaction, mode, and input");
			return rawInvoke(binding, invocation.interaction, invocation.mode, invocation.input, context);
		}
	});
	const controller = Object.freeze({
		get revoked() {
			return state.revoked;
		},
		revoke() {
			if (state.revoked) return false;
			state.revoked = true;
			return true;
		}
	});
	bindingMetadata.set(binding, {
		projection,
		installation,
		installationState: installationMeta.state,
		manifest,
		admission,
		...observer === void 0 ? {} : { observer },
		...coordinator === void 0 ? {} : { coordinator },
		interactions: interactionResolutions,
		state,
		...parent === void 0 ? {} : { parent }
	});
	for (const entry of projectionMeta.aliases.values()) {
		const manifestModes = manifestInteractions.filter((interaction) => interaction.interactionId === entry.interaction.interactionId);
		const publicModes = manifestModes.map((interaction) => Object.freeze({
			mode: interaction.mode,
			realizationId: interaction.realizationId,
			expectedContractDigest: interaction.expectedContractDigest,
			actualContractDigest: interaction.actualContractDigest,
			...interaction.request === void 0 ? {} : { request: interaction.request }
		}));
		const publicResolution = Object.freeze({
			interactionId: entry.interaction.interactionId,
			inputArity: entry.interaction.inputArity,
			modes: Object.freeze(publicModes)
		});
		const byMode = /* @__PURE__ */ new Map();
		for (const manifestEntry of manifestModes) {
			const source = modeEntries.find((candidate) => candidate.actual.contract.id === manifestEntry.interactionId && candidate.mode === manifestEntry.mode);
			byMode.set(manifestEntry.mode, Object.freeze({
				manifest: manifestEntry,
				expected: source.expected,
				actual: source.actual,
				sameContract: manifestEntry.expectedContractDigest === manifestEntry.actualContractDigest
			}));
		}
		interactionResolutions.set(entry.interaction.interactionId, Object.freeze({
			public: publicResolution,
			byMode
		}));
		resolvedMetadata.set(publicResolution, {
			binding,
			interactionId: entry.interaction.interactionId
		});
	}
	return Object.freeze({
		status: "bound",
		binding,
		controller
	});
}
//#endregion
export { restrictBinding as a, metadataForInstallation as c, bindProjection as i, implementInteractions as l, admitWhen as n, assessProjection as o, assertProjectionBinding as r, installInteractions as s, admitAll as t };
