import { f as failHost } from "./definitions-CFjJCGn-.js";
import { canonicalJson, cloneJson, normalizeJson, validateSchemaValue } from "@foxworth/boundary/program";
//#region packages/core/host/src/observed/view.ts
/** Capturing views never escape their snapshot lifetime. Failed or unawaited
* reads make the invocation ineligible for retention. */
function captureView(snapshot) {
	const observations = [];
	const state = {
		active: true,
		failed: false,
		pending: 0
	};
	const enter = () => {
		if (!state.active) throw new Error("observation view is closed");
		state.pending++;
	};
	return {
		view: Object.freeze({
			async read(key) {
				enter();
				try {
					const owned = normalizeJson(key);
					const result = await snapshot.read(owned);
					if (result.kind !== "present" && result.kind !== "absent") throw new TypeError("invalid point evidence");
					const token = normalizeJson(result.token);
					const value = result.kind === "present" ? normalizeJson(result.value) : null;
					if (!state.active) throw new Error("observation view is closed");
					observations.push(Object.freeze({
						kind: "point",
						key: owned,
						present: result.kind === "present",
						token
					}));
					return result.kind === "present" ? Object.freeze({
						kind: "present",
						value
					}) : Object.freeze({ kind: "absent" });
				} catch (error) {
					state.failed = true;
					throw error;
				} finally {
					state.pending--;
				}
			},
			async query(query) {
				enter();
				try {
					const owned = normalizeJson(query);
					const result = await snapshot.query(owned);
					const token = normalizeJson(result.token);
					const value = normalizeJson(result.value);
					if (!state.active) throw new Error("observation view is closed");
					observations.push(Object.freeze({
						kind: "query",
						query: owned,
						token
					}));
					return value;
				} catch (error) {
					state.failed = true;
					throw error;
				} finally {
					state.pending--;
				}
			}
		}),
		observations,
		state
	};
}
//#endregion
//#region packages/core/host/src/observed/runtime.ts
function createObservedExecutor(options, contract, pins) {
	const entries = /* @__PURE__ */ new Map();
	const reuse = options.reuse === "validated" && options.maxEntries > 0;
	let revoked = false;
	const report = async (diagnostic) => {
		try {
			await options.diagnostic?.(Object.freeze(diagnostic));
		} catch {}
	};
	const execute = async (input, context) => {
		await options.authorize(input, context);
		const scope = normalizeJson(options.scope(context));
		const key = canonicalJson(normalizeJson({
			input,
			scope,
			...pins
		}));
		let diagnostic;
		let invoked = false;
		let invocations = 0;
		let ended = false;
		let completed = false;
		let callbackOutput;
		let activeCapture;
		let candidate;
		let output;
		try {
			output = await options.snapshots.withSnapshot(context, scope, (snapshot) => {
				invocations++;
				const computation = (async () => {
					if (invoked || ended) throw new Error("snapshot source must invoke its callback exactly once before settling");
					invoked = true;
					if (revoked) throw new Error("observed read installation is revoked");
					let validations = 0;
					let reason = reuse ? "miss" : "reuse-off";
					const retained = reuse ? entries.get(key) : void 0;
					if (retained) {
						reason = "matching";
						for (const observation of retained.observations) {
							validations++;
							let validation;
							try {
								validation = await snapshot.validate(observation);
							} catch {
								validation = "unavailable";
							}
							if (validation !== "matching") {
								reason = validation === "changed" ? "changed" : "unavailable";
								break;
							}
						}
						if (reason === "matching") {
							diagnostic = {
								reused: true,
								validations,
								observations: retained.observations.length,
								reason
							};
							if (ended) throw new Error("snapshot source settled before evaluation completed");
							completed = true;
							callbackOutput = retained.output;
							return cloneJson(retained.output);
						}
						entries.delete(key);
					}
					if (ended) throw new Error("snapshot source settled before evaluation completed");
					const captured = captureView(snapshot);
					activeCapture = captured;
					let result;
					try {
						result = normalizeJson(await options.evaluate(input, captured.view, context));
						if (validateSchemaValue(contract.outputSchema, result).length > 0) throw new TypeError("observed read returned invalid output");
						if (!revoked && reuse && !captured.state.failed && captured.state.pending === 0) candidate = Object.freeze({
							output: result,
							observations: Object.freeze([...captured.observations])
						});
					} finally {
						captured.state.active = false;
					}
					diagnostic = {
						reused: false,
						validations,
						observations: captured.observations.length,
						reason
					};
					completed = true;
					callbackOutput = result;
					return cloneJson(result);
				})();
				computation.catch(() => {});
				return computation;
			});
		} finally {
			ended = true;
			if (activeCapture) activeCapture.state.active = false;
		}
		if (!invoked) throw new Error("snapshot source did not invoke its callback");
		if (invocations !== 1) throw new Error("snapshot source must invoke its callback exactly once");
		if (!completed) throw new Error("snapshot source did not await successful evaluation");
		if (canonicalJson(normalizeJson(output)) !== canonicalJson(callbackOutput)) throw new Error("snapshot source changed its callback result");
		if (candidate && !revoked) {
			if (!entries.has(key) && entries.size >= options.maxEntries) entries.delete(entries.keys().next().value);
			entries.set(key, candidate);
		}
		if (diagnostic) await report(diagnostic);
		return output;
	};
	return {
		execute,
		clear() {
			revoked = true;
			entries.clear();
		}
	};
}
//#endregion
//#region packages/core/host/src/observed/integration.ts
var observed = /* @__PURE__ */ new WeakMap();
function registerObservedRead(implementation, definition, options) {
	observed.set(implementation, Object.freeze({
		definition,
		options
	}));
}
/** Private integration seam: one executor/cache per exact installation. */
function installObservedRead(implementation, definition, contract, pins) {
	const metadata = observed.get(implementation);
	if (!metadata) return void 0;
	if (metadata.definition !== definition) failHost("FOREIGN_IMPLEMENTATIONS", "observedRead", "observed definition differs from installed definition");
	if (!pins.realizationId) failHost("REALIZATION_COVERAGE_MISMATCH", "observedRead", "direct realization requires an explicit identity");
	return createObservedExecutor(metadata.options, contract, pins);
}
//#endregion
export { registerObservedRead as n, installObservedRead as t };
