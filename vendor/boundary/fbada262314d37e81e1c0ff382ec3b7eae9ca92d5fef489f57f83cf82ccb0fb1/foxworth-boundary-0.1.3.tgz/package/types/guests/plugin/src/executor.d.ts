/** The host owns preparation, admission, concurrency, and worker lifetime. */
import type { PluginInspection } from "./host.js";
import { type GuestInstance, type PluginFault, type PluginHostFunction } from "./execution-types.js";
import { type ExecutorLimits, type ExecutorOptions } from "./worker-protocol.js";
export type { ExecutorOptions } from "./worker-protocol.js";
export type ExecutorStats = {
    workers: number;
    instances: number;
    /** Waiting jobs; active jobs are reported separately. */
    pending: number;
    active: number;
    preparations: number;
    compilations: number;
    cacheHits: number;
    preparedBytes: number;
    prepareMs: number;
    compileMs: number;
    instantiateMs: number;
    invokeMs: number;
};
export declare class PluginExecutor {
    readonly limits: Readonly<ExecutorLimits>;
    private readonly resourceLimits;
    private readonly slots;
    private readonly retiring;
    private closed;
    private bindingSequence;
    private closePromise?;
    private totals;
    constructor(options?: ExecutorOptions);
    /** Validate before copying or inspecting a component supplied to this executor. */
    assertArtifactSize(bytes: Uint8Array): void;
    stats(): ExecutorStats;
    private hasCapacity;
    private artifact;
    bind(bytes: Uint8Array, inspection: PluginInspection, host: Readonly<Record<string, PluginHostFunction>>): Promise<GuestInstance | PluginFault>;
    close(): Promise<void>;
}
export declare function createPluginExecutor(options?: ExecutorOptions): PluginExecutor;
