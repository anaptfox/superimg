import { type ImportOffer, type ImportCheck, type RequiredImport } from "./imports.js";
/**
 * How long one guest instance lives. Part of a realization's identity, not a
 * tuning knob: two calls on a `per-call` guest cannot observe each other; two
 * calls on a `persistent` one can, because guest heap state survives between
 * them. A contract cannot mention that state, so opting into it declares a
 * different realization and gets a different realization id. Mirrors
 * `PluginLifetime` in `crates/boundary-plugin`.
 */
export type PluginLifetime = "per-call" | "persistent";
/**
 * The inspected artifact a host may bind as an interaction implementation.
 *
 * Inspection reads bytes and checks a host-authored offer. It never executes
 * plugin code or grants authority beyond that offer.
 */
export type PluginInspection = {
    readonly required: readonly RequiredImport[];
    readonly componentDigest: `sha256:${string}`;
    readonly realizationId: `sha256:${string}`;
    readonly lifetime: PluginLifetime;
    /**
     * Digest of exactly what the offer grants. The realization id answers
     * "which bytes ran"; this answers "what could they reach". The offer is not
     * an input to the realization id — the same component under a narrow offer
     * and a wide one is byte-identical — so a receipt naming only the
     * realization is half a receipt. Mirrors `ImportOffer::authority_digest`
     * in `crates/boundary-plugin/src/imports.rs`.
     */
    readonly authorityDigest: `sha256:${string}`;
    readonly check: ImportCheck;
};
/**
 * Digests an offer: the interface it is scoped to, then every WIT name it
 * grants, sorted. The interface is included in full — package and version —
 * because bind already treats `footprints@1.0.0` and `@9.9.9` as different
 * interfaces.
 */
export declare function authorityDigest(offer: Pick<ImportOffer, "interface" | "witNames">): `sha256:${string}`;
/**
 * Inspects a plugin component against a host offer.
 *
 * Does not instantiate. Instantiation is a later host-runtime step and
 * must not run when `check.status` is `refused`.
 */
export declare function inspectPlugin(bytesValue: Uint8Array, offer: ImportOffer, witDigest: string, lifetime?: PluginLifetime): Promise<PluginInspection>;
