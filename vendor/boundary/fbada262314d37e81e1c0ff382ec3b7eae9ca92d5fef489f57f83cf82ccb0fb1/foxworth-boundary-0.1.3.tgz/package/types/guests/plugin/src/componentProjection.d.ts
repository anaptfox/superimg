import type { RequiredImport } from "./imports.js";
import { type Form } from "./componentWat.js";
/** Only the enclosing component's imports can require authority from its host. */
export declare function requiredImports(root: Form): RequiredImport[];
