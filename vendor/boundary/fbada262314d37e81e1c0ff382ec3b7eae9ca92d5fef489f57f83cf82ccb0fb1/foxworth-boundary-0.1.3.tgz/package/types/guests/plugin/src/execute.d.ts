/** Node plugin loading: inspect and resolve authority before worker preparation. */
import { type PluginLifetime } from "./host.js";
import type { ImportOffer } from "./imports.js";
import type { PluginExecutor } from "./executor.js";
import { type PluginHostFunction, type PluginLoadResult } from "./execution-types.js";
export type { GuestInstance, PluginCallOptions, PluginCallResult, PluginFault, PluginHostFunction, PluginHostReply, PluginLoadResult } from "./execution-types.js";
/** The executor owns compilation, worker capacity, deadlines, and cleanup. */
export declare function loadPlugin(args: {
    executor: PluginExecutor;
    bytes: Uint8Array;
    offer: ImportOffer;
    witDigest: string;
    host: Readonly<Record<string, PluginHostFunction>>;
    lifetime?: PluginLifetime;
}): Promise<PluginLoadResult>;
