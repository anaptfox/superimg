import { type PluginCallOptions, type PluginCallResult, type PluginHostFunction } from "./execution-types.js";
import type { ExecutorLimits, ExecutorOptions, WorkerCommand, WorkerEvent } from "./worker-protocol.js";
type Command = Exclude<WorkerCommand, {
    type: "close";
}>;
type PendingCommand = Command extends infer C ? C extends Command ? Omit<C, "job"> : never : never;
type Job = {
    command: Command;
    resolve: (result: PluginCallResult) => void;
    controller: AbortController;
    timer: ReturnType<typeof setTimeout>;
    signal?: AbortSignal;
    abort: () => void;
};
export type SlotCallbacks = {
    prepared: (slot: WorkerSlot, event: Extract<WorkerEvent, {
        type: "prepared";
    }>) => boolean;
    result: (event: Extract<WorkerEvent, {
        type: "result";
    }>) => void;
    stopped: (slot: WorkerSlot) => void;
};
export declare class WorkerSlot {
    readonly digest: string;
    private readonly limits;
    private readonly callbacks;
    readonly bindings: Map<number, Readonly<Record<string, PluginHostFunction>>>;
    readonly queue: Job[];
    active?: Job;
    alive: boolean;
    ready: boolean;
    preparedBytes: number;
    /** Binds admitted by the cache that have not yet registered their handle. */
    reservations: number;
    lastUsed: number;
    private sequence;
    private worker;
    private prepareTimer;
    private termination?;
    constructor(digest: string, bytes: Uint8Array, limits: ExecutorLimits, resourceLimits: ExecutorOptions["resourceLimits"], callbacks: SlotCallbacks);
    enqueue(command: PendingCommand, options?: PluginCallOptions): Promise<PluginCallResult>;
    private settle;
    private cancel;
    private dispatch;
    private receive;
    private hostCall;
    closeBinding(binding: number): Promise<void>;
    stop(reason: string): Promise<void>;
}
export {};
