export type Atom = Readonly<{
    value: string;
    quoted: boolean;
    bytes?: Uint8Array;
}>;
export type Form = (Atom | Form)[];
export declare function fail(message: string): never;
/** Tokenize the printer's S-expressions, without interpreting Wasm grammar. */
export declare function forms(wat: string): Form;
export declare function atom(value: Atom | Form | undefined): string | undefined;
export declare function name(form: Form): string;
export declare function optionalDescriptor(form: Form): Form | undefined;
export declare function descriptor(form: Form): Form;
export declare function identifier(form: Form): string | undefined;
