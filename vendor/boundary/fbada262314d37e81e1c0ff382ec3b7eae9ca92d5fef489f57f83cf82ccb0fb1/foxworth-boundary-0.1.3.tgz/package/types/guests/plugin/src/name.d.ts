/**
 * Interaction identifier to WIT identifier derivation.
 *
 * Interaction ids follow the Program v1 token grammar,
 * `[A-Za-z0-9][A-Za-z0-9._~-]{0,127}`. WIT identifiers are lowercase kebab
 * segments, `[a-z][a-z0-9]*(-[a-z0-9]+)*`, and a small keyword set is
 * reserved. The two grammars do not correspond, so this module derives a name
 * and reports an exact failure rather than guessing.
 *
 * Derivation never invents authority or identity: the interaction id remains
 * the contract identity, and the derived name is only the WIT spelling of it.
 * The projector records both, so a reader can always recover the id.
 *
 * This is a from-scratch TypeScript port of the algorithm in
 * `crates/boundary-plugin/src/name.rs`. It must derive byte-identical WIT
 * identifiers for the same interaction id; the shared conformance vector is the
 * check, not this comment.
 */
import { BoundaryErrorBase } from "@foxworth/boundary/program";
/** Why an interaction id has no valid WIT spelling. */
export type NameDiagnosticCode = "EMPTY" | "SEGMENT_START" | "SEGMENT_CHARACTER" | "RESERVED";
/** One interaction id that cannot be spelled as a WIT identifier. */
export declare class NameError extends BoundaryErrorBase {
    readonly code: NameDiagnosticCode;
    /** The interaction id that failed. */
    readonly interactionId: string;
    /** The derived name at the point of failure, when one existed. */
    readonly derived?: string;
    /** The offending segment, for `SEGMENT_START` and `SEGMENT_CHARACTER`. */
    readonly segment?: string;
    constructor(code: NameDiagnosticCode, interactionId: string, message: string, options?: Readonly<{
        derived?: string;
        segment?: string;
    }>);
}
/** The outcome of deriving a WIT identifier: success or a structured failure. */
export type NameResult = {
    readonly ok: true;
    readonly value: string;
} | {
    readonly ok: false;
    readonly error: NameError;
};
/**
 * Derives the WIT identifier for one interaction id.
 *
 * Returns a structured {@link NameError} rather than throwing, so a caller
 * that must report every failing id (never just the first) can collect
 * results across a whole Program before deciding what to do.
 */
export declare function witIdentifier(interactionId: string): NameResult;
