export { NameError, witIdentifier, type NameDiagnosticCode, type NameResult, } from "./name.js";
export { DEFAULT_WIT_PROJECTION_OPTIONS, WitProjectionError, projectWit, type ProjectedInteraction, type WitProjection, type WitProjectionDiagnosticCode, type WitProjectionOptions, } from "./wit.js";
export { ImportOffer, qualifiedImport, type ImportCheck, type RequiredImport, } from "./imports.js";
export { readRequiredImports } from "./component.js";
export { authorityDigest, inspectPlugin, type PluginInspection, type PluginLifetime, } from "./host.js";
export { type GuestInstance, loadPlugin, type PluginCallOptions, type PluginCallResult, type PluginFault, type PluginHostFunction, type PluginHostReply, type PluginLoadResult, } from "./execute.js";
export { createPluginExecutor, PluginExecutor } from "./executor.js";
export type { ExecutorOptions } from "./worker-protocol.js";
