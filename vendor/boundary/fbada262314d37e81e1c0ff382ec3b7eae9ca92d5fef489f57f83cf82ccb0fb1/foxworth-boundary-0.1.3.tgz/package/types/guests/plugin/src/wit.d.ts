/**
 * Deterministic WIT world projection from a Program.
 *
 * The emitted world is a spelling of contracts the Program already owns. It
 * carries no authority: an import listed here is a name the host *may* map to
 * a function, never a grant. Binding checks that a component's actual imports
 * are a subset of the host's map; this file only decides what the guest is
 * allowed to ask for.
 *
 * Every interaction becomes one exported function taking canonical JSON and
 * returning `result<string, string>`. The ok payload is the interaction
 * output; the err payload is a declared interaction error. Anything else is a
 * trap, and a trap is an infrastructure fault with unknown certainty, never a
 * domain error. The JSON-string profile is deliberate: JSON Schema has no
 * total mapping onto WIT records and variants, so lowering waits for an
 * explicit opt-in profile.
 *
 * This is a from-scratch TypeScript port of
 * `crates/boundary-plugin/src/wit.rs`. It must emit byte-identical WIT text
 * for the same Program and options; the shared conformance vector is the
 * check, not this comment.
 */
import { BoundaryErrorBase, type Program, type Sha256Digest } from "@foxworth/boundary/program";
import { NameError } from "./name.js";
/** Options controlling the emitted package and world names. */
export type WitProjectionOptions = {
    /** WIT package name, such as `boundary:guest`. */
    readonly package: string;
    /** Package version, such as `1.0.0`. */
    readonly version: string;
    /** World name, such as `guest`. */
    readonly world: string;
    /** Interface name holding the host functions a guest may import. */
    readonly importsInterface: string;
};
/** Default options: `boundary:guest@1.0.0`, world `guest`, interface `footprints`. */
export declare const DEFAULT_WIT_PROJECTION_OPTIONS: WitProjectionOptions;
/** Why a Program has no valid WIT world. */
export type WitProjectionDiagnosticCode = "NAMES_UNSPELLABLE" | "NAME_COLLISION" | "FOOTPRINT_UNSPELLABLE" | "FOOTPRINT_COLLISION";
/**
 * A Program that has no valid WIT world. Exactly one of `errors`,
 * (`witName`, `interactionIds`), or (`footprint`, `cause`) is populated,
 * selected by `code`.
 */
export declare class WitProjectionError extends BoundaryErrorBase {
    readonly code: WitProjectionDiagnosticCode;
    /** Every interaction id that cannot be spelled in WIT, sorted. `NAMES_UNSPELLABLE` only. */
    readonly errors?: readonly NameError[];
    /** The colliding WIT identifier. `NAME_COLLISION` only. */
    readonly witName?: string;
    /** Every interaction id that derives `witName`, sorted. `NAME_COLLISION` only. */
    readonly interactionIds?: readonly string[];
    /** The offending footprint. `FOOTPRINT_UNSPELLABLE` only. */
    readonly footprint?: string;
    /** Every footprint that derives `witName`, sorted. `FOOTPRINT_COLLISION` only. */
    readonly footprints?: readonly string[];
    private constructor();
    /** One or more interaction ids have no valid WIT spelling. Never just the first. */
    static names(errors: readonly NameError[]): WitProjectionError;
    /** Two distinct interaction ids derive the same WIT identifier. */
    static collision(witName: string, interactionIds: readonly string[]): WitProjectionError;
    /** A footprint has no valid WIT spelling. */
    static footprint(footprint: string, cause: NameError): WitProjectionError;
    /**
     * Two distinct footprints derive the same WIT identifier.
     *
     * The interaction-name collision has a footprint twin, because the same
     * derivation collapses distinct sources the same way. Rendering both would
     * emit two functions with one name in a single interface: invalid WIT, and
     * a WIT digest computed over text no toolchain would accept.
     */
    static footprintCollision(witName: string, footprints: readonly string[]): WitProjectionError;
}
/** One projected interaction, pinning the WIT spelling to a contract identity. */
export type ProjectedInteraction = {
    /** The WIT function name. */
    readonly witName: string;
    /** The interaction id, which remains the contract identity. */
    readonly interactionId: string;
    /** The v1 contract digest. */
    readonly contractDigest: Sha256Digest;
};
/** A deterministic WIT world plus the mapping back to interaction identities. */
export type WitProjection = {
    /** The WIT source text. */
    readonly wit: string;
    /** Projected interactions, sorted by WIT name. */
    readonly interactions: readonly ProjectedInteraction[];
    /** Footprint names a guest may import, sorted. */
    readonly footprints: readonly string[];
    /** The Program digest this projection was derived from. */
    readonly programDigest: Sha256Digest;
};
/**
 * Projects a Program into a WIT world.
 *
 * The output is a pure function of the Program and the options: the same
 * inputs always produce byte-identical text, which is what lets the Rust and
 * TypeScript projectors be checked against one shared conformance vector.
 *
 * Throws {@link WitProjectionError} when an interaction id or footprint has no
 * valid WIT spelling, or when two ids collide. The projector never resolves a
 * collision by renaming; the host must supply an explicit alias.
 */
export declare function projectWit(program: Program, options?: Readonly<Partial<WitProjectionOptions>>): WitProjection;
