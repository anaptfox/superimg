/** One function a component genuinely imports. */
export type RequiredImport = {
    readonly instance: string | undefined;
    readonly name: string;
};
/** Outcome of checking a component's imports against a host offer. */
export type ImportCheck = {
    readonly status: "satisfied";
    readonly used: readonly string[];
} | {
    readonly status: "refused";
    readonly unmapped: readonly string[];
    readonly offered: readonly string[];
};
type CapturedOffer = Pick<ImportOffer, "interface" | "witNames" | "check">;
/** Internal capture: async inspection cannot observe later authority changes. */
export declare function snapshotImportOffer(offer: CapturedOffer): CapturedOffer;
/** The complete set of imports a host offers one guest. */
export declare class ImportOffer {
    readonly interface: string;
    private readonly entries;
    constructor(interfaceName: string);
    /**
     * Offers one footprint under its derived WIT name.
     *
     * Distinct footprints can derive one WIT name (`a.bC` and `a.b-c` both give
     * `a-b-c`). Overwriting the first would leave the host believing it offered
     * two capabilities while a guest reaches whichever was offered last — a
     * read-class footprint replaced by a change-class one, with nothing
     * reported. Mirrors `HostImports::provide` in Rust.
     */
    offer(footprint: string): ImportOffer;
    contains(witName: string): boolean;
    witNames(): string[];
    check(required: readonly RequiredImport[]): ImportCheck;
}
export declare function qualifiedImport(imported: RequiredImport): string;
export {};
