import type { RequiredImport } from "./imports.js";
/** Reads every root import member, retaining names and full interface versions. */
export declare function readRequiredImports(bytes: Uint8Array): Promise<RequiredImport[]>;
