import type { ResourceLimits } from "node:worker_threads";
import type { PluginCallResult } from "./execution-types.js";
import type { PluginLifetime } from "./host.js";
import type { RequiredImport } from "./imports.js";
export type ExecutorOptions = {
    maxWorkers?: number;
    maxInstances?: number;
    maxPending?: number;
    maxArtifactBytes?: number;
    maxPreparedBytes?: number;
    maxPayloadBytes?: number;
    prepareTimeoutMs?: number;
    callTimeoutMs?: number;
    /** V8 heap limits; these do not cap Wasm linear memory or total process RSS. */
    resourceLimits?: ResourceLimits;
};
export type ExecutorLimits = Required<Omit<ExecutorOptions, "resourceLimits">>;
export declare const DEFAULT_EXECUTOR_LIMITS: ExecutorLimits;
export type WorkerSetup = {
    bytes: Uint8Array;
    maxPreparedBytes: number;
    maxPayloadBytes: number;
};
export type WorkerCommand = {
    type: "bind";
    job: number;
    binding: number;
    required: readonly RequiredImport[];
    lifetime: PluginLifetime;
} | {
    type: "call";
    job: number;
    binding: number;
    name: string;
    input: string;
} | {
    type: "close";
    binding: number;
};
export type WorkerEvent = {
    type: "prepared";
    bytes: number;
    modules: number;
    prepareMs: number;
    compileMs: number;
} | {
    type: "prepare-failed";
    reason: string;
} | {
    type: "host";
    job: number;
    binding: number;
    name: string;
    request: string;
    shared: SharedArrayBuffer;
} | {
    type: "result";
    job: number;
    outcome: PluginCallResult;
    instantiateMs: number;
    invokeMs: number;
};
