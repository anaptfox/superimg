import type { InteractionMode, ProjectionBindingManifest } from "@foxworth/boundary/program";
import { type JsonValue } from "@foxworth/boundary/program";
import type { CheckedHandoff, HandoffExecutable, HandoffInvocation, HandoffOutcome } from "./types.js";
/** Snapshot and fully validate an untrusted v1 Binding handshake. */
export declare function validateProjectionBindingManifest(value: unknown): Promise<ProjectionBindingManifest>;
/** Snapshot and validate only the v1 invocation envelope shape. */
export declare function validateHandoffInvocation(value: unknown): HandoffInvocation;
/** Snapshot and validate an untrusted v1 outcome and its certainty law. */
export declare function validateHandoffOutcome(value: unknown): HandoffOutcome;
/** Validate a remote outcome against the exact handshake it claims to answer. */
export declare function validateHandoffOutcomeAgainstManifest(manifestValue: unknown, outcomeValue: unknown): Promise<HandoffOutcome>;
/** Check one response against the exact sent invocation and its pinned contracts.
 * Identity correlation does not prove which input computed a returned value.
 */
export declare function validateHandoffResponse(manifestValue: unknown, invocationValue: unknown, outcomeValue: unknown): Promise<HandoffOutcome>;
/** Execute exactly once: no retry, rebind, replay, or replacement following. */
export declare function executeHandoff<Context>(binding: HandoffExecutable, invocationValue: unknown, context: Context): Promise<HandoffOutcome>;
/** Create an exact portable envelope for one validated Binding mode. */
export declare function createHandoffInvocation(manifestValue: unknown, interactionId: string, mode: InteractionMode, input: JsonValue): Promise<HandoffInvocation>;
/** Bind the checked seam while keeping context invocation-scoped. */
export declare function createCheckedHandoff<Context>(binding: HandoffExecutable): Promise<CheckedHandoff<Context>>;
export { HandoffError, type HandoffDiagnosticCode } from "./errors.js";
export type { CheckedHandoff, HandoffBindingInvocation, HandoffCertainty, HandoffExecutable, HandoffFaultCause, HandoffInvocation, HandoffOutcome, HandoffResolvedInteraction, HandoffResult, HandoffValidationIssue, } from "./types.js";
export type { ProjectionBindingManifest, ProjectionBindingInteraction, } from "@foxworth/boundary/program";
