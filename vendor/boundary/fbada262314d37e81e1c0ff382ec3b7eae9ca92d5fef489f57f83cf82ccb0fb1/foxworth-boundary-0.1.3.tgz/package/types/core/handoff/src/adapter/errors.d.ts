import type { AnyInteractionDefinition, DefinitionErrors, InteractionHandle, ProjectedInteractionHandle } from "@foxworth/boundary";
import type { HandoffValidationIssue } from "@foxworth/boundary/handoff";
import { BoundaryErrorBase, type JsonValue, type Sha256Digest } from "@foxworth/boundary/program";
export type AdapterDiagnosticCode = "INVALID_DECLARATION" | "DUPLICATE_DECLARATION" | "INTERACTION_NOT_EXPOSED" | "INVALID_REQUEST" | "INVALID_RESPONSE" | "UNSUPPORTED_SCHEMA" | "SCHEMA_MISMATCH" | "STALE_BINDING" | "STALE_CONTRACT" | "STALE_REFERENCE" | "TRANSPORT_FAILURE" | "REMOTE_EXECUTION_FAILED";
export declare class AdapterError extends BoundaryErrorBase {
    readonly code: AdapterDiagnosticCode;
    constructor(code: AdapterDiagnosticCode, path: string, message: string, options?: Readonly<{
        cause?: unknown;
    }>);
}
/** A validated server diagnostic proving dispatch did not begin. */
export declare class RemoteProtocolRejection extends AdapterError {
    readonly certainty: "not-started";
    readonly status: 400 | 409;
    readonly remoteCode: string;
    constructor(status: 400 | 409, remoteCode: string, path: string);
}
type DefinitionOf<Handle> = Handle extends ProjectedInteractionHandle<InteractionHandle<infer Definition>, any> ? Definition : AnyInteractionDefinition;
export type InteractionDeclaredError<Handle> = DefinitionErrors<DefinitionOf<Handle>> extends infer Errors extends Readonly<Record<string, JsonValue>> ? {
    [Code in keyof Errors & string]: Readonly<{
        code: Code;
        details: Errors[Code];
    }>;
}[keyof Errors & string] : never;
export declare class RemoteDomainError<Value extends Readonly<{
    code: string;
    details: JsonValue;
}> = Readonly<{
    code: string;
    details: JsonValue;
}>> extends BoundaryErrorBase {
    readonly code: "REMOTE_DOMAIN_ERROR";
    readonly interactionId: string;
    readonly expectedContractDigest: Sha256Digest;
    readonly value: Value;
    constructor(interactionId: string, expectedContractDigest: Sha256Digest, value: Value);
}
export type RemoteInteractionDomainError<Handle> = RemoteDomainError<InteractionDeclaredError<Handle>>;
export declare function isDomainErrorFor<Handle extends {
    readonly interactionId: string;
    readonly contractDigest: Sha256Digest;
}>(handle: Handle, error: unknown): error is RemoteInteractionDomainError<Handle>;
/** The invocation crossed the dispatch boundary, so its consequence is unknown. */
export declare class RemoteInvocationError extends BoundaryErrorBase {
    readonly code: "REMOTE_INVOCATION_FAILED";
    readonly certainty: "unknown";
    readonly phase: "transport" | "response";
    constructor(phase: "transport" | "response", message: string, options?: Readonly<{
        cause?: unknown;
    }>);
}
export declare class RemoteProtocolError extends BoundaryErrorBase {
    readonly certainty: string;
    constructor(code: string, path: string, message: string, certainty?: string);
}
export declare class RemoteExecutionError extends BoundaryErrorBase {
    readonly code: "REMOTE_EXECUTION_FAILED";
    readonly certainty: string;
    readonly cause: string;
    readonly issues?: readonly HandoffValidationIssue[];
    constructor(path: string, certainty: string, cause: string, issues?: readonly HandoffValidationIssue[]);
}
export type RemoteInteractionError<Handle> = RemoteInteractionDomainError<Handle> | RemoteProtocolError | RemoteExecutionError | RemoteInvocationError | RemoteProtocolRejection | AdapterError;
export {};
