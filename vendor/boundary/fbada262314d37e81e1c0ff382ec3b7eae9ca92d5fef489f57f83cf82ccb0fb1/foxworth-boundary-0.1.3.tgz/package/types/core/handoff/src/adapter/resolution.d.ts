import type { InteractionMode, ProjectedInteractionHandle, Projection, ProjectionBindingManifest, ProjectionBindingInteraction } from "@foxworth/boundary";
import { type CheckedHandoff } from "@foxworth/boundary/handoff";
import { type InteractionDescriptor } from "@foxworth/boundary/program";
export type AnyProjectedInteractionHandle = ProjectedInteractionHandle<any, any, any>;
export type ResolvedBindingInteraction<Handle extends AnyProjectedInteractionHandle = AnyProjectedInteractionHandle> = Readonly<{
    handle: Handle;
    mode: InteractionMode;
    expected: InteractionDescriptor;
    actual: InteractionDescriptor;
    binding: ProjectionBindingInteraction;
}>;
export type BindingResolution = Readonly<{
    handoff: CheckedHandoff<any>;
    manifest: ProjectionBindingManifest;
    interactions: ReadonlyMap<string, ResolvedBindingInteraction>;
}>;
export type ResolvedProjectionInteraction<Handle extends AnyProjectedInteractionHandle = AnyProjectedInteractionHandle> = Readonly<{
    handle: Handle;
    mode: InteractionMode;
    descriptor: InteractionDescriptor;
}>;
export type ProjectionResolution = Readonly<{
    projection: Projection<any>;
    interactions: ReadonlyMap<string, ResolvedProjectionInteraction>;
}>;
export declare function interactionKey(interactionId: string, mode: InteractionMode): string;
export declare function snapshotProjectedHandle<Handle extends AnyProjectedInteractionHandle>(value: Handle, path?: string): Handle;
export declare function modeForHandle(handle: AnyProjectedInteractionHandle, requested: InteractionMode | undefined, path: string): InteractionMode;
export declare function compileBindingResolution(handoff: CheckedHandoff<any>, selected: readonly Readonly<{
    handle: AnyProjectedInteractionHandle;
    mode: InteractionMode;
}>[]): Promise<BindingResolution>;
export declare function compileProjectionResolution(projection: Projection<any>, selected: readonly Readonly<{
    handle: AnyProjectedInteractionHandle;
    mode: InteractionMode;
}>[]): Promise<ProjectionResolution>;
