import type { AnyInteractionDefinition, DefinitionArity, DefinitionInput, DefinitionOutput, InteractionHandle, InteractionMode, ProjectedInteractionHandle } from "@foxworth/boundary";
import { type CheckedHandoff, type HandoffFaultCause, type HandoffInvocation, type HandoffOutcome, type HandoffValidationIssue } from "@foxworth/boundary/handoff";
import type { JsonValue } from "@foxworth/boundary/program";
import { type AnyProjectedInteractionHandle, type BindingResolution, type ResolvedBindingInteraction } from "./resolution.js";
type DefinitionOf<Handle> = Handle extends ProjectedInteractionHandle<InteractionHandle<infer Definition>, any> ? Definition : AnyInteractionDefinition;
export type InteractionInput<Handle extends AnyProjectedInteractionHandle> = DefinitionInput<DefinitionOf<Handle>>;
export type InteractionOutput<Handle extends AnyProjectedInteractionHandle> = DefinitionOutput<DefinitionOf<Handle>>;
export type InteractionHasInput<Handle extends AnyProjectedInteractionHandle> = DefinitionArity<DefinitionOf<Handle>> extends 0 ? false : true;
export type SerializedInvocation<Input extends JsonValue = JsonValue> = HandoffInvocation<Input>;
export type RemoteCallResult = HandoffOutcome;
export type ExposedInteraction = ResolvedBindingInteraction;
export type Exposure = BindingResolution;
export declare function compileExposure(handoff: CheckedHandoff<any>, selected: readonly Readonly<{
    handle: AnyProjectedInteractionHandle;
    mode: InteractionMode;
}>[]): Promise<Exposure>;
export declare function compileHandoffExposure(handoff: CheckedHandoff<any>): Promise<Exposure>;
/** Preserve exact Binding pins while sanitizing a failure outside Handoff. */
export declare function sanitizedInternalResult(exposure: Exposure, exposed: ExposedInteraction): HandoffOutcome;
export declare function faultResult(exposure: Exposure, exposed: ExposedInteraction, cause: HandoffFaultCause, issues?: readonly HandoffValidationIssue[]): HandoffOutcome;
export declare function executeExposedInteraction<Context>(args: Readonly<{
    exposure: Exposure;
    context: Context;
    handle: AnyProjectedInteractionHandle;
    mode: InteractionMode;
    input: unknown;
}>): Promise<HandoffOutcome>;
/** Validate and serialize locally, before the consequential dispatch boundary. */
export declare function prepareExposedInteraction(args: Readonly<{
    exposure: Exposure;
    handle: AnyProjectedInteractionHandle;
    mode: InteractionMode;
    input: unknown;
}>): Promise<Readonly<{
    exposed: ExposedInteraction;
    invocation: HandoffInvocation;
}>>;
/** The only adapter step that crosses into host dispatch. */
export declare function invokePreparedInteraction<Context>(exposure: Exposure, invocation: HandoffInvocation, context: Context): Promise<HandoffOutcome>;
export declare function executeSerializedInvocation<Context>(args: Readonly<{
    handoff: CheckedHandoff<Context>;
    context: Context;
    invocation: HandoffInvocation;
}>): Promise<HandoffOutcome>;
export declare function statusForRemoteResult(result: HandoffOutcome): number;
export type { AnyProjectedInteractionHandle, CheckedHandoff, HandoffInvocation, HandoffOutcome, };
