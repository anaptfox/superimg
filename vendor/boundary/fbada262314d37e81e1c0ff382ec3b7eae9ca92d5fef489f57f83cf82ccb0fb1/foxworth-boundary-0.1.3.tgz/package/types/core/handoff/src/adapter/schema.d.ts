import { type JsonSchema, type JsonValue } from "@foxworth/boundary/program";
/** Normalize and validate one value against Program's canonical schema profile. */
export declare function validatePortableValue(schema: JsonSchema, value: unknown, path?: string): JsonValue;
