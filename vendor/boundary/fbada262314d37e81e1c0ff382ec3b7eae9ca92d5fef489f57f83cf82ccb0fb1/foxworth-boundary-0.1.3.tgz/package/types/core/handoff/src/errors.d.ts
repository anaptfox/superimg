import { BoundaryErrorBase } from "@foxworth/boundary/program";
import type { HandoffValidationIssue } from "./types.js";
export type HandoffDiagnosticCode = "INVALID_MANIFEST" | "UNSUPPORTED_VERSION" | "INVALID_INVOCATION" | "STALE_BINDING" | "STALE_INSTALLATION" | "INTERACTION_NOT_EXPOSED" | "MODE_NOT_EXPOSED" | "STALE_CONTRACT" | "STALE_REALIZATION" | "INVALID_INPUT" | "INVALID_OUTCOME";
export declare class HandoffError extends BoundaryErrorBase {
    readonly code: HandoffDiagnosticCode;
    readonly issues?: readonly HandoffValidationIssue[];
    constructor(code: HandoffDiagnosticCode, path: string, message: string, options?: Readonly<{
        cause?: unknown;
        issues?: readonly HandoffValidationIssue[];
    }>);
}
export declare function failHandoffWithIssues(code: HandoffDiagnosticCode, path: string, message: string, issues: readonly HandoffValidationIssue[]): never;
export declare function failHandoff(code: HandoffDiagnosticCode, path: string, message: string, cause?: unknown): never;
