import { type BindingInteractionDescription, type JsonValue, type RawInvocationOutcome } from "@foxworth/boundary/program";
import type { MaybePromise } from "./types.js";
export type InvocationPolicy = Readonly<Omit<RawInvocationOutcome, "certainty" | "result">>;
export interface CoordinatedInvocation<Context> {
    readonly policy: InvocationPolicy;
    readonly interaction: BindingInteractionDescription;
    readonly input: JsonValue;
    readonly context: Context;
}
/** Native host policy: admission precedes this hook, including retained-result disclosure.
 * The zero-argument continuation preserves the exact invocation and dispatches at most once.
 * Hosts own serialization, retained-input identity, storage, and reconciliation; unknown is not retry permission.
 */
export type InvocationCoordinator<Context> = (invocation: CoordinatedInvocation<Context>, proceed: () => Promise<RawInvocationOutcome>) => MaybePromise<RawInvocationOutcome>;
/** Check a host-retained outcome without accepting native request-owned factory tokens. */
export declare function checkedCoordinatedOutcome<Context>(value: unknown, request: CoordinatedInvocation<Context>): RawInvocationOutcome;
