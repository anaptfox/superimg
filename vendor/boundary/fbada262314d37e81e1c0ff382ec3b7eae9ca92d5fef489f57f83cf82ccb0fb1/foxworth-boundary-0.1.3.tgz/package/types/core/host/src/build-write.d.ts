import type { HostArtifactCheckResult, HostArtifactDestinationOptions, HostArtifactSet, HostArtifactWriteResult } from "./build-types.js";
export declare function writeHostArtifacts(artifacts: HostArtifactSet, options: HostArtifactDestinationOptions): Promise<HostArtifactWriteResult>;
export declare function checkHostArtifacts(artifacts: HostArtifactSet, options: HostArtifactDestinationOptions): Promise<HostArtifactCheckResult>;
