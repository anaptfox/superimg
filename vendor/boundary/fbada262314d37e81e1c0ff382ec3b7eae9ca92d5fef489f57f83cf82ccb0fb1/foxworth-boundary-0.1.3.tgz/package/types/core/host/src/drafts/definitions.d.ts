/**
 * A worker proposes a full contract that does not exist yet. Direct mode:
 * proposing never changes what is declared, so it stays ordinary and immediate.
 */
export declare const draftsPropose: import("..").InteractionDefinition<"drafts.propose", import("@foxworth/boundary/program").JsonValue, import("@foxworth/boundary/program").JsonValue, {
    readonly invalidDraft: any;
}, 1>;
/**
 * An author accepts a Draft. Request mode by default: acceptance is a
 * decision, distinct from the host's separate act of recompiling a Program
 * that declares the accepted contract.
 */
export declare const draftsAccept: import("..").InteractionDefinition<"drafts.accept", import("@foxworth/boundary/program").JsonValue, import("@foxworth/boundary/program").JsonValue, {
    readonly draftNotFound: any;
}, 1>;
/**
 * An author rejects a Draft with a reason from a closed set. Request mode by
 * default, for the same reason acceptance is: rejection is a decision.
 */
export declare const draftsReject: import("..").InteractionDefinition<"drafts.reject", import("@foxworth/boundary/program").JsonValue, import("@foxworth/boundary/program").JsonValue, {
    readonly draftNotFound: any;
    readonly invalidReason: any;
}, 1>;
/** The closed set of Draft interactions, ready for `compileInteractions`. */
export declare const draftsInteractions: Readonly<{
    propose: import("..").InteractionDefinition<"drafts.propose", import("@foxworth/boundary/program").JsonValue, import("@foxworth/boundary/program").JsonValue, {
        readonly invalidDraft: any;
    }, 1>;
    accept: import("..").InteractionDefinition<"drafts.accept", import("@foxworth/boundary/program").JsonValue, import("@foxworth/boundary/program").JsonValue, {
        readonly draftNotFound: any;
    }, 1>;
    reject: import("..").InteractionDefinition<"drafts.reject", import("@foxworth/boundary/program").JsonValue, import("@foxworth/boundary/program").JsonValue, {
        readonly draftNotFound: any;
        readonly invalidReason: any;
    }, 1>;
}>;
