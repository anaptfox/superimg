import type { InteractionContract, JsonValue } from "@foxworth/boundary/program";
import type { AnyInteractionDefinition } from "../types.js";
import type { ObservedReadOptions } from "./types.js";
type Options = ObservedReadOptions<AnyInteractionDefinition, unknown, JsonValue, JsonValue, JsonValue, JsonValue>;
export declare function registerObservedRead(implementation: Function, definition: AnyInteractionDefinition, options: Options): void;
/** Private integration seam: one executor/cache per exact installation. */
export declare function installObservedRead(implementation: Function, definition: AnyInteractionDefinition, contract: InteractionContract, pins: Readonly<{
    installationId: string;
    realizationId: string;
}>): {
    execute: (input: JsonValue, context: unknown) => Promise<unknown>;
    clear(): void;
} | undefined;
export {};
