/**
 * The business logic behind the three Draft interactions, factored out of
 * `defineInteraction` wiring so a host can call it directly (as these tests
 * do) or hand it to `implementInteractions`/a Control-style request
 * contribution.
 *
 * Every function here talks to a host-supplied {@link DraftStore} and
 * nothing else. None of them ever touches a Program, an Installation, or a
 * source file: turning an accepted Draft into a declared interaction remains
 * the host's separate, ordinary recompilation.
 */
import { type JsonObject, type InteractionContract, type Sha256Digest } from "@foxworth/boundary/program";
import { type DraftRejectReason, type DraftStore } from "./types.js";
/** Wire shape of {@link Draft} accepted by `drafts.propose`. */
export interface DraftInput {
    readonly version: 1;
    readonly contract: JsonObject;
    readonly gap: string;
    readonly proposer: string;
    readonly createdAt: string;
    readonly draftDigest: string;
}
export interface DraftProposeOutput {
    readonly draftDigest: Sha256Digest;
}
export interface DraftDecisionInput {
    readonly draftDigest: string;
    readonly decidedBy: string;
    readonly decidedAt: string;
}
export interface DraftAcceptOutput {
    readonly contract: InteractionContract;
    readonly contractDigest: Sha256Digest;
}
export interface DraftRejectInput extends DraftDecisionInput {
    readonly reason: string;
}
export interface DraftRejectOutput {
    readonly draftDigest: Sha256Digest;
    readonly reason: DraftRejectReason;
}
/**
 * `drafts.propose`: verify and persist a Draft. Direct mode. Never reads or
 * writes anything beyond `store.put`, and therefore never changes
 * what is declared.
 */
export declare function proposeDraft(store: DraftStore, input: DraftInput): Promise<DraftProposeOutput>;
/**
 * `drafts.accept`: request mode by default. Returns the accepted contract
 * and its digest and records the decision. It never mutates a live Program
 * and never writes source files.
 */
export declare function acceptDraft(store: DraftStore, input: DraftDecisionInput): Promise<DraftAcceptOutput>;
/**
 * `drafts.reject`: request mode by default. Takes a reason from the closed
 * set `ordinary-code` | `covered-by-existing` and records the decision.
 */
export declare function rejectDraft(store: DraftStore, input: DraftRejectInput): Promise<DraftRejectOutput>;
