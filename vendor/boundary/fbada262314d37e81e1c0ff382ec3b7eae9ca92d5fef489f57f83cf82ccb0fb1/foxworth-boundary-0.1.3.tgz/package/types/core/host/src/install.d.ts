import { type ControlRequestContributions } from "./control.js";
import type { ActualInteractionResolution, CompiledInteractions, InstallationId, NativeInteractionBinding, InteractionDefinitions, InteractionImplementations, InteractionInstallation, InstalledInteractions, RealizationIds } from "./types.js";
export declare const INSTALLATION_DOMAIN = "boundary.installation/v1";
type BareInstallOptions<Definitions extends InteractionDefinitions, Context> = Readonly<{
    installationId: InstallationId;
    implementations: InteractionImplementations<any, Context>;
    bindings?: never;
    requests?: ControlRequestContributions<Definitions, Context>;
    realizationIds: RealizationIds;
}>;
type NativeInstallOptions<Definitions extends InteractionDefinitions, Context> = Readonly<{
    installationId: InstallationId;
    implementations?: never;
    bindings: readonly {
        [Alias in keyof Definitions]: NativeInteractionBinding<Definitions[Alias], any, Context>;
    }[keyof Definitions][];
    requests?: ControlRequestContributions<Definitions, Context>;
    realizationIds: RealizationIds;
}>;
export type InstallInteractionsOptions<Definitions extends InteractionDefinitions, Context> = BareInstallOptions<Definitions, Context> | NativeInstallOptions<Definitions, Context>;
type InstallationMetadata<Context> = Readonly<{
    compiled: CompiledInteractions<any>;
    interactions: ReadonlyMap<string, ActualInteractionResolution<Context>>;
    state: {
        revoked: boolean;
    };
}>;
export declare function installInteractions<Definitions extends InteractionDefinitions, Context = void>(compiled: CompiledInteractions<Definitions>, options: InstallInteractionsOptions<Definitions, Context>): Promise<InstalledInteractions<Context>>;
export declare function metadataForInstallation<Context>(value: InteractionInstallation<Context>): InstallationMetadata<Context>;
export {};
