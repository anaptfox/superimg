import type { CompiledInteractions, InteractionHandle, ProjectionSelection } from "../types.js";
import type { draftsInteractions } from "./definitions.js";
type DraftsCompiled = CompiledInteractions<typeof draftsInteractions>;
/** A worker's authority: propose only, direct mode. Never accept or reject. */
export declare function proposerProjection(compiled: DraftsCompiled): Promise<import("..").Projection<{
    readonly propose: ProjectionSelection<InteractionHandle<import("..").InteractionDefinition<"drafts.propose", import("../../../program/src.js").JsonValue, import("../../../program/src.js").JsonValue, {
        readonly invalidDraft: any;
    }, 1>>, readonly ["direct"]>;
}>>;
/** An author's authority: accept and reject, request mode. Never propose. */
export declare function authorProjection(compiled: DraftsCompiled): Promise<import("..").Projection<{
    readonly accept: ProjectionSelection<InteractionHandle<import("..").InteractionDefinition<"drafts.accept", import("../../../program/src.js").JsonValue, import("../../../program/src.js").JsonValue, {
        readonly draftNotFound: any;
    }, 1>>, readonly ["request"]>;
    readonly reject: ProjectionSelection<InteractionHandle<import("..").InteractionDefinition<"drafts.reject", import("../../../program/src.js").JsonValue, import("../../../program/src.js").JsonValue, {
        readonly draftNotFound: any;
        readonly invalidReason: any;
    }, 1>>, readonly ["request"]>;
}>>;
/**
 * No Draft authority at all: neither propose, nor accept, nor reject. For
 * a host that only needs to gate invocation of interactions already
 * declared and must prove it grants no Draft-deciding capability at all.
 */
export declare function runnerProjection(compiled: DraftsCompiled): Promise<import("..").Projection<{}>>;
export {};
