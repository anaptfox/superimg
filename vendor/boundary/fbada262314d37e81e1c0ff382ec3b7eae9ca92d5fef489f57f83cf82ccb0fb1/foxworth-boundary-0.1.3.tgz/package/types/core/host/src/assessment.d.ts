import { type InteractionContract, type InstallationManifest, type ProjectionManifest, type ProjectionInteraction } from "@foxworth/boundary/program";
import type { UnrealizedIssue } from "./types.js";
/** Data-only check shared by live construction and candidate assessment. */
export declare function assessInteraction(selection: ProjectionInteraction, expected: InteractionContract, actual: Readonly<{
    contract: InteractionContract;
    inputArity?: 0 | 1;
    direct: boolean;
    request: boolean;
}> | undefined, revoked?: boolean): readonly UnrealizedIssue[];
export type ProjectionAssessment = Readonly<{
    status: "fit" | "mismatch";
    issues: readonly UnrealizedIssue[];
    missingEvidence: readonly ("artifact-authenticity" | "actual-input-arity" | "live-revocation" | "admission")[];
}>;
/**
 * Compare the declarations and availability claimed by candidate manifests.
 * This does not authenticate artifacts, construct a Binding, or grant a call.
 */
export declare function assessProjection(projection: ProjectionManifest, installation: InstallationManifest): ProjectionAssessment;
