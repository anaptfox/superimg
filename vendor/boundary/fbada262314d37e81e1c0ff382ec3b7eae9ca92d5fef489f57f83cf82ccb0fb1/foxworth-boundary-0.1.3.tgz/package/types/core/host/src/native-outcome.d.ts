import type { InvocationCertainty, JsonValue } from "@foxworth/boundary/program";
import type { AnyInteractionDefinition, DefinitionErrors, DefinitionOutput, ErrorValues } from "./types.js";
/**
 * An opaque result issued by the exact native binding that dispatched it.
 *
 * Native dispatchers receive the factory on `NativeDispatchRequest.outcomes`.
 * Plain outcome-shaped objects are ordinary output values; they cannot change
 * lifecycle certainty or claim a declared error or denial.
 */
export interface NativeDispatchOutcome<Definition extends AnyInteractionDefinition = AnyInteractionDefinition> {
    readonly [nativeDispatchOutcomeType]?: Definition;
}
/** Factory available only on one installed native dispatch request. */
export interface NativeDispatchOutcomes<Definition extends AnyInteractionDefinition = AnyInteractionDefinition> {
    returned(value: DefinitionOutput<Definition>): NativeDispatchOutcome<Definition>;
    declared<Code extends keyof DefinitionErrors<Definition> & string>(code: Code, details: ErrorValues<DefinitionErrors<Definition>>[Code]): NativeDispatchOutcome<Definition>;
    denied(code: string): NativeDispatchOutcome<Definition>;
    notStarted(): NativeDispatchOutcome<Definition>;
    notCompleted(): NativeDispatchOutcome<Definition>;
    unknown(): NativeDispatchOutcome<Definition>;
}
type NativeDispatchOutcomeRecord = Readonly<{
    kind: "returned";
    value: unknown;
}> | Readonly<{
    kind: "declared-error";
    code: string;
    details: JsonValue;
}> | Readonly<{
    kind: "denied";
    code: string;
}> | Readonly<{
    kind: "fault";
    certainty: Exclude<InvocationCertainty, "completed">;
}>;
declare const nativeDispatchOutcomeType: unique symbol;
export declare function createNativeDispatchOutcomes<Definition extends AnyInteractionDefinition = AnyInteractionDefinition>(): NativeDispatchOutcomes<Definition>;
export declare function nativeDispatchOutcomeRecord(value: unknown): NativeDispatchOutcomeRecord | undefined;
/**
 * Captures an outcome only when the native dispatcher returned a token issued
 * by this exact request's factory. The captured token is private to the
 * installation boundary; a retained token from another call becomes ordinary
 * output and cannot carry denial or certainty across an invocation.
 */
export declare function captureNativeDispatchOutcome(value: unknown, outcomes: object): object | undefined;
export {};
