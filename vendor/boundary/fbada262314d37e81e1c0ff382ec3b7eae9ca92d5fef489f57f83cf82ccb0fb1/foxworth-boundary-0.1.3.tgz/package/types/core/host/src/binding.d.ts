import { type InvocationCoordinator } from "./coordination.js";
import { type InvocationObserver } from "./observation.js";
import type { Admission, BindResult, InteractionInstallation, Projection, ProjectionBinding, ProjectionSelections } from "./types.js";
export declare const PROJECTION_BINDING_DOMAIN = "boundary.projection-binding/v1";
export declare function assertProjectionBinding(value: unknown): void;
export declare const admitAll: Admission<any>;
/** Admit when `allow(context)` is true; otherwise deny with `reason`. */
export declare function admitWhen<Context>(allow: (context: Context) => boolean, reason?: string | ((context: Context) => string)): Admission<Context>;
export declare function bindProjection<const Selections extends ProjectionSelections, Context = void>(projection: Projection<Selections>, installation: InteractionInstallation<Context>, options: Readonly<{
    admit: Admission<Context>;
    observation?: InvocationObserver<Context>;
    coordinate?: InvocationCoordinator<Context>;
}>): Promise<BindResult<Projection<Selections>["handles"], Context>>;
/** Derive a caller capability without discarding its inherited admission or revocation. */
export declare function restrictBinding<const Selections extends ProjectionSelections, Context>(parent: ProjectionBinding<any, Context>, options: Readonly<{
    projection: Projection<Selections>;
    admit: Admission<Context>;
}>): Promise<BindResult<Projection<Selections>["handles"], Context>>;
