import type { LoadInteractionsEntryOptions, LoadedInteractions } from "./build-types.js";
import type { InteractionDefinitions } from "./types.js";
export declare function loadInteractionsEntry<Definitions extends InteractionDefinitions = InteractionDefinitions>(options: LoadInteractionsEntryOptions): Promise<LoadedInteractions<Definitions>>;
