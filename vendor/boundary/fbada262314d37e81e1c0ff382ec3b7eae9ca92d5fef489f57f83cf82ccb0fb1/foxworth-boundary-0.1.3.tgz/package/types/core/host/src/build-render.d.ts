import type { HostArtifactSet, RenderHostArtifactsOptions } from "./build-types.js";
export declare const HOST_ARTIFACT_INVENTORY_PATH: ".boundary-core-host-inventory.json";
export declare function renderHostArtifacts(options: RenderHostArtifactsOptions): HostArtifactSet;
export declare function assertHostArtifactSet(value: unknown): asserts value is HostArtifactSet;
