import { type JsonObject, type JsonValue, type PortableSchema, type Sha256Digest } from "@foxworth/boundary/program";
import type { AnyInteractionDefinition, AuthoringSchema, InteractionHandle, InteractionDefinition, SchemaValue } from "./types.js";
type CommonDefinitionSource<Id extends string, OutputSchema extends AuthoringSchema, Errors extends AuthoringErrorSchemas> = Readonly<{
    id: Id;
    output: OutputSchema;
    errors?: Errors;
    reads?: readonly string[];
    changes?: readonly string[];
    summary?: string;
    description?: string;
    annotations?: JsonObject;
}>;
type InputDefinitionSource<Id extends string, InputSchema extends AuthoringSchema, OutputSchema extends AuthoringSchema, Errors extends AuthoringErrorSchemas> = CommonDefinitionSource<Id, OutputSchema, Errors> & Readonly<{
    input: InputSchema;
}>;
type NoInputDefinitionSource<Id extends string, OutputSchema extends AuthoringSchema, Errors extends AuthoringErrorSchemas> = CommonDefinitionSource<Id, OutputSchema, Errors> & Readonly<{
    input?: never;
}>;
type AuthoringErrorSchemas = Readonly<Record<string, AuthoringSchema>>;
type AuthoringErrorValues<Schemas extends AuthoringErrorSchemas> = {
    readonly [Code in keyof Schemas]: SchemaValue<Schemas[Code]>;
};
export declare function defineInteraction<const Id extends string, const InputSchema extends AuthoringSchema, const OutputSchema extends AuthoringSchema, const Errors extends AuthoringErrorSchemas = Readonly<Record<never, never>>>(source: InputDefinitionSource<Id, InputSchema, OutputSchema, Errors>): InteractionDefinition<Id, Extract<SchemaValue<InputSchema>, JsonValue>, Extract<SchemaValue<OutputSchema>, JsonValue>, Extract<AuthoringErrorValues<Errors>, Readonly<Record<string, JsonValue>>>, 1>;
export declare function defineInteraction<const Id extends string, const OutputSchema extends AuthoringSchema, const Errors extends AuthoringErrorSchemas = Readonly<Record<never, never>>>(source: NoInputDefinitionSource<Id, OutputSchema, Errors>): InteractionDefinition<Id, null, Extract<SchemaValue<OutputSchema>, JsonValue>, Extract<AuthoringErrorValues<Errors>, Readonly<Record<string, JsonValue>>>, 0>;
export declare function isInteractionDefinition(value: unknown): value is AnyInteractionDefinition;
export declare function declaredErrorSchema(interactionId: string, errorSchemas: Readonly<Record<string, PortableSchema>>): PortableSchema | undefined;
export declare class DeclaredInteractionError<Details extends JsonValue = JsonValue> extends Error {
    readonly interactionId: string;
    readonly code: string;
    readonly details: Details;
    constructor(interactionId: string, code: string, details: Details);
}
export declare function declaredInteractionError<Definition extends AnyInteractionDefinition, Code extends keyof DefinitionErrorsFor<Definition> & string>(definition: Definition, code: Code, details: DefinitionErrorsFor<Definition>[Code]): DeclaredInteractionError<DefinitionErrorsFor<Definition>[Code]>;
/** Reconstructs a validated declared error for a typed local caller. */
export declare function restoreDeclaredInteractionError(interactionId: string, contractDigest: Sha256Digest, code: string, details: JsonValue): DeclaredInteractionError;
type DefinitionErrorsFor<Value> = Value extends InteractionDefinition<string, any, any, infer Errors, any> ? Errors : never;
type DefinitionForHandle<Handle extends InteractionHandle> = Handle extends InteractionHandle<infer Definition> ? Definition : never;
type ErrorsForHandle<Handle extends InteractionHandle> = DefinitionErrorsFor<DefinitionForHandle<Handle>>;
export declare function isDeclaredInteractionError<Handle extends InteractionHandle, Code extends keyof ErrorsForHandle<Handle> & string>(error: unknown, handle: Handle, code: Code): error is DeclaredInteractionError<ErrorsForHandle<Handle>[Code]> & Readonly<{
    code: Code;
}>;
export declare function isAuthenticDeclaredError(value: unknown): value is DeclaredInteractionError;
export declare function definitionForDeclaredError(value: DeclaredInteractionError): AnyInteractionDefinition | undefined;
export declare function errorEnvelope(error: DeclaredInteractionError): JsonObject;
export {};
