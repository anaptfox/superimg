import { type JsonSchema, type JsonValue, type Sha256Digest } from "@foxworth/boundary/program";
import type { AnyInteractionDefinition, CompiledInteractions, DefinitionInput, MaybePromise, InteractionDefinitions, InteractionHandle, RequestInvocationPolicy } from "./types.js";
declare const controlRequestContributionTypes: unique symbol;
/**
 * Opaque Host contribution artifact. Installation accepts only values minted
 * and snapshotted by this module, never caller-assembled structural records.
 */
export interface ControlRequestContributions<Definitions extends InteractionDefinitions = InteractionDefinitions, Context = unknown> {
    readonly [controlRequestContributionTypes]?: {
        readonly definitions: Definitions;
        readonly context: Context;
    };
}
export interface ControlRequestContributionSource<Definition extends AnyInteractionDefinition = AnyInteractionDefinition, Context = unknown, Proposal extends JsonValue = JsonValue> {
    readonly interaction: InteractionHandle<Definition>;
    readonly controlDigest: Sha256Digest;
    readonly previewSchema: JsonSchema;
    request(input: DefinitionInput<Definition>, context: Context, policy: RequestInvocationPolicy): MaybePromise<Proposal>;
}
export type ControlRequestContributionSources<Definitions extends InteractionDefinitions, Context> = Readonly<Partial<{
    [Alias in keyof Definitions]: ControlRequestContributionSource<Definitions[Alias], Context, any>;
}>>;
export type ControlRequestContributionMetadata<Context> = Readonly<{
    entries: ReadonlyMap<string, ControlRequestEntry<Context>>;
}>;
export type ControlRequestEntry<Context> = Readonly<{
    interaction: InteractionHandle;
    controlDigest: Sha256Digest;
    previewSchema: JsonSchema;
    request(input: JsonValue, context: Context, policy: RequestInvocationPolicy): MaybePromise<JsonValue>;
}>;
/**
 * @internal Support seam consumed by `@foxworth/boundary/control/host`.
 *
 * JavaScript package exports cannot authenticate which package called a
 * function. A direct caller of this support seam is therefore part of the Host
 * TCB; artifact authenticity means module-minted and mutation-safe, not that
 * arbitrary in-process request code has been proven effect-free.
 */
export declare function createControlRequestContributions<Definitions extends InteractionDefinitions, Context>(compiled: CompiledInteractions<Definitions>, sources: ControlRequestContributionSources<Definitions, Context>): ControlRequestContributions<Definitions, Context>;
/** @internal Host installation authenticity check. */
export declare function metadataForControlRequestContributions<Context>(value: unknown): ControlRequestContributionMetadata<Context>;
export type { RequestInvocationPolicy } from "./types.js";
