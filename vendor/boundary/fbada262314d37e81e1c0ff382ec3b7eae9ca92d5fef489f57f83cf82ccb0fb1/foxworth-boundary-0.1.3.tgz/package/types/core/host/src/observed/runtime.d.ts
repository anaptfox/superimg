import { type InteractionContract, type JsonValue } from "@foxworth/boundary/program";
import type { ObservedReadOptions } from "./types.js";
import type { AnyInteractionDefinition } from "../types.js";
type Options = ObservedReadOptions<AnyInteractionDefinition, unknown, JsonValue, JsonValue, JsonValue, JsonValue>;
export declare function createObservedExecutor(options: Options, contract: InteractionContract, pins: Readonly<{
    installationId: string;
    realizationId: string;
}>): {
    execute: (input: JsonValue, context: unknown) => Promise<unknown>;
    clear(): void;
};
export {};
