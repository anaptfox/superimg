/**
 * `@foxworth/boundary/drafts`: the workflow that turns a Draft into a
 * decision.
 *
 * Three ordinary Boundary interactions — `drafts.propose`, `drafts.accept`, and
 * `drafts.reject` — plus a host-supplied {@link DraftStore} port and three
 * Projection presets split by authority. Mirrors `@foxworth/boundary/host/control`:
 * Boundary owns the workflow, the host owns storage.
 */
export { draftsAccept, draftsInteractions, draftsPropose, draftsReject, } from "./definitions.js";
export { acceptDraft, proposeDraft, rejectDraft, type DraftAcceptOutput, type DraftDecisionInput, type DraftInput, type DraftProposeOutput, type DraftRejectInput, type DraftRejectOutput, } from "./service.js";
export { authorProjection, proposerProjection, runnerProjection, } from "./projections.js";
export { DRAFT_REJECT_REASONS, isDraftRejectReason, type DraftDecision, type DraftRejectReason, type DraftStore, } from "./types.js";
