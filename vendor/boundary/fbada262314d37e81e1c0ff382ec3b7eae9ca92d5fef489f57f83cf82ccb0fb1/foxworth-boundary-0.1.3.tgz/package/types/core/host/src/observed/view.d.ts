import { type JsonValue } from "@foxworth/boundary/program";
import type { ObservationView, ObservedSnapshot, ReadObservation } from "./types.js";
/** Capturing views never escape their snapshot lifetime. Failed or unawaited
 * reads make the invocation ineligible for retention. */
export declare function captureView(snapshot: ObservedSnapshot<JsonValue, JsonValue, JsonValue, JsonValue>): {
    view: ObservationView<JsonValue, JsonValue, JsonValue, JsonValue>;
    observations: ReadObservation[];
    state: {
        active: boolean;
        failed: boolean;
        pending: number;
    };
};
