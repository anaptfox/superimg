import type { BindInteractionCallers, BindInteractionsIssue, BindInteractionsOptions, BindInteractionsResult, ExactCallerAliases, ContextFromHandlers, ContextInferringHandlers, CompatibleHandlerContexts } from "./bind-interactions-types.js";
import type { InteractionDefinitions } from "./types.js";
export declare class BindInteractionsError extends Error {
    readonly issues: readonly BindInteractionsIssue[];
    constructor(issues: readonly BindInteractionsIssue[]);
}
/** Compile, install, project, and bind named direct callers through Boundary's native pipeline. */
export declare function bindInteractions<const Definitions extends InteractionDefinitions, const Handlers extends ContextInferringHandlers<Definitions>, const Callers extends BindInteractionCallers<Definitions, ContextFromHandlers<Definitions, Handlers>>>(definitions: Definitions, options: Omit<BindInteractionsOptions<Definitions, ContextFromHandlers<Definitions, Handlers>, Callers>, "handlers" | "callers"> & {
    readonly handlers: Handlers & Record<Exclude<keyof Handlers, keyof Definitions>, never> & CompatibleHandlerContexts<Definitions, Handlers>;
    readonly callers: Callers & ExactCallerAliases<Definitions, Callers>;
}): Promise<BindInteractionsResult<Definitions, ContextFromHandlers<Definitions, Handlers>, Callers>>;
