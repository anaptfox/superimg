import { type InvocationObservation, type JsonValue, type RawInvocationOutcome } from "@foxworth/boundary/program";
import type { MaybePromise } from "./types.js";
/** Host-held observer; publication is awaited and failures cannot change execution truth. */
export interface InvocationObserver<Context> {
    publish(event: InvocationObservation): MaybePromise<void>;
    correlate?(context: Context): JsonValue;
}
export declare function snapshotObserver<Context>(observer: InvocationObserver<Context> | undefined): InvocationObserver<Context> | undefined;
export declare function observationCorrelation<Context>(observer: InvocationObserver<Context> | undefined, context: Context): JsonValue | undefined;
export declare function publishObservation<Context>(observer: InvocationObserver<Context> | undefined, outcome: RawInvocationOutcome, reads: readonly string[], changes: readonly string[], correlation: JsonValue | undefined): Promise<void>;
