import type { CompiledInteractions, HandlesOf, InteractionDefinitions, InteractionMode, ProjectedInteractionHandle, Projection, ProjectionInteraction, ProjectionSelection, ProjectionSelections } from "./types.js";
export declare const PROJECTION_DOMAIN = "boundary.projection/v1";
type ProjectionMetadata = Readonly<{
    compiled: object;
    aliases: ReadonlyMap<string, Readonly<{
        alias: string;
        handle: ProjectedInteractionHandle;
        interaction: ProjectionInteraction;
    }>>;
}>;
export type AliasProjectionSelections<Definitions extends InteractionDefinitions, Selections extends Readonly<Record<string, InteractionMode | ProjectionSelection>>> = {
    readonly [Alias in keyof Selections]: Selections[Alias] extends InteractionMode ? Alias extends keyof Definitions ? ProjectionSelection<HandlesOf<Definitions>[Alias], readonly [Selections[Alias]]> : never : Selections[Alias] extends ProjectionSelection ? Selections[Alias] : never;
};
export declare function projectInteractions<Definitions extends InteractionDefinitions, const Selections extends ProjectionSelections>(compiled: CompiledInteractions<Definitions>, selections: Selections): Promise<Projection<Selections>>;
export declare function projectInteractions<Definitions extends InteractionDefinitions, const Selections extends Readonly<Record<string, InteractionMode | ProjectionSelection>>>(compiled: CompiledInteractions<Definitions>, selections: Selections & {
    readonly [Alias in keyof Selections]: Selections[Alias] extends InteractionMode ? Alias extends keyof Definitions ? Selections[Alias] : never : Selections[Alias];
}): Promise<Projection<AliasProjectionSelections<Definitions, Selections>>>;
export declare function metadataForProjection(value: unknown): ProjectionMetadata;
export declare function metadataForProjectedHandle(value: unknown): Readonly<{
    projection: object;
    alias: string;
    source: object;
}> | undefined;
export type DirectProjectionSelections<Definitions extends InteractionDefinitions> = {
    readonly [Alias in keyof Definitions]: ProjectionSelection<HandlesOf<Definitions>[Alias], readonly ["direct"]>;
};
/** Project every compiled handle in direct mode. */
export declare function projectAllDirect<Definitions extends InteractionDefinitions>(compiled: CompiledInteractions<Definitions>): Promise<Projection<DirectProjectionSelections<Definitions>>>;
/**
 * Re-project a named subset of an existing Projection.
 * Keys resolve as aliases first, then as interaction ids.
 * The result is a new Projection with its own digest.
 */
export declare function pickProjection<Selections extends ProjectionSelections, const Keys extends readonly (keyof Selections & string)[]>(projection: Projection<Selections>, ...keys: Keys): Promise<Projection<Pick<Selections, Keys[number]>>>;
export declare function pickProjection<Selections extends ProjectionSelections>(projection: Projection<Selections>, ...keys: readonly string[]): Promise<Projection<Selections>>;
export {};
