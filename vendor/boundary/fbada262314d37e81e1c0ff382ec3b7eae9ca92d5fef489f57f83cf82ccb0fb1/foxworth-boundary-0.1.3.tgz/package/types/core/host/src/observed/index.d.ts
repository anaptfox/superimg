import type { JsonValue } from "@foxworth/boundary/program";
import type { AnyInteractionDefinition } from "../types.js";
import type { ObservedReadImplementation, ObservedReadOptions } from "./types.js";
export type { ObservationSource, ObservedSnapshot, ObservationView, ObservationValidation, ObservedPoint, PointEvidence, QueryEvidence, ReadObservation, ObservedReadOptions, ObservedReadImplementation, ObservedReadDiagnostic, } from "./types.js";
/** Create an inert native implementation adapter. Its cache and exact identity
 * are supplied by Installation, never by the caller or a declaration. */
export declare function observedRead<const Definition extends AnyInteractionDefinition, Context, Key extends JsonValue, Point extends JsonValue, Query extends JsonValue, Rows extends JsonValue>(definition: Definition, options: ObservedReadOptions<Definition, Context, Key, Point, Query, Rows>): ObservedReadImplementation<Definition, Context>;
