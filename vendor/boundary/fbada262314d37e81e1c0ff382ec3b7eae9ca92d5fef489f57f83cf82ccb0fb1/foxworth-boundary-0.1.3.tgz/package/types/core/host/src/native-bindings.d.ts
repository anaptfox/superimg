import type { NativeDispatchOutcome } from "./native-outcome.js";
import type { CompiledInteractions, InteractionDefinitions, MaybePromise, NativeDispatchRequest, NativeInteractionBinding } from "./types.js";
export type NativeDispatchers<Definitions extends InteractionDefinitions, Targets, Context> = {
    readonly [Alias in keyof Definitions]: (request: NativeDispatchRequest<Definitions[Alias], Targets[Alias & keyof Targets], Context>) => MaybePromise<NativeDispatchOutcome<Definitions[Alias]>>;
};
/** Correlate each compiled alias with its native target and dispatch types. */
export declare function bindNativeInteractions<Definitions extends InteractionDefinitions, Targets extends {
    readonly [Alias in keyof Definitions]: unknown;
}, Context = void>(compiled: CompiledInteractions<Definitions>, targets: Targets, dispatchers: NativeDispatchers<Definitions, Targets, Context>): readonly {
    [Alias in keyof Definitions]: NativeInteractionBinding<Definitions[Alias], Targets[Alias], Context>;
}[keyof Definitions][];
