import type { InteractionDefinitions, Projection, ProjectionSelections } from "./types.js";
import type { NamedCallers } from "./bind-interactions-types.js";
/** Build named methods over the authentic caller returned by a native Binding. */
export declare function namedCallers<Definitions extends InteractionDefinitions, Context, Callers extends Readonly<Record<string, {
    readonly direct: readonly (keyof Definitions & string)[];
}>>>(selections: Callers, projections: Readonly<Record<string, Projection<ProjectionSelections>>>, bindings: Readonly<Record<string, import("./types.js").ProjectionBinding<any, Context>>>): NamedCallers<Definitions, Context, Callers>;
