import { type ExecutionEvidence } from "@foxworth/boundary/program";
import type { MaybePromise } from "./types.js";
/** Private host delivery capability; accepting evidence grants no authority. */
export interface ExecutionEvidencePublisher {
    publish(evidence: ExecutionEvidence): MaybePromise<void>;
}
export type ExecutionEvidencePublication = Readonly<{
    status: "published";
    evidence: ExecutionEvidence;
} | {
    status: "delivery-failed";
    evidence: ExecutionEvidence;
    cause: unknown;
}>;
/**
 * Explicitly publish a host-selected envelope. Validation precedes delivery;
 * delivery failure retains evidence and cannot rewrite execution/subject truth.
 * No invocation hook, read token export, authentication or retry is implied.
 */
export declare function publishExecutionEvidence(publisher: ExecutionEvidencePublisher, value: unknown): Promise<ExecutionEvidencePublication>;
