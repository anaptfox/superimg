import type { AnyInteractionDefinition, ImplementationMap, InteractionDefinitions, InteractionImplementations } from "./types.js";
type ImplementationMetadata = Readonly<{
    definitions: Readonly<Record<string, AnyInteractionDefinition>>;
    functions: ReadonlyMap<string, (...args: any[]) => unknown>;
}>;
type ExactImplementations<Definitions extends InteractionDefinitions, Context, Candidate extends ImplementationMap<Definitions, Context>> = Candidate & Record<Exclude<keyof Candidate, keyof Definitions>, never>;
export declare function implementInteractions<const Definitions extends InteractionDefinitions, Context = void, const Candidate extends ImplementationMap<Definitions, Context> = ImplementationMap<Definitions, Context>>(definitions: Definitions, implementations: ExactImplementations<Definitions, Context, Candidate>): InteractionImplementations<Definitions, Context>;
export declare function metadataForImplementations(value: unknown): ImplementationMetadata;
export {};
