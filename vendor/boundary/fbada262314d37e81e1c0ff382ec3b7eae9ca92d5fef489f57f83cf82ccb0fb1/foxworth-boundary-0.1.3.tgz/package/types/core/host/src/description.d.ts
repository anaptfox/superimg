import { type BindingInteractionDescription } from "@foxworth/boundary/program";
import type { ProjectionBinding } from "./types.js";
/** Snapshot only the selected public contracts of an authentic native Binding. */
export declare function describeBinding<Context>(binding: ProjectionBinding<any, Context>): readonly BindingInteractionDescription[];
