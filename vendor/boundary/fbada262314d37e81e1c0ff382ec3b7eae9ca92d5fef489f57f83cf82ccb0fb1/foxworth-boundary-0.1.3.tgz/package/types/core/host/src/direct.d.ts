import type { CompiledInteractions, InteractionDefinitions, InteractionHandle, ProjectionSelection, RealizationId } from "./types.js";
/** Closed projection selection for one compiled handle in direct mode. */
export declare function direct<Handle extends InteractionHandle>(handle: Handle): ProjectionSelection<Handle, readonly ["direct"]>;
export type DirectRealizationIds<Definitions extends InteractionDefinitions> = {
    readonly [Alias in keyof Definitions]: Readonly<{
        readonly direct: RealizationId;
    }>;
};
/**
 * Host-owned direct realization IDs keyed by compiled alias and release revision.
 * The host still passes this record into `installInteractions`.
 */
export declare function directRealizationIds<Definitions extends InteractionDefinitions>(compiled: CompiledInteractions<Definitions>, revision: string): DirectRealizationIds<Definitions>;
