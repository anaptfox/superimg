import { type InteractionPresentationOverride, type ProjectionPresentation } from "@foxworth/boundary/program";
import type { Projection, ProjectionSelections } from "./types.js";
/** Derive schemas from the selected contract; presentation overrides cannot change execution facts. */
export declare function presentProjection<Selections extends ProjectionSelections>(projection: Projection<Selections>, overrides?: Readonly<Partial<Record<keyof Selections & string, InteractionPresentationOverride>>>): Promise<ProjectionPresentation>;
