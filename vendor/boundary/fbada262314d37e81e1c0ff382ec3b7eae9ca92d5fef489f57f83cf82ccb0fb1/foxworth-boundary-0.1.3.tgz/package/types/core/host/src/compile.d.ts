import { type InteractionDescriptor, type PortableSchema } from "@foxworth/boundary/program";
import type { AnyInteractionDefinition, CompileInteractionsOptions, CompiledInteractions, InteractionDefinitions, InteractionHandle, InteractionLowering } from "./types.js";
type CompiledMetadata = Readonly<{
    definitions: Readonly<Record<string, AnyInteractionDefinition>>;
    descriptors: ReadonlyMap<string, InteractionDescriptor>;
    aliasesByDefinition: ReadonlyMap<AnyInteractionDefinition, string>;
    handlesByDefinition: ReadonlyMap<AnyInteractionDefinition, InteractionHandle>;
    nativeTargets: ReadonlyMap<string, unknown>;
    errorSchemas: ReadonlyMap<string, Readonly<Record<string, PortableSchema>>>;
}>;
export declare function snapshotDefinitions(value: unknown, path?: string): Readonly<Record<string, AnyInteractionDefinition>>;
type DefinitionsOf<Value> = Value extends CompiledInteractions<infer Definitions> ? Definitions : never;
type UnionToIntersection<Value> = (Value extends unknown ? (value: Value) => void : never) extends (value: infer Intersection) => void ? Intersection : never;
type ComposedDefinitions<Inputs extends readonly CompiledInteractions[]> = UnionToIntersection<DefinitionsOf<Inputs[number]>> extends infer Definitions extends InteractionDefinitions ? Definitions : never;
export declare function compileInteractions<const Definitions extends InteractionDefinitions>(definitions: Definitions, options?: CompileInteractionsOptions): Promise<CompiledInteractions<Definitions>>;
export declare function compileInteractions<const Native extends Readonly<Record<string, unknown>>, const Definitions extends InteractionDefinitions>(native: Native, lowering: InteractionLowering<Native, Definitions>, options?: CompileInteractionsOptions): Promise<CompiledInteractions<Definitions>>;
/**
 * Compose already-compiled closed records without weakening their typed
 * handles. Alias collisions are rejected before Program composition; interaction
 * identity conflicts retain Program's structured diagnostics.
 */
export declare function composeCompiledInteractions<const Inputs extends readonly [
    CompiledInteractions,
    ...CompiledInteractions[]
]>(...inputs: Inputs): Promise<CompiledInteractions<ComposedDefinitions<Inputs>>>;
/** Compare portable interaction identity without conflating docs or annotations. */
export declare function diffCompiledInteractions(previous: CompiledInteractions, next: CompiledInteractions): import("@foxworth/boundary/program").ProgramDiff;
export declare function metadataForCompiled(value: unknown): CompiledMetadata;
export declare function metadataForHandle(value: unknown): Readonly<{
    compiled: object;
    alias: string;
    definition: AnyInteractionDefinition;
    descriptor: InteractionDescriptor;
}> | undefined;
export declare function handleBelongsToCompiled(handle: unknown, compiled: object): boolean;
export {};
