import { type ContractCompatibility } from "./compatibility.js";
import { type JsonValue } from "./json.js";
import { type InteractionContract } from "./program.js";
/** How one declared element changed. */
export type ChangeKind = "added" | "removed" | "changed";
/**
 * One changed element. Paths are dotted display labels, not patch addresses:
 * property names containing dots are included literally. An absent value is
 * omitted; a declared JSON null remains null.
 */
export type ContractChange = Readonly<{
    path: string;
    kind: ChangeKind;
    before?: JsonValue;
    after?: JsonValue;
}>;
/** Declaration changes and whether a caller of before can be served by after. */
export type ContractDelta = Readonly<{
    changes: readonly ContractChange[];
    existingCallers: Readonly<ContractCompatibility>;
}>;
/**
 * Explain changes between validated, normalized contract snapshots. Arrays
 * change as whole values; changes are ordered by UTF-8 path. This native review
 * aid has no wire form or identity and makes no claim about realization behavior.
 * Compatibility remains the same directional judgment used by Binding.
 */
export declare function contractChanges(before: InteractionContract, after: InteractionContract): ContractDelta;
