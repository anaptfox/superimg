import { type JsonSchema, type JsonValue } from "./json.js";
import { type SchemaValueIssue } from "./validation.js";
/** Evaluate one already-normalized JSON value against the portable contract. */
export declare function validateSchemaValue(schema: JsonSchema, value: JsonValue, path?: string): readonly SchemaValueIssue[];
