import { z } from "zod";
import { BoundaryErrorBase } from "./errors.js";
import { type JsonValue } from "./json.js";
import { type SchemaAdapter, type SchemaCompilation, type SchemaRole } from "./schema.js";
export type SchemaCompilationDiagnosticCode = "SCHEMA_NON_FINITE_NUMBER" | "SCHEMA_NON_JSON_VALUE" | "SCHEMA_UNKNOWN_ZOD_NODE" | "SCHEMA_RUNTIME_TRANSFORM" | "SCHEMA_NON_JSON_TYPE" | "SCHEMA_UNSUPPORTED_KEYWORD" | "SCHEMA_NOT_PORTABLE" | "SCHEMA_NOT_OBJECT";
export declare class SchemaCompilationError extends BoundaryErrorBase {
    readonly code: SchemaCompilationDiagnosticCode;
    constructor(code: SchemaCompilationDiagnosticCode, path: string, message: string);
}
export declare function jsonValue(value: unknown, path: string): JsonValue;
/** Built-in browser-safe adapter for Zod 4 schemas. */
export declare const zodSchemaAdapter: SchemaAdapter<z.ZodType> & Readonly<{
    supports(value: unknown): value is z.ZodType;
}>;
export declare function compileZodSchema(schema: z.ZodType, role: SchemaRole, path: string): SchemaCompilation;
