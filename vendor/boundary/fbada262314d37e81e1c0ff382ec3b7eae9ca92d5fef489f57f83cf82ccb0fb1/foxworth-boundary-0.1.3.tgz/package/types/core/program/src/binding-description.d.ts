import type { ProjectionBindingInteraction, ProjectionBindingManifest } from "./artifacts.js";
import type { InteractionDescriptor } from "./program.js";
/** Public selected data. It conveys no liveness, permission, or implementation capability. */
export interface BindingInteractionDescription extends ProjectionBindingInteraction {
    readonly expected: InteractionDescriptor;
    readonly actual: InteractionDescriptor;
}
/** Join declared pins from a checked manifest; this function does not authenticate its source. */
export declare function bindingDescriptions(manifest: ProjectionBindingManifest): readonly BindingInteractionDescription[];
