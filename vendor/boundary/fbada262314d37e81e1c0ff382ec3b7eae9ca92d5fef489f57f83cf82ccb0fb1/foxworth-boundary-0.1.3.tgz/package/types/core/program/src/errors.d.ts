/**
 * One error base for the Boundary production libraries. Every stable diagnostic
 * class is a thin subclass: it owns its own diagnostic code union and any
 * extra fields, but shares this message template and cause plumbing.
 */
export declare class BoundaryErrorBase extends Error {
    readonly code: string;
    readonly path: string;
    readonly cause?: unknown;
    constructor(code: string, path: string, message: string, options?: {
        readonly cause?: unknown;
    });
}
