export declare function isOwnedJson(value: object): boolean;
import { BoundaryErrorBase } from "./errors.js";
export type JsonPrimitive = string | number | boolean | null;
export type JsonValue = JsonPrimitive | JsonObject | JsonArray;
export type JsonObject = {
    readonly [key: string]: JsonValue;
};
export type JsonArray = readonly JsonValue[];
export type JsonSchema = JsonObject;
export type Sha256Digest = `sha256:${string}`;
export type DomainHasher = (domain: string, value: JsonValue) => Promise<Sha256Digest>;
/** Stable failures at Boundary' portable JSON seam. */
export type JsonDiagnosticCode = "JSON_ACCESSOR_PROPERTY" | "JSON_ARRAY_HOLE" | "JSON_CYCLIC_REFERENCE" | "JSON_INSPECTION_FAILED" | "JSON_INVALID_UNICODE" | "JSON_NON_ENUMERABLE_PROPERTY" | "JSON_NON_FINITE_NUMBER" | "JSON_NON_PLAIN_OBJECT" | "JSON_SYMBOL_KEY" | "JSON_UNDEFINED" | "JSON_UNSUPPORTED_PROPERTY" | "JSON_UNSUPPORTED_TYPE" | "HASH_INVALID_DOMAIN" | "HASH_SHA256_UNAVAILABLE";
export declare class JsonError extends BoundaryErrorBase {
    readonly code: JsonDiagnosticCode;
    constructor(code: JsonDiagnosticCode, path: string, message: string);
}
/** Compare strings by UTF-8 bytes, independent of locale and runtime. */
export declare function compareUtf8(left: string, right: string): number;
/**
 * Validate, canonicalize, clone, and deeply freeze one portable JSON value.
 * Optional data is absent; explicit `undefined` is rejected.
 */
export declare function normalizeJson(value: unknown, path?: string): JsonValue;
/** Stable JSON for identity and language-neutral conformance vectors. */
export declare function canonicalJson(value: JsonValue): string;
export declare function cloneJson<T extends JsonValue>(value: T, path?: string): T;
export declare function isSha256Digest(value: unknown): value is Sha256Digest;
/** Hash canonical JSON in an explicit domain separated by a NUL byte. */
export declare function hashJson(domain: string, value: JsonValue): Promise<Sha256Digest>;
/** Generic canonical-JSON hash; Boundary protocol identities use explicit domains. */
export declare function sha256(value: JsonValue): Promise<Sha256Digest>;
