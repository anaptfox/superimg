import type { InteractionContract } from "./program.js";
import { type ContractCompatibility } from "./schemaCompatibility.js";
export type { ContractCompatibility } from "./schemaCompatibility.js";
/**
 * Structural judgment on the portable schema profile.
 *
 * Inputs are contravariant, outputs and errors are covariant, and footprints
 * are covariant too: the offered contract may read and change a subset of
 * what the expected contract declares, never a superset.
 */
export declare function contractCompatibility(expected: InteractionContract, offered: InteractionContract): ContractCompatibility;
