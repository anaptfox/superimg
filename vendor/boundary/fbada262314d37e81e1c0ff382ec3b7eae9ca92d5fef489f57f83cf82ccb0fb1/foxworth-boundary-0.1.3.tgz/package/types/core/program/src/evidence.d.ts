import { BoundaryErrorBase } from "./errors.js";
import { type InvocationObservation } from "./observation.js";
export type EvidenceReferenceKind = "evidence" | "invocation" | "subject" | "attempt" | "receipt";
/** A host-issued public identity. Namespace and ID together identify one entity. */
export type EvidenceReference<Kind extends EvidenceReferenceKind = EvidenceReferenceKind> = Readonly<{
    kind: Kind;
    namespace: string;
    id: string;
}>;
export type EvidenceSubjectState = "pending" | "completed" | "not-started" | "not-completed" | "uncertain";
/**
 * Explicit host-published links, separate from invocation observation v1 and
 * private observed-read evidence. Missing links remain missing evidence. The
 * envelope does not authenticate its publisher, grant authority, instruct retry,
 * or assert a global event order.
 */
export type ExecutionEvidence = Readonly<{
    version: 1;
    reference: EvidenceReference<"evidence">;
    invocation: Readonly<{
        reference: EvidenceReference<"invocation">;
        observation: InvocationObservation;
    }>;
    subject?: Readonly<{
        reference: EvidenceReference<"subject">;
        state: EvidenceSubjectState;
    }>;
    parents?: readonly EvidenceReference[];
    children?: readonly EvidenceReference[];
    attempt?: EvidenceReference<"attempt">;
    receipt?: EvidenceReference<"receipt">;
}>;
export type ExecutionEvidenceDiagnosticCode = "INVALID_EXECUTION_EVIDENCE" | "CONFLICTING_EVIDENCE_REFERENCE" | "DUPLICATE_EVIDENCE_REFERENCE";
export declare class ExecutionEvidenceError extends BoundaryErrorBase {
    readonly code: ExecutionEvidenceDiagnosticCode;
    constructor(code: ExecutionEvidenceDiagnosticCode, path: string, message: string);
}
/** Strictly validate, clone and deeply freeze an execution evidence envelope. */
export declare function validateExecutionEvidence(value: unknown): ExecutionEvidence;
