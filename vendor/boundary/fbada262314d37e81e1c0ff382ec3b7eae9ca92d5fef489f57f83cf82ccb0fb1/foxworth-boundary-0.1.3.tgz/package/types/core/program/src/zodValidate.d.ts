import { z } from "zod";
export declare function validateZodNode(schema: z.ZodType, path: string, active?: WeakSet<object>): void;
