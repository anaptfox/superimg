import { type JsonValue } from "./json.js";
/** A structured, class-agnostic failure. `fail` turns it into a thrown error. */
export type SnapshotFailure = {
    code: string;
    path: string;
    message: string;
};
type ExactObjectOptions = {
    readonly path: string;
    /**
     * The exact expected key set, or `"discover"` to accept every own string
     * key the object actually has (still rejecting symbols, accessors, and
     * prototype pollution). Discover mode lets callers that must learn an
     * object's keys before validating them route the walk itself through this
     * kernel instead of pre-walking with `Reflect.ownKeys` and feeding the
     * discovered set back in, which degrades this check to accessor-only.
     */
    readonly keys: readonly string[] | "discover";
    readonly optionalKeys?: readonly string[];
    readonly fail: (failure: SnapshotFailure) => never;
};
/**
 * Walk an own-enumerable-data-only object. Rejects accessors, symbols, extra
 * keys, and prototype pollution. `keys` are required (or `"discover"`);
 * `optionalKeys` may be absent but, if present, must be exact data properties
 * like every other key.
 */
export declare function exactObject(value: unknown, options: ExactObjectOptions): Record<string, unknown>;
/**
 * Deep-copy a value into owned, frozen, plain JSON data. Throws via `fail`
 * on non-JSON shapes. Delegates to the workspace's one JSON walker so the
 * accessor/symbol/prototype rules stay in exactly one place.
 */
export declare function snapshotJson(value: unknown, options: {
    readonly path: string;
    readonly fail: (failure: SnapshotFailure) => never;
}): JsonValue;
/** Structural JSON equality by canonical form. */
export declare function jsonEquals(a: JsonValue, b: JsonValue): boolean;
export {};
