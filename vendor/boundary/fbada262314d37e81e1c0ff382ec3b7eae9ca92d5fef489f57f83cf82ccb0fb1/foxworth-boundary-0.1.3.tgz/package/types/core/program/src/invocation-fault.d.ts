import type { InteractionMode, InvocationCertainty } from "./artifacts.js";
/** The shared v1 stable fault law, used for retained native and Handoff outcomes. */
export declare function isInvocationFaultLegal(mode: InteractionMode, cause: string, certainty: InvocationCertainty): boolean;
