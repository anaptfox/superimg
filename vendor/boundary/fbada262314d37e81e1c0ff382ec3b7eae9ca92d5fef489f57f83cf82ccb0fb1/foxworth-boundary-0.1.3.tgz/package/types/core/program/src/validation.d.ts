import { BoundaryErrorBase } from "./errors.js";
import { type JsonObject, type JsonSchema, type JsonValue } from "./json.js";
export type PortableSchemaDiagnosticCode = "SCHEMA_CONTRACT_INVALID" | "SCHEMA_UNSUPPORTED_KEYWORD";
export declare class PortableSchemaError extends BoundaryErrorBase {
    readonly code: PortableSchemaDiagnosticCode;
    constructor(code: PortableSchemaDiagnosticCode, path: string, message: string);
}
export type SchemaValueIssue = {
    readonly path: string;
    readonly message: string;
};
declare const portableSchemaValue: unique symbol;
/** A literal portable schema carrying the JSON value type it describes. */
export type PortableSchema<Value extends JsonValue = JsonValue> = JsonSchema & {
    readonly [portableSchemaValue]: Value;
};
export type PortableSchemaValue<Schema extends PortableSchema> = Schema[typeof portableSchemaValue];
/** Recognize only schemas returned by portableSchema(), without branding JSON. */
export declare function isPortableSchema(value: unknown): value is PortableSchema;
export declare function isObject(value: JsonValue): value is JsonObject;
export declare function propertyPath(path: string, key: string): string;
/** Validate Boundary' bounded, executable JSON Schema profile. */
export declare function validatePortableSchema(schema: JsonSchema, path?: string): void;
/** Whether `schema` has already passed validatePortableSchema by identity. */
export declare function hasValidatedSchema(schema: object): boolean;
/**
 * Author a literal schema without a runtime-specific adapter. The returned
 * schema is normalized portable JSON and deeply frozen.
 */
export declare function portableSchema<Value extends JsonValue = JsonValue>(schema: JsonSchema, path?: string): PortableSchema<Value>;
export {};
