import { BoundaryErrorBase } from "./errors.js";
import { type DomainHasher, type JsonArray, type JsonObject, type JsonSchema, type Sha256Digest } from "./json.js";
export declare const INTERACTION_CONTRACT_DOMAIN = "boundary.interaction-contract/v1";
export declare const PROGRAM_DOMAIN = "boundary.program/v1";
export declare const INTERACTION_ID_PATTERN: "^[A-Za-z0-9][A-Za-z0-9._~-]{0,127}$";
export declare function isInteractionId(value: unknown): value is string;
/** The complete declared identity of one interaction in Boundary Program v1. */
export type InteractionContract = {
    readonly version: 1;
    readonly id: string;
    readonly inputSchema: JsonSchema;
    readonly outputSchema: JsonSchema;
    readonly errorSchema?: JsonSchema;
    readonly reads: readonly string[];
    readonly changes: readonly string[];
};
/** The exact contract value hashed for identity. */
export type InteractionContractIdentity = InteractionContract;
/** Exact interaction identity carried across realization and control seams. */
export type InteractionIdentity = {
    readonly interactionId: string;
    readonly contractDigest: Sha256Digest;
};
export type InteractionDocumentation = {
    readonly summary?: string;
    readonly description?: string;
};
export type InteractionDescriptorSource = {
    readonly contract: InteractionContract;
    readonly docs?: InteractionDocumentation;
    readonly annotations?: JsonObject;
};
/** Handler-free interaction meaning plus non-identity presentation metadata. */
export type InteractionDescriptor = {
    readonly version: 1;
    readonly contract: InteractionContract;
    readonly contractDigest: Sha256Digest;
    readonly docs: InteractionDocumentation;
    readonly annotations: JsonObject;
};
/** A deterministic handler-free set of interaction descriptors. */
export type Program = {
    readonly version: 1;
    readonly interactions: readonly InteractionDescriptor[];
    readonly programDigest: Sha256Digest;
};
export type ProgramDiff = {
    readonly added: readonly string[];
    readonly removed: readonly string[];
    readonly changed: readonly string[];
    readonly unchanged: readonly string[];
};
export type ProgramDiagnosticCode = "INVALID_HASHER_RESULT" | "INVALID_INTERACTION_ID" | "INVALID_INTERACTION_FOOTPRINT" | "UNSUPPORTED_CONTRACT_VERSION" | "UNSUPPORTED_DESCRIPTOR_VERSION" | "UNSUPPORTED_PROGRAM_VERSION" | "EMPTY_READ" | "EMPTY_CHANGE" | "CONTRACT_DIGEST_MISMATCH" | "PROGRAM_DIGEST_MISMATCH" | "DUPLICATE_INTERACTION_ID" | "INVALID_DOCUMENTATION";
export declare class ProgramError extends BoundaryErrorBase {
    readonly code: ProgramDiagnosticCode;
    constructor(code: ProgramDiagnosticCode, path: string, message: string);
}
export declare function interactionContractIdentity(contract: InteractionContract): InteractionContractIdentity;
export declare function digestInteractionContract(contract: InteractionContract, hasher?: DomainHasher): Promise<Sha256Digest>;
export declare function createInteractionDescriptor(source: InteractionDescriptorSource, hasher?: DomainHasher): Promise<InteractionDescriptor>;
/** Return the exact sorted JSON array hashed for whole-program identity. */
export declare function programIdentity(interactions: readonly InteractionDescriptor[]): JsonArray;
export declare function digestProgram(interactions: readonly InteractionDescriptor[], hasher?: DomainHasher): Promise<Sha256Digest>;
export declare function createProgram(interactions: readonly InteractionDescriptor[], hasher?: DomainHasher): Promise<Program>;
export declare function validateProgram(program: Program, hasher?: DomainHasher): Promise<Program>;
export declare function composePrograms(programs: readonly Program[], hasher?: DomainHasher): Promise<Program>;
export declare function diffPrograms(previous: Program, next: Program): ProgramDiff;
