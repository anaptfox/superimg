import { type JsonValue } from "./json.js";
import type { RawInvocationOutcome } from "./artifacts.js";
/** Host-published evidence. Correlation identifies a call, never authorizes or deduplicates it. */
export type InvocationObservation = Readonly<Omit<RawInvocationOutcome, "result"> & {
    version: 1;
    resultKind: RawInvocationOutcome["result"]["kind"];
    reads: readonly string[];
    changes: readonly string[];
    correlation?: JsonValue;
}>;
/** Validate data received from a host-chosen observation channel. This does not authenticate its publisher. */
export declare function validateInvocationObservation(value: unknown): InvocationObservation;
