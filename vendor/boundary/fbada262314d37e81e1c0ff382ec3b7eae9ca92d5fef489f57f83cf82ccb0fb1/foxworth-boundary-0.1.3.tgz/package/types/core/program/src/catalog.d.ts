import { BoundaryErrorBase } from "./errors.js";
import { type JsonSchema, type Sha256Digest } from "./json.js";
import type { Program } from "./program.js";
export type CatalogDirectMode = Readonly<{
    realizationId: string;
}>;
export type CatalogRequestMode = Readonly<{
    realizationId: string;
    controlDigest: Sha256Digest;
    previewSchema: JsonSchema;
}>;
/** Handler-free availability for one declared interaction. */
export type CatalogEntry = Readonly<{
    interactionId: string;
    direct?: CatalogDirectMode;
    request?: CatalogRequestMode;
}>;
/**
 * Handler-free deployment overlay. Membership never changes interaction meaning;
 * it pins which exact mode realizations one deployment makes available.
 */
export type Catalog = Readonly<{
    version: 1;
    programDigest: Sha256Digest;
    interactions: readonly CatalogEntry[];
}>;
export type CatalogSource = readonly CatalogEntry[];
export type CatalogDiagnosticCode = "CATALOG_INVALID_PROGRAM_DIGEST" | "CATALOG_PROGRAM_MISMATCH" | "CATALOG_UNKNOWN_INTERACTION" | "CATALOG_MISSING_INTERACTION" | "CATALOG_DUPLICATE_INTERACTION" | "CATALOG_INVALID_AVAILABILITY" | "CATALOG_INVALID_REALIZATION_ID" | "CATALOG_DUPLICATE_REALIZATION" | "CATALOG_INVALID_CONTROL_DIGEST" | "CATALOG_INVALID_PREVIEW_SCHEMA";
export declare class CatalogError extends BoundaryErrorBase {
    readonly code: CatalogDiagnosticCode;
    constructor(code: CatalogDiagnosticCode, path: string, message: string);
}
export declare function createCatalog(program: Program, interactions: CatalogSource): Catalog;
/** Revalidate a received catalog against the exact program it claims to expose. */
export declare function validateCatalog(program: Program, catalog: Catalog): Catalog;
