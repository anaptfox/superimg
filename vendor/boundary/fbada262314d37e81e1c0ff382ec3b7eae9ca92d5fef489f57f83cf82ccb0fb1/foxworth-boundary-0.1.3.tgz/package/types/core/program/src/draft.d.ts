/**
 * The interaction Draft: a bot proposes a contract that does not exist yet.
 *
 * "Proposal" already names Control's pending effect, so a contract that does
 * not yet exist gets its own word. A Draft wraps a FULL interaction contract —
 * the entire declared identity in {@link InteractionContract}, never a
 * fragment — because anything less would fork contract identity, which is
 * the whole thing to avoid. It adds only what a proposal needs on top: the
 * gap the contract would fill (`gap`), who proposed it (`proposer`, an
 * opaque host-supplied string), and when (`createdAt`, a host-supplied
 * ISO-8601 timestamp).
 *
 * A Draft is not a Program entry. {@link Program} never contains one, and
 * nothing here is callable. It is an inert artifact: a person still reviews
 * it and, if accepted, a host still declares the contract through the
 * ordinary {@link InteractionContract} path. Declaration remains distinct from
 * realization, and interfaces still narrow authority rather than invent it.
 *
 * Boundary never reads a clock internally; ambient time would be unreviewable,
 * silently varying input, so `createdAt` is host-supplied and only checked
 * for shape here.
 *
 * This is a from-scratch TypeScript port of the algorithm in
 * `crates/boundary-core/src/program/draft.rs`. It must produce byte-identical
 * digests for the same input; the shared conformance vector is the check,
 * not this comment.
 */
import { BoundaryErrorBase } from "./errors.js";
import { type DomainHasher, type Sha256Digest } from "./json.js";
import { type InteractionContract } from "./program.js";
/** Identity domain for a Draft. */
export declare const INTERACTION_DRAFT_DOMAIN = "boundary.interaction-draft/v1";
/** Why a Draft cannot be built, or a draft that failed to verify. */
export type DraftDiagnosticCode = "EMPTY_GAP" | "EMPTY_PROPOSER" | "INVALID_CREATED_AT" | "DIGEST_MISMATCH";
/** A Draft that cannot be built, or a draft that failed to verify. */
export declare class DraftError extends BoundaryErrorBase {
    readonly code: DraftDiagnosticCode;
    constructor(code: DraftDiagnosticCode, path: string, message: string);
}
/** Inputs for {@link createDraft}. The contract is validated the same way
 * Program validates every interaction contract; an invalid contract throws the
 * same error `@foxworth/boundary/program`'s contract path already throws. */
export type DraftSource = {
    readonly contract: InteractionContract;
    readonly gap: string;
    readonly proposer: string;
    readonly createdAt: string;
};
/** An inert artifact proposing a full interaction contract that does not exist yet. */
export type Draft = {
    readonly version: 1;
    readonly contract: InteractionContract;
    readonly gap: string;
    readonly proposer: string;
    readonly createdAt: string;
    readonly draftDigest: Sha256Digest;
};
/**
 * Validates the strict ISO-8601 shape a Draft's `createdAt` requires:
 * `YYYY-MM-DDTHH:MM:SS[.f+](Z|(+|-)HH:MM)`, with calendar-aware
 * day-of-month bounds and a leap-second allowance on the seconds field.
 *
 * This is a from-scratch port of `crates/boundary-core/src/program/timestamp.rs`.
 */
export declare function isValidDraftTimestamp(value: string): boolean;
/**
 * Builds and validates a Draft, computing its digest.
 *
 * @throws {DraftError} when `gap` or `proposer` is empty, or `createdAt` is
 * not a valid ISO-8601 timestamp.
 */
export declare function createDraft(source: DraftSource, hasher?: DomainHasher): Promise<Draft>;
/**
 * Recomputes and checks the digest of a Draft that crossed a boundary.
 *
 * @throws {DraftError} with code `DIGEST_MISMATCH` when the draft's recorded
 * digest does not match its content.
 */
export declare function verifyDraft(draft: Draft, hasher?: DomainHasher): Promise<void>;
