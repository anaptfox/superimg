import { type JsonSchema } from "./json.js";
/**
 * Structural schema matcher backing `contractCompatibility` (compatibility.ts).
 * Split out for file-size hygiene; the two modules form one feature.
 */
export type ContractCompatibility = {
    compatible: true;
} | {
    compatible: false;
    reason: string;
    path: string;
};
export type ExtraProperties = "reject" | "ignore";
export declare function incompatible(reason: string, path: string): ContractCompatibility;
export declare function acceptsEvery(wider: JsonSchema, narrower: JsonSchema, path: string, extras: ExtraProperties): ContractCompatibility;
