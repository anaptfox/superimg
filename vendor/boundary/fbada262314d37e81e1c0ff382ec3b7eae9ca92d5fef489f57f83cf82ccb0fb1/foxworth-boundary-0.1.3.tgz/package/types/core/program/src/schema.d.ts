import { BoundaryErrorBase } from "./errors.js";
import { type JsonObject, type JsonSchema } from "./json.js";
export type SchemaRole = "input" | "output" | "error";
export type SchemaCompilationContext = {
    readonly role: SchemaRole;
    readonly path: string;
};
export type SchemaCompilation = {
    /** Assertion-bearing portable JSON Schema used by contract identity. */
    readonly contract: JsonSchema;
    /** Projector hints and documentation excluded from contract identity. */
    readonly annotations: JsonObject;
};
export interface SchemaAdapter<Schema> {
    compile(schema: Schema, context: SchemaCompilationContext): {
        readonly contract: unknown;
        readonly annotations?: unknown;
    };
}
export type SchemaAdapterDiagnosticCode = "SCHEMA_ADAPTER_COMPILE_FAILED" | "SCHEMA_ADAPTER_CONTRACT_NOT_OBJECT" | "SCHEMA_ADAPTER_ANNOTATIONS_NOT_OBJECT";
export declare class SchemaAdapterError extends BoundaryErrorBase {
    readonly code: SchemaAdapterDiagnosticCode;
    constructor(code: SchemaAdapterDiagnosticCode, path: string, message: string, options?: {
        readonly cause?: unknown;
    });
}
/**
 * Compile through an explicit schema adapter, then enforce Boundary' strict
 * portable JSON seam. Core never has to know an adapter's internal format.
 */
export declare function compileSchema<Schema>(schema: Schema, adapter: SchemaAdapter<Schema>, context: SchemaCompilationContext): SchemaCompilation;
