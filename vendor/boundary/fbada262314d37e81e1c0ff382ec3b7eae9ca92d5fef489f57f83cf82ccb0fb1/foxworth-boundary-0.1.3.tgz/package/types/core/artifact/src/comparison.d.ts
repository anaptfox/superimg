import { type ContractDelta, type InteractionContract } from "@foxworth/boundary/program";
import { type ArtifactDigest, type ContentManifest, type PackReceipt } from "./integrity.js";
import { type ArtifactPackageMetadata } from "./metadata.js";
/** Exact paths and optional reviewed pins supplied by the consumer. */
export type PackageArtifactSource = Readonly<{
    root: string;
    receiptPath?: string;
    expected?: Readonly<{
        name?: string;
        version?: string;
        aggregateDigest?: ArtifactDigest;
        tarballDigest?: ArtifactDigest;
    }>;
}>;
export type VerifiedPackageArtifact = Readonly<{
    root: string;
    content: ContentManifest;
    metadata: ArtifactPackageMetadata;
    /** Present only after verifying the adjacent tarball and linking its content pin. */
    receipt?: PackReceipt;
}>;
export type ArtifactMemberDiff = Readonly<{
    added: readonly string[];
    removed: readonly string[];
    changed: readonly string[];
    unchanged: readonly string[];
}>;
export type PackageArtifactComparisonOptions = Readonly<{
    before: PackageArtifactSource;
    after: PackageArtifactSource;
    /** Exact subpath declarations; patterns and implicit root discovery are not expanded. */
    requiredExports?: readonly string[];
    /** Reviewed declarations supplied explicitly, never discovered by evaluating package code. */
    contracts?: readonly Readonly<{
        before: InteractionContract;
        after: InteractionContract;
    }>[];
}>;
export type PackageArtifactComparison = Readonly<{
    version: 1;
    before: VerifiedPackageArtifact;
    after: VerifiedPackageArtifact;
    identity: Readonly<{
        sameName: boolean;
        sameVersion: boolean;
        sameContent: boolean;
        /** Null when either receipt was omitted; missing evidence is not equal bytes. */
        sameTarball: boolean | null;
        versionReusedWithDifferentContent: boolean;
    }>;
    files: ArtifactMemberDiff;
    exports: ArtifactMemberDiff & Readonly<{
        required: readonly string[];
        missingBefore: readonly string[];
        missingAfter: readonly string[];
    }>;
    /** Exact engines strings and changes; this does not solve semver or prove a runtime supports them. */
    runtimes: ArtifactMemberDiff;
    /** Directional declaration judgments only, with caller-supplied provenance. */
    contracts: Readonly<{
        source: "caller-supplied";
        deltas: readonly Readonly<{
            beforeId: string;
            afterId: string;
            delta: ContractDelta;
        }>[];
    }>;
}>;
/**
 * Read-only verification and comparison of explicit artifacts. Integrity checks
 * fail closed; differences are reported for host review, never installed or
 * treated as signing, publisher authentication, or realization equivalence.
 */
export declare function comparePackageArtifacts(options: PackageArtifactComparisonOptions): Promise<PackageArtifactComparison>;
