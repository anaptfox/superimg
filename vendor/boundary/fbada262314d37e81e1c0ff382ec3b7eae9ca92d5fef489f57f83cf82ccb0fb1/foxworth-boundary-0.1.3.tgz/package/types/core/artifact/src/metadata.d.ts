import { type JsonValue } from "@foxworth/boundary/program";
import type { ContentManifest } from "./integrity.js";
/** Declared package metadata, not a module resolution or runtime compatibility proof. */
export type ArtifactPackageMetadata = Readonly<{
    exports: Readonly<Record<string, JsonValue>>;
    engines: Readonly<Record<string, string>>;
}>;
export declare function freezeArtifact<Value>(value: Value): Value;
export declare function hasExportTarget(value: JsonValue | undefined): boolean;
export declare function requiredExportNames(values: readonly string[]): readonly string[];
export declare function readArtifactMetadata(root: string, content: ContentManifest): Promise<ArtifactPackageMetadata>;
