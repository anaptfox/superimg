export declare const CONTENT_MANIFEST_VERSION = 1;
export declare const CONTENT_MANIFEST_FILE = "boundary-artifact.json";
export declare const PACK_RECEIPT_VERSION = 1;
export declare const PACK_RECEIPT_SUFFIX = ".receipt.json";
export type ArtifactDigest = `sha256:${string}`;
export type ContentManifest = Readonly<{
    version: 1;
    algorithm: "sha256";
    package: Readonly<{
        name: string;
        version: string;
    }>;
    files: readonly Readonly<{
        path: string;
        bytes: number;
        sha256: ArtifactDigest;
    }>[];
    aggregateDigest: ArtifactDigest;
}>;
export type PackReceipt = Readonly<{
    version: 1;
    algorithm: "sha256";
    package: Readonly<{
        name: string;
        version: string;
    }>;
    tarball: Readonly<{
        filename: string;
        bytes: number;
        sha256: ArtifactDigest;
    }>;
    contentDigest: ArtifactDigest;
}>;
export declare function readContentManifest(root: string): Promise<ContentManifest>;
export declare function writeContentManifest(root: string, packageValue: Readonly<{
    name: string;
    version: string;
}>): Promise<ContentManifest>;
export declare function verifyContentManifest(root: string, expected?: Readonly<{
    name?: string;
    version?: string;
    aggregateDigest?: ArtifactDigest;
}>): Promise<ContentManifest>;
export declare function writePackReceipt(options: Readonly<{
    tarballPath: string;
    packageName: string;
    packageVersion: string;
    contentDigest: ArtifactDigest;
}>): Promise<Readonly<{
    receipt: PackReceipt;
    receiptPath: string;
}>>;
export declare function verifyPackReceipt(receiptPath: string, expected?: Readonly<{
    name?: string;
    version?: string;
}>): Promise<Readonly<{
    receipt: PackReceipt;
    tarballPath: string;
}>>;
