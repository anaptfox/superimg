import { type JsonSchema, type JsonValue, type Sha256Digest } from "@foxworth/boundary/program";
import type { Grant, Proposal, ProposalRecord } from "./types.js";
export declare const CONTROL_PROPOSAL_DOMAIN = "boundary.control-proposal/v1";
/** JSON Schema used by every projected public-proposal surface. */
export declare const PUBLIC_PROPOSAL_SCHEMA: JsonSchema;
export type ProposalIntegrity = {
    readonly status: "valid";
    readonly proposal: ProposalRecord;
} | {
    readonly status: "invalid";
    readonly reason: string;
};
/** Snapshot and enforce the exact public proposal contract owned by Control. */
export declare function normalizePublicProposal<Preview extends JsonValue = JsonValue>(value: unknown, path: string): Proposal<Preview>;
export declare function proposalDigest(proposal: Omit<ProposalRecord, "proposalDigest">): Promise<Sha256Digest>;
export declare function verifyProposalIntegrity(value: ProposalRecord): Promise<ProposalIntegrity>;
export declare function requireValidProposal(value: ProposalRecord): Promise<ProposalRecord>;
export declare function publicProposal<Preview extends JsonValue>(proposal: ProposalRecord<Preview>): Proposal<Preview>;
export declare function publicHandleMatches(handle: Proposal, record: ProposalRecord): boolean;
export declare function grantMatchesProposal(grant: Grant, proposal: ProposalRecord): boolean;
export { approvalMatchesProposal, snapshotApprovalRecords } from "./approvalRecords.js";
