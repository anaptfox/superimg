export declare function snapshot<T>(value: T, path: string): T;
export declare function requiredString(value: unknown): value is string;
export declare function isObject(value: unknown): value is Record<string, unknown>;
export declare function projectionSourceSnapshot<T>(value: T, path: string): T;
export declare function requireExactFields(value: Record<string, unknown>, allowed: ReadonlySet<string>, required: readonly string[], path: string): void;
