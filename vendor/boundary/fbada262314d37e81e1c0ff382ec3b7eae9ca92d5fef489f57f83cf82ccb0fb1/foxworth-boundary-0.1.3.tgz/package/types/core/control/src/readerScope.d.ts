import type { ControlReaderScope } from "./types.js";
/** Snapshot caller-owned scope data so later mutation cannot widen observation. */
export declare function snapshotControlReaderScope(value: ControlReaderScope): ControlReaderScope;
export declare function controlReaderScopeIncludes(scope: ControlReaderScope, proposal: unknown): boolean;
export declare function controlRecordProposalId(value: unknown): string | undefined;
