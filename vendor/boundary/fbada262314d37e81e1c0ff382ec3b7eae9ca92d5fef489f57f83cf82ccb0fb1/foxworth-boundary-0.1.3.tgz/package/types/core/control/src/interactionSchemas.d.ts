import { type JsonValue, type Sha256Digest } from "@foxworth/boundary/program";
import { CONTROL_RECORD_VERSION } from "./types.js";
import type { AttemptRef, EffectResult, Grant, Receipt } from "./types.js";
export type PublicGrant<Preview extends JsonValue = JsonValue> = {
    readonly version: typeof CONTROL_RECORD_VERSION;
    readonly id: string;
    readonly proposalId: string;
    readonly proposalDigest: Sha256Digest;
    readonly bindingDigest: Sha256Digest;
    readonly projectionDigest: Sha256Digest;
    readonly installationId: string;
    readonly installationDigest: Sha256Digest;
    readonly expectedProgramDigest: Sha256Digest;
    readonly actualProgramDigest: Sha256Digest;
    readonly programDigest: Sha256Digest;
    readonly controlDigest: Sha256Digest;
    readonly interactionId: string;
    readonly expectedContractDigest: Sha256Digest;
    readonly contractDigest: Sha256Digest;
    readonly requestRealizationId: string;
    readonly executionRealizationId: string;
    readonly controlRealizationDigest: Sha256Digest;
    readonly requestedBy: string;
    readonly approvedBy: readonly string[];
    readonly subject: Grant<Preview>["subject"];
    readonly preview: Preview;
    readonly issuedBy: string;
    readonly issuedAt: number;
    readonly expiresAt?: number;
};
export type PublicControlStatus = {
    readonly proposal: PublicProposalJson;
    readonly grant?: PublicGrant;
    readonly attempt?: AttemptRef;
    readonly receipt?: Receipt;
};
export type ControlApprovalDecision = {
    readonly allow: true;
};
export type ControlListFilter = {
    readonly interactionId?: string;
    readonly proposalId?: string;
};
export declare const CONTROL_REQUEST_INPUT_SCHEMA: import("@foxworth/boundary/program").PortableSchema<{
    readonly interactionId: string;
    readonly input: JsonValue;
    readonly contractDigest?: Sha256Digest;
    readonly controlDigest?: Sha256Digest;
}>;
export declare const CONTROL_APPROVE_INPUT_SCHEMA: import("@foxworth/boundary/program").PortableSchema<{
    readonly proposalId: string;
    readonly decision: ControlApprovalDecision;
}>;
export type ControlStatusError = {
    readonly code: "CONTROL_NOT_FOUND";
    readonly proposalId: string;
};
export declare const CONTROL_STATUS_ERROR_SCHEMA: import("@foxworth/boundary/program").PortableSchema<ControlStatusError>;
export declare const CONTROL_PROPOSAL_ID_INPUT_SCHEMA: import("@foxworth/boundary/program").PortableSchema<{
    readonly proposalId: string;
}>;
export declare const CONTROL_GRANT_ID_INPUT_SCHEMA: import("@foxworth/boundary/program").PortableSchema<{
    readonly grantId: string;
}>;
export declare const CONTROL_ATTEMPT_ID_INPUT_SCHEMA: import("@foxworth/boundary/program").PortableSchema<{
    readonly attemptId: string;
}>;
export declare const CONTROL_LIST_INPUT_SCHEMA: import("@foxworth/boundary/program").PortableSchema<{
    readonly filter?: ControlListFilter;
}>;
export type PublicProposalJson = {
    readonly version: typeof CONTROL_RECORD_VERSION;
    readonly id: string;
    readonly proposalDigest: Sha256Digest;
    readonly bindingDigest: Sha256Digest;
    readonly projectionDigest: Sha256Digest;
    readonly installationId: string;
    readonly installationDigest: Sha256Digest;
    readonly expectedProgramDigest: Sha256Digest;
    readonly actualProgramDigest: Sha256Digest;
    readonly programDigest: Sha256Digest;
    readonly controlDigest: Sha256Digest;
    readonly interactionId: string;
    readonly expectedContractDigest: Sha256Digest;
    readonly contractDigest: Sha256Digest;
    readonly requestRealizationId: string;
    readonly executionRealizationId: string;
    readonly controlRealizationDigest: Sha256Digest;
    readonly requestedBy: string;
    readonly subject: {
        readonly kind: string;
        readonly id: string;
    };
    readonly baselineSummary: string;
    readonly effects: readonly JsonValue[];
    readonly preview: JsonValue;
    readonly createdAt: number;
};
export declare const PUBLIC_PROPOSAL_OUTPUT_SCHEMA: import("@foxworth/boundary/program").PortableSchema<PublicProposalJson>;
export declare const PUBLIC_GRANT_SCHEMA: import("@foxworth/boundary/program").PortableSchema<PublicGrant<JsonValue> & JsonValue>;
export declare const PUBLIC_EFFECT_RESULT_SCHEMA: import("@foxworth/boundary/program").PortableSchema<EffectResult<JsonValue> & JsonValue>;
export declare const PUBLIC_CONTROL_STATUS_SCHEMA: import("@foxworth/boundary/program").PortableSchema<PublicControlStatus & JsonValue>;
export declare const PUBLIC_CONTROL_STATUS_LIST_SCHEMA: import("@foxworth/boundary/program").PortableSchema<readonly (PublicControlStatus & JsonValue)[]>;
/** Snapshot and validate one complete durable grant at a journal boundary. */
export declare function snapshotGrantRecord<Preview extends JsonValue = JsonValue>(value: unknown, path?: string): Grant<Preview>;
export declare function publicGrant<Preview extends JsonValue>(grant: Grant<Preview>): PublicGrant<Preview>;
export type { EffectResult };
