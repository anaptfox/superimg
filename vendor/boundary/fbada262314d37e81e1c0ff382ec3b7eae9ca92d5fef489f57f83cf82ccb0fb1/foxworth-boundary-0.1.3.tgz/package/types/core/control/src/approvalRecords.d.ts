import type { Approval, ProposalRecord } from "./types.js";
export declare function approvalMatchesProposal(approval: Approval, proposal: ProposalRecord): boolean;
/** Snapshot and validate the complete durable approval list at a journal boundary. */
export declare function snapshotApprovalRecords(value: unknown, path: string): readonly Approval[];
/** Snapshot and validate one complete durable approval at a journal boundary. */
export declare function snapshotApprovalRecord(value: unknown, path?: string): Approval;
