import { type JsonObject, type JsonValue, type InteractionIdentity, type Sha256Digest } from "@foxworth/boundary/program";
import type { AnyControlHook, ControlHook, ControlPlan, ControlTarget } from "./types.js";
export declare const CONTROL_REALIZATION_DOMAIN = "boundary.control-realization/v1";
export type ControlRealizationIdentity = InteractionIdentity;
export type ControlRuntimeIdentity = {
    readonly bindingDigest: Sha256Digest;
    readonly projectionDigest: Sha256Digest;
    readonly installationId: string;
    readonly installationDigest: Sha256Digest;
    readonly expectedProgramDigest: Sha256Digest;
    readonly actualProgramDigest: Sha256Digest;
    readonly programDigest: Sha256Digest;
    readonly interactionId: string;
    readonly expectedContractDigest: Sha256Digest;
    readonly contractDigest: Sha256Digest;
    readonly requestRealizationId: string;
    readonly executionRealizationId: string;
};
export type ControlDigestIdentity = {
    readonly interactionId: string;
    readonly interactionContractDigest: Sha256Digest;
    readonly realizationDigest: Sha256Digest;
    readonly stateSchema: JsonObject;
    readonly previewSchema: JsonObject;
};
export type ControlSchemaCompilation = {
    readonly contract: JsonObject;
};
export type ControlSchemaCompiler = {
    compileSchema(schema: unknown, context: {
        readonly role: "input" | "output" | "error";
        readonly path: string;
    }): ControlSchemaCompilation;
};
export type ResolvedControl<Context = unknown> = {
    readonly identity: ControlRealizationIdentity;
    readonly hook: AnyControlHook<Context>;
    readonly controlDigest: Sha256Digest;
    readonly stateSchema: JsonObject;
    readonly previewSchema: JsonObject;
};
export declare function requireResolvedControl<Context>(control: ResolvedControl<Context>): ResolvedControl<Context>;
export declare function targetForControl<Context>(control: ResolvedControl<Context>, identity: ControlRuntimeIdentity): ControlTarget;
export declare function validateControlHook<Context = unknown>(value: unknown, path: string): AnyControlHook<Context>;
/** Type and freeze one author-facing control realization. */
export declare function controlled<Input, Output, State extends JsonValue, Preview extends JsonValue, StateSchema = unknown, PreviewSchema = unknown, Context = unknown>(hook: ControlHook<Input, Output, State, Preview, StateSchema, PreviewSchema, Context>): ControlHook<Input, Output, State, Preview, StateSchema, PreviewSchema, Context>;
export declare function digestControlRealization<Context = unknown>(compiler: ControlSchemaCompiler, identity: ControlRealizationIdentity, control: unknown): Promise<ResolvedControl<Context>>;
export declare function normalizeControlPlan(plan: ControlPlan, path: string): ControlPlan;
