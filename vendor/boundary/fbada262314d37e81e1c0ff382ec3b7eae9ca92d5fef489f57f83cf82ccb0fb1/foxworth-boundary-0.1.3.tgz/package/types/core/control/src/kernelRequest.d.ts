import { type ControlRuntime } from "./kernelShared.js";
import type { Approval, ControlRequest, Grant, Proposal } from "./types.js";
export declare function requestControl<Actor, Context>(runtime: ControlRuntime<Actor, Context>, request: ControlRequest<Actor, Context>): Promise<Proposal>;
export declare function approveControl<Actor, Context>(runtime: ControlRuntime<Actor, Context>, actor: Actor, handle: Proposal | string): Promise<Approval>;
export declare function grantControl<Actor, Context>(runtime: ControlRuntime<Actor, Context>, actor: Actor, handle: Proposal | string): Promise<Grant>;
