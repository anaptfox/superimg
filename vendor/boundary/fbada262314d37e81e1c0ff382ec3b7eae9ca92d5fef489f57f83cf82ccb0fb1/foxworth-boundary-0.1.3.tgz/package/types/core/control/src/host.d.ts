import type { AnyInteractionDefinition, CompiledInteractions, InteractionDefinitions, InteractionHandle, RealizationId } from "@foxworth/boundary";
import { type ControlRequestContributions as HostControlRequestContributions } from "@foxworth/boundary/host/control";
import { type ResolvedControl } from "./realization.js";
import type { ControlRequester, MaybePromise } from "./types.js";
export type ControlRequestContribution<Definition extends AnyInteractionDefinition = AnyInteractionDefinition, Actor = unknown, Context = unknown> = Readonly<{
    interaction: InteractionHandle<Definition>;
    control: ResolvedControl<Context>;
    executionRealizationId: RealizationId;
    actor(context: Context): MaybePromise<Actor>;
}>;
export type ControlRequestContributions<Definitions extends InteractionDefinitions, Actor, Context> = Readonly<Partial<{
    [Alias in keyof Definitions]: ControlRequestContribution<Definitions[Alias], Actor, Context>;
}>>;
/**
 * Project proposal creation into opaque Host request contributions.
 *
 * The returned bindings possess only an authentic `ControlRequester`; Reader
 * and Admin are structurally absent. Under the Host-supplied request-only plan
 * contract, each request performs one proposal-creation attempt and never
 * approves, grants, executes, reconciles, retries, or replays.
 */
export declare function contributeControlRequests<Definitions extends InteractionDefinitions, Actor, Context>(compiled: CompiledInteractions<Definitions>, requester: ControlRequester<Actor, Context>, contributions: ControlRequestContributions<Definitions, Actor, Context>): HostControlRequestContributions<Definitions, Context>;
