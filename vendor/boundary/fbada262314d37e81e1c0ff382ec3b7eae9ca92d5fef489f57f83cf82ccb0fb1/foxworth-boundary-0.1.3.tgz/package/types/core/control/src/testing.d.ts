import { type Sha256Digest } from "@foxworth/boundary/program";
import type { Approval, AttemptRecord, ControlClock, ControlJournalQuery, ControlStatusChain, ControlJournal, ControlRecordKind, CreateRecordResult, Grant, ProposalRecord, ReceiptRecord } from "./types.js";
/** Deterministic, independently incrementing identifiers for control fixtures. */
export declare class TestIds {
    #private;
    constructor(prefix?: string);
    nextId(kind: ControlRecordKind): string;
}
/** Mutable deterministic clock for control and lease tests. */
export declare class TestClock implements ControlClock {
    #private;
    constructor(initialNow?: number);
    now(): number;
    set(value: number): number;
    advance(milliseconds: number): number;
    static assertTime(value: number, path: string): number;
}
/**
 * Browser-safe, process-local control journal for deterministic tests.
 *
 * Every boundary returns a fresh, deeply frozen JSON snapshot. Create methods
 * contain no suspension point, so their uniqueness checks and writes are one
 * atomic JavaScript turn.
 */
export declare class MemoryJournal implements ControlJournal {
    #private;
    constructor(ids?: TestIds);
    nextId(kind: ControlRecordKind): string;
    createProposal(proposal: ProposalRecord): Promise<CreateRecordResult<ProposalRecord>>;
    getProposal(id: string): Promise<ProposalRecord | undefined>;
    findProposalByDigest(digest: Sha256Digest): Promise<ProposalRecord | undefined>;
    listProposals(): Promise<readonly ProposalRecord[]>;
    queryProposals(query: ControlJournalQuery): Promise<readonly ProposalRecord[]>;
    readStatusChains(digests: readonly Sha256Digest[]): Promise<readonly ControlStatusChain[]>;
    createApproval(approval: Approval): Promise<CreateRecordResult<Approval>>;
    listApprovals(proposalDigest: Sha256Digest): Promise<readonly Approval[]>;
    getApproval(id: string): Promise<Approval | undefined>;
    createGrant(grant: Grant): Promise<CreateRecordResult<Grant>>;
    getGrant(id: string): Promise<Grant | undefined>;
    findGrantByProposalDigest(digest: Sha256Digest): Promise<Grant | undefined>;
    createAttempt(attempt: AttemptRecord): Promise<CreateRecordResult<AttemptRecord>>;
    compareAndSwapAttempt(attempt: AttemptRecord, expectedRecordRevision: number): Promise<boolean>;
    getAttempt(id: string): Promise<AttemptRecord | undefined>;
    findAttemptByProposalDigest(digest: Sha256Digest): Promise<AttemptRecord | undefined>;
    createReceipt(receipt: ReceiptRecord): Promise<CreateRecordResult<ReceiptRecord>>;
    getReceipt(id: string): Promise<ReceiptRecord | undefined>;
    findReceiptByProposalDigest(digest: Sha256Digest): Promise<ReceiptRecord | undefined>;
}
