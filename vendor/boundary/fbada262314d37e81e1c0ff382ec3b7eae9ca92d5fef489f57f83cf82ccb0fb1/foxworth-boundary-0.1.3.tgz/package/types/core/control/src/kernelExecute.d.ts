import { type ControlRuntime } from "./kernelShared.js";
import type { EffectResult, Grant } from "./types.js";
export declare function executeControl<Actor, Context, Output = unknown>(runtime: ControlRuntime<Actor, Context>, grantHandle: Grant | string, actor: Actor, context: Context): Promise<EffectResult<Output>>;
