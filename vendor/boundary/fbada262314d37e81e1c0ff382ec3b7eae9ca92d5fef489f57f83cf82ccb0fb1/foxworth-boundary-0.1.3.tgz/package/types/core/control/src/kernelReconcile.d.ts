import { type ControlRuntime } from "./kernelShared.js";
import type { UntypedAttemptRef, EffectResult } from "./types.js";
export declare function reconcileControl<Actor, Context, Output = unknown>(runtime: ControlRuntime<Actor, Context>, handle: UntypedAttemptRef | string, actor: Actor, context: Context): Promise<EffectResult<Output>>;
