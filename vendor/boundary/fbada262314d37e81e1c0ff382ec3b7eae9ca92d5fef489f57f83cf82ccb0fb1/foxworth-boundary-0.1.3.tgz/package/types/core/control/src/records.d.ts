import type { AttemptRef, UntypedAttemptRef, AttemptRecord, Grant, ProposalRecord, ReceiptRecord } from "./types.js";
export { snapshot } from "./recordSnapshot.js";
export { CONTROL_PROPOSAL_DOMAIN, PUBLIC_PROPOSAL_SCHEMA, approvalMatchesProposal, grantMatchesProposal, normalizePublicProposal, publicHandleMatches, publicProposal, proposalDigest, requireValidProposal, snapshotApprovalRecords, verifyProposalIntegrity, type ProposalIntegrity, } from "./proposalRecords.js";
export declare function attemptMatches(attempt: AttemptRecord, proposal: ProposalRecord, grant: Grant): boolean;
/** Snapshot and validate one complete durable attempt at a journal boundary. */
export declare function snapshotAttemptRecord(value: unknown): AttemptRecord;
/** Durable projection has no native output-type evidence. */
export declare function publicAttempt(attempt: AttemptRecord): AttemptRef;
export declare function attemptRefMatches(reference: UntypedAttemptRef, attempt: AttemptRecord): boolean;
export declare function receiptMatches(receipt: ReceiptRecord, attempt: AttemptRecord, proposal: ProposalRecord, grant: Grant): boolean;
/** Snapshot and validate one complete durable receipt at a journal boundary. */
export declare function snapshotReceiptRecord(value: unknown, path?: string): ReceiptRecord;
