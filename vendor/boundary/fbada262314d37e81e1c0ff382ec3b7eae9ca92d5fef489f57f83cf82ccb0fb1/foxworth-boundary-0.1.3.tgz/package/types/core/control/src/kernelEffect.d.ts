import { type JsonValue } from "@foxworth/boundary/program";
import { type ControlRuntime } from "./kernelShared.js";
import type { UntypedAttemptRef, AttemptRecord, ControlBinding, ControlLease, EffectResult, Grant, ProposalRecord, ReceiptRecord, Verification } from "./types.js";
export declare function leaseDuration<Actor, Context>(runtime: ControlRuntime<Actor, Context>): number;
export declare function uncertain<Output = never>(attempt: AttemptRecord): EffectResult<Output>;
export declare function notApplied(reason: string): EffectResult<never>;
export declare function loadAuthority<Actor, Context>(runtime: ControlRuntime<Actor, Context>, grantHandle: Grant | string): Promise<{
    readonly proposal: ProposalRecord;
    readonly grant: Grant;
}>;
export declare function bindPrivateProposal<Actor, Context>(runtime: ControlRuntime<Actor, Context>, proposal: ProposalRecord, path: string): Promise<{
    readonly binding: ControlBinding<Context>;
    readonly input: unknown;
    readonly state: JsonValue;
}>;
export declare function findExistingAttempt<Actor, Context>(runtime: ControlRuntime<Actor, Context>, proposal: ProposalRecord): Promise<AttemptRecord | undefined>;
export declare function findExistingReceipt<Actor, Context>(runtime: ControlRuntime<Actor, Context>, proposal: ProposalRecord): Promise<ReceiptRecord | undefined>;
export declare function publishReceipt<Actor, Context, Output>(runtime: ControlRuntime<Actor, Context>, proposal: ProposalRecord, grant: Grant, attempt: AttemptRecord): Promise<EffectResult<Output>>;
export type AttemptSession = {
    current(): AttemptRecord;
    transition(patch: Partial<Omit<AttemptRecord, "recordRevision">>): Promise<boolean>;
    lease: ControlLease;
};
export declare function createAttemptSession<Actor, Context>(runtime: ControlRuntime<Actor, Context>, initial: AttemptRecord): AttemptSession;
export declare function containFailure<Actor, Context>(runtime: ControlRuntime<Actor, Context>, session: AttemptSession, message: string, verificationState?: AttemptRecord["verification"]): Promise<EffectResult<never>>;
export declare function runVerification<Actor, Context>(runtime: ControlRuntime<Actor, Context>, session: AttemptSession, proposal: ProposalRecord, binding: ControlBinding<Context>, input: unknown, state: JsonValue, output: unknown, context: Context): Promise<Verification>;
export declare function loadAttemptRecord<Actor, Context>(runtime: ControlRuntime<Actor, Context>, handle: UntypedAttemptRef | string): Promise<AttemptRecord>;
export declare function loadAttemptAuthority<Actor, Context>(runtime: ControlRuntime<Actor, Context>, attempt: AttemptRecord): Promise<{
    readonly proposal: ProposalRecord;
    readonly grant: Grant;
}>;
