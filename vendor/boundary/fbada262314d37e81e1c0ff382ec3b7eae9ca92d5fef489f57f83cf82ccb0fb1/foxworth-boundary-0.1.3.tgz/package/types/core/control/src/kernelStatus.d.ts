import { type ControlListFilter, type PublicControlStatus } from "./interactionSchemas.js";
import type { ControlJournal, ControlReaderScope, ControlPageQuery, ControlPage } from "./types.js";
export declare function statusControl(journal: ControlJournal, proposalId: string, scopeValue: ControlReaderScope): Promise<PublicControlStatus>;
export declare function listControl(journal: ControlJournal, filter: ControlListFilter | undefined, scopeValue: ControlReaderScope): Promise<readonly PublicControlStatus[]>;
/** Bounded native reader query. A cursor is an exclusive id, not a snapshot token. */
export declare function pageControl(journal: ControlJournal, query: ControlPageQuery, scopeValue: ControlReaderScope): Promise<ControlPage<PublicControlStatus>>;
