import type { ControlListFilter, PublicControlStatus } from "./interactionSchemas.js";
import type { ControlAdmin, ControlCapabilities, ControlHost, ControlOptions, ControlPart, ControlReader, ControlRequester, ControlReaderScope } from "./types.js";
export declare function createControlRequester<Actor, Context>(options: ControlOptions<Actor>, host: ControlHost<Context>): ControlRequester<Actor, Context>;
/** @internal Authenticate and snapshot proposal-creation authority. */
export declare function requestForControlRequester<Actor, Context>(requester: ControlRequester<Actor, Context>): ControlRequester<Actor, Context>["request"];
export declare function createControlAdmin<Actor, Context>(options: ControlOptions<Actor>, host: ControlHost<Context>): ControlAdmin<Actor, Context>;
export declare function createControlReader(options: Pick<ControlOptions<unknown>, "journal">, scopeValue: ControlReaderScope): ControlReader<PublicControlStatus, ControlListFilter>;
export declare function createControlCapabilities<Actor, Context>(options: ControlOptions<Actor>, host: ControlHost<Context>, readerScope: ControlReaderScope): ControlCapabilities<Actor, Context, PublicControlStatus, ControlListFilter>;
/** Configure Control without importing or assuming an application model. */
export declare function control<Actor = string>(options: ControlOptions<Actor>): ControlPart<Actor>;
export declare function isControlPart(value: unknown): value is ControlPart<unknown>;
export declare function controlPartOptions<Actor>(part: ControlPart<Actor>): ControlOptions<Actor>;
export declare function installControlPart<Actor, Context>(part: ControlPart<Actor>, host: ControlHost<Context>, readerScope: ControlReaderScope): ControlCapabilities<Actor, Context, PublicControlStatus, ControlListFilter>;
