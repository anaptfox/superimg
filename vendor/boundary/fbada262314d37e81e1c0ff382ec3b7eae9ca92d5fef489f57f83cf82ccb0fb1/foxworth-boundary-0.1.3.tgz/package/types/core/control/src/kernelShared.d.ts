import { type JsonValue } from "@foxworth/boundary/program";
import { ControlError } from "./errors.js";
import type { ControlBinding, ControlDecision, ControlHost, ControlOptions, ControlTarget, CreateRecordResult, Proposal, ProposalRecord } from "./types.js";
export type ControlRuntime<Actor, Context> = ControlOptions<Actor> & {
    readonly host: ControlHost<Context>;
};
export declare function snapshotCreateResult<RecordValue>(value: CreateRecordResult<RecordValue>, path: string): CreateRecordResult<RecordValue>;
export declare function messageOf(error: unknown, fallback: string): string;
export declare function beforeAttempt(error: unknown, path: string, fallback: string): ControlError;
export declare function clockNow<Actor, Context>(runtime: ControlRuntime<Actor, Context>, path: string): number;
export declare function nextId<Actor, Context>(runtime: ControlRuntime<Actor, Context>, kind: Parameters<ControlRuntime<Actor, Context>["journal"]["nextId"]>[0]): Promise<string>;
export declare function actorId<Actor, Context>(runtime: ControlRuntime<Actor, Context>, actor: Actor): string;
export declare function requireDecision(decision: ControlDecision, path: string): asserts decision is Extract<ControlDecision, {
    readonly allow: true;
}>;
export declare function targetOf(proposal: ProposalRecord): ControlTarget;
export declare function recordIdentity(target: ControlTarget): ControlTarget;
export declare function requireTarget(target: ControlTarget, path: string): ControlTarget;
export declare function resolveCurrentBinding<Context>(host: ControlHost<Context>, targetValue: ControlTarget, path: string): Promise<ControlBinding<Context>>;
export declare function loadProposalRecord<Actor, Context>(runtime: ControlRuntime<Actor, Context>, handle: Proposal | string): Promise<ProposalRecord>;
export declare function loadProposal<Actor, Context>(runtime: ControlRuntime<Actor, Context>, handle: Proposal | string): Promise<ProposalRecord>;
export declare function parsePrivateProposal<Context>(binding: ControlBinding<Context>, proposal: ProposalRecord): Promise<{
    readonly input: unknown;
    readonly state: JsonValue;
    readonly preview: JsonValue;
}>;
