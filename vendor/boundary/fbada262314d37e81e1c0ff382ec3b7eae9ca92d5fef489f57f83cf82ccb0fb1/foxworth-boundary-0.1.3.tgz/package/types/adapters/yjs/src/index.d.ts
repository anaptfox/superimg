import * as Y from "yjs";
import { type JsonValue } from "@foxworth/boundary/program";
/** @experimental Boundary snapshot adapter; its API may change incompatibly. */
export interface YjsCapture {
    readonly engine: "yjs";
    /** Hex encoded Yjs Snapshot bytes, including the snapshot delete set. */
    readonly frontier: string;
    /** Return a fresh copy of the captured full-state update. */
    encode(): Uint8Array;
    /** Project JSON data from a newly materialized document for each read. */
    read<Result extends JsonValue>(project: (doc: Y.Doc) => Result | PromiseLike<Result>): Promise<Result>;
}
/**
 * Capture an immutable, process-local view of one Yjs document state.
 * Subdocuments are refused because a full-state update contains their
 * references, not the subdocuments' contents.
 * @experimental For evaluation; no production support commitment. The API may change incompatibly.
 */
export declare function captureYjs(doc: Y.Doc): YjsCapture;
