import type { HttpHandler } from "../../http/src/http.js";
/** Vite server mode used to prepare an explicit candidate. */
export type ProjectionViteMode = "development" | "preview";
/** A host-owned implementation generation and its cleanup boundary. */
export type ProjectionViteCandidate = Readonly<{
    readonly generation: string;
    readonly handler: HttpHandler;
    readonly dispose?: () => void | Promise<void>;
}>;
/** Non-authoritative lifecycle diagnostics; observers cannot change truth. */
export type ProjectionViteDiagnostic = Readonly<{
    readonly code: "CANDIDATE_REJECTED" | "CANDIDATE_DISPOSAL_FAILED" | "RETIRED_DISPOSAL_FAILED" | "STALE_CLIENT" | "NOT_READY" | "CLOSED";
    readonly message: string;
    readonly generation?: string;
    readonly cause?: unknown;
}>;
/** Snapshot of the published generation and lifecycle state. */
export type ProjectionViteStatus = Readonly<{
    readonly state: "idle" | "starting" | "ready" | "failed" | "closed";
    readonly generation?: string;
    readonly diagnostic?: ProjectionViteDiagnostic;
}>;
/** Explicit inputs supplied to the host entry loader. */
export type ProjectionViteEntryContext = Readonly<{
    readonly mode: ProjectionViteMode;
    readonly previousGeneration?: string;
    readonly signal: AbortSignal;
    /** Vite's native SSR loader when the host supplies one. */
    readonly loadModule?: (url: string) => Promise<Record<string, unknown>>;
}>;
/** Host callbacks for preparing, validating, and observing generations. */
export type ProjectionViteLifecycleOptions = Readonly<{
    readonly entry: (context: ProjectionViteEntryContext) => ProjectionViteCandidate | Promise<ProjectionViteCandidate>;
    readonly validate?: (candidate: ProjectionViteCandidate) => void | Promise<void>;
    readonly onDiagnostic?: (diagnostic: ProjectionViteDiagnostic) => void;
}>;
/**
 * Own explicit Vite implementation generations without rebinding outstanding
 * requests. Publication follows successful preparation and validation only.
 */
export declare function createProjectionViteLifecycle(options: ProjectionViteLifecycleOptions): {
    start: (mode: ProjectionViteMode, loadModule?: ProjectionViteEntryContext["loadModule"]) => Promise<Readonly<{
        readonly state: "idle" | "starting" | "ready" | "failed" | "closed";
        readonly generation?: string;
        readonly diagnostic?: ProjectionViteDiagnostic;
    }>>;
    replace: (mode: ProjectionViteMode, loadModule?: ProjectionViteEntryContext["loadModule"]) => Promise<Readonly<{
        readonly state: "idle" | "starting" | "ready" | "failed" | "closed";
        readonly generation?: string;
        readonly diagnostic?: ProjectionViteDiagnostic;
    }>>;
    status: () => Readonly<{
        readonly state: "idle" | "starting" | "ready" | "failed" | "closed";
        readonly generation?: string;
        readonly diagnostic?: ProjectionViteDiagnostic;
    }>;
    diagnostic: () => Readonly<{
        readonly code: "CANDIDATE_REJECTED" | "CANDIDATE_DISPOSAL_FAILED" | "RETIRED_DISPOSAL_FAILED" | "STALE_CLIENT" | "NOT_READY" | "CLOSED";
        readonly message: string;
        readonly generation?: string;
        readonly cause?: unknown;
    }> | undefined;
    dispatch(request: Request): Promise<Response>;
    dispose(): Promise<void>;
};
