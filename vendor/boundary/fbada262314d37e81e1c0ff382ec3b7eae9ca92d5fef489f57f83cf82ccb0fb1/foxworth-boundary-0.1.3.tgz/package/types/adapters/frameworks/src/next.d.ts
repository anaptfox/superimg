import type { AnyInteractionDefinition, DefinitionArity, DefinitionInput, DefinitionOutput, InteractionHandle, ProjectedInteractionHandle, ProjectionBinding } from "@foxworth/boundary";
import type { HttpHandler } from "../../http/src/http.js";
type AnyProjectedInteractionHandle = ProjectedInteractionHandle<any, any, any>;
type DefinitionOf<Handle> = Handle extends ProjectedInteractionHandle<InteractionHandle<infer Definition>, any> ? Definition : AnyInteractionDefinition;
type HandleInput<Handle extends AnyProjectedInteractionHandle> = DefinitionInput<DefinitionOf<Handle>>;
type HandleOutput<Handle extends AnyProjectedInteractionHandle> = DefinitionOutput<DefinitionOf<Handle>>;
type HandleArity<Handle extends AnyProjectedInteractionHandle> = DefinitionArity<DefinitionOf<Handle>>;
type HandleArguments<Handle extends AnyProjectedInteractionHandle> = HandleArity<Handle> extends 0 ? readonly [] : readonly [input: HandleInput<Handle>];
type DirectHandle<Handle extends AnyProjectedInteractionHandle> = Handle & ("direct" extends Handle["modes"][number] ? unknown : never);
type RequestHandle<Handle extends AnyProjectedInteractionHandle> = Handle & ("request" extends Handle["modes"][number] ? unknown : never);
type RequestOutput<Handle extends AnyProjectedInteractionHandle> = Handle extends ProjectedInteractionHandle<any, any, infer Output> ? Output : never;
/**
 * The exact completed direct invocation that a host may use to refresh its own
 * Next cache entries. Tags, paths, visibility scopes, and error reporting stay
 * host-owned: an interaction footprint alone is not permission to share a cache.
 */
export type NextActionCompletion<Context> = Readonly<{
    context: Context;
    interactionId: string;
    bindingDigest: string;
    installationId: string;
}>;
export type NextServerCallerOptions<Handles extends Readonly<Record<string, ProjectedInteractionHandle<any, any, any>>>, Context> = Readonly<{
    /** A single already-bound, pinned host Binding; this helper never installs one. */
    binding: ProjectionBinding<Handles, Context>;
    /** Derive authenticated request/action context for every invocation. */
    context: () => Context | Promise<Context>;
    /**
     * Runs only after a direct action completed. Typical hosts call Next's
     * `updateTag` or `revalidateTag` here with tenant- and visibility-scoped tags.
     */
    afterAction?: (completion: NextActionCompletion<Context>) => void | Promise<void>;
    /** Observes cache-refresh failures without changing an already-completed action. */
    onCacheError?: (error: unknown, completion: NextActionCompletion<Context>) => void;
}>;
export type NextServerCaller<Handles extends Readonly<Record<string, ProjectedInteractionHandle<any, any, any>>>> = Readonly<{
    /** Direct server read; it invokes the pinned Binding without a self-HTTP call. */
    read: Readonly<{
        call<Handle extends Handles[keyof Handles]>(handle: DirectHandle<Handle>, ...args: HandleArguments<Handle>): Promise<HandleOutput<Handle>>;
    }>;
    /**
     * Direct mutation and proposal entry points for a Server Action or form.
     * Neither path retries an invocation. Only a completed direct call triggers
     * the optional host cache callback.
     */
    action: Readonly<{
        call<Handle extends Handles[keyof Handles]>(handle: DirectHandle<Handle>, ...args: HandleArguments<Handle>): Promise<HandleOutput<Handle>>;
        request<Handle extends Handles[keyof Handles]>(handle: RequestHandle<Handle>, ...args: HandleArguments<Handle>): Promise<RequestOutput<Handle>>;
    }>;
}>;
/**
 * Adapt one existing Binding to Next server reads and Server Actions.
 *
 * The application owns installation lifetime and authentication. `context()`
 * deliberately runs for each call, so this helper cannot turn a selected
 * projection, module singleton, or prior request into authority.
 */
export declare function createNextServerCaller<Handles extends Readonly<Record<string, ProjectedInteractionHandle<any, any, any>>>, Context>(options: NextServerCallerOptions<Handles, Context>): NextServerCaller<Handles>;
export type ProjectionHandlers = Readonly<{
    GET: HttpHandler;
    POST: HttpHandler;
    PUT: HttpHandler;
    PATCH: HttpHandler;
    DELETE: HttpHandler;
    HEAD: HttpHandler;
    OPTIONS: HttpHandler;
}>;
/**
 * Bind one explicit HTTP projection to Next App Router method exports.
 * Route placement and segment config stay in the caller's `route.ts` file.
 */
export declare function createProjectionHandlers(handler: HttpHandler): ProjectionHandlers;
export {};
