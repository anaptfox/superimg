import type { InteractionMode, ProjectionBinding } from "@foxworth/boundary";
import { type AnyRouter } from "@trpc/server";
import type { HttpHandler } from "../../http/src/http.js";
import { type AnyProjectedInteractionHandle } from "../../../core/handoff/src/adapter/resolution.js";
export type TrpcProcedureKind = "query" | "mutation";
export type TrpcProcedure<Handle extends AnyProjectedInteractionHandle = AnyProjectedInteractionHandle> = Readonly<{
    handle: Handle;
    mode: InteractionMode;
    name: string;
    kind: TrpcProcedureKind;
}>;
export declare function procedure<Handle extends AnyProjectedInteractionHandle>(handleValue: Handle, options: Readonly<{
    name?: string;
    kind: TrpcProcedureKind;
    mode?: InteractionMode;
}>): TrpcProcedure<Handle>;
export type CreateTrpcRouterOptions<ProjectionContext, TrpcContext extends object> = Readonly<{
    binding: ProjectionBinding<any, ProjectionContext>;
    context(context: TrpcContext): ProjectionContext | Promise<ProjectionContext>;
    procedures: readonly TrpcProcedure[];
}>;
/** Create a router containing only explicitly declared Binding procedures. */
export declare function createTrpcRouter<ProjectionContext, TrpcContext extends object>(options: CreateTrpcRouterOptions<ProjectionContext, TrpcContext>): Promise<AnyRouter>;
export type CreateTrpcHandlerOptions<ProjectionContext> = Readonly<{
    binding: ProjectionBinding<any, ProjectionContext>;
    context(request: Request): ProjectionContext | Promise<ProjectionContext>;
    procedures: readonly TrpcProcedure[];
    endpoint?: string;
}>;
export declare function createTrpcHandler<ProjectionContext>(options: CreateTrpcHandlerOptions<ProjectionContext>): HttpHandler;
