import type { Connect, Plugin } from "vite";
import type { HttpHandler } from "../../http/src/http.js";
import { type ProjectionViteLifecycleOptions } from "./viteLifecycle.js";
export { createProjectionViteLifecycle } from "./viteLifecycle.js";
export type { ProjectionViteCandidate, ProjectionViteDiagnostic, ProjectionViteEntryContext, ProjectionViteLifecycleOptions, ProjectionViteMode, ProjectionViteStatus, } from "./viteLifecycle.js";
export type ProjectionViteOptions = {
    /** The HTTP projection created by `createHttpHandler`. */
    readonly handler: HttpHandler;
    /**
     * Connect mount paths owned by this plugin. A path may be an exact route or
     * a route prefix. Boundary never discovers these from the application.
     */
    readonly mount: string | readonly string[];
    /** Handle framework/transport failures. Domain failures belong to handler. */
    readonly onError?: (error: unknown, request: Request) => Response | undefined | Promise<Response | undefined>;
};
export type ProjectionViteLifecyclePluginOptions = ProjectionViteLifecycleOptions & Pick<ProjectionViteOptions, "mount" | "onError"> & Readonly<{
    /** Explicit entry files Vite should include in its development watcher. */
    readonly watch?: string | readonly string[];
}>;
/** Connect middleware around one explicit Projection HTTP handler. */
export declare function createProjectionMiddleware(handler: HttpHandler, options?: Pick<ProjectionViteOptions, "onError">): Connect.NextHandleFunction;
/** Mount one injected Projection HTTP handler in Vite dev and preview. */
export declare function mountProjection(options: ProjectionViteOptions): Plugin;
/** Mounts an explicit, generation-owned entry with Vite dev/preview lifecycle hooks. */
export declare function mountProjectionLifecycle(options: ProjectionViteLifecyclePluginOptions): Plugin;
