import * as Automerge from "@automerge/automerge";
import { type JsonValue } from "@foxworth/boundary/program";
/** @experimental Boundary snapshot adapter; its API may change incompatibly. */
export interface AutomergeCapture<T> {
    readonly engine: "automerge";
    readonly heads: readonly string[];
    encode(): Uint8Array;
    read<Result extends JsonValue>(project: (doc: Automerge.Doc<T>) => Result | PromiseLike<Result>): Promise<Result>;
}
/**
 * Capture one Automerge version for isolated projections that return portable JSON.
 * @experimental For evaluation; no production support commitment. The API may change incompatibly.
 */
export declare function captureAutomerge<T>(doc: Automerge.Doc<T>): AutomergeCapture<T>;
