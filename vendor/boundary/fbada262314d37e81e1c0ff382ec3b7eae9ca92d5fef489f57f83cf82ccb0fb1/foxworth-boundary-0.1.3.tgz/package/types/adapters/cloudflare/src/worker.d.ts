import type { HttpHandler } from "@foxworth/boundary/http";
export type WorkerFetch<Environment = unknown, Execution = unknown> = (request: Request, environment: Environment, execution: Execution) => Response | Promise<Response>;
/** The platform values available while processing one matched Worker request. */
export type ProjectionWorkerInvocation<Environment = unknown, Execution = unknown> = Readonly<{
    request: Request;
    environment: Environment;
    execution: Execution;
}>;
/**
 * Creates the already-checked Projection HTTP handler for one Worker request.
 *
 * Keep reusable bindings outside this factory. The application derives
 * invocation-scoped authentication and host context here; environment or a
 * service binding alone is not end-user authority.
 */
export type ProjectionWorkerHandlerFactory<Environment = unknown, Execution = unknown> = (invocation: ProjectionWorkerInvocation<Environment, Execution>) => HttpHandler | Promise<HttpHandler>;
export type ProjectionWorkerOptions<Environment = unknown, Execution = unknown> = {
    /** Optional framework mount path(s). Omit to send every request to Projection. */
    readonly mount?: string | readonly string[];
    /** Called for requests outside `mount`; defaults to a plain 404. */
    readonly fallback?: WorkerFetch<Environment, Execution>;
};
/** Adapt one explicit Projection HTTP handler to a Workers module `fetch`. */
export declare function createProjectionWorkerFetch<Environment = unknown, Execution = unknown>(handler: HttpHandler, options?: ProjectionWorkerOptions<Environment, Execution>): WorkerFetch<Environment, Execution>;
/**
 * Adapt a native Worker invocation factory to module `fetch`.
 *
 * Only matched requests create a Projection handler. Fallback routing keeps
 * the application's request, environment, and execution context unchanged.
 */
export declare function createProjectionWorkerFetchWithContext<Environment = unknown, Execution = unknown>(createHandler: ProjectionWorkerHandlerFactory<Environment, Execution>, options?: ProjectionWorkerOptions<Environment, Execution>): WorkerFetch<Environment, Execution>;
