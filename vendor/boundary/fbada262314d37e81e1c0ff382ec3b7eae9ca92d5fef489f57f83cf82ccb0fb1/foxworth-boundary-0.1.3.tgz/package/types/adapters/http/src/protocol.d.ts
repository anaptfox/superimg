import type { ProjectionBinding, ProjectionBindingManifest } from "@foxworth/boundary";
import type { HttpHandler } from "./http.js";
export type ProgramHandshake = ProjectionBindingManifest;
import type { ClientTransport } from "../../../callers/client/src/transport.js";
export type { ClientTransport, ClientInvokeFraming } from "../../../callers/client/src/transport.js";
export type CreateProtocolHandlerOptions<Context> = Readonly<{
    binding: ProjectionBinding<any, Context>;
    context(request: Request): Context | Promise<Context>;
    path: string;
}>;
/** Opt-in version 1 Handoff protocol for one pinned live Binding. */
export declare function createProtocolHandler<Context>(options: CreateProtocolHandlerOptions<Context>): HttpHandler;
export type FetchTransportOptions = Readonly<{
    baseUrl: string;
    fetch?: typeof globalThis.fetch;
    headers?: HeadersInit;
}>;
/** Fetch transport for the exact two-endpoint version 1 protocol. */
export declare function fetchTransport(options: FetchTransportOptions): ClientTransport;
