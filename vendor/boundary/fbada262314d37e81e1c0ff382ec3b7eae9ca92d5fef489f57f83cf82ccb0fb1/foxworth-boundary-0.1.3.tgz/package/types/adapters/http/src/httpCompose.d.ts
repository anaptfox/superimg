import type { ProjectionBinding } from "@foxworth/boundary";
import { type HttpHandler, type HttpRoute } from "./http.js";
export type CreateCompositeHttpHandlerOptions<Context> = Readonly<{
    binding: ProjectionBinding<any, Context>;
    context(request: Request): Context | Promise<Context>;
    routes: readonly HttpRoute[];
    title: string;
    version: string;
    /** Host-owned mount for Program inspection and calls. */
    protocolPath: string;
}>;
/** One REST + browser-protocol + OpenAPI door. Applications keep their routes and title. */
export declare function createCompositeHttpHandler<Context>(options: CreateCompositeHttpHandlerOptions<Context>): HttpHandler;
export type HttpMount = Readonly<{
    path: string;
    fetch(request: Request): Response | Promise<Response>;
}>;
/** Dispatch one handler across non-overlapping explicit path prefixes. */
export declare function mountHandlers(mounts: readonly HttpMount[]): {
    handler: HttpHandler;
    paths: readonly string[];
};
