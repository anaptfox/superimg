import { type InvocationObservation } from "@foxworth/boundary/program";
type MaybePromise<T> = T | Promise<T>;
export type ObservationHttpOptions<Context> = Readonly<{
    path: string;
    /** Authenticate on the host. Return a Response to reject the subscription. */
    context(request: Request): MaybePromise<Context | Response>;
    /** The host selects recipients, redacts correlation, and owns delivery. */
    subscribe(context: Context, publish: (event: InvocationObservation) => void, signal: AbortSignal): MaybePromise<() => void>;
}>;
/** Live, bounded SSE delivery. No replay log, authority, or effect execution. */
export declare function createObservationHttpHandler<Context>(options: ObservationHttpOptions<Context>): (request: Request) => Promise<Response | null>;
export {};
