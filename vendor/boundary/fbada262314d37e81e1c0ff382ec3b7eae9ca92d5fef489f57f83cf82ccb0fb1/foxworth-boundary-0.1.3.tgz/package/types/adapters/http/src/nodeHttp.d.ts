import type { IncomingMessage, ServerResponse } from "node:http";
export type NodeHttpIncoming = IncomingMessage & {
    originalUrl?: string;
};
/**
 * Build a WinterCG Request from a Node IncomingMessage.
 * When `canonicalPathname` is set, it replaces the URL pathname (query kept).
 */
export declare function toFetchRequest(req: NodeHttpIncoming, options?: {
    base?: string;
    canonicalPathname?: string;
    origin?: string;
}): Request;
/** Stream a Fetch Response onto a Node ServerResponse. */
export declare function sendFetchResponse(res: ServerResponse, response: Response, method?: string): Promise<void>;
