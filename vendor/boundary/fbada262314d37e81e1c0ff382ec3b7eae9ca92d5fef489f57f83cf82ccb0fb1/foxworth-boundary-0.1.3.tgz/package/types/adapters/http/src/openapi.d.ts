import type { Projection, ProjectionBinding } from "@foxworth/boundary";
import type { JsonObject } from "@foxworth/boundary/program";
import type { HttpRoute } from "./http.js";
type OpenApiCommon = Readonly<{
    routes: readonly HttpRoute[];
    title: string;
    version: string;
}>;
export type OpenApiOptions<Context = unknown> = OpenApiCommon & (Readonly<{
    projection: Projection<any>;
    binding?: never;
}> | Readonly<{
    binding: ProjectionBinding<any, Context>;
    projection?: never;
}>);
/** Describe exactly the routes supplied by the application. */
export declare function openapi<Context>(options: OpenApiOptions<Context>): Promise<JsonObject>;
export {};
