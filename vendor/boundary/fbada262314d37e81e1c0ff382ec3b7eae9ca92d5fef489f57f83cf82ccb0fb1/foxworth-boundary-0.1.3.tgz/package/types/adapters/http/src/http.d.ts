import type { InteractionMode, ProjectedInteractionHandle, ProjectionBinding } from "@foxworth/boundary";
import { type InteractionHasInput, type InteractionInput } from "../../../core/handoff/src/adapter/remote.js";
import { type AnyProjectedInteractionHandle } from "../../../core/handoff/src/adapter/resolution.js";
export type HttpMethod = "GET" | "POST" | "PUT" | "PATCH" | "DELETE";
export type HttpHandler = (request: Request) => Promise<Response>;
export type RouteInputContext = Readonly<{
    request: Request;
    params: Readonly<Record<string, string>>;
    query: Readonly<Record<string, string | readonly string[]>>;
    body(): Promise<unknown>;
}>;
type RouteBaseOptions = Readonly<{
    method: HttpMethod;
    path: string;
    mode?: InteractionMode;
    successStatus?: number;
    headers?: Readonly<Record<string, string>>;
}>;
export type RouteOptions<Handle extends AnyProjectedInteractionHandle> = InteractionHasInput<Handle> extends false ? RouteBaseOptions & Readonly<{
    input?: never;
}> : RouteBaseOptions & Readonly<{
    input?: (context: RouteInputContext) => InteractionInput<Handle> | Promise<InteractionInput<Handle>>;
}>;
export type HttpRoute<Handle extends AnyProjectedInteractionHandle = AnyProjectedInteractionHandle> = Readonly<{
    handle: Handle;
    mode: InteractionMode;
    method: HttpMethod;
    path: string;
    inputMapping: "default" | "custom";
    successStatus?: number;
    headers?: Readonly<Record<string, string>>;
}>;
export declare function route<Handle extends AnyProjectedInteractionHandle>(handleValue: Handle, options: RouteOptions<Handle>): HttpRoute<Handle>;
export type CreateHttpHandlerOptions<Context> = Readonly<{
    binding: ProjectionBinding<any, Context>;
    context(request: Request): Context | Promise<Context>;
    routes: readonly HttpRoute[];
}>;
/** Build a Fetch-native adapter over one exact live Binding. */
export declare function createHttpHandler<Context>(options: CreateHttpHandlerOptions<Context>): HttpHandler;
export type { ProjectedInteractionHandle };
