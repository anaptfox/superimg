import type { HttpHandler } from "@foxworth/boundary/http";
import type { IpcMainInvokeEvent, WebContents, WebFrameMain } from "electron";
import { type ClientTransport } from "@foxworth/boundary/http/protocol";
import { type SerializedFetchRequest, type SerializedFetchResponse } from "./dispatch.js";
export type ElectronIpcInvoke = (channel: string, payload: SerializedFetchRequest) => Promise<SerializedFetchResponse>;
export type ElectronIpcSender = WebContents;
export type ElectronIpcSenderFrame = WebFrameMain;
export type ElectronIpcInvokeEvent = Pick<IpcMainInvokeEvent, "sender" | "senderFrame">;
export type ElectronIpcContextFactory<Context> = (event: ElectronIpcInvokeEvent) => Context | Promise<Context>;
export type ElectronIpcSenderValidator = (event: ElectronIpcInvokeEvent) => boolean | Promise<boolean>;
export type ElectronIpcBridgeOptions<Context> = Readonly<{
    validateSender: ElectronIpcSenderValidator;
    createContext: ElectronIpcContextFactory<Context>;
    ipcHandler: ElectronIpcHandler<Context>;
}> | Readonly<{
    validateSender: ElectronIpcSenderValidator;
    createContext?: never;
    ipcHandler?: never;
}>;
export type ElectronIpcHandler<Context = undefined> = (request: Request, context: Context) => Promise<Response>;
export type ElectronIpcHandle = {
    handle(channel: string, listener: (event: ElectronIpcInvokeEvent, payload: SerializedFetchRequest) => Promise<SerializedFetchResponse>): void;
    removeHandler?(channel: string): void;
};
export declare function ipcFetchChannel(channel: string): string;
/** Main-process IPC door: reconstruct a Request and call the same handler. */
export declare function installElectronIpcBridge<Context = undefined>(ipc: ElectronIpcHandle, handler: HttpHandler, channel: string, options: ElectronIpcBridgeOptions<Context>): () => void;
/** Validate one exact WebContents and main frame pair; URL alone is insufficient. */
export declare function allowElectronSender(expected: Readonly<{
    sender: ElectronIpcSender;
    frame: ElectronIpcSenderFrame;
    url: string;
}>): ElectronIpcSenderValidator;
/**
 * Preload/renderer fetch that posts through `ipcRenderer.invoke`.
 * Relative URLs resolve against the host-owned `baseUrl`.
 */
export declare function createElectronIpcFetch(invoke: ElectronIpcInvoke, options: Readonly<{
    channel: string;
    baseUrl: string;
}>): typeof fetch;
/** Typed projection client transport over the IPC fetch bridge. */
export declare function electronIpcTransport(options: {
    readonly invoke: ElectronIpcInvoke;
    readonly channel: string;
    readonly baseUrl: string;
    readonly headers?: HeadersInit;
}): ClientTransport;
