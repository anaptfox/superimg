import type { HttpHandler } from "@foxworth/boundary/http";
import type { App as ElectronApp, BrowserWindow as ElectronBrowserWindow, BrowserWindowConstructorOptions, IpcMain, Protocol, Session } from "electron";
import { type ElectronIpcBridgeOptions } from "./ipc.js";
type ElectronSessionApi = {
    fromPartition(partition: string): Session;
};
/** Injected from the Electron entry; this package never discovers the app. */
export type ElectronApis = {
    app: ElectronApp;
    BrowserWindow: typeof ElectronBrowserWindow;
    ipcMain?: IpcMain;
    protocol?: Protocol;
    session?: ElectronSessionApi;
};
export type ProjectionElectronReadyContext = {
    readonly baseUrl: string;
    readonly protocolUrl: string;
    readonly window: ElectronBrowserWindow | undefined;
    dispatch(request: Request): Promise<Response>;
};
export type CreateProjectionElectronMainOptions<Context = never> = {
    readonly electron: ElectronApis;
    /** The HTTP projection created by `createHttpHandler`. */
    readonly handler: HttpHandler;
    /**
     * Host-owned localhost TCP port for the HTTP door.
     * `false` skips TCP; the renderer can still use protocol or IPC.
     */
    readonly port: number | false;
    readonly rendererUrl?: string;
    readonly windowOptions?: BrowserWindowConstructorOptions;
    /** When false, start only the projection doors. Default true. */
    readonly openWindow?: boolean;
    /**
     * Host-owned privileged in-process scheme.
     * `false` skips `protocol.handle`.
     */
    readonly scheme: string | false;
    /**
     * Host-owned IPC channel prefix for `channel:fetch`.
     * `false` skips the IPC door.
     */
    readonly ipcChannel: string | false;
    /**
     * Explicit renderer trust and context policy for the IPC door. An omitted
     * policy fails closed; renderer headers are never treated as identity.
     */
    readonly ipc?: ElectronIpcBridgeOptions<Context>;
    /** Session partition for the window and protocol door. */
    readonly partition: string;
    /**
     * Unique window `name` for Electron 44 `windowStatePersistence`.
     * Persistence is on when this is set, unless `persistWindowState` is false.
     */
    readonly windowName?: string;
    readonly persistWindowState?: boolean;
    readonly onReady?: (context: ProjectionElectronReadyContext) => void | Promise<void>;
};
export type ProjectionElectronMain = {
    readonly baseUrl: string;
    readonly protocolUrl: string;
    readonly window: ElectronBrowserWindow | undefined;
    dispatch(request: Request): Promise<Response>;
    /** Stop HTTP, protocol, and IPC doors without owning Electron's lifecycle. */
    close(): Promise<void>;
};
export type PrepareProjectionElectronOptions = {
    readonly scheme: string | false;
};
/**
 * Register the privileged in-process scheme. Must run before `app.ready`.
 * `createProjectionElectronMain` calls this when the app is not yet ready.
 */
export declare function prepareProjectionElectron(electron: Pick<ElectronApis, "app" | "protocol">, options: PrepareProjectionElectronOptions): void;
/**
 * Run one explicit Projection HTTP handler in Electron's main process.
 * HTTP, a privileged scheme, and IPC are doors to the same handler.
 * Renderer placement and window lifecycle remain application decisions.
 */
export declare function createProjectionElectronMain<Context = never>(options: CreateProjectionElectronMainOptions<Context>): Promise<ProjectionElectronMain>;
export {};
