import type { HttpHandler } from "@foxworth/boundary/http";
export type SerializedFetchRequest = {
    readonly url: string;
    readonly method: string;
    readonly headers: readonly [string, string][];
    readonly body: string | null;
};
export type SerializedFetchResponse = {
    readonly status: number;
    readonly statusText: string;
    readonly headers: readonly [string, string][];
    readonly body: string | null;
};
/** Resolve a renderer fetch input against the in-process projection origin. */
export declare function projectionRequest(input: RequestInfo | URL, origin: string, init?: RequestInit): Request;
export declare function serializeFetchRequest(request: Request): Promise<SerializedFetchRequest>;
export declare function deserializeFetchRequest(wire: SerializedFetchRequest): Request;
export declare function serializeFetchResponse(response: Response): Promise<SerializedFetchResponse>;
export declare function deserializeFetchResponse(wire: SerializedFetchResponse): Response;
export declare function internalError(): Response;
/** Run one injected handler and never leak thrown values. */
export declare function dispatchHandler(handler: HttpHandler, request: Request): Promise<Response>;
