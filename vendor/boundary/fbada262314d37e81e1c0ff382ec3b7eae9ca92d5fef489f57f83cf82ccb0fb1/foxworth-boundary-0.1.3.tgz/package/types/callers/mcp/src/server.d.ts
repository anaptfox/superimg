import type { InteractionMode, ProjectionBinding } from "@foxworth/boundary";
import { McpServer, type CreateMcpHandlerOptions, type McpHttpHandler, type ServerContext, type ScopeChallengeHandler, type McpServerOptions } from "@modelcontextprotocol/server";
import { type AnyProjectedInteractionHandle } from "@foxworth/boundary/handoff/adapter";
export type McpTool<Value extends AnyProjectedInteractionHandle = AnyProjectedInteractionHandle> = Readonly<{
    handle: Value;
    mode: InteractionMode;
    name: string;
    title?: string;
    description?: string;
    /** Host-owned scope preflight; it never widens the Binding. */
    scopeChallenge?: ScopeChallengeHandler;
}>;
export declare function tool<Value extends AnyProjectedInteractionHandle>(handleValue: Value, options?: Readonly<{
    mode?: Value["modes"][number];
    name?: string;
    title?: string;
    description?: string;
    scopeChallenge?: ScopeChallengeHandler;
}>): McpTool<Value>;
export type McpContextRequest = Readonly<{
    tool: McpTool;
    extra: ServerContext;
    request?: Request;
}>;
export type CreateMcpServerOptions<Context> = Readonly<{
    binding: ProjectionBinding<any, Context>;
    context(request: McpContextRequest): Context | Promise<Context>;
    /**
     * How the Binding's interactions are presented: names and modes. This is a
     * fixed list, never a per-request predicate. Omitting a projected interaction
     * here hides nothing the Binding still carries; narrow the Projection when
     * a model must not see an interaction.
     */
    tools: readonly McpTool[];
    /** Host-owned MCP server identity. */
    name: string;
    version: string;
    /** Bound server-side input validation work without changing authority. */
    maxToolInputElements?: McpServerOptions["maxToolInputElements"];
}>;
/** Create a library-only MCP server from explicit projected-handle tools. */
export declare function createMcpServer<Context>(options: CreateMcpServerOptions<Context>): Promise<McpServer>;
export type BoundaryMcpHttpOptions = Omit<CreateMcpHandlerOptions, "legacy">;
export declare function createMcpHandler<Context>(options: CreateMcpServerOptions<Context>, handlerOptions?: BoundaryMcpHttpOptions): McpHttpHandler;
export type ToolSource = Readonly<{
    readonly handles: Readonly<Record<string, AnyProjectedInteractionHandle>>;
}>;
/** One MCP tool per projected handle, using each handle's default mode. */
export declare function toolsFor(projection: ToolSource): McpTool[];
