import type { ProjectionBinding } from "@foxworth/boundary";
import { type HttpHandler } from "@foxworth/boundary/http";
import { type CreateMcpServerOptions, type McpTool, type BoundaryMcpHttpOptions } from "./server.js";
export type ServeDoor<Context = unknown> = Readonly<{
    binding: ProjectionBinding<any, Context>;
    context(request: Request): Context | Promise<Context>;
    path: string;
}>;
export type ServeHostMcp<Context = unknown> = Readonly<{
    path: string;
    name: string;
    version: string;
    binding: ProjectionBinding<any, Context>;
    context: CreateMcpServerOptions<Context>["context"];
    tools: readonly McpTool[];
    handlerOptions?: BoundaryMcpHttpOptions;
    maxToolInputElements?: CreateMcpServerOptions<Context>["maxToolInputElements"];
}>;
export type ServeHostOptions = Readonly<{
    doors: readonly ServeDoor<any>[];
    mcp?: ServeHostMcp<any>;
}>;
export type ServeHostResult = Readonly<{
    handler: HttpHandler;
    paths: readonly string[];
    dispose(): Promise<void>;
}>;
/** Compose protocol doors and an optional MCP mount into one handler. */
export declare function serveHost(options: ServeHostOptions): ServeHostResult;
