import type { AnyInteractionDefinition, DefinitionArity, DefinitionInput, DefinitionOutput, InteractionHandle, ProjectedInteractionHandle } from "@foxworth/boundary";
import type { ProjectionClient } from "@foxworth/boundary/client";
import { type AuthorizedStatusReader, type InvocationStateSnapshot, type ProposalStatusSnapshot } from "@foxworth/boundary/client";
type AnyProjectedInteractionHandle = ProjectedInteractionHandle<any, any, any>;
type DefinitionOf<Handle> = Handle extends ProjectedInteractionHandle<InteractionHandle<infer Definition>, any> ? Definition : AnyInteractionDefinition;
type InteractionArguments<Handle extends AnyProjectedInteractionHandle> = DefinitionArity<DefinitionOf<Handle>> extends 0 ? readonly [] : readonly [input: DefinitionInput<DefinitionOf<Handle>>];
type InteractionOutput<Handle extends AnyProjectedInteractionHandle, Mode extends "direct" | "request"> = Mode extends "direct" ? DefinitionOutput<DefinitionOf<Handle>> : Handle extends ProjectedInteractionHandle<any, any, infer RequestOutput> ? RequestOutput : never;
type HandleForMode<Handle extends AnyProjectedInteractionHandle, Mode extends "direct" | "request"> = Handle & (Mode extends Handle["modes"][number] ? unknown : never);
/**
 * React adaptation of the framework-neutral explicit invocation store. It is
 * inert on mount; the application calls `invoke` from its own event handler.
 */
export declare function useInvocationState<Handle extends AnyProjectedInteractionHandle, Mode extends "direct" | "request">(client: ProjectionClient, handle: HandleForMode<Handle, Mode>, mode: Mode): InvocationStateSnapshot<Handle, Mode> & Readonly<{
    invoke: (...args: InteractionArguments<Handle>) => Promise<InteractionOutput<Handle, Mode>>;
    markStale(): void;
    disconnect(): void;
}>;
/**
 * Request-mode interaction with a caller-supplied, public-only status reader.
 * The hook does not create a Control client, expose records, or observe on its
 * own; call `observe` explicitly for a returned proposal.
 */
export declare function useProposalInteraction<Handle extends AnyProjectedInteractionHandle, Status>(client: ProjectionClient, handle: HandleForMode<Handle, "request">, observeStatus: AuthorizedStatusReader<InteractionOutput<Handle, "request">, Status>): Readonly<{
    invocation: InvocationStateSnapshot<Handle, "request">;
    status: ProposalStatusSnapshot<InteractionOutput<Handle, "request">, Status>;
    request: (...args: InteractionArguments<Handle>) => Promise<InteractionOutput<Handle, "request">>;
    observe(proposal: InteractionOutput<Handle, "request">): Promise<Status>;
    markStale(): void;
    disconnect(): void;
}>;
export {};
