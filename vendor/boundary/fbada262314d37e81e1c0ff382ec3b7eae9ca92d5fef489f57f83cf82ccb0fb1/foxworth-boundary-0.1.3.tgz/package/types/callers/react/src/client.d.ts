import type { ProjectionClient } from "@foxworth/boundary/client";
import { type ComponentType, type ReactNode } from "react";
export type ProjectionProviderProps<Value extends ProjectionClient> = {
    readonly client: Value;
    readonly children?: ReactNode;
};
export type ProjectionViewProps<Value extends ProjectionClient> = {
    readonly client: Value;
};
export type ProjectionView<Value extends ProjectionClient, Props extends object = object> = ComponentType<Props & ProjectionViewProps<Value>>;
export type BoundProjectionView<Props extends object = object> = ComponentType<Props>;
export type ProjectionContext<Value extends ProjectionClient> = Readonly<{
    Provider: ComponentType<ProjectionProviderProps<Value>>;
    useClient(): Value;
    /** Declare a view explicitly and inject only the client it needs. */
    view<Props extends object>(component: ProjectionView<Value, Props>): BoundProjectionView<Props>;
}>;
/**
 * Create one typed React boundary for a browser client.
 *
 * It never inspects the program, chooses a view, or carries server authority.
 */
export declare function createProjectionContext<Value extends ProjectionClient = ProjectionClient>(): ProjectionContext<Value>;
