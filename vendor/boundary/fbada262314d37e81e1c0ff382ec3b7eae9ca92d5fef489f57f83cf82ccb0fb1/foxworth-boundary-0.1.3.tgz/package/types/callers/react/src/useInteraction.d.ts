import type { AnyInteractionDefinition, DefinitionArity, DefinitionInput, DefinitionOutput, InteractionHandle, ProjectedInteractionHandle } from "@foxworth/boundary";
import type { ProjectionClient } from "@foxworth/boundary/client";
import { type InteractionReadError } from "@foxworth/boundary/client/cache";
type AnyProjectedInteractionHandle = ProjectedInteractionHandle<any, any>;
type DefinitionOf<Handle> = Handle extends ProjectedInteractionHandle<InteractionHandle<infer Definition>, any> ? Definition : AnyInteractionDefinition;
type HandleInput<Handle extends AnyProjectedInteractionHandle> = DefinitionInput<DefinitionOf<Handle>>;
type HandleOutput<Handle extends AnyProjectedInteractionHandle> = DefinitionOutput<DefinitionOf<Handle>>;
type HandleArity<Handle extends AnyProjectedInteractionHandle> = DefinitionArity<DefinitionOf<Handle>>;
type HandleArguments<Handle extends AnyProjectedInteractionHandle> = HandleArity<Handle> extends 0 ? readonly [] : readonly [input: HandleInput<Handle>];
type DirectHandle<Handle extends AnyProjectedInteractionHandle> = Handle & ("direct" extends Handle["modes"][number] ? unknown : never);
export type UseInteractionError<Value extends AnyProjectedInteractionHandle> = InteractionReadError<Value>;
export type UseInteractionResult<Value extends AnyProjectedInteractionHandle> = Readonly<{
    data: HandleOutput<Value> | undefined;
    error: UseInteractionError<Value> | undefined;
    isPending: boolean;
    refetch: (...args: HandleArguments<Value>) => Promise<HandleOutput<Value>>;
    call: (...args: HandleArguments<Value>) => Promise<HandleOutput<Value>>;
}>;
export type InteractionErrorKind = "domain" | "protocol" | "execution" | "unknown";
export type DescribedInteractionError = Readonly<{
    kind: InteractionErrorKind;
    message: string;
}>;
/** Distinguish declared domain errors from sanitized protocol failures. */
export declare function describeInteractionError(error: unknown): DescribedInteractionError;
export declare function useInteraction<Value extends AnyProjectedInteractionHandle>(client: ProjectionClient, handle: DirectHandle<Value>, ...args: [] | HandleArguments<Value>): UseInteractionResult<Value>;
export {};
