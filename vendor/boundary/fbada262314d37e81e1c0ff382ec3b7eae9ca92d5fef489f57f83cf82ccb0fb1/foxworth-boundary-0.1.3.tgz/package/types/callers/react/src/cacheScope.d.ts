import { type ReactNode } from "react";
import type { InteractionCacheScope } from "@foxworth/boundary/client/cache";
export type InteractionCacheProviderProps = Readonly<{
    scope: InteractionCacheScope;
    children?: ReactNode;
}>;
/** Explicitly share completed-change invalidation across descendant clients. */
export declare function InteractionCacheProvider({ scope, children, }: InteractionCacheProviderProps): import("react").FunctionComponentElement<import("react").ProviderProps<Readonly<{
    readonly kind: "boundary-interaction-cache-scope";
}> | undefined>>;
/** The nearest explicit scope, or undefined for the default client-local cache. */
export declare function useInteractionCacheScope(): InteractionCacheScope | undefined;
