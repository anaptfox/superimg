import type { ProjectedInteractionHandle } from "@foxworth/boundary";
import type { ProjectionClient } from "./client.js";
import { type RemoteInteractionError } from "../../../core/handoff/src/adapter/errors.js";
import type { InteractionInput, InteractionOutput } from "../../../core/handoff/src/adapter/remote.js";
import { type AnyProjectedInteractionHandle } from "../../../core/handoff/src/adapter/resolution.js";
export type InteractionFootprint = Readonly<{
    reads: readonly string[];
    changes: readonly string[];
}>;
export type FootprintSource = Readonly<{
    expectedProgram: Readonly<{
        interactions: readonly Readonly<{
            contract: Readonly<{
                id: string;
                reads: readonly string[];
                changes: readonly string[];
            }>;
        }>[];
    }>;
}>;
export type InteractionCacheScope = Readonly<{
    /** Opaque identity; create scopes with createInteractionCacheScope(). */
    readonly kind: "boundary-interaction-cache-scope";
}>;
type DirectHandle<Handle extends AnyProjectedInteractionHandle> = Handle & ("direct" extends Handle["modes"][number] ? unknown : never);
type WatchInteractionArguments<Handle extends AnyProjectedInteractionHandle> = Handle["inputArity"] extends 0 ? readonly [options?: WatchInteractionOptions] : readonly [input: InteractionInput<Handle>, options?: WatchInteractionOptions];
export type WatchInteractionOptions = Readonly<{
    /** Share invalidation only with readers registered in this explicit scope. */
    scope?: InteractionCacheScope;
}>;
export type InteractionReadError<Handle extends AnyProjectedInteractionHandle> = RemoteInteractionError<Handle> | Error;
export type InteractionReadSnapshot<Handle extends AnyProjectedInteractionHandle> = Readonly<{
    data: InteractionOutput<Handle> | undefined;
    error: InteractionReadError<Handle> | undefined;
    isPending: boolean;
}>;
/** A framework-neutral, lifecycle-owned read of one direct projected interaction. */
export type InteractionRead<Handle extends AnyProjectedInteractionHandle> = Readonly<{
    getSnapshot(): InteractionReadSnapshot<Handle>;
    subscribe(listener: () => void): () => void;
    refresh(): Promise<InteractionOutput<Handle>>;
    dispose(): void;
}>;
export declare function createInteractionCacheScope(): InteractionCacheScope;
/** Index `reads` / `changes` from the Binding's pinned expected Program. */
export declare function indexInteractionFootprints(source: FootprintSource): ReadonlyMap<string, InteractionFootprint>;
/** A completed change invalidates a mounted read when their footprints share a resource. */
export declare function readInvalidatedBy(footprints: ReadonlyMap<string, InteractionFootprint>, readInteractionId: string, changeInteractionId: string): boolean;
export declare function isReadInteraction(footprints: ReadonlyMap<string, InteractionFootprint>, interactionId: string): boolean;
export declare function footprintsFor(client: ProjectionClient): Promise<ReadonlyMap<string, InteractionFootprint>>;
/** The footprint index, when the client's handshake has already resolved. */
export declare function peekFootprints(client: ProjectionClient): ReadonlyMap<string, InteractionFootprint> | undefined;
export declare function mountRead(client: ProjectionClient, interactionId: string, refresh: () => Promise<void>, scope?: InteractionCacheScope): () => void;
/**
 * Read one direct interaction as a small external store. It never invokes a
 * change: the pinned Binding and declared footprint are checked before every
 * transport call. Invalidation is deliberately scoped to mounted readers.
 */
export declare function watchInteraction<Handle extends AnyProjectedInteractionHandle>(client: ProjectionClient, handleValue: DirectHandle<Handle>, ...args: WatchInteractionArguments<Handle>): InteractionRead<Handle>;
/**
 * Refresh every mounted read whose `reads` footprint intersects the change's
 * declared `changes` footprint. Reads are client-local by default. Pass the
 * same explicit scope to share invalidation across clients. Request proposals
 * do not imply completion and therefore do not invalidate reads.
 */
export declare function invalidateReadsForChange(client: ProjectionClient, change: Pick<ProjectedInteractionHandle<any, any>, "interactionId">, scope?: InteractionCacheScope): Promise<void>;
/** Refresh potentially affected reads after a host-published outcome. Never repeats the change. */
export declare function invalidateReadsForObservation(value: unknown, scope: InteractionCacheScope): Promise<void>;
/** Refresh this installation's mounted reads after reconnect; never repeats changes. */
export declare function refreshReadsForClient(client: ProjectionClient, scope: InteractionCacheScope): Promise<void>;
export {};
