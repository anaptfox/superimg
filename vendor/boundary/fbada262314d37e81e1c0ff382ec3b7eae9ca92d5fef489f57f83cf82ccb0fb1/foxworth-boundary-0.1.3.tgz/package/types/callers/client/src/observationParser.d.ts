type ObservationStreamEvent = Readonly<{
    event: string;
    data: string;
}>;
/** Internal SSE framing; reconnect and observation authority belong to the caller. */
export declare function createObservationParser(): {
    feed: (chunk: string) => Generator<ObservationStreamEvent>;
};
export {};
