import type { AnyInteractionDefinition, DefinitionArity, DefinitionInput, DefinitionOutput, InteractionHandle, InteractionMode, ProjectedInteractionHandle, ProjectionBindingManifest } from "@foxworth/boundary";
import { type JsonValue } from "@foxworth/boundary/program";
import type { ClientTransport } from "./transport.js";
import { type AnyProjectedInteractionHandle } from "../../../core/handoff/src/adapter/resolution.js";
type DefinitionOf<Handle> = Handle extends ProjectedInteractionHandle<InteractionHandle<infer Definition>, any> ? Definition : AnyInteractionDefinition;
type HandleInput<Handle extends AnyProjectedInteractionHandle> = DefinitionInput<DefinitionOf<Handle>>;
type HandleOutput<Handle extends AnyProjectedInteractionHandle> = DefinitionOutput<DefinitionOf<Handle>>;
type HandleArity<Handle extends AnyProjectedInteractionHandle> = DefinitionArity<DefinitionOf<Handle>>;
type HandleModes<Handle extends AnyProjectedInteractionHandle> = Handle extends ProjectedInteractionHandle<any, infer Modes, any> ? Modes[number] : never;
type HandleRequestOutput<Handle extends AnyProjectedInteractionHandle> = Handle extends ProjectedInteractionHandle<any, any, infer RequestOutput> ? RequestOutput : JsonValue;
type InvocationArguments<Handle extends AnyProjectedInteractionHandle> = HandleArity<Handle> extends 0 ? readonly [] : readonly [input: HandleInput<Handle>];
export type ProjectionClient = Readonly<{
    inspect(): Promise<ProjectionBindingManifest>;
    call<Handle extends AnyProjectedInteractionHandle>(handle: Handle & ("direct" extends HandleModes<Handle> ? unknown : never), ...args: InvocationArguments<Handle>): Promise<HandleOutput<Handle>>;
    request<Handle extends AnyProjectedInteractionHandle>(handle: Handle & ("request" extends HandleModes<Handle> ? unknown : never), ...args: InvocationArguments<Handle>): Promise<HandleRequestOutput<Handle>>;
    callRaw(interactionId: string, input?: unknown): Promise<JsonValue>;
    requestRaw(interactionId: string, input?: unknown): Promise<JsonValue>;
}>;
/** Build a client pinned to the first exact version 1 Binding handshake. */
export declare function createProjectionClient(transport: ClientTransport): ProjectionClient;
export type HandlesFromBinding = Readonly<Record<string, ProjectedInteractionHandle<InteractionHandle, readonly InteractionMode[]>>>;
/**
 * Hydrate projected handles from a Binding `inspect()` handshake.
 * The browser never compiles interactions to call.
 */
export declare function handlesFromBinding(client: ProjectionClient): Promise<HandlesFromBinding>;
/**
 * Validate generated, digest-pinned references against the remote Binding.
 * The reference value carries its type; callers cannot select a type argument.
 */
export declare function pinProjectionReferences<const References extends Readonly<Record<string, AnyProjectedInteractionHandle>>>(client: ProjectionClient, references: References): Promise<References>;
export type { ClientTransport } from "./transport.js";
export { createInvocationState, createProposalInteraction, type AuthorizedStatusReader, type InteractionPhase, type InvocationState, type InvocationStateOptions, type InvocationStateSnapshot, type ProposalInteraction, type ProposalStatusSnapshot, } from "./interaction.js";
