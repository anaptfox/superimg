import type { ProjectionClient } from "./client.js";
import { type InteractionCacheScope } from "./cache.js";
export type ObservationSubscription = Readonly<{
    /** Resolves after subscription and authoritative read refresh. */
    ready: Promise<void>;
    readonly state: "connecting" | "connected" | "disconnected" | "disposed";
    disconnect(): void;
    /** Explicitly reconnects and refreshes reads to cover any delivery gap. */
    reconnect(): Promise<void>;
    dispose(): void;
}>;
export type ObservationClientOptions = Readonly<{
    url: string;
    scope: InteractionCacheScope;
    fetch?: typeof fetch;
    headers?: HeadersInit;
    credentials?: RequestCredentials;
    onError?(error: Error): void;
}>;
/** Subscribe to host-selected observations. Never invokes or retries a change. */
export declare function subscribeToObservations(client: ProjectionClient, options: ObservationClientOptions): ObservationSubscription;
