import type { AnyInteractionDefinition, DefinitionArity, DefinitionInput, DefinitionOutput, InteractionHandle, ProjectedInteractionHandle } from "@foxworth/boundary";
import type { ProjectionClient } from "./client.js";
import { type RemoteInteractionError } from "../../../core/handoff/src/adapter/errors.js";
import { type InteractionCacheScope } from "./cache.js";
import { type AnyProjectedInteractionHandle } from "../../../core/handoff/src/adapter/resolution.js";
type DefinitionOf<Handle> = Handle extends ProjectedInteractionHandle<InteractionHandle<infer Definition>, any> ? Definition : AnyInteractionDefinition;
type HandleInput<Handle extends AnyProjectedInteractionHandle> = DefinitionInput<DefinitionOf<Handle>>;
type HandleOutput<Handle extends AnyProjectedInteractionHandle> = DefinitionOutput<DefinitionOf<Handle>>;
type HandleArity<Handle extends AnyProjectedInteractionHandle> = DefinitionArity<DefinitionOf<Handle>>;
type InteractionArguments<Handle extends AnyProjectedInteractionHandle> = HandleArity<Handle> extends 0 ? readonly [] : readonly [input: HandleInput<Handle>];
type HandleForMode<Handle extends AnyProjectedInteractionHandle, Mode extends "direct" | "request"> = Handle & (Mode extends Handle["modes"][number] ? unknown : never);
type InteractionOutput<Handle extends AnyProjectedInteractionHandle, Mode extends "direct" | "request"> = Mode extends "direct" ? HandleOutput<Handle> : Handle extends ProjectedInteractionHandle<any, any, infer RequestOutput> ? RequestOutput : never;
export type InteractionPhase = "idle" | "pending" | "succeeded" | "failed" | "uncertain" | "stale" | "disconnected" | "disposed";
/** Client-local state; it is not an authoritative host lifecycle record. */
export type InvocationStateSnapshot<Handle extends AnyProjectedInteractionHandle, Mode extends "direct" | "request"> = Readonly<{
    /** Latest attempt evidence; connection changes do not overwrite it. */
    phase: InteractionPhase;
    /** Invocation gating, independent of the outcome of an existing attempt. */
    availability: "available" | "stale" | "disconnected" | "disposed";
    result: InteractionOutput<Handle, Mode> | undefined;
    error: RemoteInteractionError<Handle> | Error | undefined;
    isPending: boolean;
}>;
export type InvocationStateOptions = Readonly<{
    /** Share only completed direct-change invalidation with this explicit scope. */
    scope?: InteractionCacheScope;
}>;
/**
 * An inert, explicit invocation store. It neither invokes on creation nor
 * retries after a lost response. A stale or disconnected store stays blocked;
 * create a fresh store around a newly authorized client to continue.
 */
export type InvocationState<Handle extends AnyProjectedInteractionHandle, Mode extends "direct" | "request"> = Readonly<{
    getSnapshot(): InvocationStateSnapshot<Handle, Mode>;
    subscribe(listener: () => void): () => void;
    invoke(...args: InteractionArguments<Handle>): Promise<InteractionOutput<Handle, Mode>>;
    markStale(): void;
    disconnect(): void;
    dispose(): void;
}>;
export declare function createInvocationState<Handle extends AnyProjectedInteractionHandle, Mode extends "direct" | "request">(client: ProjectionClient, handleValue: HandleForMode<Handle, Mode>, mode: Mode, options?: InvocationStateOptions): InvocationState<Handle, Mode>;
/** A host-issued public-read function, narrowed to observation only. */
export type AuthorizedStatusReader<Proposal, Status> = (proposal: Proposal) => Promise<Status>;
export type ProposalStatusSnapshot<Proposal, Status> = Readonly<{
    proposal: Proposal | undefined;
    status: Status | undefined;
    error: Error | undefined;
    isPending: boolean;
}>;
export type ProposalInteraction<Handle extends AnyProjectedInteractionHandle, Status> = Readonly<{
    invocation: InvocationState<Handle, "request">;
    getStatusSnapshot(): ProposalStatusSnapshot<InteractionOutput<Handle, "request">, Status>;
    subscribeStatus(listener: () => void): () => void;
    observe(proposal: InteractionOutput<Handle, "request">): Promise<Status>;
    markStale(): void;
    disconnect(): void;
    dispose(): void;
}>;
/**
 * Explicit proposal submission plus observation through a host-authorized
 * public reader. Its function type does not establish authorization or
 * redaction; the host must supply an authenticated public-only reader.
 */
export declare function createProposalInteraction<Handle extends AnyProjectedInteractionHandle, Status = unknown>(client: ProjectionClient, handle: HandleForMode<Handle, "request">, observeStatus: AuthorizedStatusReader<InteractionOutput<Handle, "request">, Status>): ProposalInteraction<Handle, Status>;
export {};
