import type { JsonValue } from "@foxworth/boundary/program";
/** Recursively overlay safe JSON Schema annotations. Drops `role` and `control`. */
export declare function overlayInputSchema(contract: JsonValue, annotations: JsonValue | undefined): JsonValue;
export declare function isObjectInputSchema(schema: unknown): schema is Record<string, unknown>;
export declare function stableJson(value: JsonValue): string;
