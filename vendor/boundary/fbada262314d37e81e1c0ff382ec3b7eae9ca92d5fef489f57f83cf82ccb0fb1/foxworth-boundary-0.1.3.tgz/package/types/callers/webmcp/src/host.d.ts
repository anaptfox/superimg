import type { ModelContextPort } from "./types.js";
/** True when the current document exposes the WebMCP imperative API. Never throws. */
export declare function isWebMcpAvailable(port?: ModelContextPort): boolean;
export declare function resolveModelContext(port?: ModelContextPort): ModelContextPort | undefined;
