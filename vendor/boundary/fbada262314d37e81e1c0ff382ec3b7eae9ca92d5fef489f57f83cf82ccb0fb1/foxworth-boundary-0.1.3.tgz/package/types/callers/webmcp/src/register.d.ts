import { type AnyProjectedInteractionHandle } from "@foxworth/boundary/handoff/adapter";
import type { RegisterWebMcpBindingOptions, RegisterWebMcpTransportOptions, WebMcpRegistration, WebMcpTool } from "./types.js";
export declare function webMcpTool<Handle extends AnyProjectedInteractionHandle>(handleValue: Handle, options?: Readonly<{
    mode?: Handle["modes"][number];
    name?: string;
    title?: string;
    description?: string;
    consequentialHint?: boolean;
    debugging?: boolean;
    untrustedContentHint?: boolean;
    exposedTo?: readonly string[];
}>): WebMcpTool<Handle>;
export type WebMcpToolSource = Readonly<{
    readonly handles: Readonly<Record<string, AnyProjectedInteractionHandle>>;
}>;
export type WebMcpToolOptions = NonNullable<Parameters<typeof webMcpTool>[1]>;
/** One WebMCP tool per projected handle. Optional extras are keyed by alias. */
export declare function webMcpTools(projection: WebMcpToolSource, extras?: Readonly<Record<string, WebMcpToolOptions>>): WebMcpTool[];
export declare function registerWebMcpBinding<Context>(options: RegisterWebMcpBindingOptions<Context>): Promise<WebMcpRegistration<Context>>;
/** Present one already-pinned remote Binding on `document.modelContext`. */
export declare function registerWebMcpTransport(options: RegisterWebMcpTransportOptions): Promise<WebMcpRegistration>;
