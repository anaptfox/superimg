/** A Unix domain socket on this machine. Trust is the OS user. */
export type UnixTransport = {
    readonly kind: "unix";
    /** Absolute socket path. */
    readonly path: string;
    /** Base path the two protocol routes hang beneath. */
    readonly base: string;
};
/** An HTTP origin serving the framing in specification section 6. */
export type HttpTransport = {
    readonly kind: "http";
    /** Absolute base URL, with no trailing slash. The two routes hang beneath it. */
    readonly url: string;
};
export type Transport = UnixTransport | HttpTransport;
/** Why a transport address is invalid. */
export type TransportViolation = {
    readonly reason: string;
};
/**
 * Validates one transport's address shape.
 *
 * Returns the violation rather than throwing, so a caller can decide how to
 * report it; {@link validateTransport} throws for callers who want that.
 */
export declare function transportViolation(transport: Transport): TransportViolation | undefined;
/**
 * A stable ordering, so a record's digest does not depend on the order a
 * host happened to list its transports.
 */
export declare function compareTransports(left: Transport, right: Transport): number;
/** Structural equality, for collapsing adjacent duplicates once sorted. */
export declare function transportsEqual(left: Transport, right: Transport): boolean;
/**
 * Sorts transports by their stable key and drops adjacent duplicates, the
 * same way a Rust host does after `sort_by` + `dedup`.
 */
export declare function sortAndDedupeTransports(transports: readonly Transport[]): readonly Transport[];
