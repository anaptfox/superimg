import type { ReachRecord } from "@foxworth/boundary/reach";
export type BusResponse = {
    readonly status: "ok";
    readonly records?: readonly ReachRecord[];
} | {
    readonly status: "error";
    readonly code: string;
    readonly message: string;
};
export declare class BusError extends Error {
    constructor(message: string);
}
export declare class BusClient {
    private readonly socket;
    private leftover;
    private constructor();
    static connect(path: string): Promise<BusClient>;
    register(record: ReachRecord): Promise<void>;
    unregister(bindingDigest: string): Promise<void>;
    list(): Promise<readonly ReachRecord[]>;
    close(): void;
    private expectOk;
    private send;
    private readLine;
}
