import { AdapterError, compileBindingResolution, interactionKey, modeForHandle, snapshotProjectedHandle } from "@foxworth/boundary/handoff/adapter";
import { createCheckedHandoff, createHandoffInvocation } from "@foxworth/boundary/handoff";
import { McpServer, createMcpHandler as createMcpHandler$1, fromJsonSchema } from "@modelcontextprotocol/server";
import { mountHandlers } from "@foxworth/boundary/http/compose";
import { createProtocolHandler } from "@foxworth/boundary/http/protocol";
//#region packages/callers/mcp/src/server.ts
var toolDeclarations = /* @__PURE__ */ new WeakSet();
var TOOL_NAME = /^[A-Za-z][A-Za-z0-9_.-]*$/u;
function detachedJsonSchema(schema) {
	return structuredClone(schema);
}
function tool(handleValue, options = {}) {
	const handle = snapshotProjectedHandle(handleValue, "tool.handle");
	const mode = modeForHandle(handle, options.mode, "tool.mode");
	const name = options.name ?? handle.interactionId;
	if (!TOOL_NAME.test(name)) throw new AdapterError("INVALID_DECLARATION", "tool.name", "tool name must start with a letter and contain only letters, digits, dot, dash, or underscore");
	if (options.title !== void 0 && !options.title.trim()) throw new AdapterError("INVALID_DECLARATION", "tool.title", "tool title must not be empty");
	if (options.description !== void 0 && !options.description.trim()) throw new AdapterError("INVALID_DECLARATION", "tool.description", "tool description must not be empty");
	const declaration = Object.freeze({
		handle,
		mode,
		name,
		...options.scopeChallenge === void 0 ? {} : { scopeChallenge: options.scopeChallenge },
		...options.title === void 0 ? {} : { title: options.title },
		...options.description === void 0 ? {} : { description: options.description }
	});
	toolDeclarations.add(declaration);
	return declaration;
}
function mcpResult(outcome) {
	const text = JSON.stringify(outcome, null, 2);
	const successful = outcome.result.kind === "returned" || outcome.result.kind === "proposed";
	return {
		content: [{
			type: "text",
			text
		}],
		structuredContent: outcome,
		...successful ? {} : { isError: true }
	};
}
function failureOutcome(manifest, resolved, certainty, cause) {
	return Object.freeze({
		version: 1,
		bindingDigest: manifest.bindingDigest,
		installationId: manifest.installationId,
		interactionId: resolved.binding.interactionId,
		expectedContractDigest: resolved.binding.expectedContractDigest,
		actualContractDigest: resolved.binding.actualContractDigest,
		mode: resolved.binding.mode,
		realizationId: resolved.binding.realizationId,
		certainty,
		result: Object.freeze({
			kind: "fault",
			cause
		})
	});
}
function inputSchemaFor(resolved) {
	if (resolved.handle.inputArity === 0) return {
		type: "object",
		properties: {},
		additionalProperties: false
	};
	const schema = resolved.expected.contract.inputSchema;
	if (schema === null || typeof schema !== "object" || Array.isArray(schema) || schema.type !== "object") throw new AdapterError("UNSUPPORTED_SCHEMA", `${resolved.handle.interactionId}.inputSchema`, "MCP tools require an object-shaped one-input contract");
	return schema;
}
/** Create a library-only MCP server from explicit projected-handle tools. */
async function createMcpServer(options) {
	if (typeof options.context !== "function") throw new AdapterError("INVALID_DECLARATION", "createMcpServer.context", "context must resolve invocation-scoped host context");
	if (!options.name.trim() || !options.version.trim()) throw new AdapterError("INVALID_DECLARATION", "createMcpServer.identity", "name and version must be explicit non-empty host values");
	for (const [index, declaration] of options.tools.entries()) if (!toolDeclarations.has(declaration)) throw new AdapterError("INVALID_DECLARATION", `tools[${index}]`, "tools must be created by tool()");
	const handoff = await createCheckedHandoff(options.binding);
	const resolution = await compileBindingResolution(handoff, options.tools.map((entry) => ({
		handle: entry.handle,
		mode: entry.mode
	})));
	const names = /* @__PURE__ */ new Set();
	const server = new McpServer({
		name: options.name,
		version: options.version
	}, {
		supportedProtocolVersions: ["2026-07-28"],
		...options.maxToolInputElements === void 0 ? {} : { maxToolInputElements: options.maxToolInputElements }
	});
	for (const declaration of options.tools) {
		if (names.has(declaration.name)) throw new AdapterError("DUPLICATE_DECLARATION", `tools.${declaration.name}`, `duplicate MCP tool name: ${declaration.name}`);
		names.add(declaration.name);
		const resolved = resolution.interactions.get(interactionKey(declaration.handle.interactionId, declaration.mode));
		const description = declaration.description ?? resolved.expected.docs.description ?? resolved.expected.docs.summary;
		server.registerTool(declaration.name, {
			...declaration.title === void 0 ? {} : { title: declaration.title },
			...description === void 0 ? {} : { description },
			...declaration.scopeChallenge === void 0 ? {} : { scopeChallenge: declaration.scopeChallenge },
			annotations: { readOnlyHint: resolved.expected.contract.changes.length === 0 },
			inputSchema: fromJsonSchema(detachedJsonSchema(inputSchemaFor(resolved)))
		}, async (input, extra) => {
			let invocation;
			try {
				invocation = await createHandoffInvocation(resolution.manifest, resolved.handle.interactionId, resolved.mode, resolved.handle.inputArity === 0 ? null : input);
			} catch {
				return mcpResult(failureOutcome(resolution.manifest, resolved, "not-started", "invalid-input"));
			}
			let context;
			try {
				const request = extra.http?.req;
				context = await options.context({
					tool: declaration,
					extra,
					...request === void 0 ? {} : { request }
				});
			} catch {
				return mcpResult(failureOutcome(resolution.manifest, resolved, "not-started", "invalid-invocation"));
			}
			try {
				return mcpResult(await handoff.invoke(invocation, context));
			} catch {
				return mcpResult(failureOutcome(resolution.manifest, resolved, "unknown", "realization-failed"));
			}
		});
	}
	return server;
}
function createMcpHandler(options, handlerOptions) {
	return createMcpHandler$1(() => createMcpServer(options), {
		...handlerOptions,
		legacy: "reject"
	});
}
/** One MCP tool per projected handle, using each handle's default mode. */
function toolsFor(projection) {
	return Object.values(projection.handles).map((handle) => tool(handle));
}
//#endregion
//#region packages/callers/mcp/src/serve.ts
/** Compose protocol doors and an optional MCP mount into one handler. */
function serveHost(options) {
	if (options.doors.length === 0 && options.mcp === void 0) throw new AdapterError("INVALID_DECLARATION", "serveHost", "serveHost requires at least one door or an MCP mount");
	const mcp = options.mcp ? createMcpHandler({
		name: options.mcp.name,
		version: options.mcp.version,
		binding: options.mcp.binding,
		context: options.mcp.context,
		tools: options.mcp.tools,
		maxToolInputElements: options.mcp.maxToolInputElements
	}, options.mcp.handlerOptions) : void 0;
	const mounts = [...options.doors.map((door) => ({
		path: door.path,
		fetch: createProtocolHandler({
			binding: door.binding,
			context: door.context,
			path: door.path
		})
	})), ...mcp && options.mcp ? [{
		path: options.mcp.path,
		fetch: (request) => mcp.fetch(request)
	}] : []];
	const { handler, paths } = mountHandlers(mounts);
	return {
		handler,
		paths,
		async dispose() {
			await mcp?.close();
		}
	};
}
//#endregion
export { createMcpHandler, createMcpServer, serveHost, tool, toolsFor };
