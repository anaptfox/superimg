import { c as isInteractionDefinition, f as failHost } from "./chunks/definitions-CFjJCGn-.js";
import { n as registerObservedRead } from "./chunks/integration-BFeEWs9s.js";
//#region packages/core/host/src/observed/index.ts
/** Create an inert native implementation adapter. Its cache and exact identity
* are supplied by Installation, never by the caller or a declaration. */
function observedRead(definition, options) {
	if (!isInteractionDefinition(definition)) failHost("FORGED_DEFINITION", "observedRead", "an authentic definition is required");
	if (definition.changes.length !== 0) failHost("INVALID_IMPLEMENTATION", "observedRead", "observed reads cannot realize changing interactions");
	if (options === null || typeof options !== "object" || typeof options.scope !== "function" || typeof options.authorize !== "function" || typeof options.evaluate !== "function" || typeof options.snapshots?.withSnapshot !== "function" || options.diagnostic !== void 0 && typeof options.diagnostic !== "function") failHost("INVALID_IMPLEMENTATION", "observedRead", "snapshot, scope, authorization and evaluation functions are required");
	const reuse = options.reuse ?? "off";
	const maxEntries = options.maxEntries ?? 128;
	if (reuse !== "off" && reuse !== "validated" || !Number.isSafeInteger(maxEntries) || maxEntries < 0) failHost("INVALID_IMPLEMENTATION", "observedRead", "invalid reuse policy or retention bound");
	const snapshots = Object.freeze({ withSnapshot: options.snapshots.withSnapshot.bind(options.snapshots) });
	const owned = Object.freeze({
		snapshots,
		scope: options.scope.bind(options),
		authorize: options.authorize.bind(options),
		evaluate: options.evaluate.bind(options),
		...options.diagnostic ? { diagnostic: options.diagnostic.bind(options) } : {},
		reuse,
		maxEntries
	});
	const implementation = Object.freeze(() => {
		throw new Error("observedRead implementations must be installed before execution");
	});
	registerObservedRead(implementation, definition, owned);
	return implementation;
}
//#endregion
export { observedRead };
