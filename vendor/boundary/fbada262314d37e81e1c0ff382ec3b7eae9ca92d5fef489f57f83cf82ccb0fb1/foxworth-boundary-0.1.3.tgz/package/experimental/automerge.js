import { normalizeJson } from "@foxworth/boundary/program";
import * as Automerge from "@automerge/automerge";
//#region packages/adapters/automerge/src/index.ts
/**
* Capture one Automerge version for isolated projections that return portable JSON.
* @experimental For evaluation; no production support commitment. The API may change incompatibly.
*/
function captureAutomerge(doc) {
	const snapshot = Automerge.clone(doc);
	let snapshotBytes;
	let heads;
	try {
		snapshotBytes = new Uint8Array(Automerge.save(snapshot));
		heads = Object.freeze([...Automerge.getHeads(snapshot)]);
	} finally {
		Automerge.free(snapshot);
	}
	return Object.freeze({
		engine: "automerge",
		heads,
		encode() {
			return new Uint8Array(snapshotBytes);
		},
		async read(project) {
			const source = Automerge.load(new Uint8Array(snapshotBytes));
			try {
				return normalizeJson(await project(source));
			} finally {
				Automerge.free(source);
			}
		}
	});
}
//#endregion
export { captureAutomerge };
