import { normalizeJson } from "@foxworth/boundary/program";
import * as Y from "yjs";
//#region packages/adapters/yjs/src/index.ts
function hex(bytes) {
	let value = "";
	for (const byte of bytes) value += byte.toString(16).padStart(2, "0");
	return value;
}
/**
* Capture an immutable, process-local view of one Yjs document state.
* Subdocuments are refused because a full-state update contains their
* references, not the subdocuments' contents.
* @experimental For evaluation; no production support commitment. The API may change incompatibly.
*/
function captureYjs(doc) {
	if (doc.getSubdocs().size > 0) throw new TypeError("Yjs capture does not support subdocuments");
	const frontier = hex(Y.encodeSnapshot(Y.snapshot(doc)));
	const ownedUpdate = Y.encodeStateAsUpdate(doc).slice();
	return Object.freeze({
		engine: "yjs",
		frontier,
		encode: () => ownedUpdate.slice(),
		async read(project) {
			const materialized = new Y.Doc();
			try {
				Y.applyUpdate(materialized, ownedUpdate.slice());
				return normalizeJson(await project(materialized));
			} finally {
				materialized.destroy();
			}
		}
	});
}
//#endregion
export { captureYjs };
