//#region packages/adapters/cloudflare/src/durableObject.ts
/**
* Give each Durable Object instance its own prebuilt Projection HTTP handler.
* State and environment stay in the application-owned factory.
*/
function createProjectionDurableObject(createHandler) {
	return class ProjectionDurableObject {
		#handler;
		constructor(state, environment) {
			this.#handler = createHandler(state, environment);
		}
		async fetch(request) {
			try {
				return await this.#handler(request);
			} catch {
				return new Response("Internal Server Error", { status: 500 });
			}
		}
	};
}
//#endregion
//#region packages/adapters/cloudflare/src/worker.ts
function mountPaths(value) {
	if (value === void 0) return void 0;
	const paths = typeof value === "string" ? [value] : [...value];
	if (paths.length === 0) throw new TypeError("@foxworth/boundary/cloudflare: mount must include at least one path");
	for (const path of paths) if (!path.startsWith("/") || path.includes("?") || path.includes("#")) throw new TypeError(`@foxworth/boundary/cloudflare: invalid mount path: ${path}`);
	return Object.freeze(paths);
}
function pathMatches(pathname, mount) {
	return mount === "/" || pathname === mount || pathname.startsWith(`${mount.replace(/\/$/, "")}/`);
}
function internalError() {
	return new Response("Internal Server Error", { status: 500 });
}
/** Adapt one explicit Projection HTTP handler to a Workers module `fetch`. */
function createProjectionWorkerFetch(handler, options = {}) {
	const mounts = mountPaths(options.mount);
	return async (request, environment, execution) => {
		const pathname = new URL(request.url).pathname;
		if (mounts && !mounts.some((mount) => pathMatches(pathname, mount))) return await options.fallback?.(request, environment, execution) ?? new Response("Not Found", { status: 404 });
		try {
			return await handler(request);
		} catch {
			return internalError();
		}
	};
}
/**
* Adapt a native Worker invocation factory to module `fetch`.
*
* Only matched requests create a Projection handler. Fallback routing keeps
* the application's request, environment, and execution context unchanged.
*/
function createProjectionWorkerFetchWithContext(createHandler, options = {}) {
	const mounts = mountPaths(options.mount);
	return async (request, environment, execution) => {
		const pathname = new URL(request.url).pathname;
		if (mounts && !mounts.some((mount) => pathMatches(pathname, mount))) return await options.fallback?.(request, environment, execution) ?? new Response("Not Found", { status: 404 });
		try {
			return await (await createHandler(Object.freeze({
				request,
				environment,
				execution
			})))(request);
		} catch {
			return internalError();
		}
	};
}
//#endregion
export { createProjectionDurableObject, createProjectionWorkerFetch, createProjectionWorkerFetchWithContext };
