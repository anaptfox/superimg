import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
//#region packages/adapters/http/src/nodeHttp.ts
function abortSignalFrom(req) {
	const controller = new AbortController();
	const onClose = () => {
		if (!req.complete) controller.abort();
	};
	req.on("close", onClose);
	return controller.signal;
}
/**
* Build a WinterCG Request from a Node IncomingMessage.
* When `canonicalPathname` is set, it replaces the URL pathname (query kept).
*/
function toFetchRequest(req, options) {
	const base = options?.base ?? "/";
	const proto = req.headers["x-forwarded-proto"]?.split(",")[0]?.trim() ?? (req.socket.encrypted ? "https" : "http");
	const host = req.headers["x-forwarded-host"] ?? req.headers.host ?? "localhost";
	let path = req.originalUrl ?? req.url ?? "/";
	if (base !== "/" && path.startsWith(base)) path = `/${path.slice(base.length)}`.replace(/\/{2,}/g, "/");
	const url = new URL(path, options?.origin ?? `${proto}://${host}`);
	if (options?.canonicalPathname) url.pathname = options.canonicalPathname;
	const method = req.method ?? "GET";
	const hasBody = method !== "GET" && method !== "HEAD";
	return new Request(url, {
		method,
		headers: req.headers,
		body: hasBody ? Readable.toWeb(req) : void 0,
		duplex: hasBody ? "half" : void 0,
		signal: abortSignalFrom(req)
	});
}
function endIfOpen(res) {
	if (!res.writableEnded) res.end();
}
/** Stream a Fetch Response onto a Node ServerResponse. */
async function sendFetchResponse(res, response, method = "GET") {
	if (res.headersSent) {
		endIfOpen(res);
		return;
	}
	const headers = {};
	response.headers.forEach((value, key) => {
		if (key.toLowerCase() === "set-cookie") return;
		headers[key] = value;
	});
	const cookies = response.headers.getSetCookie?.() ?? [];
	if (cookies.length) headers["set-cookie"] = cookies;
	res.writeHead(response.status, headers);
	if (method === "HEAD" || !response.body || response.status === 204 || response.status === 304) {
		endIfOpen(res);
		return;
	}
	try {
		await pipeline(Readable.fromWeb(response.body), res);
	} catch {
		endIfOpen(res);
	}
}
//#endregion
export { sendFetchResponse, toFetchRequest };
