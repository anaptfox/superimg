import { validateInvocationObservation } from "@foxworth/boundary/program";
//#region packages/adapters/http/src/observationHttp.ts
/** Live, bounded SSE delivery. No replay log, authority, or effect execution. */
function createObservationHttpHandler(options) {
	if (!options.path.startsWith("/") || options.path.includes("?") || options.path.includes("#")) throw new TypeError("observation path must be an absolute pathname");
	const encoder = new TextEncoder();
	return async (request) => {
		if (new URL(request.url).pathname !== options.path) return null;
		if (request.method !== "GET") return new Response("Method not allowed", {
			status: 405,
			headers: { allow: "GET" }
		});
		const context = await options.context(request);
		if (context instanceof Response) return context;
		const abort = new AbortController();
		let cleanup;
		let closed = false;
		let controller;
		const stop = () => {
			if (closed) return;
			closed = true;
			abort.abort();
			request.signal.removeEventListener("abort", onAbort);
			const release = cleanup;
			cleanup = void 0;
			try {
				release?.();
			} catch {}
		};
		const onAbort = () => {
			stop();
			try {
				controller.close();
			} catch {}
		};
		const stream = new ReadableStream({
			async start(streamController) {
				controller = streamController;
				request.signal.addEventListener("abort", onAbort, { once: true });
				if (request.signal.aborted) {
					onAbort();
					return;
				}
				try {
					const release = await options.subscribe(context, (value) => {
						if (closed) return;
						const event = validateInvocationObservation(value);
						const encoded = encoder.encode(`event: observation\ndata: ${JSON.stringify(event)}\n\n`);
						if (encoded.byteLength > 65536 || (controller.desiredSize ?? 0) <= 0) {
							stop();
							controller.error(/* @__PURE__ */ new Error("observation subscriber exceeded its bounded buffer"));
							return;
						}
						controller.enqueue(encoded);
					}, abort.signal);
					if (typeof release !== "function") throw new TypeError("observation subscription must return cleanup");
					if (closed) {
						release();
						return;
					}
					cleanup = release;
					controller.enqueue(encoder.encode("event: ready\ndata: {}\n\n"));
				} catch (error) {
					stop();
					controller.error(error);
				}
			},
			cancel: stop
		}, { highWaterMark: 32 });
		return new Response(stream, { headers: {
			"content-type": "text/event-stream; charset=utf-8",
			"cache-control": "no-store",
			"x-accel-buffering": "no"
		} });
	};
}
//#endregion
export { createObservationHttpHandler };
