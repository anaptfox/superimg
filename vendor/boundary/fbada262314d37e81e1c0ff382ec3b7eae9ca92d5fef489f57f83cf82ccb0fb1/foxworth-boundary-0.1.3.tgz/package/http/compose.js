export { t as createCompositeHttpHandler, n as mountHandlers } from "../chunks/httpCompose-DXqu_Em5.js";
import "./openapi.js";
import "./protocol.js";
