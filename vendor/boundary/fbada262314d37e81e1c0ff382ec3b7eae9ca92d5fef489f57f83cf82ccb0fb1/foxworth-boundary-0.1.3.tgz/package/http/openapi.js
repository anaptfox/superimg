import { n as compileProjectionResolution, o as AdapterError, r as interactionKey, t as compileBindingResolution } from "../chunks/resolution-DipfP_4a.js";
import { createCheckedHandoff } from "@foxworth/boundary/handoff";
//#region packages/adapters/http/src/openapi.ts
function object(value, path) {
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new AdapterError("UNSUPPORTED_SCHEMA", path, "HTTP input schemas must be objects");
	return value;
}
function parameterNames(path) {
	return Object.freeze(path.split("/").filter((segment) => segment.startsWith("{") && segment.endsWith("}")).map((segment) => segment.slice(1, -1)));
}
function propertySchemas(schema) {
	const root = object(schema, "route.inputSchema");
	return root.properties === void 0 ? Object.freeze({}) : object(root.properties, "route.inputSchema.properties");
}
function withoutProperties(schema, excluded) {
	const root = object(schema, "route.inputSchema");
	const properties = propertySchemas(schema);
	const required = Array.isArray(root.required) ? root.required.filter((name) => typeof name === "string" && !excluded.has(name)) : [];
	return {
		...root,
		properties: Object.fromEntries(Object.entries(properties).filter(([name]) => !excluded.has(name))),
		...root.required === void 0 ? {} : { required }
	};
}
function identityProperties(descriptor, mode, binding, installationId) {
	return {
		version: { const: 1 },
		bindingDigest: {
			type: "string",
			pattern: "^sha256:"
		},
		installationId: installationId === void 0 ? { type: "string" } : { const: installationId },
		interactionId: { const: descriptor.contract.id },
		expectedContractDigest: { const: descriptor.contractDigest },
		actualContractDigest: binding ? { const: binding.actualContractDigest } : {
			type: "string",
			pattern: "^sha256:"
		},
		mode: { const: mode },
		realizationId: binding ? { const: binding.realizationId } : { type: "string" }
	};
}
function outcomeSchema(descriptor, mode, branches, bindingDigest, binding, installationId) {
	const properties = {
		...identityProperties(descriptor, mode, binding, installationId),
		...bindingDigest === void 0 ? {} : { bindingDigest: { const: bindingDigest } }
	};
	return { oneOf: branches.map(({ certainty, result }) => ({
		type: "object",
		additionalProperties: false,
		required: [
			"version",
			"bindingDigest",
			"installationId",
			"interactionId",
			"expectedContractDigest",
			"actualContractDigest",
			"mode",
			"realizationId",
			"certainty",
			"result"
		],
		properties: {
			...properties,
			certainty: { const: certainty },
			result
		}
	})) };
}
function response(description, schema) {
	return {
		description,
		content: { "application/json": { schema } }
	};
}
var validationIssue = {
	type: "object",
	additionalProperties: false,
	required: ["path", "message"],
	properties: {
		path: {
			type: "string",
			minLength: 1
		},
		message: {
			type: "string",
			minLength: 1
		}
	}
};
function faultResult(causes, issues = false) {
	return {
		type: "object",
		additionalProperties: false,
		required: [
			"kind",
			"cause",
			...issues ? ["issues"] : []
		],
		properties: {
			kind: { const: "fault" },
			cause: causes.length === 1 ? { const: causes[0] } : { enum: causes },
			...issues ? { issues: {
				type: "array",
				minItems: 1,
				items: validationIssue
			} } : {}
		}
	};
}
function faultBranch(certainty, cause) {
	return Object.freeze({
		certainty,
		result: faultResult([cause])
	});
}
function internalFaultBranches(mode) {
	if (mode === "request") return Object.freeze([faultBranch("not-started", "admission-failed"), faultBranch("not-started", "request-failed")]);
	return Object.freeze([
		faultBranch("not-started", "admission-failed"),
		faultBranch("unknown", "invalid-realization-outcome"),
		faultBranch("not-started", "realization-failed"),
		faultBranch("not-completed", "realization-failed"),
		faultBranch("unknown", "realization-failed")
	]);
}
function declaredResultSchema(errorSchema) {
	const addKind = (schema) => {
		const root = object(schema, "route.errorSchema");
		const properties = root.properties === void 0 ? Object.freeze({}) : object(root.properties, "route.errorSchema.properties");
		const required = Array.isArray(root.required) ? root.required.filter((value) => typeof value === "string") : [];
		return {
			...root,
			properties: {
				...properties,
				kind: { const: "declared-error" }
			},
			required: [...required, "kind"]
		};
	};
	const root = object(errorSchema, "route.errorSchema");
	return Array.isArray(root.oneOf) ? { oneOf: root.oneOf.map(addKind) } : addKind(root);
}
function interactionPath(route, descriptor, bindingDigest, binding, installationId) {
	if (route.inputMapping === "custom") throw new AdapterError("INVALID_DECLARATION", `${descriptor.contract.id}.route.input`, "OpenAPI cannot infer a custom route input mapping");
	const names = parameterNames(route.path);
	const excluded = new Set(names);
	const inputSchema = descriptor.contract.inputSchema;
	const mapsObjectProperties = route.method === "GET" || names.length > 0;
	const inputObject = mapsObjectProperties ? object(inputSchema, "route.inputSchema") : void 0;
	const properties = mapsObjectProperties ? propertySchemas(inputSchema) : Object.freeze({});
	const required = new Set(Array.isArray(inputObject?.required) ? inputObject.required : []);
	const parameters = names.map((name) => {
		const schema = properties[name];
		if (!schema) throw new AdapterError("INVALID_DECLARATION", `${descriptor.contract.id}.route.path.${name}`, `path parameter ${name} is absent from the interaction input contract`);
		return {
			name,
			in: "path",
			required: true,
			schema
		};
	});
	if (route.method === "GET") {
		for (const [name, schema] of Object.entries(properties)) if (!excluded.has(name)) parameters.push({
			name,
			in: "query",
			required: required.has(name),
			schema
		});
	}
	const successResult = route.mode === "direct" ? {
		type: "object",
		additionalProperties: false,
		required: ["kind", "value"],
		properties: {
			kind: { const: "returned" },
			value: descriptor.contract.outputSchema
		}
	} : {
		type: "object",
		additionalProperties: false,
		required: ["kind", "proposal"],
		properties: {
			kind: { const: "proposed" },
			proposal: binding?.request?.previewSchema ?? {}
		}
	};
	const responses = {
		[String(route.successStatus ?? (route.mode === "request" ? 202 : 200))]: response("Interaction completed", outcomeSchema(descriptor, route.mode, [{
			certainty: route.mode === "request" ? "not-started" : "completed",
			result: successResult
		}], bindingDigest, binding, installationId)),
		"400": response("Invalid input or invocation", outcomeSchema(descriptor, route.mode, [{
			certainty: "not-started",
			result: faultResult(["invalid-input"], true)
		}, {
			certainty: "not-started",
			result: faultResult(["invalid-invocation"])
		}], bindingDigest, binding, installationId)),
		"403": response("Admission denied", outcomeSchema(descriptor, route.mode, [{
			certainty: "not-started",
			result: {
				type: "object",
				additionalProperties: false,
				required: ["kind", "code"],
				properties: {
					kind: { const: "denied" },
					code: { type: "string" }
				}
			}
		}], bindingDigest, binding, installationId)),
		"409": response("Binding revoked", outcomeSchema(descriptor, route.mode, [faultBranch("not-started", "revoked")], bindingDigest, binding, installationId)),
		"500": response("Undeclared failure", outcomeSchema(descriptor, route.mode, internalFaultBranches(route.mode), bindingDigest, binding, installationId))
	};
	if (route.mode === "direct" && descriptor.contract.errorSchema !== void 0) responses["422"] = response("Declared domain error", outcomeSchema(descriptor, route.mode, [{
		certainty: "completed",
		result: declaredResultSchema(descriptor.contract.errorSchema)
	}], bindingDigest, binding, installationId));
	return {
		interactionId: descriptor.contract.id,
		...descriptor.docs.summary === void 0 ? {} : { summary: descriptor.docs.summary },
		...descriptor.docs.description === void 0 ? {} : { description: descriptor.docs.description },
		"x-boundary-contract-digest": descriptor.contractDigest,
		"x-boundary-mode": route.mode,
		...parameters.length === 0 ? {} : { parameters },
		...route.method === "GET" || route.handle.inputArity === 0 ? {} : { requestBody: {
			required: true,
			content: { "application/json": { schema: names.length === 0 ? inputSchema : withoutProperties(inputSchema, excluded) } }
		} },
		responses
	};
}
/** Describe exactly the routes supplied by the application. */
async function openapi(options) {
	const declarations = options.routes.map((route) => ({
		handle: route.handle,
		mode: route.mode
	}));
	let resolved;
	let bindingDigest;
	let installationId;
	let programDigest;
	let sourceDigest;
	if (options.binding !== void 0) {
		const handoff = await createCheckedHandoff(options.binding);
		const binding = await compileBindingResolution(handoff, declarations);
		bindingDigest = binding.manifest.bindingDigest;
		installationId = binding.manifest.installationId;
		programDigest = binding.manifest.expectedProgramDigest;
		sourceDigest = binding.manifest.projectionDigest;
		resolved = new Map([...binding.interactions].map(([key, value]) => [key, {
			descriptor: value.expected,
			binding: value.binding
		}]));
	} else {
		const projection = await compileProjectionResolution(options.projection, declarations);
		programDigest = projection.projection.program.programDigest;
		sourceDigest = projection.projection.projectionDigest;
		resolved = new Map([...projection.interactions].map(([key, value]) => [key, { descriptor: value.descriptor }]));
	}
	const paths = {};
	const seen = /* @__PURE__ */ new Set();
	for (const [index, route] of options.routes.entries()) {
		const routeKey = `${route.method} ${route.path}`;
		if (seen.has(routeKey)) throw new AdapterError("DUPLICATE_DECLARATION", `routes[${index}]`, `duplicate route: ${routeKey}`);
		seen.add(routeKey);
		const interaction = resolved.get(interactionKey(route.handle.interactionId, route.mode));
		const path = paths[route.path] ?? {};
		path[route.method.toLowerCase()] = interactionPath(route, interaction.descriptor, bindingDigest, interaction.binding, installationId);
		paths[route.path] = path;
	}
	return {
		openapi: "3.1.0",
		info: {
			title: options.title,
			version: options.version
		},
		"x-boundary-program-digest": programDigest,
		"x-boundary-projection-digest": sourceDigest,
		...bindingDigest === void 0 ? {} : { "x-boundary-binding-digest": bindingDigest },
		paths
	};
}
//#endregion
export { openapi };
