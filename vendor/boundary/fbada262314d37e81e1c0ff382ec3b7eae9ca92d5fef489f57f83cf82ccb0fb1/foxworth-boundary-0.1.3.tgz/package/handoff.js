import { BoundaryErrorBase, compareUtf8, contractCompatibility, exactObject, hashJson, isInteractionId, isInvocationFaultLegal, isSha256Digest, jsonEquals, snapshotJson, validateCatalog, validatePortableSchema, validateProgram, validateSchemaValue } from "@foxworth/boundary/program";
//#region packages/core/handoff/src/errors.ts
var HandoffError = class extends BoundaryErrorBase {
	issues;
	constructor(code, path, message, options = {}) {
		super(code, path, message, options);
		this.name = "HandoffError";
		if (options.issues !== void 0) this.issues = Object.freeze(options.issues.map((issue) => Object.freeze({
			path: issue.path,
			message: issue.message
		})));
	}
};
function failHandoffWithIssues(code, path, message, issues) {
	throw new HandoffError(code, path, message, { issues });
}
function failHandoff(code, path, message, cause) {
	throw new HandoffError(code, path, message, cause === void 0 ? {} : { cause });
}
//#endregion
//#region packages/core/handoff/src/index.ts
var validatedManifests = /* @__PURE__ */ new WeakMap();
var validatedInvocations = /* @__PURE__ */ new WeakSet();
function hasImmutableManifest(binding, manifest) {
	try {
		const property = Object.getOwnPropertyDescriptor(binding, "manifest");
		if (!property || !("value" in property) || property.value !== manifest || property.writable || property.configurable) return false;
		const seen = /* @__PURE__ */ new WeakSet();
		const pending = [manifest];
		while (pending.length > 0) {
			const value = pending.pop();
			if (value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value)) continue;
			if (typeof value !== "object") return false;
			if (seen.has(value)) continue;
			if (!Object.isFrozen(value)) return false;
			const prototype = Object.getPrototypeOf(value);
			if (prototype !== null && prototype !== Object.prototype && prototype !== Array.prototype) return false;
			seen.add(value);
			for (const key of Reflect.ownKeys(value)) {
				if (typeof key !== "string") return false;
				const descriptor = Object.getOwnPropertyDescriptor(value, key);
				if (!descriptor || !("value" in descriptor)) return false;
				pending.push(descriptor.value);
			}
		}
		return true;
	} catch {
		return false;
	}
}
var BINDING_DOMAIN = "boundary.projection-binding/v1";
var PROJECTION_DOMAIN = "boundary.projection/v1";
var OPAQUE_ID = /^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u;
var ALIAS = /^[A-Za-z_$][A-Za-z0-9_$]*$/u;
var FAULT_CAUSES = /* @__PURE__ */ new Set([
	"invalid-input",
	"revoked",
	"admission-failed",
	"request-failed",
	"invalid-realization-outcome",
	"realization-failed",
	"invalid-invocation"
]);
function malformed(path, message, cause) {
	return failHandoff("INVALID_MANIFEST", path, message, cause);
}
function invocationFailure(path, message) {
	return failHandoff("INVALID_INVOCATION", path, message);
}
function outcomeFailure(path, message) {
	return failHandoff("INVALID_OUTCOME", path, message);
}
function exact(value, path, keys, optionalKeys = [], kind = "manifest") {
	const fail = (failure) => {
		if (kind === "invocation") return invocationFailure(failure.path, failure.message);
		if (kind === "outcome") return outcomeFailure(failure.path, failure.message);
		return malformed(failure.path, failure.message);
	};
	return exactObject(value, {
		path,
		keys,
		optionalKeys,
		fail
	});
}
function snapshot(value, path, kind) {
	return snapshotJson(value, {
		path,
		fail(failure) {
			if (kind === "invocation") return invocationFailure(failure.path, failure.message);
			if (kind === "outcome") return outcomeFailure(failure.path, failure.message);
			return malformed(failure.path, failure.message);
		}
	});
}
function requireVersion(value, path) {
	if (value !== 1) failHandoff("UNSUPPORTED_VERSION", path, "only Handoff protocol version 1 is accepted");
}
function requireDigest(value, path, kind) {
	if (isSha256Digest(value)) return;
	if (kind === "manifest") malformed(path, "digest must be sha256:<64 lowercase hex>");
	if (kind === "invocation") invocationFailure(path, "digest must be sha256:<64 lowercase hex>");
	outcomeFailure(path, "digest must be sha256:<64 lowercase hex>");
}
function requireOpaqueId(value, path, kind) {
	if (typeof value === "string" && OPAQUE_ID.test(value)) return;
	if (kind === "manifest") malformed(path, "identity must be a stable non-empty ASCII token");
	if (kind === "invocation") invocationFailure(path, "identity must be a stable non-empty ASCII token");
	outcomeFailure(path, "identity must be a stable non-empty ASCII token");
}
function requireInteractionId(value, path, kind) {
	if (isInteractionId(value)) return;
	if (kind === "manifest") malformed(path, "interactionId is invalid");
	if (kind === "invocation") invocationFailure(path, "interactionId is invalid");
	outcomeFailure(path, "interactionId is invalid");
}
function requireMode(value, path, kind) {
	if (value === "direct" || value === "request") return;
	if (kind === "manifest") malformed(path, "mode must be \"direct\" or \"request\"");
	if (kind === "invocation") invocationFailure(path, "mode must be \"direct\" or \"request\"");
	outcomeFailure(path, "mode must be \"direct\" or \"request\"");
}
function descriptorById(interactions) {
	return new Map(interactions.map((descriptor) => [descriptor.contract.id, descriptor]));
}
function interactionKey(interaction) {
	return `${interaction.interactionId}\u0000${interaction.mode}`;
}
function validateBindingInteraction(value, index, expected, actual) {
	const path = `manifest.interactions[${index}]`;
	const raw = exact(value, path, [
		"alias",
		"interactionId",
		"expectedContractDigest",
		"actualContractDigest",
		"inputArity",
		"mode",
		"realizationId"
	], ["request"]);
	if (typeof raw.alias !== "string" || !ALIAS.test(raw.alias)) malformed(`${path}.alias`, "alias must be a JavaScript identifier-like string");
	requireInteractionId(raw.interactionId, `${path}.interactionId`, "manifest");
	requireDigest(raw.expectedContractDigest, `${path}.expectedContractDigest`, "manifest");
	requireDigest(raw.actualContractDigest, `${path}.actualContractDigest`, "manifest");
	if (raw.inputArity !== 0 && raw.inputArity !== 1) malformed(`${path}.inputArity`, "inputArity must be 0 or 1");
	requireMode(raw.mode, `${path}.mode`, "manifest");
	requireOpaqueId(raw.realizationId, `${path}.realizationId`, "manifest");
	const expectedDescriptor = expected.get(raw.interactionId);
	const actualDescriptor = actual.get(raw.interactionId);
	if (!expectedDescriptor || !actualDescriptor) malformed(`${path}.interactionId`, "interaction must occur in both pinned Programs");
	if (expectedDescriptor.contractDigest !== raw.expectedContractDigest) malformed(`${path}.expectedContractDigest`, "expected contract digest is not pinned by expectedProgram");
	if (actualDescriptor.contractDigest !== raw.actualContractDigest) malformed(`${path}.actualContractDigest`, "actual contract digest is not pinned by actualProgram");
	const compatibility = contractCompatibility(expectedDescriptor.contract, actualDescriptor.contract);
	if (!compatibility.compatible) malformed(`${path}.${compatibility.path}`, `expected and actual contracts are incompatible: ${compatibility.reason}`);
	let request;
	if (raw.mode === "request") {
		const requestObject = exact(raw.request, `${path}.request`, ["controlDigest", "previewSchema"]);
		requireDigest(requestObject.controlDigest, `${path}.request.controlDigest`, "manifest");
		try {
			validatePortableSchema(requestObject.previewSchema, `${path}.request.previewSchema`);
		} catch (error) {
			malformed(`${path}.request.previewSchema`, "previewSchema is not portable", error);
		}
		request = Object.freeze({
			controlDigest: requestObject.controlDigest,
			previewSchema: requestObject.previewSchema
		});
	} else if (raw.request !== void 0) malformed(`${path}.request`, "request metadata is forbidden for direct mode");
	return Object.freeze({
		alias: raw.alias,
		interactionId: raw.interactionId,
		expectedContractDigest: raw.expectedContractDigest,
		actualContractDigest: raw.actualContractDigest,
		inputArity: raw.inputArity,
		mode: raw.mode,
		realizationId: raw.realizationId,
		...request === void 0 ? {} : { request }
	});
}
/** Snapshot and fully validate an untrusted v1 Binding handshake. */
async function validateProjectionBindingManifest(value) {
	if (value !== null && typeof value === "object" && validatedManifests.has(value)) return value;
	const owned = snapshot(value, "manifest", "manifest");
	requireVersion(owned !== null && typeof owned === "object" && !Array.isArray(owned) ? owned.version : void 0, "manifest.version");
	const raw = exact(owned, "manifest", [
		"version",
		"bindingDigest",
		"projectionDigest",
		"installationId",
		"installationDigest",
		"expectedProgramDigest",
		"actualProgramDigest",
		"expectedProgram",
		"actualProgram",
		"actualCatalog",
		"interactions"
	]);
	requireVersion(raw.version, "manifest.version");
	requireDigest(raw.bindingDigest, "manifest.bindingDigest", "manifest");
	requireDigest(raw.projectionDigest, "manifest.projectionDigest", "manifest");
	requireOpaqueId(raw.installationId, "manifest.installationId", "manifest");
	requireDigest(raw.installationDigest, "manifest.installationDigest", "manifest");
	requireDigest(raw.expectedProgramDigest, "manifest.expectedProgramDigest", "manifest");
	requireDigest(raw.actualProgramDigest, "manifest.actualProgramDigest", "manifest");
	if (!Array.isArray(raw.interactions)) malformed("manifest.interactions", "Binding interactions must be an array");
	let expectedProgram;
	let actualProgram;
	try {
		expectedProgram = await validateProgram(raw.expectedProgram);
		actualProgram = await validateProgram(raw.actualProgram);
	} catch (error) {
		malformed("manifest", "pinned Programs are invalid", error);
	}
	if (expectedProgram.programDigest !== raw.expectedProgramDigest) malformed("manifest.expectedProgramDigest", "expected Program digest does not match expectedProgram");
	if (actualProgram.programDigest !== raw.actualProgramDigest) malformed("manifest.actualProgramDigest", "actual Program digest does not match actualProgram");
	let actualCatalog;
	try {
		actualCatalog = validateCatalog(actualProgram, raw.actualCatalog);
	} catch (error) {
		malformed("manifest.actualCatalog", "actual Catalog is invalid", error);
	}
	const expected = descriptorById(expectedProgram.interactions);
	const actual = descriptorById(actualProgram.interactions);
	const catalogById = new Map(actualCatalog.interactions.map((entry) => [entry.interactionId, entry]));
	const interactions = Object.freeze(raw.interactions.map((entry, index) => validateBindingInteraction(entry, index, expected, actual)));
	const keys = /* @__PURE__ */ new Set();
	const aliases = /* @__PURE__ */ new Map();
	const modesByAlias = /* @__PURE__ */ new Map();
	const modesById = /* @__PURE__ */ new Map();
	for (let index = 0; index < interactions.length; index += 1) {
		const interaction = interactions[index];
		const key = interactionKey(interaction);
		if (keys.has(key)) malformed(`manifest.interactions[${index}]`, "duplicate interaction and mode entry");
		keys.add(key);
		const alias = aliases.get(interaction.alias);
		if (alias && (alias.interactionId !== interaction.interactionId || alias.inputArity !== interaction.inputArity)) malformed(`manifest.interactions[${index}].alias`, "one alias must identify one interaction and arity");
		aliases.set(interaction.alias, {
			interactionId: interaction.interactionId,
			inputArity: interaction.inputArity
		});
		const aliasModes = modesByAlias.get(interaction.alias) ?? [];
		aliasModes.push(interaction);
		modesByAlias.set(interaction.alias, aliasModes);
		const idModes = modesById.get(interaction.interactionId) ?? /* @__PURE__ */ new Map();
		idModes.set(interaction.mode, interaction);
		modesById.set(interaction.interactionId, idModes);
		const availability = catalogById.get(interaction.interactionId);
		if (!availability) malformed(`manifest.interactions[${index}].interactionId`, "Catalog does not contain the pinned interaction");
		if (interaction.mode === "direct" && availability.direct?.realizationId !== interaction.realizationId) malformed(`manifest.interactions[${index}].realizationId`, "Catalog does not pin the same direct realization");
		if (interaction.mode === "request" && (availability.request?.realizationId !== interaction.realizationId || availability.request?.controlDigest !== interaction.request.controlDigest || !jsonEquals(availability.request?.previewSchema ?? null, interaction.request.previewSchema))) malformed(`manifest.interactions[${index}].request`, "Catalog does not pin the same request realization and control identity");
		if (index > 0) {
			const previous = interactions[index - 1];
			if (compareUtf8(previous.alias, interaction.alias) > 0 || previous.alias === interaction.alias && compareUtf8(previous.mode, interaction.mode) >= 0) malformed(`manifest.interactions[${index}]`, "interaction modes are not in canonical alias/mode order");
		}
	}
	if (expected.size !== aliases.size || actual.size !== new Set(interactions.map((interaction) => interaction.interactionId)).size) malformed("manifest.interactions", "Binding interactions must exhaust both pinned selected Programs");
	if (actualCatalog.interactions.reduce((count, entry) => count + (entry.direct === void 0 ? 0 : 1) + (entry.request === void 0 ? 0 : 1), 0) !== interactions.length) malformed("manifest.actualCatalog.interactions", "Catalog modes must exactly match the pinned Binding interaction modes");
	const projectionInteractions = Object.freeze([...aliases.entries()].map(([alias, interaction]) => {
		const entries = modesByAlias.get(alias);
		return Object.freeze({
			alias,
			interactionId: interaction.interactionId,
			expectedContractDigest: entries[0].expectedContractDigest,
			inputArity: interaction.inputArity,
			modes: Object.freeze(entries.map((entry) => entry.mode).sort(compareUtf8))
		});
	}).sort((left, right) => compareUtf8(left.alias, right.alias)));
	if (await hashJson(PROJECTION_DOMAIN, Object.freeze({
		program: expectedProgram.programDigest,
		interactions: Object.freeze(projectionInteractions.map((interaction) => Object.freeze({
			alias: interaction.alias,
			interaction: interaction.interactionId,
			contract: interaction.expectedContractDigest,
			arity: interaction.inputArity === 0 ? "zero" : "one",
			modes: interaction.modes.length === 2 ? "direct-and-request" : interaction.modes[0]
		})))
	})) !== raw.projectionDigest) malformed("manifest.projectionDigest", "projection digest does not match the selected expected surface");
	const identity = Object.freeze({
		version: 1,
		projectionDigest: raw.projectionDigest,
		installationId: raw.installationId,
		installationDigest: raw.installationDigest,
		expectedProgramDigest: raw.expectedProgramDigest,
		actualProgramDigest: raw.actualProgramDigest,
		expectedProgram,
		actualProgram,
		actualCatalog,
		interactions
	});
	const bindingDigest = await hashJson(BINDING_DOMAIN, identity);
	if (bindingDigest !== raw.bindingDigest) malformed("manifest.bindingDigest", "binding digest does not match the pinned Binding identity");
	const manifest = Object.freeze({
		...identity,
		bindingDigest
	});
	validatedManifests.set(manifest, Object.freeze({
		interactions: modesById,
		expected,
		actual
	}));
	return manifest;
}
/** Snapshot and validate only the v1 invocation envelope shape. */
function validateHandoffInvocation(value) {
	if (value !== null && typeof value === "object" && validatedInvocations.has(value)) return value;
	const owned = snapshot(value, "invocation", "invocation");
	requireVersion(owned !== null && typeof owned === "object" && !Array.isArray(owned) ? owned.version : void 0, "invocation.version");
	const raw = exact(owned, "invocation", [
		"version",
		"bindingDigest",
		"installationId",
		"interactionId",
		"expectedContractDigest",
		"actualContractDigest",
		"mode",
		"realizationId",
		"input"
	], [], "invocation");
	requireVersion(raw.version, "invocation.version");
	requireDigest(raw.bindingDigest, "invocation.bindingDigest", "invocation");
	requireOpaqueId(raw.installationId, "invocation.installationId", "invocation");
	requireInteractionId(raw.interactionId, "invocation.interactionId", "invocation");
	requireDigest(raw.expectedContractDigest, "invocation.expectedContractDigest", "invocation");
	requireDigest(raw.actualContractDigest, "invocation.actualContractDigest", "invocation");
	requireMode(raw.mode, "invocation.mode", "invocation");
	requireOpaqueId(raw.realizationId, "invocation.realizationId", "invocation");
	if (owned !== null && typeof owned === "object") validatedInvocations.add(owned);
	return owned;
}
function validateResult(rawValue, mode, certainty) {
	const path = "outcome.result";
	const tagged = exact(rawValue, path, ["kind"], [
		"value",
		"code",
		"details",
		"proposal",
		"cause",
		"issues"
	], "outcome");
	switch (tagged.kind) {
		case "returned":
			exact(rawValue, path, ["kind", "value"], [], "outcome");
			if (mode !== "direct" || certainty !== "completed") outcomeFailure(path, "returned is valid only for a completed direct invocation");
			return rawValue;
		case "declared-error":
			exact(rawValue, path, [
				"kind",
				"code",
				"details"
			], [], "outcome");
			if (mode !== "direct" || certainty !== "completed" || typeof tagged.code !== "string" || !tagged.code.trim()) outcomeFailure(path, "declared-error requires a non-empty code on a completed direct invocation");
			return rawValue;
		case "proposed":
			exact(rawValue, path, ["kind", "proposal"], [], "outcome");
			if (mode !== "request" || certainty !== "not-started") outcomeFailure(path, "proposed is valid only for a not-started request invocation");
			return rawValue;
		case "denied":
			exact(rawValue, path, ["kind", "code"], [], "outcome");
			if (certainty !== "not-started" || typeof tagged.code !== "string" || !tagged.code.trim()) outcomeFailure(path, "denied requires a non-empty code and not-started certainty");
			return rawValue;
		case "fault": {
			const fault = exact(rawValue, path, ["kind", "cause"], ["issues"], "outcome");
			if (!FAULT_CAUSES.has(tagged.cause)) outcomeFailure(path, "fault requires a stable cause");
			const cause = tagged.cause;
			if (!isInvocationFaultLegal(mode, cause, certainty)) outcomeFailure(path, `fault cause ${cause} is invalid for ${mode} mode with ${certainty} certainty`);
			if (fault.issues !== void 0) {
				if (tagged.cause !== "invalid-input") outcomeFailure(`${path}.issues`, "validation issues are valid only for invalid-input faults");
				validateIssues(fault.issues, `${path}.issues`);
			}
			return rawValue;
		}
		default: return outcomeFailure(`${path}.kind`, "unknown Handoff result kind");
	}
}
function validateIssues(value, path) {
	if (!Array.isArray(value) || value.length === 0) outcomeFailure(path, "validation issues must be a non-empty array");
	return Object.freeze(value.map((entry, index) => {
		const issuePath = `${path}[${index}]`;
		const issue = exact(entry, issuePath, ["path", "message"], [], "outcome");
		if (typeof issue.path !== "string" || !issue.path.trim()) outcomeFailure(`${issuePath}.path`, "issue path must be non-empty");
		if (typeof issue.message !== "string" || !issue.message.trim()) outcomeFailure(`${issuePath}.message`, "issue message must be non-empty");
		return Object.freeze({
			path: issue.path,
			message: issue.message
		});
	}));
}
/** Snapshot and validate an untrusted v1 outcome and its certainty law. */
function validateHandoffOutcome(value) {
	const owned = snapshot(value, "outcome", "outcome");
	requireVersion(owned !== null && typeof owned === "object" && !Array.isArray(owned) ? owned.version : void 0, "outcome.version");
	const raw = exact(owned, "outcome", [
		"version",
		"bindingDigest",
		"installationId",
		"interactionId",
		"expectedContractDigest",
		"actualContractDigest",
		"mode",
		"realizationId",
		"certainty",
		"result"
	], [], "outcome");
	requireVersion(raw.version, "outcome.version");
	requireDigest(raw.bindingDigest, "outcome.bindingDigest", "outcome");
	requireOpaqueId(raw.installationId, "outcome.installationId", "outcome");
	requireInteractionId(raw.interactionId, "outcome.interactionId", "outcome");
	requireDigest(raw.expectedContractDigest, "outcome.expectedContractDigest", "outcome");
	requireDigest(raw.actualContractDigest, "outcome.actualContractDigest", "outcome");
	requireMode(raw.mode, "outcome.mode", "outcome");
	requireOpaqueId(raw.realizationId, "outcome.realizationId", "outcome");
	if (raw.certainty !== "not-started" && raw.certainty !== "not-completed" && raw.certainty !== "completed" && raw.certainty !== "unknown") outcomeFailure("outcome.certainty", "certainty is invalid");
	validateResult(raw.result, raw.mode, raw.certainty);
	return owned;
}
/** Validate a remote outcome against the exact handshake it claims to answer. */
async function validateHandoffOutcomeAgainstManifest(manifestValue, outcomeValue) {
	const manifest = await validateProjectionBindingManifest(manifestValue);
	const outcome = validateHandoffOutcome(outcomeValue);
	if (outcome.bindingDigest !== manifest.bindingDigest) failHandoff("STALE_BINDING", "outcome.bindingDigest", "outcome targets a different Binding");
	if (outcome.installationId !== manifest.installationId) failHandoff("STALE_INSTALLATION", "outcome.installationId", "outcome targets a different Installation");
	const index = validatedManifests.get(manifest);
	const interaction = index.interactions.get(outcome.interactionId)?.get(outcome.mode);
	if (!interaction) failHandoff("INTERACTION_NOT_EXPOSED", "outcome.interactionId", "outcome interaction mode is not exposed by this Binding");
	if (interaction.expectedContractDigest !== outcome.expectedContractDigest || interaction.actualContractDigest !== outcome.actualContractDigest) failHandoff("STALE_CONTRACT", "outcome.expectedContractDigest", "outcome contract pins do not match this Binding");
	if (interaction.realizationId !== outcome.realizationId) failHandoff("STALE_REALIZATION", "outcome.realizationId", "outcome realization does not match this Binding");
	const expected = index.expected.get(outcome.interactionId);
	const actual = index.actual.get(outcome.interactionId);
	if (outcome.result.kind === "returned") {
		if (validateSchemaValue(expected.contract.outputSchema, outcome.result.value, "outcome.result.value").length > 0 || validateSchemaValue(actual.contract.outputSchema, outcome.result.value, "outcome.result.value").length > 0) outcomeFailure("outcome.result.value", "returned value does not match both pinned contracts");
	}
	if (outcome.result.kind === "declared-error") {
		const declared = Object.freeze({
			code: outcome.result.code,
			details: outcome.result.details
		});
		if (expected.contract.errorSchema === void 0 || actual.contract.errorSchema === void 0 || validateSchemaValue(expected.contract.errorSchema, declared, "outcome.result").length > 0 || validateSchemaValue(actual.contract.errorSchema, declared, "outcome.result").length > 0) outcomeFailure("outcome.result", "declared error does not match both pinned contracts");
	}
	if (outcome.result.kind === "proposed" && validateSchemaValue(interaction.request.previewSchema, outcome.result.proposal, "outcome.result.proposal").length > 0) outcomeFailure("outcome.result.proposal", "proposal does not match the pinned request contract");
	return outcome;
}
/** Check one response against the exact sent invocation and its pinned contracts.
* Identity correlation does not prove which input computed a returned value.
*/
async function validateHandoffResponse(manifestValue, invocationValue, outcomeValue) {
	const manifest = await validateProjectionBindingManifest(manifestValue);
	const invocation = validateHandoffInvocation(invocationValue);
	const outcome = await validateHandoffOutcomeAgainstManifest(manifest, outcomeValue);
	for (const key of [
		"bindingDigest",
		"installationId",
		"interactionId",
		"expectedContractDigest",
		"actualContractDigest",
		"mode",
		"realizationId"
	]) if (outcome[key] !== invocation[key]) outcomeFailure(`outcome.${key}`, "response does not answer the sent invocation");
	try {
		pinnedInteraction(manifest, invocation);
	} catch (error) {
		if (!(error instanceof HandoffError && error.code === "INVALID_INPUT" && outcome.result.kind === "fault" && outcome.result.cause === "invalid-input")) throw error;
	}
	return outcome;
}
function pinnedInteraction(manifest, invocation) {
	if (invocation.bindingDigest !== manifest.bindingDigest) failHandoff("STALE_BINDING", "invocation.bindingDigest", "invocation targets a different Binding");
	if (invocation.installationId !== manifest.installationId) failHandoff("STALE_INSTALLATION", "invocation.installationId", "invocation targets a different Installation");
	const index = validatedManifests.get(manifest);
	const byInteraction = index.interactions.get(invocation.interactionId);
	if (!byInteraction) failHandoff("INTERACTION_NOT_EXPOSED", "invocation.interactionId", "interaction is not exposed by this Binding");
	const interaction = byInteraction.get(invocation.mode);
	if (!interaction) failHandoff("MODE_NOT_EXPOSED", "invocation.mode", "mode is not exposed by this Binding");
	if (invocation.expectedContractDigest !== interaction.expectedContractDigest || invocation.actualContractDigest !== interaction.actualContractDigest) failHandoff("STALE_CONTRACT", "invocation.expectedContractDigest", "invocation contract pins do not match this Binding");
	if (invocation.realizationId !== interaction.realizationId) failHandoff("STALE_REALIZATION", "invocation.realizationId", "invocation targets a different realization");
	if (interaction.inputArity === 0 && invocation.input !== null) failHandoffWithIssues("INVALID_INPUT", "invocation.input", "zero-arity interactions require the canonical null wire input", [Object.freeze({
		path: "invocation.input",
		message: "zero-arity interactions require the canonical null wire input"
	})]);
	const expected = index.expected.get(invocation.interactionId);
	const actual = index.actual.get(invocation.interactionId);
	const issues = distinctIssues([...validateSchemaValue(expected.contract.inputSchema, invocation.input, "invocation.input"), ...validateSchemaValue(actual.contract.inputSchema, invocation.input, "invocation.input")]);
	if (issues.length > 0) failHandoffWithIssues("INVALID_INPUT", issues[0].path, "input does not match both pinned contracts", issues);
	return interaction;
}
function distinctIssues(issues) {
	const seen = /* @__PURE__ */ new Set();
	const result = [];
	for (const issue of issues) {
		const key = `${issue.path}\u0000${issue.message}`;
		if (seen.has(key)) continue;
		seen.add(key);
		result.push(Object.freeze({
			path: issue.path,
			message: issue.message
		}));
	}
	return Object.freeze(result);
}
function invalidInputOutcome(manifest, invocation, error) {
	const issues = error.issues ?? Object.freeze([Object.freeze({
		path: error.path,
		message: "input is invalid"
	})]);
	return validateHandoffOutcome({
		version: 1,
		bindingDigest: manifest.bindingDigest,
		installationId: invocation.installationId,
		interactionId: invocation.interactionId,
		expectedContractDigest: invocation.expectedContractDigest,
		actualContractDigest: invocation.actualContractDigest,
		mode: invocation.mode,
		realizationId: invocation.realizationId,
		certainty: "not-started",
		result: {
			kind: "fault",
			cause: "invalid-input",
			issues
		}
	});
}
function faultOutcome(manifest, invocation, certainty, cause) {
	return validateHandoffOutcome({
		version: 1,
		bindingDigest: manifest.bindingDigest,
		installationId: invocation.installationId,
		interactionId: invocation.interactionId,
		expectedContractDigest: invocation.expectedContractDigest,
		actualContractDigest: invocation.actualContractDigest,
		mode: invocation.mode,
		realizationId: invocation.realizationId,
		certainty,
		result: {
			kind: "fault",
			cause
		}
	});
}
function rawResult(result) {
	if (result.kind !== "fault") return result;
	return Object.freeze({
		kind: "fault",
		cause: FAULT_CAUSES.has(result.cause) ? result.cause : "realization-failed"
	});
}
async function outcomeFromRaw(manifest, invocation, rawValue) {
	const raw = exact(snapshot(rawValue, "hostOutcome", "outcome"), "hostOutcome", [
		"bindingDigest",
		"projectionDigest",
		"installationId",
		"installationDigest",
		"interactionId",
		"expectedContractDigest",
		"actualContractDigest",
		"mode",
		"realizationId",
		"certainty",
		"result"
	], [], "outcome");
	if (!(raw.bindingDigest === manifest.bindingDigest && raw.projectionDigest === manifest.projectionDigest && raw.installationId === invocation.installationId && raw.installationDigest === manifest.installationDigest && raw.interactionId === invocation.interactionId && raw.expectedContractDigest === invocation.expectedContractDigest && raw.actualContractDigest === invocation.actualContractDigest && raw.mode === invocation.mode && raw.realizationId === invocation.realizationId)) return outcomeFailure("outcome", "host outcome does not echo the invocation identity pins");
	return validateHandoffOutcomeAgainstManifest(manifest, validateHandoffOutcome({
		version: 1,
		bindingDigest: manifest.bindingDigest,
		installationId: raw.installationId,
		interactionId: raw.interactionId,
		expectedContractDigest: raw.expectedContractDigest,
		actualContractDigest: raw.actualContractDigest,
		mode: raw.mode,
		realizationId: raw.realizationId,
		certainty: raw.certainty,
		result: rawResult(raw.result)
	}));
}
/** Execute exactly once: no retry, rebind, replay, or replacement following. */
async function executeHandoff(binding, invocationValue, context) {
	const invocation = validateHandoffInvocation(invocationValue);
	return executeWithManifest(binding, await validateProjectionBindingManifest(binding.manifest), invocation, context);
}
async function executeWithManifest(binding, manifest, invocation, context) {
	try {
		pinnedInteraction(manifest, invocation);
	} catch (error) {
		if (error instanceof HandoffError && error.code === "INVALID_INPUT") return invalidInputOutcome(manifest, invocation, error);
		throw error;
	}
	const interaction = binding.resolve(invocation.interactionId);
	if (!interaction) failHandoff("INTERACTION_NOT_EXPOSED", "invocation.interactionId", "live Binding no longer resolves this interaction");
	let raw;
	try {
		raw = await binding.invoke({
			interaction,
			mode: invocation.mode,
			input: invocation.input
		}, context);
	} catch {
		return faultOutcome(manifest, invocation, "unknown", "realization-failed");
	}
	try {
		return await outcomeFromRaw(manifest, invocation, raw);
	} catch {
		return invocation.mode === "request" ? faultOutcome(manifest, invocation, "unknown", "realization-failed") : faultOutcome(manifest, invocation, "unknown", "invalid-realization-outcome");
	}
}
/** Create an exact portable envelope for one validated Binding mode. */
async function createHandoffInvocation(manifestValue, interactionId, mode, input) {
	const manifest = await validateProjectionBindingManifest(manifestValue);
	const interaction = validatedManifests.get(manifest).interactions.get(interactionId)?.get(mode);
	if (!interaction) failHandoff("MODE_NOT_EXPOSED", "interaction", "Binding does not expose the requested interaction mode");
	return validateHandoffInvocation({
		version: 1,
		bindingDigest: manifest.bindingDigest,
		installationId: manifest.installationId,
		interactionId: interaction.interactionId,
		expectedContractDigest: interaction.expectedContractDigest,
		actualContractDigest: interaction.actualContractDigest,
		mode: interaction.mode,
		realizationId: interaction.realizationId,
		input
	});
}
/** Bind the checked seam while keeping context invocation-scoped. */
async function createCheckedHandoff(binding) {
	const source = binding.manifest;
	const immutable = hasImmutableManifest(binding, source);
	const manifest = await validateProjectionBindingManifest(source);
	return Object.freeze({
		manifest,
		async invoke(invocation, context) {
			return immutable ? executeWithManifest(binding, manifest, validateHandoffInvocation(invocation), context) : executeHandoff(binding, invocation, context);
		}
	});
}
//#endregion
export { HandoffError, createCheckedHandoff, createHandoffInvocation, executeHandoff, validateHandoffInvocation, validateHandoffOutcome, validateHandoffOutcomeAgainstManifest, validateHandoffResponse, validateProjectionBindingManifest };
