import { a as ipcFetchChannel, c as dispatchHandler, d as serializeFetchResponse, i as installElectronIpcBridge, l as projectionRequest, n as createElectronIpcFetch, o as deserializeFetchRequest, r as electronIpcTransport, s as deserializeFetchResponse, t as allowElectronSender, u as serializeFetchRequest } from "./chunks/ipc-2ZpSg71u.js";
import { createServer } from "node:http";
import { sendFetchResponse, toFetchRequest } from "@foxworth/boundary/http/node";
//#region packages/adapters/electron/src/projectionMain.ts
var preparedSchemes = /* @__PURE__ */ new WeakMap();
var RESERVED_SCHEMES = /* @__PURE__ */ new Set([
	"about",
	"blob",
	"data",
	"electron",
	"file",
	"http",
	"https",
	"javascript"
]);
function schemeName(value) {
	if (value === false) return void 0;
	const scheme = value;
	if (!/^[a-z][a-z0-9+.-]*$/u.test(scheme) || RESERVED_SCHEMES.has(scheme)) throw new TypeError(`@foxworth/boundary/electron: invalid protocol scheme: ${scheme}`);
	return scheme;
}
function protocolUrlFor(scheme) {
	return scheme ? `${scheme}://projection` : "";
}
/**
* Register the privileged in-process scheme. Must run before `app.ready`.
* `createProjectionElectronMain` calls this when the app is not yet ready.
*/
function prepareProjectionElectron(electron, options) {
	const scheme = schemeName(options.scheme);
	if (!scheme || !electron.protocol || electron.app.isReady()) return;
	const prepared = preparedSchemes.get(electron.protocol) ?? /* @__PURE__ */ new Set();
	if (prepared.has(scheme)) return;
	electron.protocol.registerSchemesAsPrivileged([{
		scheme,
		privileges: {
			standard: true,
			secure: true,
			supportFetchAPI: true,
			corsEnabled: true,
			stream: true
		}
	}]);
	prepared.add(scheme);
	preparedSchemes.set(electron.protocol, prepared);
}
function listen(server, port) {
	return new Promise((resolve, reject) => {
		server.once("error", reject);
		server.listen(port, "127.0.0.1", () => {
			server.off("error", reject);
			const address = server.address();
			if (!address || typeof address === "string") {
				reject(/* @__PURE__ */ new Error("@foxworth/boundary/electron: HTTP server has no TCP address"));
				return;
			}
			resolve(`http://127.0.0.1:${address.port}`);
		});
	});
}
function closeServer(server) {
	if (!server?.listening) return Promise.resolve();
	return new Promise((resolve, reject) => {
		server.close((error) => error ? reject(error) : resolve());
	});
}
async function closeResources(cleanups, server) {
	let failed = false;
	let firstError;
	for (const cleanup of cleanups.splice(0).reverse()) try {
		await cleanup();
	} catch (error) {
		if (!failed) {
			failed = true;
			firstError = error;
		}
	}
	try {
		await closeServer(server);
	} catch (error) {
		if (!failed) {
			failed = true;
			firstError = error;
		}
	}
	if (failed) throw firstError;
}
function windowOptionsFor(options, partition) {
	const persist = Boolean(options.windowName) && options.persistWindowState !== false;
	const requested = options.windowOptions ?? {};
	return {
		width: 1100,
		height: 800,
		...persist ? {
			name: options.windowName,
			windowStatePersistence: true
		} : {},
		...requested,
		webPreferences: {
			contextIsolation: true,
			nodeIntegration: false,
			sandbox: true,
			partition,
			...requested.webPreferences
		}
	};
}
/**
* Run one explicit Projection HTTP handler in Electron's main process.
* HTTP, a privileged scheme, and IPC are doors to the same handler.
* Renderer placement and window lifecycle remain application decisions.
*/
async function createProjectionElectronMain(options) {
	const { app: electronApp, BrowserWindow } = options.electron;
	const openWindow = options.openWindow !== false;
	const scheme = schemeName(options.scheme);
	const partition = options.partition;
	if (!partition.trim()) throw new TypeError("@foxworth/boundary/electron: partition must be non-empty");
	const ipcChannel = options.ipcChannel === false ? void 0 : options.ipcChannel;
	const protocolUrl = protocolUrlFor(scheme);
	const dispatch = (request) => dispatchHandler(options.handler, request);
	prepareProjectionElectron(options.electron, { scheme: options.scheme });
	await electronApp.whenReady();
	let server;
	const cleanups = [];
	let baseUrl = protocolUrl;
	let window;
	try {
		let httpUrl;
		const port = options.port;
		if (port !== false) {
			server = createServer(async (incoming, outgoing) => {
				try {
					const request = toFetchRequest(incoming, { origin: `http://${incoming.headers.host ?? "127.0.0.1"}` });
					const response = await dispatch(request);
					await sendFetchResponse(outgoing, response, incoming.method ?? "GET");
				} catch {
					if (!outgoing.headersSent) outgoing.writeHead(500, { "content-type": "text/plain; charset=utf-8" });
					if (!outgoing.writableEnded) outgoing.end("Internal Server Error");
				}
			});
			httpUrl = await listen(server, port);
		}
		if (ipcChannel && options.electron.ipcMain) {
			const ipcOptions = options.ipc;
			const bridgeOptions = ipcOptions && ipcOptions.ipcHandler !== void 0 && ipcOptions.createContext !== void 0 ? {
				validateSender: ipcOptions.validateSender,
				createContext: ipcOptions.createContext,
				ipcHandler: ipcOptions.ipcHandler
			} : { validateSender: ipcOptions?.validateSender ?? (() => false) };
			cleanups.push(installElectronIpcBridge(options.electron.ipcMain, options.handler, ipcChannel, bridgeOptions));
		}
		if (scheme && options.electron.session) {
			const session = options.electron.session.fromPartition(partition);
			session.protocol.handle(scheme, (request) => dispatch(request));
			cleanups.push(() => {
				session.protocol.unhandle(scheme);
			});
		}
		baseUrl = httpUrl ?? protocolUrl;
		if (openWindow) window = new BrowserWindow(windowOptionsFor(options, partition));
		if (options.onReady) await options.onReady({
			baseUrl,
			protocolUrl,
			window,
			dispatch
		});
		else if (window && options.rendererUrl) await window.loadURL(options.rendererUrl);
	} catch (error) {
		try {
			await closeResources(cleanups, server);
		} catch {}
		throw error;
	}
	return Object.freeze({
		baseUrl,
		protocolUrl,
		window,
		dispatch,
		close: () => closeResources(cleanups, server)
	});
}
//#endregion
export { allowElectronSender, createElectronIpcFetch, createProjectionElectronMain, deserializeFetchRequest, deserializeFetchResponse, dispatchHandler, electronIpcTransport, installElectronIpcBridge, ipcFetchChannel, prepareProjectionElectron, projectionRequest, serializeFetchRequest, serializeFetchResponse };
