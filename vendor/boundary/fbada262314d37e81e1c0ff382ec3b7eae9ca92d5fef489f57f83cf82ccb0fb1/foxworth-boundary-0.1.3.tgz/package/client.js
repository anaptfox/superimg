import { a as snapshotProjectedHandle, c as RemoteExecutionError, d as RemoteProtocolRejection, l as RemoteInvocationError, o as AdapterError, r as interactionKey, s as RemoteDomainError, u as RemoteProtocolError } from "./chunks/resolution-DipfP_4a.js";
import { createInteractionCacheScope, footprintsFor, indexInteractionFootprints, invalidateReadsForChange, invalidateReadsForObservation, isReadInteraction, mountRead, peekFootprints, readInvalidatedBy, refreshReadsForClient, watchInteraction } from "./client/cache.js";
import { t as subscribeToObservations } from "./chunks/observationClient-BSoi1fkw.js";
import { normalizeJson } from "@foxworth/boundary/program";
import { createHandoffInvocation, validateHandoffResponse, validateProjectionBindingManifest } from "@foxworth/boundary/handoff";
//#region packages/callers/client/src/interaction.ts
function snapshot(phase, result, error, availability = "available") {
	return Object.freeze({
		phase,
		availability,
		result,
		error,
		isPending: phase === "pending"
	});
}
function asError(value) {
	return value instanceof Error ? value : new Error(String(value));
}
function createInvocationState(client, handleValue, mode, options = {}) {
	const handle = snapshotProjectedHandle(handleValue, "createInvocationState.handle");
	if (!handle.modes.includes(mode)) throw new AdapterError("INTERACTION_NOT_EXPOSED", handle.interactionId, `${mode} is absent from the projected handle`);
	let current = snapshot("idle", void 0, void 0);
	let active = false;
	const listeners = /* @__PURE__ */ new Set();
	const publish = (next) => {
		current = next;
		for (const listener of [...listeners]) try {
			listener();
		} catch {}
	};
	const blocked = () => {
		if (current.availability !== "available") return current.availability;
	};
	return Object.freeze({
		getSnapshot: () => current,
		subscribe(listener) {
			if (current.availability === "disposed") throw new Error("interaction interaction was disposed");
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		async invoke(...args) {
			const state = blocked();
			if (state !== void 0) return Promise.reject(/* @__PURE__ */ new Error(`interaction interaction is ${state}; create a fresh interaction before invoking again`));
			if (active) return Promise.reject(/* @__PURE__ */ new Error("interaction interaction already has an invocation in flight"));
			active = true;
			publish(snapshot("pending", current.result, void 0, current.availability));
			try {
				const value = mode === "direct" ? await client.call(handle, ...args) : await client.request(handle, ...args);
				if (mode === "direct") invalidateReadsForChange(client, handle, options.scope).catch(() => {});
				publish(snapshot("succeeded", value, void 0, current.availability));
				return value;
			} catch (caught) {
				const error = asError(caught);
				const phase = error.certainty === "unknown" ? "uncertain" : error instanceof AdapterError && (error.code === "STALE_BINDING" || error.code === "STALE_CONTRACT" || error.code === "STALE_REFERENCE") ? "stale" : "failed";
				const availability = phase === "stale" && current.availability === "available" ? "stale" : current.availability;
				publish(snapshot(phase, current.result, error, availability));
				throw error;
			} finally {
				active = false;
			}
		},
		markStale() {
			if (current.availability !== "disposed") publish(snapshot(current.phase === "idle" ? "stale" : current.phase, current.result, current.error, "stale"));
		},
		disconnect() {
			if (current.availability !== "disposed") publish(snapshot(current.phase === "idle" ? "disconnected" : current.phase, current.result, current.error, "disconnected"));
		},
		dispose() {
			if (current.availability === "disposed") return;
			publish(snapshot(current.phase === "idle" ? "disposed" : current.phase, current.result, current.error, "disposed"));
			listeners.clear();
		}
	});
}
/**
* Explicit proposal submission plus observation through a host-authorized
* public reader. Its function type does not establish authorization or
* redaction; the host must supply an authenticated public-only reader.
*/
function createProposalInteraction(client, handle, observeStatus) {
	if (typeof observeStatus !== "function") throw new TypeError("a public status reader function is required");
	const invocation = createInvocationState(client, handle, "request");
	let disposed = false;
	let generation = 0;
	let current = Object.freeze({
		proposal: void 0,
		status: void 0,
		error: void 0,
		isPending: false
	});
	const listeners = /* @__PURE__ */ new Set();
	const publish = (next) => {
		if (disposed) return;
		current = Object.freeze(next);
		for (const listener of [...listeners]) try {
			listener();
		} catch {}
	};
	const stopRetirement = invocation.subscribe(() => {
		const availability = invocation.getSnapshot().availability;
		if (availability === "available") return;
		generation += 1;
		if (current.proposal !== void 0 || current.status !== void 0 || current.error !== void 0 || current.isPending) publish({
			proposal: void 0,
			status: void 0,
			error: void 0,
			isPending: false
		});
		if (availability === "disposed") {
			disposed = true;
			listeners.clear();
			stopRetirement();
		}
	});
	return Object.freeze({
		invocation,
		getStatusSnapshot: () => current,
		subscribeStatus(listener) {
			if (disposed) throw new Error("proposal interaction was disposed");
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		async observe(proposal) {
			if (disposed) return Promise.reject(/* @__PURE__ */ new Error("proposal interaction was disposed"));
			const availability = invocation.getSnapshot().availability;
			if (availability !== "available") return Promise.reject(/* @__PURE__ */ new Error(`proposal interaction is ${availability}; create a fresh interaction before observing again`));
			const mine = ++generation;
			publish({
				proposal,
				status: void 0,
				error: void 0,
				isPending: true
			});
			try {
				const status = await observeStatus(proposal);
				if (!disposed && mine === generation && invocation.getSnapshot().availability === "available") publish({
					proposal,
					status,
					error: void 0,
					isPending: false
				});
				return status;
			} catch (caught) {
				const error = asError(caught);
				if (!disposed && mine === generation && invocation.getSnapshot().availability === "available") publish({
					proposal,
					status: void 0,
					error,
					isPending: false
				});
				throw error;
			}
		},
		markStale() {
			invocation.markStale();
		},
		disconnect() {
			invocation.disconnect();
		},
		dispose() {
			invocation.dispose();
		}
	});
}
//#endregion
//#region packages/callers/client/src/client.ts
function assertTransport(transport) {
	if (!transport || typeof transport !== "object" || typeof transport.inspect !== "function" || typeof transport.invoke !== "function") throw new AdapterError("INVALID_DECLARATION", "createProjectionClient.transport", "transport must provide inspect() and invoke()");
}
function portableInput(interactionId, inputArity, args) {
	if (args.length !== inputArity) throw new AdapterError("INVALID_DECLARATION", `${interactionId}.arguments`, inputArity === 0 ? "this interaction accepts no input" : "this interaction requires one input");
	try {
		return inputArity === 0 ? null : normalizeJson(args[0], `${interactionId}.input`);
	} catch (cause) {
		throw new AdapterError("SCHEMA_MISMATCH", `${interactionId}.input`, "input is not portable JSON", { cause });
	}
}
function throwFailure(outcome, expectedContractDigest) {
	const result = outcome.result;
	if (result.kind === "declared-error") throw new RemoteDomainError(outcome.interactionId, expectedContractDigest, Object.freeze({
		code: result.code,
		details: result.details
	}));
	if (result.kind === "denied") throw new RemoteProtocolError(result.code, outcome.interactionId, "the interaction was denied", outcome.certainty);
	if (result.kind === "fault") throw new RemoteExecutionError(outcome.interactionId, outcome.certainty, result.cause, result.issues);
	throw new AdapterError("INVALID_RESPONSE", "response.result", "remote returned the wrong result kind");
}
/** Build a client pinned to the first exact version 1 Binding handshake. */
function createProjectionClient(transport) {
	assertTransport(transport);
	const handshake = Promise.resolve().then(async () => {
		let value;
		try {
			value = await transport.inspect();
		} catch (error) {
			if (error instanceof AdapterError) throw error;
			throw new AdapterError("TRANSPORT_FAILURE", "transport.inspect", "the Binding handshake failed", { cause: error });
		}
		try {
			const manifest = await validateProjectionBindingManifest(value);
			return {
				manifest,
				interactions: new Map(manifest.interactions.map((interaction) => [interactionKey(interaction.interactionId, interaction.mode), interaction]))
			};
		} catch (cause) {
			throw new AdapterError("INVALID_RESPONSE", "transport.inspect", "the remote Binding manifest is invalid", { cause });
		}
	});
	handshake.catch(() => {});
	async function invoke(mode, interactionId, input, handle) {
		const { manifest, interactions } = await handshake;
		const interaction = interactions.get(interactionKey(interactionId, mode));
		if (!interaction) throw new AdapterError("INTERACTION_NOT_EXPOSED", interactionId, `${interactionId} ${mode} is absent from the pinned Binding`);
		if (handle && (handle.contractDigest !== interaction.expectedContractDigest || handle.inputArity !== interaction.inputArity || !handle.modes.includes(mode))) throw new AdapterError("STALE_REFERENCE", interactionId, "projected handle does not match the pinned Binding");
		const invocation = await createHandoffInvocation(manifest, interactionId, mode, input);
		let raw;
		try {
			raw = await transport.invoke(invocation);
		} catch (error) {
			if (error instanceof RemoteProtocolRejection) throw error;
			throw new RemoteInvocationError("transport", "the remote invocation may have started but no outcome was received", { cause: error });
		}
		let outcome;
		try {
			outcome = await validateHandoffResponse(manifest, invocation, raw);
		} catch (cause) {
			throw new RemoteInvocationError("response", "the remote invocation returned an invalid outcome; its consequence is unknown", { cause });
		}
		if (outcome.result.kind === "returned") return outcome.result.value;
		if (outcome.result.kind === "proposed") return outcome.result.proposal;
		return throwFailure(outcome, interaction.expectedContractDigest);
	}
	return Object.freeze({
		inspect: async () => (await handshake).manifest,
		async call(handleValue, ...args) {
			const handle = snapshotProjectedHandle(handleValue, "client.call.handle");
			const input = portableInput(handle.interactionId, handle.inputArity, args);
			return invoke("direct", handle.interactionId, input, handle);
		},
		async request(handleValue, ...args) {
			const handle = snapshotProjectedHandle(handleValue, "client.request.handle");
			const input = portableInput(handle.interactionId, handle.inputArity, args);
			return invoke("request", handle.interactionId, input, handle);
		},
		async callRaw(interactionId, input) {
			const { interactions } = await handshake;
			const interaction = interactions.get(interactionKey(interactionId, "direct"));
			if (!interaction) throw new AdapterError("INTERACTION_NOT_EXPOSED", interactionId, `${interactionId} direct is absent from the pinned Binding`);
			return invoke("direct", interactionId, portableInput(interactionId, interaction.inputArity, interaction.inputArity === 0 ? [] : [input]));
		},
		async requestRaw(interactionId, input) {
			const { interactions } = await handshake;
			const interaction = interactions.get(interactionKey(interactionId, "request"));
			if (!interaction) throw new AdapterError("INTERACTION_NOT_EXPOSED", interactionId, `${interactionId} request is absent from the pinned Binding`);
			return invoke("request", interactionId, portableInput(interactionId, interaction.inputArity, interaction.inputArity === 0 ? [] : [input]));
		}
	});
}
/**
* Hydrate projected handles from a Binding `inspect()` handshake.
* The browser never compiles interactions to call.
*/
async function handlesFromBinding(client) {
	const manifest = await client.inspect();
	const byAlias = /* @__PURE__ */ new Map();
	for (const interaction of manifest.interactions) {
		const existing = byAlias.get(interaction.alias);
		if (!existing) {
			byAlias.set(interaction.alias, {
				interactionId: interaction.interactionId,
				contractDigest: interaction.expectedContractDigest,
				inputArity: interaction.inputArity,
				modes: [interaction.mode]
			});
			continue;
		}
		if (!existing.modes.includes(interaction.mode)) existing.modes.push(interaction.mode);
	}
	const handles = {};
	for (const [alias, spec] of byAlias) Object.defineProperty(handles, alias, {
		value: Object.freeze({
			interactionId: spec.interactionId,
			contractDigest: spec.contractDigest,
			inputArity: spec.inputArity,
			modes: Object.freeze([...spec.modes].sort())
		}),
		enumerable: true,
		writable: false,
		configurable: false
	});
	return Object.freeze(handles);
}
/**
* Validate generated, digest-pinned references against the remote Binding.
* The reference value carries its type; callers cannot select a type argument.
*/
async function pinProjectionReferences(client, references) {
	const manifest = await client.inspect();
	for (const [alias, referenceValue] of Object.entries(references)) {
		const reference = snapshotProjectedHandle(referenceValue, `pinProjectionReferences.${alias}`);
		const interactions = manifest.interactions.filter((candidate) => candidate.alias === alias);
		const modes = interactions.map((candidate) => candidate.mode).sort();
		const pinnedModes = [...reference.modes].sort();
		if (interactions.length === 0 || interactions.some((candidate) => candidate.interactionId !== reference.interactionId || candidate.expectedContractDigest !== reference.contractDigest || candidate.inputArity !== reference.inputArity) || modes.length !== pinnedModes.length || modes.some((mode, index) => mode !== pinnedModes[index])) throw new AdapterError("STALE_REFERENCE", alias, "generated reference does not match the pinned Binding");
	}
	return references;
}
//#endregion
export { createInteractionCacheScope, createInvocationState, createProjectionClient, createProposalInteraction, footprintsFor, handlesFromBinding, indexInteractionFootprints, invalidateReadsForChange, invalidateReadsForObservation, isReadInteraction, mountRead, peekFootprints, pinProjectionReferences, readInvalidatedBy, refreshReadsForClient, subscribeToObservations, watchInteraction };
