# Boundary SDK

`@foxworth/boundary` is one package with explicit subpath interfaces. The root
exports native host authoring. Core, discovery, guests, callers, and adapters
are source modules; they are not independently published packages. Optional
runtimes are peer dependencies loaded only by the selected subpath.

```text
packages/
  core/        program, host, handoff, control
  discovery/   reach, bus
  guests/      plugin
  callers/     client, react, mcp, webmcp
  adapters/    http, frameworks, cloudflare, electron, yjs, automerge
```

Use `defineInteraction` from `@foxworth/boundary` for a declaration, then
compile, implement, install, project, and bind it. The host retains its domain
identifiers and execution rules. `@foxworth/boundary/reach` locates a Binding;
`/bus` registers local Reach records; `/plugin` admits guest realizations
against the host's import offer.

Install the SDK once. The Host root requires Zod; the portable `/program`
subpath does not. React, MCP, framework, Electron, Yjs, Automerge, and plugin
runtimes are optional peers required only by their owning subpaths. Yjs and
Automerge subpaths (`/experimental/yjs` and `/experimental/automerge`) are
**experimental** and capture local document versions
for isolated JSON reads; they do not provide a network provider or persistence layer.
Their APIs may change incompatibly; see the
[experimental integration status](../docs/product/current-status.md#experimental-integrations).

The source manifest stays private. Packaging generates one public manifest
and tarball. Applications and executable proofs remain under `examples/`
and `tests/`; Rust remains an independent native implementation under `crates/`.

The Boundary rename changes imports, declaration vocabulary, protocol field
names, identity domains, CLI naming, and WIT namespaces. Regenerate derived
caller references and rebuild guests together with the host. Earlier identity
pins are intentionally incompatible; declarations retain the same host-owned
domain IDs, schemas, footprints, admission, dispatch, and recovery behavior.
