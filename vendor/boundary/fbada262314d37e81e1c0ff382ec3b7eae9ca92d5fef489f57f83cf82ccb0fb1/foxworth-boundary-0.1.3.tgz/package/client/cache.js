import { a as snapshotProjectedHandle, o as AdapterError } from "../chunks/resolution-DipfP_4a.js";
import { normalizeJson, validateInvocationObservation } from "@foxworth/boundary/program";
//#region packages/callers/client/src/cache.ts
var caches = /* @__PURE__ */ new WeakMap();
var scopeReads = /* @__PURE__ */ new WeakMap();
var clientScopes = /* @__PURE__ */ new WeakMap();
function createInteractionCacheScope() {
	const scope = Object.freeze({ kind: "boundary-interaction-cache-scope" });
	scopeReads.set(scope, /* @__PURE__ */ new Set());
	return scope;
}
function scopeFor(client, scope) {
	if (scope) {
		if (!scopeReads.has(scope)) throw new TypeError("an authentic interaction cache scope is required");
		return scope;
	}
	const existing = clientScopes.get(client);
	if (existing) return existing;
	const created = createInteractionCacheScope();
	clientScopes.set(client, created);
	return created;
}
function cacheFor(client) {
	const existing = caches.get(client);
	if (existing) return existing;
	const created = {};
	created.handshake = Promise.resolve().then(() => client.inspect()).catch((error) => {
		if (caches.get(client) === created) caches.delete(client);
		throw error;
	});
	caches.set(client, created);
	return created;
}
/** Index `reads` / `changes` from the Binding's pinned expected Program. */
function indexInteractionFootprints(source) {
	const footprints = /* @__PURE__ */ new Map();
	for (const interaction of source.expectedProgram.interactions) footprints.set(interaction.contract.id, Object.freeze({
		reads: Object.freeze([...interaction.contract.reads]),
		changes: Object.freeze([...interaction.contract.changes])
	}));
	return footprints;
}
/** A completed change invalidates a mounted read when their footprints share a resource. */
function readInvalidatedBy(footprints, readInteractionId, changeInteractionId) {
	const changed = footprints.get(changeInteractionId)?.changes ?? [];
	if (changed.length === 0) return false;
	return (footprints.get(readInteractionId)?.reads ?? []).some((resource) => changed.includes(resource));
}
function isReadInteraction(footprints, interactionId) {
	return (footprints.get(interactionId)?.changes.length ?? -1) === 0;
}
async function footprintsFor(client) {
	const cache = cacheFor(client);
	if (!cache.footprints) cache.footprints = indexInteractionFootprints(await cache.handshake);
	return cache.footprints;
}
/** The footprint index, when the client's handshake has already resolved. */
function peekFootprints(client) {
	return caches.get(client)?.footprints;
}
function mountRead(client, interactionId, refresh, scope) {
	const entry = {
		client,
		interactionId,
		refresh
	};
	cacheFor(client);
	const mountedReads = scopeReads.get(scopeFor(client, scope));
	mountedReads.add(entry);
	return () => {
		mountedReads.delete(entry);
	};
}
function interactionError(caught) {
	return caught instanceof Error ? caught : new Error(String(caught));
}
function abortError() {
	const error = /* @__PURE__ */ new Error("interaction read was disposed");
	error.name = "AbortError";
	return error;
}
function snapshotFor(data, error, isPending) {
	return Object.freeze({
		data,
		error,
		isPending
	});
}
function watchOptions(value) {
	if (value === void 0) return void 0;
	if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError("watchInteraction options must be an object");
	return value;
}
/**
* Read one direct interaction as a small external store. It never invokes a
* change: the pinned Binding and declared footprint are checked before every
* transport call. Invalidation is deliberately scoped to mounted readers.
*/
function watchInteraction(client, handleValue, ...args) {
	const handle = snapshotProjectedHandle(handleValue, "watchInteraction.handle");
	const supplied = args;
	let input;
	let options;
	if (handle.inputArity === 0) {
		if (supplied.length > 1) throw new AdapterError("INVALID_REQUEST", `${handle.interactionId}.arguments`, "this interaction accepts no input");
		options = watchOptions(supplied[0]);
	} else {
		if (supplied.length < 1 || supplied.length > 2) throw new AdapterError("INVALID_REQUEST", `${handle.interactionId}.arguments`, "this interaction requires one input");
		try {
			input = normalizeJson(supplied[0], `${handle.interactionId}.input`);
		} catch {
			throw new AdapterError("SCHEMA_MISMATCH", `${handle.interactionId}.input`, "input is not portable JSON");
		}
		options = watchOptions(supplied[1]);
	}
	let snapshot = snapshotFor(void 0, void 0, false);
	let active;
	let unmount;
	let refreshedSinceMount = false;
	let disposed = false;
	const listeners = /* @__PURE__ */ new Set();
	const publish = (data, error, isPending) => {
		if (disposed) return;
		snapshot = snapshotFor(data, error, isPending);
		for (const listener of [...listeners]) try {
			listener();
		} catch {}
	};
	const assertReadable = async () => {
		if (!handle.modes.includes("direct")) throw new AdapterError("INTERACTION_NOT_EXPOSED", handle.interactionId, "watchInteraction requires a direct projected interaction");
		const cache = cacheFor(client);
		const [manifest, footprints] = await Promise.all([cache.handshake, footprintsFor(client)]);
		const binding = manifest.interactions.find((candidate) => candidate.interactionId === handle.interactionId && candidate.mode === "direct");
		if (!binding) throw new AdapterError("INTERACTION_NOT_EXPOSED", handle.interactionId, "the direct interaction is absent from the pinned Binding");
		if (binding.expectedContractDigest !== handle.contractDigest || binding.inputArity !== handle.inputArity) throw new AdapterError("STALE_REFERENCE", handle.interactionId, "projected handle does not match the pinned Binding");
		const footprint = footprints.get(handle.interactionId);
		if (!footprint) throw new AdapterError("INTERACTION_NOT_EXPOSED", handle.interactionId, "the interaction is absent from the pinned Program");
		if (footprint.changes.length > 0) throw new AdapterError("INVALID_REQUEST", handle.interactionId, "watchInteraction accepts declared reads only");
	};
	const invoke = async (run) => {
		if (disposed) throw abortError();
		publish(snapshot.data, void 0, true);
		run.phase = "preparing";
		await assertReadable();
		if (disposed) throw abortError();
		run.phase = "dispatched";
		const call = client.call;
		const value = handle.inputArity === 0 ? await call(handle) : await call(handle, input);
		if (disposed) throw abortError();
		publish(value, void 0, false);
		return value;
	};
	const start = () => {
		if (disposed) return Promise.reject(abortError());
		refreshedSinceMount = true;
		if (active) {
			if (active.phase === "dispatched") active.trailing = true;
			return active.promise;
		}
		let resolve;
		let reject;
		const promise = new Promise((nextResolve, nextReject) => {
			resolve = nextResolve;
			reject = nextReject;
		});
		const run = {
			phase: "preparing",
			trailing: false,
			promise,
			resolve,
			reject
		};
		active = run;
		(async () => {
			let value;
			let failure;
			do {
				run.trailing = false;
				failure = void 0;
				try {
					value = await invoke(run);
				} catch (caught) {
					failure = caught;
					if (!disposed) publish(snapshot.data, interactionError(caught), false);
				}
			} while (run.trailing && !disposed);
			if (active === run) active = void 0;
			if (disposed) return;
			if (failure !== void 0) run.reject(failure);
			else run.resolve(value);
		})();
		return promise;
	};
	const refresh = () => start();
	const subscribe = (listener) => {
		if (disposed) throw abortError();
		listeners.add(listener);
		if (listeners.size === 1) {
			unmount = mountRead(client, handle.interactionId, async () => {
				await refresh();
			}, options?.scope);
			if (!refreshedSinceMount) refresh().catch(() => {});
		}
		return () => {
			listeners.delete(listener);
			if (listeners.size === 0) {
				unmount?.();
				unmount = void 0;
				refreshedSinceMount = false;
			}
		};
	};
	const dispose = () => {
		if (disposed) return;
		disposed = true;
		unmount?.();
		unmount = void 0;
		listeners.clear();
		active?.reject(abortError());
		active = void 0;
		snapshot = snapshotFor(void 0, void 0, false);
	};
	return Object.freeze({
		getSnapshot: () => snapshot,
		subscribe,
		refresh,
		dispose
	});
}
function readInvalidatedByResources(changeFootprints, readFootprints, readInteractionId, changeInteractionId) {
	const changed = changeFootprints.get(changeInteractionId)?.changes ?? [];
	if (changed.length === 0) return false;
	return (readFootprints.get(readInteractionId)?.reads ?? []).some((resource) => changed.includes(resource));
}
/**
* Refresh every mounted read whose `reads` footprint intersects the change's
* declared `changes` footprint. Reads are client-local by default. Pass the
* same explicit scope to share invalidation across clients. Request proposals
* do not imply completion and therefore do not invalidate reads.
*/
async function invalidateReadsForChange(client, change, scope) {
	const changeFootprints = await footprintsFor(client);
	const changeInteractionId = change.interactionId;
	if (!changeFootprints.has(changeInteractionId)) console.warn(`@foxworth/boundary/client: interaction "${changeInteractionId}" is not in this client's expected Program; no reads were invalidated for it`);
	const jobs = [];
	for (const read of scopeReads.get(scopeFor(client, scope))) if (readInvalidatedByResources(changeFootprints, read.client === client ? changeFootprints : await footprintsFor(read.client), read.interactionId, changeInteractionId)) jobs.push(read.refresh());
	await Promise.all(jobs);
}
/** Refresh potentially affected reads after a host-published outcome. Never repeats the change. */
async function invalidateReadsForObservation(value, scope) {
	const event = validateInvocationObservation(value);
	if (event.certainty === "not-started" || event.changes.length === 0) return;
	const mounted = scopeReads.get(scope);
	if (!mounted) throw new TypeError("an authentic interaction cache scope is required");
	await Promise.all([...mounted].map(async (read) => {
		const manifest = await cacheFor(read.client).handshake;
		if (manifest.installationId !== event.installationId || manifest.installationDigest !== event.installationDigest) return;
		if ((await footprintsFor(read.client)).get(read.interactionId)?.reads.some((resource) => event.changes.includes(resource))) await read.refresh();
	}));
}
/** Refresh this installation's mounted reads after reconnect; never repeats changes. */
async function refreshReadsForClient(client, scope) {
	const mounted = scopeReads.get(scope);
	if (!mounted) throw new TypeError("an authentic interaction cache scope is required");
	const expected = await cacheFor(client).handshake;
	await Promise.all([...mounted].map(async (read) => {
		const actual = await cacheFor(read.client).handshake;
		if (actual.installationId === expected.installationId && actual.installationDigest === expected.installationDigest) await read.refresh();
	}));
}
//#endregion
export { createInteractionCacheScope, footprintsFor, indexInteractionFootprints, invalidateReadsForChange, invalidateReadsForObservation, isReadInteraction, mountRead, peekFootprints, readInvalidatedBy, refreshReadsForClient, watchInteraction };
