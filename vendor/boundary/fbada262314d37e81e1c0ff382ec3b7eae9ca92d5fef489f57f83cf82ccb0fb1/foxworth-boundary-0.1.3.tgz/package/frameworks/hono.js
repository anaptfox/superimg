//#region packages/adapters/frameworks/src/hono.ts
/**
* Turn one explicit Projection HTTP handler into Hono middleware.
* The Hono application chooses the route or prefix where it is installed.
*/
function mountProjection(handler) {
	return (context) => handler(context.req.raw);
}
/**
* Adapt a per-invocation Projection handler factory to Hono middleware.
*
* Unlike {@link mountProjection}, this preserves Hono's typed Context for the
* host to derive invocation-scoped context. It does not provide automatic
* Hono RPC routing or infer any authority from a route or middleware value.
*/
function createProjectionHonoMiddleware(createHandler) {
	return async (context) => {
		return (await createHandler(context))(context.req.raw);
	};
}
//#endregion
export { createProjectionHonoMiddleware, mountProjection };
