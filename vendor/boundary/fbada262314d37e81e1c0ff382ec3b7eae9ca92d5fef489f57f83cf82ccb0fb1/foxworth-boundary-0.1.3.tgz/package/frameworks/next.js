import { o as AdapterError } from "../chunks/resolution-DipfP_4a.js";
import { indexInteractionFootprints, isReadInteraction } from "../client/cache.js";
//#region packages/adapters/frameworks/src/next.ts
function assertOptions(value) {
	if (!value || typeof value !== "object") throw new TypeError("createNextServerCaller requires options");
	const options = value;
	if (!options.binding || typeof options.context !== "function") throw new TypeError("createNextServerCaller requires a Binding and per-invocation context function");
	if (options.afterAction !== void 0 && typeof options.afterAction !== "function") throw new TypeError("createNextServerCaller.afterAction must be a function");
	if (options.onCacheError !== void 0 && typeof options.onCacheError !== "function") throw new TypeError("createNextServerCaller.onCacheError must be a function");
}
/**
* Adapt one existing Binding to Next server reads and Server Actions.
*
* The application owns installation lifetime and authentication. `context()`
* deliberately runs for each call, so this helper cannot turn a selected
* projection, module singleton, or prior request into authority.
*/
function createNextServerCaller(options) {
	assertOptions(options);
	const caller = options.binding.connect();
	const footprints = indexInteractionFootprints(options.binding.manifest);
	function assertDeclaredRead(handle) {
		if (!isReadInteraction(footprints, handle.interactionId)) throw new AdapterError("INVALID_DECLARATION", `${handle.interactionId}.reads`, "Next server reads require a selected interaction with no declared changes; use action.call instead");
	}
	async function direct(handle, args) {
		assertDeclaredRead(handle);
		const context = await options.context();
		const call = caller.call;
		return handle.inputArity === 0 ? await call(handle, context) : await call(handle, args[0], context);
	}
	async function afterCompletedAction(handle, args) {
		const context = await options.context();
		const call = caller.call;
		const value = handle.inputArity === 0 ? await call(handle, context) : await call(handle, args[0], context);
		const completion = Object.freeze({
			context,
			interactionId: handle.interactionId,
			bindingDigest: options.binding.manifest.bindingDigest,
			installationId: options.binding.manifest.installationId
		});
		if (options.afterAction) try {
			await options.afterAction(completion);
		} catch (error) {
			try {
				options.onCacheError?.(error, completion);
			} catch {}
		}
		return value;
	}
	async function request(handle, args) {
		const context = await options.context();
		const requestCaller = caller;
		return handle.inputArity === 0 ? await requestCaller.request(handle, context) : await requestCaller.request(handle, args[0], context);
	}
	const read = Object.freeze({ call: async (handle, ...args) => direct(handle, args) });
	const action = Object.freeze({
		call: async (handle, ...args) => afterCompletedAction(handle, args),
		request: async (handle, ...args) => request(handle, args)
	});
	return Object.freeze({
		read,
		action
	});
}
/**
* Bind one explicit HTTP projection to Next App Router method exports.
* Route placement and segment config stay in the caller's `route.ts` file.
*/
function createProjectionHandlers(handler) {
	return Object.freeze({
		GET: handler,
		POST: handler,
		PUT: handler,
		PATCH: handler,
		DELETE: handler,
		HEAD: handler,
		OPTIONS: handler
	});
}
//#endregion
export { createNextServerCaller, createProjectionHandlers };
