import { a as snapshotProjectedHandle, i as modeForHandle, o as AdapterError, r as interactionKey } from "../chunks/resolution-DipfP_4a.js";
import { a as faultResult, c as sanitizedInternalResult, o as invokePreparedInteraction, s as prepareExposedInteraction, t as compileExposure } from "../chunks/remote-BuX2MHpJ.js";
import { createCheckedHandoff } from "@foxworth/boundary/handoff";
import { initTRPC } from "@trpc/server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
//#region packages/adapters/frameworks/src/trpc.ts
var procedureDeclarations = /* @__PURE__ */ new WeakSet();
var PROCEDURE_NAME = /^[A-Za-z][A-Za-z0-9_-]*(?:\.[A-Za-z][A-Za-z0-9_-]*)*$/u;
function procedure(handleValue, options) {
	const handle = snapshotProjectedHandle(handleValue, "procedure.handle");
	const mode = modeForHandle(handle, options.mode, "procedure.mode");
	const name = options.name ?? handle.interactionId;
	if (!PROCEDURE_NAME.test(name)) throw new AdapterError("INVALID_DECLARATION", "procedure.name", "procedure name must contain dot-separated identifier segments");
	if (options.kind !== "query" && options.kind !== "mutation") throw new AdapterError("INVALID_DECLARATION", "procedure.kind", "procedure kind must be query or mutation");
	const declaration = Object.freeze({
		handle,
		mode,
		name,
		kind: options.kind
	});
	procedureDeclarations.add(declaration);
	return declaration;
}
function parseProcedureInput(handle, input) {
	if (handle.inputArity === 0) return input === void 0 ? null : input;
	return input;
}
function setLeaf(tree, path, leaf) {
	const segments = path.split(".");
	let cursor = tree;
	for (const [index, segment] of segments.entries()) {
		const last = index === segments.length - 1;
		const existing = cursor[segment];
		if (last) {
			if (existing !== void 0) throw new AdapterError("DUPLICATE_DECLARATION", `procedures.${path}`, `duplicate or colliding tRPC procedure: ${path}`);
			cursor[segment] = Object.freeze({ leaf });
			return;
		}
		if (existing && "leaf" in existing) throw new AdapterError("DUPLICATE_DECLARATION", `procedures.${path}`, `tRPC procedure collides with namespace: ${path}`);
		cursor = cursor[segment] ??= {};
	}
}
/** Create a router containing only explicitly declared Binding procedures. */
async function createTrpcRouter(options) {
	if (!options || typeof options.context !== "function") throw new AdapterError("INVALID_DECLARATION", "createTrpcRouter.context", "context must resolve one invocation-scoped host value");
	for (const [index, declaration] of options.procedures.entries()) if (!procedureDeclarations.has(declaration)) throw new AdapterError("INVALID_DECLARATION", `procedures[${index}]`, "procedures must be created by procedure()");
	let exposure;
	try {
		const handoff = await createCheckedHandoff(options.binding);
		exposure = await compileExposure(handoff, options.procedures.map((entry) => ({
			handle: entry.handle,
			mode: entry.mode
		})));
	} catch {
		throw new AdapterError("INVALID_DECLARATION", "createTrpcRouter.procedures", "the tRPC router could not compile its declared exposure");
	}
	const t = initTRPC.context().create();
	const tree = {};
	for (const declaration of options.procedures) {
		const exposed = exposure.interactions.get(interactionKey(declaration.handle.interactionId, declaration.mode));
		if (!exposed) throw new AdapterError("INVALID_DECLARATION", `procedures.${declaration.name}`, "the tRPC procedure is absent from the compiled exposure");
		const resolver = async (input, context) => {
			let prepared;
			let hostContext;
			try {
				hostContext = await options.context(context);
				prepared = await prepareExposedInteraction({
					exposure,
					handle: declaration.handle,
					mode: declaration.mode,
					input
				});
			} catch {
				return faultResult(exposure, exposed, "realization-failed");
			}
			try {
				return await invokePreparedInteraction(exposure, prepared.invocation, hostContext);
			} catch {
				return sanitizedInternalResult(exposure, prepared.exposed);
			}
		};
		const base = t.procedure.input((input) => parseProcedureInput(declaration.handle, input));
		const leaf = declaration.kind === "query" ? base.query(({ input, ctx }) => resolver(input, ctx)) : base.mutation(({ input, ctx }) => resolver(input, ctx));
		setLeaf(tree, declaration.name, leaf);
	}
	const build = (node) => t.router(Object.fromEntries(Object.entries(node).map(([name, childValue]) => {
		const child = childValue;
		return [name, "leaf" in child ? child.leaf : build(child)];
	})));
	return build(tree);
}
function createTrpcHandler(options) {
	const endpoint = options.endpoint ?? "/trpc";
	const router = createTrpcRouter({
		binding: options.binding,
		context: (context) => options.context(context.request),
		procedures: options.procedures
	});
	return async (request) => {
		let ready;
		try {
			ready = await router;
		} catch {
			return Response.json({
				certainty: "not-started",
				error: {
					kind: "internal",
					code: "ADAPTER_INITIALIZATION_FAILED",
					message: "The tRPC adapter could not initialize its declared exposure."
				}
			}, { status: 500 });
		}
		return fetchRequestHandler({
			endpoint,
			req: request,
			router: ready,
			createContext: () => ({ request })
		});
	};
}
//#endregion
export { createTrpcHandler, createTrpcRouter, procedure };
