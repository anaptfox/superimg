import { sendFetchResponse, toFetchRequest } from "../http/node.js";
import { isAbsolute, resolve, win32 } from "node:path";
//#region packages/adapters/frameworks/src/viteLifecycle.ts
var freeze = (value) => Object.freeze(value);
function validCandidate(value) {
	if (!value || typeof value !== "object") throw new TypeError("candidate must be an object");
	if (!value.generation || typeof value.generation !== "string") throw new TypeError("candidate.generation must be a non-empty string");
	if (typeof value.handler !== "function") throw new TypeError("candidate.handler must be a function");
	if (value.dispose !== void 0 && typeof value.dispose !== "function") throw new TypeError("candidate.dispose must be a function");
}
/**
* Own explicit Vite implementation generations without rebinding outstanding
* requests. Publication follows successful preparation and validation only.
*/
function createProjectionViteLifecycle(options) {
	if (typeof options.entry !== "function") throw new TypeError("entry must be a function");
	let current;
	const candidates = /* @__PURE__ */ new Set();
	const accepted = /* @__PURE__ */ new WeakSet();
	let status = freeze({ state: "idle" });
	let lastDiagnostic;
	let closed = false;
	let closePromise;
	const abort = new AbortController();
	let queue = Promise.resolve();
	const report = (value) => {
		lastDiagnostic = freeze(value);
		try {
			options.onDiagnostic?.(lastDiagnostic);
		} catch {}
	};
	const disposeCandidate = async (candidate, code) => {
		if ("disposed" in candidate) {
			if (candidate.disposed) return;
			candidate.disposed = true;
		}
		try {
			await candidate.dispose?.();
		} catch (cause) {
			report({
				code,
				message: `Vite ${code === "RETIRED_DISPOSAL_FAILED" ? "retired" : "rejected"} generation disposal failed`,
				generation: candidate.generation,
				cause
			});
		}
	};
	const cleanup = (candidate) => {
		if (candidate.cleanup || !candidate.retired || candidate.active !== 0) return candidate.cleanup;
		candidate.cleanup = disposeCandidate(candidate, "RETIRED_DISPOSAL_FAILED").then(() => {
			candidates.delete(candidate);
			candidate.resolveIdle();
		});
		return candidate.cleanup;
	};
	const retire = (candidate) => {
		candidate.retired = true;
		cleanup(candidate);
	};
	const run = async (mode, kind, loadModule) => {
		if (closed) return status;
		status = freeze({
			state: "starting",
			...current ? { generation: current.generation } : {}
		});
		let prepared;
		let disposePrepared = false;
		try {
			prepared = await options.entry({
				mode,
				...current ? { previousGeneration: current.generation } : {},
				signal: abort.signal,
				...loadModule ? { loadModule } : {}
			});
			disposePrepared = !!prepared && typeof prepared === "object" && !accepted.has(prepared);
			validCandidate(prepared);
			if (accepted.has(prepared)) throw new Error("candidate object was already accepted");
			if (current?.generation === prepared.generation) throw new Error(`generation is already published: ${prepared.generation}`);
			await options.validate?.(prepared);
			if (closed) throw new Error("lifecycle closed while preparing candidate");
			let resolveIdle;
			const next = {
				...prepared,
				active: 0,
				leases: /* @__PURE__ */ new Set(),
				retired: false,
				disposed: false,
				idle: new Promise((resolve) => {
					resolveIdle = resolve;
				}),
				resolveIdle
			};
			accepted.add(prepared);
			candidates.add(next);
			const previous = current;
			current = next;
			status = freeze({
				state: "ready",
				generation: next.generation
			});
			lastDiagnostic = void 0;
			if (previous) retire(previous);
			return status;
		} catch (cause) {
			if (prepared && disposePrepared) await disposeCandidate(prepared, "CANDIDATE_DISPOSAL_FAILED");
			const failure = freeze({
				code: "CANDIDATE_REJECTED",
				message: `Vite ${kind} candidate was rejected; the previous generation remains active`,
				...prepared?.generation ? { generation: prepared.generation } : {},
				cause
			});
			report(failure);
			status = freeze({
				state: current ? "ready" : "failed",
				...current ? { generation: current.generation } : {},
				diagnostic: failure
			});
			return status;
		}
	};
	const enqueue = (mode, kind, loadModule) => {
		const result = queue.then(() => run(mode, kind, loadModule));
		queue = result.then(() => void 0, () => void 0);
		return result;
	};
	const release = (candidate, lease) => {
		if (!candidate.leases.delete(lease)) return;
		candidate.active -= 1;
		if (candidate.retired && candidate.active === 0) cleanup(candidate);
	};
	return {
		start: (mode, loadModule) => enqueue(mode, "start", loadModule),
		replace: (mode, loadModule) => enqueue(mode, "replace", loadModule),
		status: () => status,
		diagnostic: () => lastDiagnostic,
		async dispatch(request) {
			if (closed) {
				const value = freeze({
					code: "CLOSED",
					message: "Vite projection lifecycle is closed"
				});
				report(value);
				return new Response(JSON.stringify({
					error: value.message,
					code: value.code
				}), {
					status: 503,
					headers: { "content-type": "application/json; charset=utf-8" }
				});
			}
			const candidate = current;
			if (!candidate) {
				const value = freeze({
					code: "NOT_READY",
					message: "Vite projection is not ready"
				});
				report(value);
				return new Response(JSON.stringify({
					error: value.message,
					code: value.code
				}), {
					status: 503,
					headers: { "content-type": "application/json; charset=utf-8" }
				});
			}
			const expected = request.headers.get("x-boundary-vite-generation");
			if (expected !== null && expected !== candidate.generation) {
				const value = freeze({
					code: "STALE_CLIENT",
					message: `client generation ${expected} is stale; current generation is ${candidate.generation}`,
					generation: expected
				});
				report(value);
				return new Response(JSON.stringify({
					error: value.message,
					code: value.code,
					generation: candidate.generation
				}), {
					status: 409,
					headers: {
						"content-type": "application/json; charset=utf-8",
						"x-boundary-vite-generation": candidate.generation
					}
				});
			}
			let released = false;
			let closeRequested = false;
			let cancelBody = async () => void 0;
			let resolveHandler;
			let resolveBody;
			const handlerDone = new Promise((resolve) => {
				resolveHandler = resolve;
			});
			const bodyReady = new Promise((resolve) => {
				resolveBody = resolve;
			});
			const lease = {
				release: () => {
					if (!released) {
						released = true;
						release(candidate, lease);
					}
				},
				cancel: async () => {
					closeRequested = true;
					try {
						await handlerDone;
						await bodyReady;
						await cancelBody();
					} finally {
						lease.release();
					}
				}
			};
			candidate.active += 1;
			candidate.leases.add(lease);
			try {
				const response = await candidate.handler(request);
				resolveHandler();
				if (!response.body) {
					resolveBody();
					lease.release();
					const headers = new Headers(response.headers);
					headers.set("x-boundary-vite-generation", candidate.generation);
					return new Response(null, {
						status: response.status,
						statusText: response.statusText,
						headers
					});
				}
				const reader = response.body.getReader();
				let controller;
				cancelBody = async () => {
					try {
						await reader.cancel();
					} finally {
						try {
							controller?.error(/* @__PURE__ */ new Error("Vite projection lifecycle closed"));
						} catch {}
					}
				};
				const stream = new ReadableStream({
					start(value) {
						controller = value;
					},
					async pull(value) {
						try {
							const item = await reader.read();
							if (item.done) {
								value.close();
								lease.release();
							} else value.enqueue(item.value);
						} catch (error) {
							value.error(error);
							lease.release();
						}
					},
					async cancel(reason) {
						try {
							await reader.cancel(reason);
						} finally {
							lease.release();
						}
					}
				});
				resolveBody();
				if (closeRequested) await cancelBody();
				const headers = new Headers(response.headers);
				headers.set("x-boundary-vite-generation", candidate.generation);
				return new Response(stream, {
					status: response.status,
					statusText: response.statusText,
					headers
				});
			} catch (error) {
				resolveHandler();
				resolveBody();
				lease.release();
				throw error;
			}
		},
		dispose() {
			if (closePromise) return closePromise;
			closePromise = (async () => {
				if (closed) return;
				closed = true;
				abort.abort();
				await queue;
				const live = [...candidates];
				for (const candidate of live) {
					candidate.retired = true;
					const leases = [...candidate.leases];
					await Promise.allSettled(leases.map((lease) => lease.cancel()));
					cleanup(candidate);
				}
				await Promise.all(live.map((candidate) => candidate.cleanup ?? candidate.idle));
				current = void 0;
				status = freeze({ state: "closed" });
			})();
			return closePromise;
		}
	};
}
//#endregion
//#region packages/adapters/frameworks/src/vite.ts
function mountPaths(value) {
	const paths = typeof value === "string" ? [value] : [...value];
	if (paths.length === 0) throw new TypeError("@foxworth/boundary/frameworks/vite: mount must include at least one path");
	for (const path of paths) if (!path.startsWith("/") || path.includes("?") || path.includes("#")) throw new TypeError(`@foxworth/boundary/frameworks/vite: mount path must start with / and omit query/hash: ${path}`);
	return Object.freeze(paths);
}
function explicitWatchPaths(value, root) {
	const paths = value === void 0 ? [] : typeof value === "string" ? [value] : [...value];
	return Object.freeze(paths.map((path) => isAbsolute(path) || win32.isAbsolute(path) ? path : resolve(root, path)));
}
function internalError() {
	return new Response(JSON.stringify({ error: "Internal Server Error" }), {
		status: 500,
		headers: { "content-type": "application/json; charset=utf-8" }
	});
}
/** Connect middleware around one explicit Projection HTTP handler. */
function createProjectionMiddleware(handler, options = {}) {
	return (incoming, outgoing) => {
		const request = toFetchRequest(incoming);
		(async () => {
			try {
				const response = await handler(request);
				await sendFetchResponse(outgoing, response, incoming.method ?? "GET");
			} catch (error) {
				if (outgoing.headersSent) {
					if (!outgoing.writableEnded) outgoing.end();
					return;
				}
				let response;
				try {
					response = await options.onError?.(error, request) ?? internalError();
				} catch {
					response = internalError();
				}
				try {
					await sendFetchResponse(outgoing, response, incoming.method ?? "GET");
				} catch {
					if (!outgoing.writableEnded) outgoing.end();
				}
			}
		})();
	};
}
/** Mount one injected Projection HTTP handler in Vite dev and preview. */
function mountProjection(options) {
	const paths = mountPaths(options.mount);
	const middleware = createProjectionMiddleware(options.handler, options);
	const install = (server) => {
		for (const path of paths) server.use(path, middleware);
	};
	return {
		name: "boundary-projection",
		configureServer(server) {
			install(server.middlewares);
		},
		configurePreviewServer(server) {
			install(server.middlewares);
		}
	};
}
/** Mounts an explicit, generation-owned entry with Vite dev/preview lifecycle hooks. */
function mountProjectionLifecycle(options) {
	const paths = mountPaths(options.mount);
	const lifecycle = createProjectionViteLifecycle(options);
	const middleware = createProjectionMiddleware((request) => lifecycle.dispatch(request), options);
	const install = (server) => {
		for (const path of paths) server.use(path, middleware);
	};
	const start = (mode, loadModule) => lifecycle.start(mode, loadModule);
	let watchPaths = [];
	let loadModule;
	return {
		name: "boundary-projection-lifecycle",
		async configureServer(server) {
			install(server.middlewares);
			watchPaths = explicitWatchPaths(options.watch, server.config.root);
			if (watchPaths.length > 0) server.watcher.add(watchPaths);
			server.httpServer?.once("close", () => {
				lifecycle.dispose();
			});
			server.watcher.on("close", () => {
				lifecycle.dispose();
			});
			loadModule = typeof server.ssrLoadModule === "function" ? server.ssrLoadModule.bind(server) : void 0;
			await start("development", loadModule);
		},
		async configurePreviewServer(server) {
			install(server.middlewares);
			server.httpServer?.once("close", () => {
				lifecycle.dispose();
			});
			await start("preview");
		},
		async handleHotUpdate(context) {
			if (watchPaths.length === 0 || !watchPaths.includes(context.file)) return context.modules;
			await lifecycle.replace("development", loadModule);
			return context.modules;
		},
		async closeBundle() {
			await lifecycle.dispose();
		}
	};
}
//#endregion
export { createProjectionMiddleware, createProjectionViteLifecycle, mountProjection, mountProjectionLifecycle };
