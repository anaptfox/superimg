import { parentPort, workerData } from "node:worker_threads";
import { transpile } from "@bytecodealliance/jco";
//#region packages/guests/plugin/src/plugin-worker.ts
/** One artifact per worker: termination releases generated ESM and compiled code. */
const port = parentPort;
if (port === null) throw new Error("plugin runtime requires a worker");
const setup = workerData;
const send = (event) => port.postMessage(event);
const bindings = /* @__PURE__ */ new Map();
const camel = (name) => name.replace(/-([a-z0-9])/g, (_, ch) => ch.toUpperCase());
const MAX_REASON_BYTES = 4096;
function bounded(text) {
	const bytes = Buffer.from(text);
	return bytes.byteLength <= MAX_REASON_BYTES ? text : `${bytes.subarray(0, MAX_REASON_BYTES).toString("utf8")}…`;
}
const failed = (reason) => ({
	status: "fault",
	certainty: "unknown",
	reason: bounded(reason)
});
const message = (error) => bounded(error instanceof Error ? error.message : String(error));
function hostFunction(job, binding, name) {
	return (request) => {
		if (typeof request !== "string" || Buffer.byteLength(request) > setup.maxPayloadBytes) throw new Error("host import request exceeds the payload limit");
		const shared = new SharedArrayBuffer(8 + setup.maxPayloadBytes);
		const header = new Int32Array(shared, 0, 2);
		send({
			type: "host",
			job,
			binding,
			name,
			request,
			shared
		});
		Atomics.wait(header, 0, 0);
		const length = Atomics.load(header, 1);
		const text = new TextDecoder().decode(new Uint8Array(shared, 8, length));
		if (Atomics.load(header, 0) !== 1) throw new Error(text);
		const reply = JSON.parse(text);
		if (typeof reply === "object" && reply !== null && "tag" in reply && reply.tag === "unknown" && "val" in reply && typeof reply.val === "string") throw new Error(`host import could not confirm its effect: ${reply.val}`);
		return reply;
	};
}
async function prepare() {
	const started = performance.now();
	const { files } = await transpile(setup.bytes, {
		name: "guest",
		instantiation: "async",
		wasiShim: false,
		noTypescript: true,
		base64Cutoff: 0
	});
	setup.bytes = /* @__PURE__ */ new Uint8Array();
	const size = Object.values(files).reduce((sum, file) => sum + file.byteLength, 0);
	if (size > setup.maxPreparedBytes) throw new Error("prepared artifact exceeds the byte limit");
	const js = Object.keys(files).filter((name) => name.endsWith(".js"));
	if (js.length !== 1) throw new Error("expected one self-contained jco JavaScript entry");
	const source = files[js[0]];
	const loaded = await import(`data:text/javascript;base64,${Buffer.from(source).toString("base64")}`);
	const compileStart = performance.now();
	const modules = /* @__PURE__ */ new Map();
	for (const [path, bytes] of Object.entries(files)) if (path.endsWith(".wasm")) {
		const core = new Uint8Array(new ArrayBuffer(bytes.byteLength));
		core.set(bytes);
		modules.set(path, await WebAssembly.compile(core));
	}
	const preparedAt = performance.now();
	const instantiate = loaded.instantiate;
	if (typeof instantiate !== "function") throw new Error("jco entry has no instantiator");
	send({
		type: "prepared",
		bytes: size,
		modules: modules.size,
		prepareMs: preparedAt - started,
		compileMs: preparedAt - compileStart
	});
	return (imports) => instantiate(async (path) => {
		const module = modules.get(path);
		if (module === void 0) throw new Error(`missing compiled core module ${path}`);
		return module;
	}, imports);
}
function importsFor(binding, id, job) {
	const imports = Object.create(null);
	for (const required of binding.required) {
		if (required.instance === void 0) throw new Error("bare imports are not supported");
		const functions = imports[required.instance] ??= Object.create(null);
		const fn = (request) => hostFunction(job(), id, required.name)(request);
		functions[required.name] = fn;
		functions[camel(required.name)] = fn;
		const at = required.instance.lastIndexOf("@");
		if (at > 0) imports[required.instance.slice(0, at)] = functions;
	}
	return imports;
}
function invoke(exports, name, input) {
	const fn = exports[name] ?? exports[camel(name)];
	if (typeof fn !== "function") return failed(`guest does not export ${name}`);
	try {
		const payload = fn(input);
		if (typeof payload !== "string") return failed("guest returned a non-string payload");
		if (Buffer.byteLength(payload) > setup.maxPayloadBytes) return failed("plugin output exceeds the payload limit");
		return {
			status: "returned",
			payload
		};
	} catch (error) {
		const payload = typeof error === "string" ? error : error instanceof Error && error.constructor.name === "ComponentError" ? error.message : void 0;
		if (payload !== void 0 && Buffer.byteLength(payload) <= setup.maxPayloadBytes) return {
			status: "declared-error",
			payload
		};
		return failed(message(error));
	}
}
try {
	const instantiate = await prepare();
	let activeJob = 0;
	let tail = Promise.resolve();
	port.on("message", (command) => {
		tail = tail.then(async () => {
			if (command.type === "close") {
				bindings.delete(command.binding);
				return;
			}
			activeJob = command.job;
			let instantiateMs = 0;
			let invokeMs = 0;
			try {
				if (command.type === "bind") bindings.set(command.binding, {
					required: command.required,
					lifetime: command.lifetime
				});
				const binding = bindings.get(command.binding);
				if (binding === void 0) throw new Error("plugin binding is closed");
				if (binding.exports === void 0) {
					const start = performance.now();
					const imports = importsFor(binding, command.binding, () => activeJob);
					binding.exports = await instantiate(imports);
					instantiateMs = performance.now() - start;
				}
				let outcome = {
					status: "returned",
					payload: ""
				};
				if (command.type === "call") {
					const start = performance.now();
					outcome = invoke(binding.exports, command.name, command.input);
					invokeMs = performance.now() - start;
					if (binding.lifetime === "per-call" || outcome.status === "fault") binding.exports = void 0;
				}
				send({
					type: "result",
					job: command.job,
					outcome,
					instantiateMs,
					invokeMs
				});
			} catch (error) {
				const binding = bindings.get(command.binding);
				if (binding !== void 0) binding.exports = void 0;
				if (command.type === "bind") bindings.delete(command.binding);
				send({
					type: "result",
					job: command.job,
					outcome: failed(message(error)),
					instantiateMs,
					invokeMs
				});
			}
		});
	});
} catch (error) {
	send({
		type: "prepare-failed",
		reason: message(error)
	});
	port.close();
}
//#endregion
