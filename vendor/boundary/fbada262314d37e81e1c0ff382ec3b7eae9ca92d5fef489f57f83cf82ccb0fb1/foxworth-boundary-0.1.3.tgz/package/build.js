import { f as failHost } from "./chunks/definitions-CFjJCGn-.js";
import { i as metadataForCompiled, o as snapshotDefinitions } from "./chunks/compile-Dpp86NdO.js";
import { c as metadataForInstallation, r as assertProjectionBinding } from "./chunks/binding-DgXVPJI_.js";
import { n as metadataForProjection } from "./chunks/projection-7MSieVvr.js";
import { canonicalJson, compareUtf8, normalizeJson } from "@foxworth/boundary/program";
import { fileURLToPath, pathToFileURL } from "node:url";
import { dirname, isAbsolute, join, relative, resolve } from "node:path";
import { lstat, mkdir, readFile, realpath, rename, unlink, writeFile } from "node:fs/promises";
//#region packages/core/host/src/build-load.ts
function entryUrl(entry) {
	let url;
	if (entry instanceof URL) url = new URL(entry.href);
	else if (typeof entry === "string" && entry.length > 0) try {
		url = new URL(entry);
	} catch {
		url = pathToFileURL(resolve(entry));
	}
	else return failHost("INVALID_INTERACTION_MODULE", "entry", "an explicit interaction module path or file URL is required");
	if (url.protocol !== "file:") return failHost("INVALID_INTERACTION_MODULE", "entry", "interaction module entries must be local file URLs");
	return url;
}
function exportedInteractions(module) {
	if (module === null || typeof module !== "object") return failHost("INVALID_INTERACTION_MODULE", "module", "interaction loader must return a module namespace object");
	const property = Object.getOwnPropertyDescriptor(module, "interactions");
	if (!property || !("value" in property) || !property.enumerable) return failHost("INVALID_INTERACTION_MODULE", "module.interactions", "interaction module must export one named interactions data property");
	const value = property.value;
	if (typeof value === "function" || value !== null && typeof value === "object" && typeof value.then === "function") return failHost("INVALID_INTERACTION_MODULE", "module.interactions", "interactions must be a closed record, not a factory or Promise");
	return value;
}
async function loadInteractionsEntry(options) {
	if (options === null || typeof options !== "object") return failHost("INVALID_INTERACTION_MODULE", "options", "loadInteractionsEntry options are required");
	const url = entryUrl(options.entry);
	let module;
	try {
		module = options.loadModule ? await options.loadModule(url) : await import(
			/* @vite-ignore */
			url.href
);
	} catch (cause) {
		return failHost("INVALID_INTERACTION_MODULE", "module", "interaction module evaluation failed", cause);
	}
	const interactions = snapshotDefinitions(exportedInteractions(module), "module.interactions");
	return Object.freeze({ interactions });
}
//#endregion
//#region packages/core/host/src/build-render.ts
var HOST_ARTIFACT_INVENTORY_PATH = ".boundary-core-host-inventory.json";
var artifactSets = /* @__PURE__ */ new WeakSet();
var encoder = new TextEncoder();
function artifactPath(name, suffix, path) {
	if (typeof name !== "string" || name.length === 0) return failHost("INVALID_ARTIFACT_PATH", path, "artifact names must be non-empty relative POSIX paths");
	if (name.includes("\\") || name.startsWith("/") || name.endsWith("/") || name.includes("\0") || name.split("/").some((part) => part === "" || part === "." || part === "..")) return failHost("INVALID_ARTIFACT_PATH", path, "artifact names must be normalized relative POSIX paths without dot segments");
	return `${name}${suffix}`;
}
function artifact(path, value) {
	let portable;
	try {
		portable = normalizeJson(value, path);
	} catch (cause) {
		return failHost("INVALID_ARTIFACT", path, "host artifacts must contain only portable JSON", cause);
	}
	const bytes = Object.freeze([...encoder.encode(`${canonicalJson(portable)}\n`)]);
	return Object.freeze({
		path,
		bytes
	});
}
function sourceArtifact(path, source) {
	return Object.freeze({
		path,
		bytes: Object.freeze([...encoder.encode(source)])
	});
}
function recordEntries(value, path) {
	if (value === void 0) return Object.freeze([]);
	if (value === null || typeof value !== "object" || Array.isArray(value)) return failHost("INVALID_ARTIFACT", path, "artifact collections must be closed records");
	return Object.freeze(Object.entries(value).sort(([left], [right]) => compareUtf8(left, right)));
}
function namedValue(entry, path) {
	if (entry === null || typeof entry !== "object") return failHost("INVALID_ARTIFACT", path, "artifact entries require an explicit name and value");
	return entry;
}
var identifier = /^[A-Za-z_$][A-Za-z0-9_$]*$/u;
function requireIdentifier(value, path) {
	if (typeof value !== "string" || !identifier.test(value)) return failHost("INVALID_ARTIFACT", path, "generated TypeScript names must be JavaScript identifiers");
	return value;
}
var reservedBindingNames = /* @__PURE__ */ new Set([
	"arguments",
	"await",
	"break",
	"case",
	"catch",
	"class",
	"const",
	"continue",
	"debugger",
	"default",
	"delete",
	"do",
	"else",
	"enum",
	"eval",
	"export",
	"extends",
	"false",
	"finally",
	"for",
	"function",
	"if",
	"implements",
	"import",
	"in",
	"instanceof",
	"interface",
	"let",
	"new",
	"null",
	"package",
	"private",
	"protected",
	"public",
	"return",
	"static",
	"super",
	"switch",
	"this",
	"throw",
	"true",
	"try",
	"typeof",
	"var",
	"void",
	"while",
	"with",
	"yield"
]);
function requireBindingName(value, path) {
	const name = requireIdentifier(value, path);
	if (reservedBindingNames.has(name)) return failHost("INVALID_ARTIFACT", path, "generated export names must be valid strict-module binding identifiers");
	if (name === "Object") return failHost("INVALID_ARTIFACT", path, "generated export names must not shadow the Object.freeze intrinsic");
	return name;
}
function requireModule(value, path) {
	if (typeof value !== "string" || value.length === 0 || value.trim() !== value || /[\0\r\n\u2028\u2029]/u.test(value)) return failHost("INVALID_ARTIFACT", path, "generated type modules must be explicit non-empty module specifiers");
	return value;
}
function requireRecord(value, path) {
	if (value === null || typeof value !== "object" || Array.isArray(value)) return failHost("INVALID_ARTIFACT", path, "generated reference metadata must be a record");
	return value;
}
function exactKeys(value, allowed, path) {
	const extra = Reflect.ownKeys(value).find((key) => typeof key !== "string" || !allowed.includes(key));
	if (extra !== void 0) failHost("INVALID_ARTIFACT", `${path}.${String(extra)}`, "generated reference metadata contains an unknown field");
}
function typeSource(value, path) {
	const record = requireRecord(value, path);
	exactKeys(record, ["module", "export"], path);
	return Object.freeze({
		module: requireModule(record.module, `${path}.module`),
		export: requireIdentifier(record.export, `${path}.export`)
	});
}
function interactionSource(value, path) {
	const record = requireRecord(value, path);
	exactKeys(record, [
		"compiled",
		"module",
		"export"
	], path);
	metadataForCompiled(record.compiled);
	return Object.freeze({
		compiled: record.compiled,
		module: requireModule(record.module, `${path}.module`),
		export: requireIdentifier(record.export, `${path}.export`)
	});
}
function renderReferenceModule(value) {
	exactKeys(requireRecord(value, "references.value"), [
		"binding",
		"projection",
		"source",
		"exportName",
		"members"
	], "references.value");
	if (value.binding === void 0 === (value.projection === void 0)) return failHost("INVALID_ARTIFACT", "references.value", "references require exactly one Projection or Binding");
	if (value.binding !== void 0) assertProjectionBinding(value.binding);
	else metadataForProjection(value.projection);
	const selections = value.binding !== void 0 ? value.binding.manifest.interactions : value.projection.manifest.interactions.flatMap((interaction) => interaction.modes.map((mode) => ({
		...interaction,
		mode
	})));
	const source = interactionSource(value.source, "references.value.source");
	const exportName = requireBindingName(value.exportName, "references.value.exportName");
	const members = requireRecord(value.members, "references.value.members");
	const grouped = /* @__PURE__ */ new Map();
	for (const interaction of selections) {
		const existing = grouped.get(interaction.alias);
		if (existing) {
			if (existing.interactionId !== interaction.interactionId || existing.contractDigest !== interaction.expectedContractDigest || existing.inputArity !== interaction.inputArity) failHost("INVALID_ARTIFACT", `references.value.binding.${interaction.alias}`, "one Binding alias must retain one expected interaction identity");
			existing.modes.push(interaction.mode);
		} else grouped.set(interaction.alias, {
			interactionId: interaction.interactionId,
			contractDigest: interaction.expectedContractDigest,
			inputArity: interaction.inputArity,
			modes: [interaction.mode]
		});
	}
	const aliases = [...grouped.keys()].sort(compareUtf8);
	const memberKeys = Reflect.ownKeys(members);
	if (memberKeys.some((key) => typeof key !== "string") || memberKeys.length !== aliases.length || aliases.some((alias) => !Object.hasOwn(members, alias))) return failHost("INVALID_ARTIFACT", "references.value.members", "reference members must cover every Binding alias exactly");
	const requestTypes = [];
	const typeFields = [];
	const valueFields = [];
	for (const [index, alias] of aliases.entries()) {
		const interaction = grouped.get(alias);
		interaction.modes.sort(compareUtf8);
		const memberPath = `references.value.members.${alias}`;
		const member = requireRecord(members[alias], memberPath);
		exactKeys(member, ["definition", "requestOutput"], memberPath);
		const definition = requireIdentifier(member.definition, `${memberPath}.definition`);
		const sourceHandle = source.compiled.handles[definition];
		if (sourceHandle === void 0 || sourceHandle.interactionId !== interaction.interactionId || sourceHandle.contractDigest !== interaction.contractDigest || sourceHandle.inputArity !== interaction.inputArity) return failHost("INVALID_ARTIFACT", `${memberPath}.definition`, "reference definition must name the exact compiled interaction bound to this alias");
		const hasRequest = interaction.modes.includes("request");
		let requestType = "";
		if (hasRequest && value.projection !== void 0) {
			if (member.requestOutput !== void 0) return failHost("INVALID_ARTIFACT", `${memberPath}.requestOutput`, "a typed public request result requires a Binding; a Projection declares request mode only");
			requestType = ", import(\"@foxworth/boundary/program\").JsonValue";
		} else if (hasRequest) {
			if (member.requestOutput === void 0) return failHost("INVALID_ARTIFACT", `${memberPath}.requestOutput`, "request references require an explicit public request output type");
			const output = typeSource(member.requestOutput, `${memberPath}.requestOutput`);
			const name = `RequestOutput${index}`;
			requestTypes.push(`type ${name} = import(${JSON.stringify(output.module)}).${output.export};`);
			requestType = `, ${name}`;
		} else if (member.requestOutput !== void 0) return failHost("INVALID_ARTIFACT", `${memberPath}.requestOutput`, "direct-only references must not declare a request output type");
		const modes = interaction.modes.map((mode) => JSON.stringify(mode)).join(", ");
		typeFields.push(`  readonly ${JSON.stringify(alias)}: ProjectedInteractionHandle<InteractionHandle<SourceInteractions[${JSON.stringify(definition)}]>, readonly [${modes}]${requestType}>;`);
		valueFields.push([
			`  [${JSON.stringify(alias)}]: Object.freeze({`,
			`    interactionId: ${JSON.stringify(interaction.interactionId)},`,
			`    contractDigest: ${JSON.stringify(interaction.contractDigest)},`,
			`    inputArity: ${interaction.inputArity},`,
			`    modes: Object.freeze([${modes}] as const),`,
			"  }),"
		].join("\n"));
	}
	return [
		"// Generated by @foxworth/boundary/host/build. Do not edit.",
		"import type { InteractionHandle, ProjectedInteractionHandle } from \"@foxworth/boundary\";",
		"",
		`type SourceInteractions = (typeof import(${JSON.stringify(source.module)}))[${JSON.stringify(source.export)}];`,
		...requestTypes,
		"",
		`export const ${exportName}: Readonly<{`,
		...typeFields,
		"}> = Object.freeze({",
		...valueFields,
		"});",
		""
	].join("\n");
}
function renderHostArtifacts(options) {
	if (options === null || typeof options !== "object") return failHost("INVALID_ARTIFACT", "options", "renderHostArtifacts options are required");
	const files = [];
	if (options.program !== void 0) {
		const entry = namedValue(options.program, "program");
		files.push(artifact(artifactPath(entry.name, ".program.json", "program.name"), entry.value));
	}
	for (const [alias, raw] of recordEntries(options.projections, "projections")) {
		const entry = namedValue(raw, `projections.${alias}`);
		metadataForProjection(entry.value);
		files.push(artifact(artifactPath(entry.name, ".projection.json", `projections.${alias}.name`), entry.value.manifest));
	}
	for (const [alias, raw] of recordEntries(options.installations, "installations")) {
		const entry = namedValue(raw, `installations.${alias}`);
		metadataForInstallation(entry.value);
		files.push(artifact(artifactPath(entry.name, ".installation.json", `installations.${alias}.name`), entry.value.manifest));
	}
	for (const [alias, raw] of recordEntries(options.bindings, "bindings")) {
		const entry = namedValue(raw, `bindings.${alias}`);
		assertProjectionBinding(entry.value);
		files.push(artifact(artifactPath(entry.name, ".binding.json", `bindings.${alias}.name`), entry.value.manifest));
	}
	for (const [alias, raw] of recordEntries(options.references, "references")) {
		const entry = namedValue(raw, `references.${alias}`);
		files.push(sourceArtifact(artifactPath(entry.name, ".references.ts", `references.${alias}.name`), renderReferenceModule(entry.value)));
	}
	files.sort((left, right) => compareUtf8(left.path, right.path));
	const duplicate = files.find((file, index) => index > 0 && files[index - 1].path === file.path);
	if (duplicate) return failHost("INVALID_ARTIFACT_PATH", duplicate.path, "two host artifacts resolve to the same path");
	const inventory = Object.freeze({
		version: 1,
		path: HOST_ARTIFACT_INVENTORY_PATH,
		files: Object.freeze(files.map((file) => file.path))
	});
	const result = Object.freeze({
		version: 1,
		files: Object.freeze(files),
		inventory
	});
	artifactSets.add(result);
	return result;
}
function assertHostArtifactSet(value) {
	if (value === null || typeof value !== "object" || !artifactSets.has(value)) failHost("INVALID_ARTIFACT", "artifacts", "an authentic renderHostArtifacts result is required");
}
//#endregion
//#region packages/core/host/src/build-write.ts
function destinationRoot(options) {
	if (options === null || typeof options !== "object") return failHost("INVALID_ARTIFACT_DESTINATION", "options", "artifact destination options are required");
	const value = options.destination;
	if (value instanceof URL) {
		if (value.protocol !== "file:") return failHost("INVALID_ARTIFACT_DESTINATION", "destination", "artifact destinations must be filesystem paths or file URLs");
		return fileURLToPath(value);
	}
	if (typeof value !== "string" || value.length === 0) return failHost("INVALID_ARTIFACT_DESTINATION", "destination", "an explicit artifact destination is required");
	return isAbsolute(value) ? value : resolve(value);
}
function target(root, relative) {
	return join(root, ...relative.split("/"));
}
async function pinnedDestinationRoot(options, create) {
	const requested = destinationRoot(options);
	try {
		const stat = await lstat(requested);
		if (stat.isSymbolicLink() || !stat.isDirectory()) return failHost("INVALID_ARTIFACT_DESTINATION", requested, "artifact destination must be a real directory, not a symlink");
		return realpath(requested);
	} catch (error) {
		if (!isMissing(error)) throw error;
	}
	const missing = [];
	let ancestor = requested;
	while (true) {
		const parent = dirname(ancestor);
		if (parent === ancestor) return failHost("INVALID_ARTIFACT_DESTINATION", requested, "artifact destination has no existing directory ancestor");
		missing.unshift(relative(parent, ancestor));
		ancestor = parent;
		try {
			const stat = await lstat(ancestor);
			if (!stat.isDirectory() && !stat.isSymbolicLink()) return failHost("INVALID_ARTIFACT_DESTINATION", ancestor, "artifact destination ancestor must be a directory");
			break;
		} catch (error) {
			if (!isMissing(error)) throw error;
		}
	}
	const pinned = join(await realpath(ancestor), ...missing);
	if (!create) return pinned;
	await mkdir(pinned, { recursive: true });
	const stat = await lstat(pinned);
	if (stat.isSymbolicLink() || !stat.isDirectory()) return failHost("INVALID_ARTIFACT_DESTINATION", pinned, "artifact destination changed while it was being created");
	return realpath(pinned);
}
async function rejectManagedSymlinks(root, managedPath) {
	const parts = managedPath.split("/");
	let current = root;
	for (let index = 0; index < parts.length; index += 1) {
		current = join(current, parts[index]);
		try {
			const stat = await lstat(current);
			if (stat.isSymbolicLink()) failHost("INVALID_ARTIFACT_DESTINATION", managedPath, "managed artifact paths must not traverse symbolic links");
			if (index < parts.length - 1 && !stat.isDirectory()) failHost("INVALID_ARTIFACT_DESTINATION", managedPath, "managed artifact parent must be a directory");
		} catch (error) {
			if (isMissing(error)) return;
			throw error;
		}
	}
}
function inventoryBytes(inventory) {
	return new TextEncoder().encode(`${canonicalJson(normalizeJson({
		version: inventory.version,
		files: inventory.files
	}, "inventory"))}\n`);
}
function isMissing(error) {
	return error !== null && typeof error === "object" && "code" in error && error.code === "ENOENT";
}
function validManagedPath(value) {
	return typeof value === "string" && value.length > 0 && !value.startsWith("/") && !value.includes("\\") && !value.includes("\0") && value.split("/").every((part) => part !== "" && part !== "." && part !== "..") && value !== ".boundary-core-host-inventory.json";
}
async function previousInventory(root) {
	await rejectManagedSymlinks(root, HOST_ARTIFACT_INVENTORY_PATH);
	let bytes;
	try {
		bytes = await readFile(target(root, HOST_ARTIFACT_INVENTORY_PATH));
	} catch (error) {
		if (isMissing(error)) return Object.freeze([]);
		throw error;
	}
	let value;
	try {
		value = JSON.parse(new TextDecoder().decode(bytes));
	} catch (cause) {
		return failHost("INVALID_ARTIFACT", HOST_ARTIFACT_INVENTORY_PATH, "existing host artifact inventory is not valid JSON", cause);
	}
	if (value === null || typeof value !== "object" || Array.isArray(value) || Reflect.ownKeys(value).some((key) => key !== "version" && key !== "files") || value.version !== 1 || !Array.isArray(value.files) || !value.files.every(validManagedPath)) return failHost("INVALID_ARTIFACT", HOST_ARTIFACT_INVENTORY_PATH, "existing host artifact inventory is malformed");
	const files = value.files;
	if (new Set(files).size !== files.length) return failHost("INVALID_ARTIFACT", HOST_ARTIFACT_INVENTORY_PATH, "existing host artifact inventory contains duplicate paths");
	return Object.freeze([...files]);
}
function equalBytes(left, right) {
	if (left.byteLength !== right.length) return false;
	for (let index = 0; index < right.length; index += 1) if (left[index] !== right[index]) return false;
	return true;
}
async function existingBytes(path) {
	try {
		return await readFile(path);
	} catch (error) {
		if (isMissing(error)) return void 0;
		throw error;
	}
}
async function writeExact(root, relativePath, bytes) {
	await rejectManagedSymlinks(root, relativePath);
	const path = target(root, relativePath);
	await mkdir(dirname(path), { recursive: true });
	await rejectManagedSymlinks(root, relativePath);
	const temporary = `${path}.boundary-core-${process.pid}-${crypto.randomUUID()}.tmp`;
	try {
		await writeFile(temporary, Uint8Array.from(bytes), { flag: "wx" });
		await rejectManagedSymlinks(root, relativePath);
		await rename(temporary, path);
	} catch (error) {
		try {
			await unlink(temporary);
		} catch (cleanupError) {
			if (!isMissing(cleanupError)) throw cleanupError;
		}
		throw error;
	}
}
async function removeManagedFile(root, relativePath) {
	await rejectManagedSymlinks(root, relativePath);
	const path = target(root, relativePath);
	try {
		if (!(await lstat(path)).isFile()) return failHost("INVALID_ARTIFACT_DESTINATION", path, "an inventoried artifact path is not a file");
		await unlink(path);
		return true;
	} catch (error) {
		if (isMissing(error)) return false;
		throw error;
	}
}
async function writeHostArtifacts(artifacts, options) {
	assertHostArtifactSet(artifacts);
	const root = await pinnedDestinationRoot(options, true);
	const previous = await previousInventory(root);
	const written = [];
	for (const file of artifacts.files) {
		await writeExact(root, file.path, file.bytes);
		written.push(file.path);
	}
	const current = new Set(artifacts.inventory.files);
	const removed = [];
	for (const stale of previous.filter((path) => !current.has(path)).sort(compareUtf8)) if (await removeManagedFile(root, stale)) removed.push(stale);
	await writeExact(root, artifacts.inventory.path, inventoryBytes(artifacts.inventory));
	return Object.freeze({
		written: Object.freeze(written),
		removed: Object.freeze(removed),
		inventory: artifacts.inventory.path
	});
}
async function checkHostArtifacts(artifacts, options) {
	assertHostArtifactSet(artifacts);
	const root = await pinnedDestinationRoot(options, false);
	const previous = await previousInventory(root);
	const missing = [];
	const changed = [];
	for (const file of artifacts.files) {
		await rejectManagedSymlinks(root, file.path);
		const actual = await existingBytes(target(root, file.path));
		if (actual === void 0) missing.push(file.path);
		else if (!equalBytes(actual, file.bytes)) changed.push(file.path);
	}
	const expectedInventory = [...inventoryBytes(artifacts.inventory)];
	await rejectManagedSymlinks(root, artifacts.inventory.path);
	const actualInventory = await existingBytes(target(root, artifacts.inventory.path));
	if (actualInventory === void 0) missing.push(artifacts.inventory.path);
	else if (!equalBytes(actualInventory, expectedInventory)) changed.push(artifacts.inventory.path);
	const current = new Set(artifacts.inventory.files);
	const stale = previous.filter((path) => !current.has(path)).sort(compareUtf8);
	return Object.freeze({
		ok: missing.length === 0 && changed.length === 0 && stale.length === 0,
		missing: Object.freeze(missing),
		changed: Object.freeze(changed),
		stale: Object.freeze(stale)
	});
}
//#endregion
export { HOST_ARTIFACT_INVENTORY_PATH, checkHostArtifacts, loadInteractionsEntry, renderHostArtifacts, writeHostArtifacts };
