"use client";
import { createContext, createElement, useCallback, useContext, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { AdapterError, RemoteDomainError, RemoteExecutionError, RemoteInvocationError, RemoteProtocolError } from "@foxworth/boundary/handoff/adapter";
import { footprintsFor, isReadInteraction, watchInteraction } from "@foxworth/boundary/client/cache";
import { createInvocationState, createProposalInteraction } from "@foxworth/boundary/client";
//#region packages/callers/react/src/cacheScope.tsx
var CacheScopeContext = createContext(void 0);
/** Explicitly share completed-change invalidation across descendant clients. */
function InteractionCacheProvider({ scope, children }) {
	return createElement(CacheScopeContext.Provider, { value: scope }, children);
}
/** The nearest explicit scope, or undefined for the default client-local cache. */
function useInteractionCacheScope() {
	return useContext(CacheScopeContext);
}
//#endregion
//#region packages/callers/react/src/client.tsx
/**
* Create one typed React boundary for a browser client.
*
* It never inspects the program, chooses a view, or carries server authority.
*/
function createProjectionContext() {
	const Context = createContext(void 0);
	function Provider({ client, children }) {
		return createElement(Context.Provider, { value: client }, children);
	}
	function useClient() {
		const client = useContext(Context);
		if (!client) throw new Error("Projection view must be rendered inside its Projection Provider");
		return client;
	}
	function view(Component) {
		function BoundView(props) {
			const client = useClient();
			return createElement(Component, {
				...props,
				client
			});
		}
		BoundView.displayName = `ProjectionView(${Component.displayName ?? Component.name ?? "Anonymous"})`;
		return BoundView;
	}
	return Object.freeze({
		Provider,
		useClient,
		view
	});
}
//#endregion
//#region packages/callers/react/src/useInvocationState.ts
function useDeferredDispose(dispose) {
	const pending = useRef(void 0);
	useEffect(() => {
		if (pending.current?.dispose === dispose) {
			clearTimeout(pending.current.timer);
			pending.current = void 0;
		}
		return () => {
			const record = {
				dispose,
				timer: setTimeout(() => {
					if (pending.current === record) pending.current = void 0;
					dispose();
				}, 0)
			};
			pending.current = record;
		};
	}, [dispose]);
}
function keyFor(handle) {
	return `${handle.interactionId}\n${handle.contractDigest}\n${handle.inputArity}\n${handle.modes.join(",")}`;
}
/**
* React adaptation of the framework-neutral explicit invocation store. It is
* inert on mount; the application calls `invoke` from its own event handler.
*/
function useInvocationState(client, handle, mode) {
	const scope = useInteractionCacheScope();
	const handleKey = keyFor(handle);
	const interaction = useMemo(() => createInvocationState(client, handle, mode, { scope }), [
		client,
		handleKey,
		mode,
		scope
	]);
	useDeferredDispose(interaction.dispose);
	const state = useSyncExternalStore(interaction.subscribe, interaction.getSnapshot, interaction.getSnapshot);
	return Object.freeze({
		...state,
		invoke: interaction.invoke,
		markStale: interaction.markStale,
		disconnect: interaction.disconnect
	});
}
/**
* Request-mode interaction with a caller-supplied, public-only status reader.
* The hook does not create a Control client, expose records, or observe on its
* own; call `observe` explicitly for a returned proposal.
*/
function useProposalInteraction(client, handle, observeStatus) {
	const handleKey = keyFor(handle);
	const statusReader = useRef(observeStatus);
	statusReader.current = observeStatus;
	const interaction = useMemo(() => createProposalInteraction(client, handle, (proposal) => statusReader.current(proposal)), [client, handleKey]);
	useDeferredDispose(interaction.dispose);
	const invocation = useSyncExternalStore(interaction.invocation.subscribe, interaction.invocation.getSnapshot, interaction.invocation.getSnapshot);
	const status = useSyncExternalStore(interaction.subscribeStatus, interaction.getStatusSnapshot, interaction.getStatusSnapshot);
	return Object.freeze({
		invocation,
		status,
		request: interaction.invocation.invoke,
		observe: interaction.observe,
		markStale: interaction.markStale,
		disconnect: interaction.disconnect
	});
}
//#endregion
//#region packages/callers/react/src/useInteraction.ts
/** Distinguish declared domain errors from sanitized protocol failures. */
function describeInteractionError(error) {
	if ((error instanceof RemoteInvocationError || error instanceof RemoteExecutionError || error instanceof RemoteProtocolError) && error.certainty === "unknown") return {
		kind: "unknown",
		message: "The interaction consequence is unknown. Reconcile before retrying."
	};
	if (error instanceof RemoteDomainError) return {
		kind: "domain",
		message: `Declared domain error: ${JSON.stringify(error.value)}`
	};
	if (error instanceof RemoteProtocolError || error instanceof AdapterError) return {
		kind: "protocol",
		message: error.message
	};
	if (error instanceof RemoteExecutionError) return {
		kind: "execution",
		message: error.message
	};
	return {
		kind: "unknown",
		message: error instanceof Error ? error.message : "The interaction failed."
	};
}
function asInteractionError(caught) {
	return caught instanceof Error ? caught : new Error(String(caught));
}
function useInteraction(client, handle, ...args) {
	const cacheScope = useInteractionCacheScope();
	const handleKey = `${handle.interactionId}\n${handle.contractDigest}\n${handle.inputArity}\n${handle.modes.join(",")}`;
	const lifetime = useMemo(() => ({ active: true }), [
		client,
		handleKey,
		cacheScope
	]);
	const argsRef = useRef(args);
	const readRef = useRef(void 0);
	const routeRef = useRef("unknown");
	const pendingCalls = useRef([]);
	const [route, setRoute] = useState("unknown");
	const [read, setRead] = useState(void 0);
	const [routeError, setRouteError] = useState(void 0);
	const mutation = useInvocationState(client, handle, "direct");
	const argKey = JSON.stringify(args[0] ?? null);
	const lastArgKey = useRef(argKey);
	useEffect(() => {
		if (lastArgKey.current !== argKey) {
			lastArgKey.current = argKey;
			argsRef.current = args;
		}
	});
	const createRead = useCallback((callArgs) => {
		const watch = watchInteraction;
		return handle.inputArity === 0 ? watch(client, handle, { scope: cacheScope }) : watch(client, handle, callArgs[0], { scope: cacheScope });
	}, [
		client,
		handleKey,
		cacheScope
	]);
	const invokeMutation = mutation.invoke;
	const invokeChange = useCallback((callArgs) => {
		return invokeMutation(...callArgs);
	}, [invokeMutation]);
	const emptyReadSnapshot = useMemo(() => Object.freeze({
		data: void 0,
		error: void 0,
		isPending: false
	}), []);
	const subscribe = useCallback((listener) => read?.subscribe(listener) ?? (() => {}), [read]);
	const getReadSnapshot = useCallback(() => read?.getSnapshot() ?? emptyReadSnapshot, [read, emptyReadSnapshot]);
	const watched = useSyncExternalStore(subscribe, getReadSnapshot, getReadSnapshot);
	const flushPendingCalls = useCallback((nextRoute) => {
		const calls = pendingCalls.current.splice(0);
		for (const pending of calls) try {
			(nextRoute === "read" ? (() => {
				const current = readRef.current;
				if (!current) return Promise.reject(/* @__PURE__ */ new Error("interaction read was not initialized"));
				if (pending.args.length > 0) {
					argsRef.current = pending.args;
					const replacement = createRead(pending.args);
					current.dispose();
					readRef.current = replacement;
					setRead(replacement);
					return replacement.refresh();
				}
				return current.refresh();
			})() : invokeChange(pending.args)).then(pending.resolve, pending.reject);
		} catch (error) {
			pending.reject(error);
		}
	}, [createRead, invokeChange]);
	useEffect(() => {
		lifetime.active = true;
		routeRef.current = "unknown";
		setRoute("unknown");
		setRouteError(void 0);
		let cancelled = false;
		let created;
		footprintsFor(client).then((footprints) => {
			if (cancelled) return;
			if (!isReadInteraction(footprints, handle.interactionId)) {
				readRef.current?.dispose();
				readRef.current = void 0;
				setRead(void 0);
				routeRef.current = "change";
				setRoute("change");
				setRouteError(void 0);
				flushPendingCalls("change");
				return;
			}
			if (argsRef.current.length !== handle.inputArity) {
				routeRef.current = "failed";
				setRoute("failed");
				const error = new AdapterError("INVALID_REQUEST", `${handle.interactionId}.args`, "this read requires arguments; pass them to useInteraction");
				setRouteError(error);
				for (const pending of pendingCalls.current.splice(0)) pending.reject(error);
				return;
			}
			created = createRead(argsRef.current);
			readRef.current?.dispose();
			readRef.current = created;
			setRead(created);
			routeRef.current = "read";
			setRoute("read");
			setRouteError(void 0);
			flushPendingCalls("read");
		}).catch((caught) => {
			if (!cancelled) {
				const error = asInteractionError(caught);
				routeRef.current = "failed";
				setRoute("failed");
				setRouteError(error);
				for (const pending of pendingCalls.current.splice(0)) pending.reject(error);
			}
		});
		return () => {
			cancelled = true;
			lifetime.active = false;
			routeRef.current = "unknown";
			const error = /* @__PURE__ */ new Error("interaction view was disposed or replaced before invocation");
			for (const pending of pendingCalls.current.splice(0)) pending.reject(error);
			if (readRef.current === created) {
				created?.dispose();
				readRef.current = void 0;
			}
		};
	}, [
		client,
		handleKey,
		argKey,
		createRead,
		flushPendingCalls,
		lifetime
	]);
	useEffect(() => () => {
		readRef.current?.dispose();
		readRef.current = void 0;
	}, []);
	const refetch = useCallback(async (...callArgs) => {
		if (!lifetime.active) return Promise.reject(/* @__PURE__ */ new Error("interaction view was disposed or replaced"));
		if (callArgs.length > 0) argsRef.current = callArgs;
		const next = callArgs.length > 0 || handle.inputArity === 0 ? callArgs : argsRef.current;
		if (routeRef.current === "read" && readRef.current) {
			if (callArgs.length === 0) return readRef.current.refresh();
			const replacement = createRead(next);
			readRef.current.dispose();
			readRef.current = replacement;
			setRead(replacement);
			return replacement.refresh();
		}
		if (routeRef.current === "change") return invokeChange(next);
		if (routeRef.current === "failed") return Promise.reject(routeError ?? /* @__PURE__ */ new Error("interaction route failed"));
		return new Promise((resolve, reject) => {
			pendingCalls.current.push({
				args: next,
				resolve,
				reject
			});
		});
	}, [
		createRead,
		handleKey,
		invokeChange,
		routeError,
		lifetime
	]);
	return {
		data: route === "read" ? watched.data : mutation.result,
		error: routeError ?? (route === "read" ? watched.error : mutation.error),
		isPending: route === "unknown" ? argsRef.current.length === handle.inputArity : route === "read" ? watched.isPending : mutation.isPending,
		refetch,
		call: refetch
	};
}
//#endregion
export { InteractionCacheProvider, createProjectionContext, describeInteractionError, useInteraction, useInteractionCacheScope, useInvocationState, useProposalInteraction };
