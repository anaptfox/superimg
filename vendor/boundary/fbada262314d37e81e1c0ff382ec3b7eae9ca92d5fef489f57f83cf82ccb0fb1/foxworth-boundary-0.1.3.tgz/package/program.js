import { _ as hashJson, a as isObject$1, b as sha256, c as propertyPath, d as jsonEquals, f as snapshotJson, g as compareUtf8, h as cloneJson, i as hasValidatedSchema, l as validatePortableSchema, m as canonicalJson, n as compileSchema, o as isPortableSchema, p as JsonError, r as PortableSchemaError, s as portableSchema, t as SchemaAdapterError, u as exactObject, v as isSha256Digest, x as BoundaryErrorBase, y as normalizeJson } from "./chunks/schema-D84XUXTj.js";
//#region packages/core/program/src/schemaValue.ts
var compiledSchemas = /* @__PURE__ */ new WeakMap();
function compile(schema) {
	const cached = compiledSchemas.get(schema);
	if (cached) return cached;
	const branch = (value) => isObject$1(value) ? compile(value) : void 0;
	const branches = (value) => Array.isArray(value) ? value.map((item) => compile(item)) : void 0;
	const compiled = Object.freeze({
		schema,
		pattern: typeof schema.pattern === "string" ? new RegExp(schema.pattern, "u") : void 0,
		properties: new Map(Object.entries(isObject$1(schema.properties) ? schema.properties : {}).map(([name, value]) => [name, compile(value)])),
		required: new Set(Array.isArray(schema.required) ? schema.required : []),
		anyOf: branches(schema.anyOf),
		oneOf: branches(schema.oneOf),
		allOf: branches(schema.allOf),
		not: branch(schema.not),
		items: branch(schema.items),
		additional: branch(schema.additionalProperties)
	});
	compiledSchemas.set(schema, compiled);
	return compiled;
}
function valueTypeMatches(type, value) {
	switch (type) {
		case "null": return value === null;
		case "boolean": return typeof value === "boolean";
		case "object": return isObject$1(value);
		case "array": return Array.isArray(value);
		case "number": return typeof value === "number";
		case "integer": return typeof value === "number" && Number.isInteger(value);
		case "string": return typeof value === "string";
		default: return false;
	}
}
function valueIssues(compiled, value, path) {
	const { schema } = compiled;
	const issues = [];
	const issue = (message, issuePath = path) => {
		issues.push(Object.freeze({
			path: issuePath,
			message
		}));
	};
	if (typeof schema.type === "string" && !valueTypeMatches(schema.type, value)) {
		issue(`value must have JSON type ${schema.type}`);
		return issues;
	}
	if (schema.const !== void 0 && !jsonEquals(schema.const, value)) issue("value must equal const");
	if (Array.isArray(schema.enum) && !schema.enum.some((candidate) => jsonEquals(candidate, value))) issue("value must be one of enum");
	if (compiled.anyOf && !compiled.anyOf.some((candidate) => valueIssues(candidate, value, path).length === 0)) issue("value must match at least one anyOf schema");
	if (compiled.oneOf) {
		let matches = 0;
		for (const candidate of compiled.oneOf) if (valueIssues(candidate, value, path).length === 0 && ++matches === 2) break;
		if (matches !== 1) issue("value must match exactly one oneOf schema");
	}
	if (compiled.allOf) for (const candidate of compiled.allOf) issues.push(...valueIssues(candidate, value, path));
	if (compiled.not && valueIssues(compiled.not, value, path).length === 0) issue("value must not match the excluded schema");
	if (typeof value === "number") {
		if (typeof schema.minimum === "number" && value < schema.minimum) issue(`number must be at least ${schema.minimum}`);
		if (typeof schema.maximum === "number" && value > schema.maximum) issue(`number must be at most ${schema.maximum}`);
		if (typeof schema.exclusiveMinimum === "number" && value <= schema.exclusiveMinimum) issue(`number must be greater than ${schema.exclusiveMinimum}`);
		if (typeof schema.exclusiveMaximum === "number" && value >= schema.exclusiveMaximum) issue(`number must be less than ${schema.exclusiveMaximum}`);
	}
	if (typeof value === "string") {
		if (typeof schema.minLength === "number" || typeof schema.maxLength === "number") {
			let length = 0;
			for (const _ of value) length += 1;
			if (typeof schema.minLength === "number" && length < schema.minLength) issue(`string must contain at least ${schema.minLength} code points`);
			if (typeof schema.maxLength === "number" && length > schema.maxLength) issue(`string must contain at most ${schema.maxLength} code points`);
		}
		const pattern = compiled.pattern;
		if (pattern && !pattern.test(value)) issue("string must match pattern");
	}
	if (Array.isArray(value)) {
		if (typeof schema.minItems === "number" && value.length < schema.minItems) issue(`array must contain at least ${schema.minItems} items`);
		if (typeof schema.maxItems === "number" && value.length > schema.maxItems) issue(`array must contain at most ${schema.maxItems} items`);
		if (compiled.items) value.forEach((item, index) => {
			issues.push(...valueIssues(compiled.items, item, `${path}[${index}]`));
		});
		if (schema.uniqueItems === true) {
			const seen = /* @__PURE__ */ new Set();
			value.forEach((item, index) => {
				const key = canonicalJson(item);
				if (seen.has(key)) issue("array items must be unique", `${path}[${index}]`);
				else seen.add(key);
			});
		}
	}
	if (isObject$1(value)) {
		for (const name of compiled.required) if (!Object.hasOwn(value, name)) issue("required property is missing", propertyPath(path, name));
		for (const [name, item] of Object.entries(value)) {
			const itemPath = propertyPath(path, name);
			const property = compiled.properties.get(name);
			if (property) {
				issues.push(...valueIssues(property, item, itemPath));
				continue;
			}
			if (schema.additionalProperties === false) issue("additional property is not allowed", itemPath);
			else if (compiled.additional) issues.push(...valueIssues(compiled.additional, item, itemPath));
		}
	}
	return issues;
}
/** Evaluate one already-normalized JSON value against the portable contract. */
function validateSchemaValue(schema, value, path = "value") {
	const owned = hasValidatedSchema(schema) ? schema : normalizeJson(schema, "schema");
	validatePortableSchema(owned);
	return Object.freeze(valueIssues(compile(owned), value, path));
}
//#endregion
//#region packages/core/program/src/schemaCompatibility.ts
function incompatible(reason, path) {
	return {
		compatible: false,
		reason,
		path
	};
}
function isOpenSchema(schema) {
	return Object.keys(schema).length === 0;
}
function schemaType(schema) {
	return typeof schema.type === "string" ? schema.type : void 0;
}
function typeSubtype(narrower, wider) {
	return narrower === wider || narrower === "integer" && wider === "number";
}
function requiredNames(schema) {
	return Array.isArray(schema.required) ? schema.required.filter((name) => typeof name === "string") : [];
}
function propertyMap(schema) {
	if (!isObject$1(schema.properties)) return {};
	const properties = {};
	for (const [name, property] of Object.entries(schema.properties)) if (isObject$1(property)) properties[name] = property;
	return properties;
}
function acceptsValue(schema, value, path) {
	try {
		return validateSchemaValue(schema, value, path).length === 0;
	} catch {
		return false;
	}
}
function acceptsEvery(wider, narrower, path, extras) {
	if (jsonEquals(wider, narrower)) return { compatible: true };
	if (isOpenSchema(wider)) return { compatible: true };
	if (isOpenSchema(narrower)) return incompatible("open schema is not accepted by a constrained schema", path);
	const widerType = schemaType(wider);
	const narrowerType = schemaType(narrower);
	if (widerType !== void 0 && narrowerType !== void 0) {
		if (!typeSubtype(narrowerType, widerType)) return incompatible(`type ${narrowerType} is not assignable to ${widerType}`, path);
	} else if (widerType !== void 0 && narrowerType === void 0) return incompatible("untyped schema is not assignable to a typed schema", path);
	if (wider.const !== void 0) {
		if (narrower.const !== void 0) {
			if (!jsonEquals(wider.const, narrower.const)) return incompatible("const values differ", path);
		} else if (Array.isArray(narrower.enum)) {
			if (!narrower.enum.every((value) => jsonEquals(value, wider.const))) return incompatible("enum is not covered by const", path);
		} else return incompatible("schema is not restricted to the expected const", path);
	} else if (narrower.const !== void 0 && !acceptsValue(wider, narrower.const, path)) return incompatible("const value is not accepted", path);
	if (Array.isArray(wider.enum)) {
		const allowed = wider.enum;
		const candidates = Array.isArray(narrower.enum) ? narrower.enum : narrower.const !== void 0 ? [narrower.const] : void 0;
		if (candidates === void 0) return incompatible("open values are not covered by enum", path);
		if (!candidates.every((value) => allowed.some((item) => jsonEquals(item, value)))) return incompatible("enum values are not covered", path);
	} else if (Array.isArray(narrower.enum)) {
		if (!narrower.enum.every((value) => acceptsValue(wider, value, path))) return incompatible("enum value is not accepted", path);
	}
	const numeric = acceptsNumeric(wider, narrower, path);
	if (!numeric.compatible) return numeric;
	const textual = acceptsTextual(wider, narrower, path);
	if (!textual.compatible) return textual;
	const arrays = acceptsArray(wider, narrower, path, extras);
	if (!arrays.compatible) return arrays;
	const objects = acceptsObject(wider, narrower, path, extras);
	if (!objects.compatible) return objects;
	return acceptsCombinators(wider, narrower, path, extras);
}
function acceptsBound(wider, narrower, path, keyword, compare) {
	if (typeof wider !== "number") return { compatible: true };
	if (typeof narrower !== "number") return incompatible(`${keyword} is not constrained enough`, `${path}.${keyword}`);
	return compare(wider, narrower) ? { compatible: true } : incompatible(`${keyword} is not compatible`, `${path}.${keyword}`);
}
function acceptsMultipleOf(wider, narrower, path) {
	if (typeof wider.multipleOf !== "number") return { compatible: true };
	if (typeof narrower.multipleOf !== "number") return incompatible("multipleOf is not constrained enough", `${path}.multipleOf`);
	const ratio = narrower.multipleOf / wider.multipleOf;
	if (!Number.isFinite(ratio) || !Number.isInteger(ratio)) return incompatible("multipleOf is not compatible", `${path}.multipleOf`);
	return { compatible: true };
}
function acceptsNumeric(wider, narrower, path) {
	return [
		acceptsBound(wider.minimum, narrower.minimum, path, "minimum", (w, n) => n >= w),
		acceptsBound(wider.maximum, narrower.maximum, path, "maximum", (w, n) => n <= w),
		acceptsBound(wider.exclusiveMinimum, narrower.exclusiveMinimum, path, "exclusiveMinimum", (w, n) => n >= w),
		acceptsBound(wider.exclusiveMaximum, narrower.exclusiveMaximum, path, "exclusiveMaximum", (w, n) => n <= w),
		acceptsMultipleOf(wider, narrower, path)
	].find((result) => !result.compatible) ?? { compatible: true };
}
function acceptsTextual(wider, narrower, path) {
	const length = [acceptsBound(wider.minLength, narrower.minLength, path, "minLength", (w, n) => n >= w), acceptsBound(wider.maxLength, narrower.maxLength, path, "maxLength", (w, n) => n <= w)].find((result) => !result.compatible);
	if (length) return length;
	if (typeof wider.pattern === "string") {
		if (narrower.pattern !== wider.pattern) return incompatible("pattern is not compatible", `${path}.pattern`);
	}
	return { compatible: true };
}
function acceptsPrefixItems(wider, narrower, path, extras) {
	if (!Array.isArray(wider.prefixItems)) return { compatible: true };
	if (!Array.isArray(narrower.prefixItems) || narrower.prefixItems.length !== wider.prefixItems.length) return incompatible("prefixItems is not constrained enough", `${path}.prefixItems`);
	for (const [index, widerItem] of wider.prefixItems.entries()) {
		const narrowerItem = narrower.prefixItems[index];
		if (!isObject$1(widerItem) || !isObject$1(narrowerItem)) return incompatible("prefixItems entries must be schemas", `${path}.prefixItems[${index}]`);
		const nested = acceptsEvery(widerItem, narrowerItem, `${path}.prefixItems[${index}]`, extras);
		if (!nested.compatible) return nested;
	}
	return { compatible: true };
}
function acceptsArray(wider, narrower, path, extras) {
	const counts = [acceptsBound(wider.minItems, narrower.minItems, path, "minItems", (w, n) => n >= w), acceptsBound(wider.maxItems, narrower.maxItems, path, "maxItems", (w, n) => n <= w)].find((result) => !result.compatible);
	if (counts) return counts;
	if (wider.uniqueItems === true && narrower.uniqueItems !== true) return incompatible("uniqueItems is required", `${path}.uniqueItems`);
	const prefix = acceptsPrefixItems(wider, narrower, path, extras);
	if (!prefix.compatible) return prefix;
	if (isObject$1(wider.items)) {
		if (!isObject$1(narrower.items)) return incompatible("array items are not constrained enough", `${path}.items`);
		return acceptsEvery(wider.items, narrower.items, `${path}.items`, extras);
	}
	return { compatible: true };
}
function widerTypeIsObject(schema) {
	return schemaType(schema) === "object";
}
function acceptsObject(wider, narrower, path, extras) {
	const counts = [acceptsBound(wider.minProperties, narrower.minProperties, path, "minProperties", (w, n) => n >= w), acceptsBound(wider.maxProperties, narrower.maxProperties, path, "maxProperties", (w, n) => n <= w)].find((result) => !result.compatible);
	if (counts) return counts;
	const widerProperties = propertyMap(wider);
	const narrowerProperties = propertyMap(narrower);
	const widerRequired = new Set(requiredNames(wider));
	const narrowerRequired = new Set(requiredNames(narrower));
	if (widerTypeIsObject(wider) || widerRequired.size > 0 || Object.keys(widerProperties).length > 0 || wider.additionalProperties !== void 0) {
		for (const name of widerRequired) if (!narrowerRequired.has(name)) return incompatible("required property may be omitted", propertyPath(path, name));
		for (const [name, widerProperty] of Object.entries(widerProperties)) {
			const narrowerProperty = narrowerProperties[name];
			if (narrowerProperty === void 0) {
				if (widerRequired.has(name)) return incompatible("required property is missing", propertyPath(path, name));
				continue;
			}
			const nested = acceptsEvery(widerProperty, narrowerProperty, propertyPath(path, name), extras);
			if (!nested.compatible) return nested;
		}
		for (const name of Object.keys(narrowerProperties)) {
			if (widerProperties[name] !== void 0) continue;
			if (extras === "ignore") continue;
			const additional = wider.additionalProperties;
			if (additional === false) return incompatible("additional property is not accepted", propertyPath(path, name));
			if (isObject$1(additional)) {
				const nested = acceptsEvery(additional, narrowerProperties[name], propertyPath(path, name), extras);
				if (!nested.compatible) return nested;
			}
		}
	}
	return { compatible: true };
}
function acceptsCombinators(wider, narrower, path, extras) {
	if (Array.isArray(narrower.anyOf)) for (const [index, alternative] of narrower.anyOf.entries()) {
		if (!isObject$1(alternative)) continue;
		const nested = acceptsEvery(wider, alternative, `${path}.anyOf[${index}]`, extras);
		if (!nested.compatible) return nested;
	}
	if (Array.isArray(narrower.oneOf)) for (const [index, alternative] of narrower.oneOf.entries()) {
		if (!isObject$1(alternative)) continue;
		const nested = acceptsEvery(wider, alternative, `${path}.oneOf[${index}]`, extras);
		if (!nested.compatible) return nested;
	}
	if (Array.isArray(narrower.allOf) && !Array.isArray(wider.allOf)) for (const [index, alternative] of narrower.allOf.entries()) {
		if (!isObject$1(alternative)) continue;
		const nested = acceptsEvery(wider, alternative, `${path}.allOf[${index}]`, extras);
		if (!nested.compatible) return nested;
	}
	const narrowerIsUnion = Array.isArray(narrower.anyOf) || Array.isArray(narrower.oneOf);
	if (Array.isArray(wider.anyOf) && !narrowerIsUnion) {
		if (!wider.anyOf.some((alternative) => isObject$1(alternative) && acceptsEvery(alternative, narrower, path, extras).compatible)) return incompatible("schema is not covered by anyOf", `${path}.anyOf`);
	}
	if (Array.isArray(wider.oneOf)) {
		const offeredType = schemaType(narrower);
		let matches = 0;
		for (const alternative of wider.oneOf) {
			if (!isObject$1(alternative)) return incompatible("oneOf exclusivity is not proven", `${path}.oneOf`);
			const branch = alternative;
			if (acceptsEvery(branch, narrower, path, extras).compatible) {
				matches += 1;
				continue;
			}
			const branchType = schemaType(branch);
			if (offeredType === void 0 || branchType === void 0 || typeSubtype(offeredType, branchType) || typeSubtype(branchType, offeredType)) return incompatible("oneOf exclusivity is not proven", `${path}.oneOf`);
		}
		if (matches !== 1) return incompatible("schema is not covered by oneOf", `${path}.oneOf`);
	}
	if (Array.isArray(wider.allOf)) for (const [index, alternative] of wider.allOf.entries()) {
		if (!isObject$1(alternative)) continue;
		const nested = acceptsEvery(alternative, narrower, `${path}.allOf[${index}]`, extras);
		if (!nested.compatible) return nested;
	}
	if (isObject$1(wider.not) || isObject$1(narrower.not)) {
		if (!jsonEquals(wider.not, narrower.not)) return incompatible("not schemas are not compatible", `${path}.not`);
	}
	return { compatible: true };
}
//#endregion
//#region packages/core/program/src/compatibility.ts
/**
* Footprints an offered contract declares that the expected one does not.
*
* Footprints are directional like the schemas around them: an implementation
* that reads or changes *less* than the caller was told to expect can serve
* that caller, because the caller already budgets for the wider set. One
* that touches *more* cannot — it would invalidate reads the caller never
* planned to refresh and reach state the caller never agreed to.
*/
function footprintExcess(expected, offered) {
	const allowed = new Set(expected);
	return [...new Set(offered)].filter((name) => !allowed.has(name)).sort(compareUtf8);
}
/**
* `allowAbsentOffered` is only sound for `errorSchema`: dropping a declared
* error contract narrows what a caller can see, which is safe. `outputSchema`
* is not optional on `InteractionContract`; an absent offered output must not
* take the "nothing to check" shortcut.
*/
function covariantSchema(expected, offered, path, options) {
	if (offered === void 0) return options.allowAbsentOffered ? { compatible: true } : incompatible(`${path} is missing`, path);
	if (expected === void 0) return incompatible("offered schema is not accepted by the expected contract", path);
	return acceptsEvery(expected, offered, path, "ignore");
}
/**
* Structural judgment on the portable schema profile.
*
* Inputs are contravariant, outputs and errors are covariant, and footprints
* are covariant too: the offered contract may read and change a subset of
* what the expected contract declares, never a superset.
*/
function contractCompatibility(expected, offered) {
	if (expected.id !== offered.id) return incompatible("interaction ids differ", "id");
	const extraReads = footprintExcess(expected.reads, offered.reads);
	if (extraReads.length > 0) return incompatible(`offered reads exceed the expected footprint: ${extraReads.join(", ")}`, "reads");
	const extraChanges = footprintExcess(expected.changes, offered.changes);
	if (extraChanges.length > 0) return incompatible(`offered changes exceed the expected footprint: ${extraChanges.join(", ")}`, "changes");
	const input = acceptsEvery(offered.inputSchema, expected.inputSchema, "inputSchema", "reject");
	if (!input.compatible) return input;
	const output = covariantSchema(expected.outputSchema, offered.outputSchema, "outputSchema", { allowAbsentOffered: false });
	if (!output.compatible) return output;
	return covariantSchema(expected.errorSchema, offered.errorSchema, "errorSchema", { allowAbsentOffered: true });
}
//#endregion
//#region packages/core/program/src/program.ts
var INTERACTION_CONTRACT_DOMAIN = "boundary.interaction-contract/v1";
var PROGRAM_DOMAIN = "boundary.program/v1";
var INTERACTION_ID_PATTERN = "^[A-Za-z0-9][A-Za-z0-9._~-]{0,127}$";
var INTERACTION_ID_REGEXP = new RegExp(INTERACTION_ID_PATTERN, "u");
var normalizedContracts = /* @__PURE__ */ new WeakSet();
function isInteractionId(value) {
	return typeof value === "string" && INTERACTION_ID_REGEXP.test(value);
}
var ProgramError = class extends BoundaryErrorBase {
	constructor(code, path, message) {
		super(code, path, message);
		this.name = "ProgramError";
	}
};
function fail$3(code, path, message) {
	throw new ProgramError(code, path, message);
}
async function digest(hasher, domain, value) {
	const result = await hasher(domain, value);
	if (!isSha256Digest(result)) fail$3("INVALID_HASHER_RESULT", domain, "hasher must return sha256:<64 lowercase hex>");
	return result;
}
function validateInteractionId(id) {
	if (!isInteractionId(id)) fail$3("INVALID_INTERACTION_ID", `${id || "interaction"}.id`, `interaction id must be a stable ASCII token of at most 128 characters: ${id}`);
}
function normalizeEffects(interactionId, field, rawValue) {
	const path = `${interactionId}.contract.${field}`;
	let value;
	try {
		value = normalizeJson(rawValue, path);
	} catch {
		return fail$3("INVALID_INTERACTION_FOOTPRINT", path, `${field} must be an own enumerable data-property array of strings`);
	}
	if (!Array.isArray(value) || value.some((entry) => typeof entry !== "string")) return fail$3("INVALID_INTERACTION_FOOTPRINT", path, `${field} must be an own enumerable data-property array of strings`);
	const normalized = [...new Set(value)].sort(compareUtf8);
	if (normalized.find((value) => !value.trim()) !== void 0) fail$3(field === "reads" ? "EMPTY_READ" : "EMPTY_CHANGE", `${interactionId}.contract.${field}`, `${interactionId} has an empty ${field === "reads" ? "read" : "change"}`);
	return Object.freeze(normalized);
}
function normalizeContract(contract) {
	if (contract.version !== 1) fail$3("UNSUPPORTED_CONTRACT_VERSION", `${contract.id}.contract.version`, `${contract.id} must use interaction contract version 1`);
	const id = contract.id;
	validateInteractionId(id);
	const snapped = exactObject(contract, {
		path: `${id}.contract`,
		keys: [
			"version",
			"id",
			"inputSchema",
			"outputSchema",
			"reads",
			"changes"
		],
		optionalKeys: ["errorSchema"],
		fail: (f) => fail$3("INVALID_INTERACTION_FOOTPRINT", f.path, f.message)
	});
	validatePortableSchema(snapped.inputSchema, `${id}.inputSchema`);
	validatePortableSchema(snapped.outputSchema, `${id}.outputSchema`);
	if (snapped.errorSchema !== void 0 && snapped.errorSchema !== null) validatePortableSchema(snapped.errorSchema, `${id}.errorSchema`);
	const normalized = Object.freeze({
		version: 1,
		id,
		inputSchema: cloneJson(snapped.inputSchema, `${id}.inputSchema`),
		outputSchema: cloneJson(snapped.outputSchema, `${id}.outputSchema`),
		...snapped.errorSchema === void 0 ? {} : { errorSchema: cloneJson(snapped.errorSchema, `${id}.errorSchema`) },
		reads: normalizeEffects(id, "reads", snapped.reads),
		changes: normalizeEffects(id, "changes", snapped.changes)
	});
	normalizedContracts.add(normalized);
	return normalized;
}
function normalizeDocumentation(docs) {
	let normalized;
	try {
		const value = normalizeJson(docs, "descriptor.docs");
		if (value === null || typeof value !== "object" || Array.isArray(value)) fail$3("INVALID_DOCUMENTATION", "descriptor.docs", "interaction documentation must be an object");
		normalized = value;
	} catch (error) {
		if (error instanceof ProgramError) throw error;
		fail$3("INVALID_DOCUMENTATION", "descriptor.docs", "interaction documentation must be portable data");
	}
	const unexpected = Object.keys(normalized).find((key) => key !== "summary" && key !== "description");
	if (unexpected !== void 0) fail$3("INVALID_DOCUMENTATION", `descriptor.docs.${unexpected}`, `unsupported documentation field: ${unexpected}`);
	for (const field of ["summary", "description"]) if (normalized[field] !== void 0 && typeof normalized[field] !== "string") fail$3("INVALID_DOCUMENTATION", `descriptor.docs.${field}`, `${field} must be a string`);
	const summary = normalized.summary;
	const description = normalized.description;
	return Object.freeze({
		...summary === void 0 ? {} : { summary },
		...description === void 0 ? {} : { description }
	});
}
/**
* Return the exact JSON value hashed for contract identity. Docs, annotations,
* execution policy and realization details are deliberately absent. Both
* `reads` and `changes` participate because callers use the complete footprint
* for authorization, invalidation, scheduling, and evidence.
*/
function identityFromNormalized(contract) {
	return Object.freeze({
		version: 1,
		id: contract.id,
		inputSchema: contract.inputSchema,
		outputSchema: contract.outputSchema,
		...contract.errorSchema === void 0 ? {} : { errorSchema: contract.errorSchema },
		reads: contract.reads,
		changes: contract.changes
	});
}
function interactionContractIdentity(contract) {
	return identityFromNormalized(normalizedContracts.has(contract) ? contract : normalizeContract(contract));
}
async function digestInteractionContract(contract, hasher = hashJson) {
	return digest(hasher, INTERACTION_CONTRACT_DOMAIN, interactionContractIdentity(contract));
}
async function createInteractionDescriptor(source, hasher = hashJson) {
	const contract = normalizeContract(source.contract);
	const contractDigest = await digestInteractionContract(contract, hasher);
	return Object.freeze({
		version: 1,
		contract,
		contractDigest,
		docs: normalizeDocumentation(source.docs ?? {}),
		annotations: cloneJson(source.annotations ?? {}, `${contract.id}.annotations`)
	});
}
async function normalizeDescriptor(descriptor, hasher) {
	if (descriptor.version !== 1) fail$3("UNSUPPORTED_DESCRIPTOR_VERSION", `${descriptor.contract.id}.descriptor.version`, `${descriptor.contract.id} must use interaction descriptor version 1`);
	const normalized = await createInteractionDescriptor({
		contract: descriptor.contract,
		docs: descriptor.docs,
		annotations: descriptor.annotations
	}, hasher);
	if (normalized.contractDigest !== descriptor.contractDigest) fail$3("CONTRACT_DIGEST_MISMATCH", `${descriptor.contract.id}.contractDigest`, `${descriptor.contract.id} contract digest does not match its contract`);
	return normalized;
}
/** Return the exact sorted JSON array hashed for whole-program identity. */
function programIdentity(interactions) {
	return Object.freeze([...interactions].sort((left, right) => compareUtf8(left.contract.id, right.contract.id)).map((interaction) => interactionContractIdentity(interaction.contract)));
}
async function digestProgram(interactions, hasher = hashJson) {
	return digest(hasher, PROGRAM_DOMAIN, programIdentity(interactions));
}
async function createProgram(interactions, hasher = hashJson) {
	const normalized = await Promise.all(interactions.map((interaction) => normalizeDescriptor(interaction, hasher)));
	normalized.sort((left, right) => compareUtf8(left.contract.id, right.contract.id));
	for (let index = 1; index < normalized.length; index += 1) {
		const current = normalized[index];
		if (normalized[index - 1].contract.id === current.contract.id) fail$3("DUPLICATE_INTERACTION_ID", `program.interactions.${current.contract.id}`, `duplicate interaction id: ${current.contract.id}`);
	}
	const frozenInteractions = Object.freeze(normalized);
	return Object.freeze({
		version: 1,
		interactions: frozenInteractions,
		programDigest: await digestProgram(frozenInteractions, hasher)
	});
}
async function validateProgram(program, hasher = hashJson) {
	if (program.version !== 1) fail$3("UNSUPPORTED_PROGRAM_VERSION", "program.version", "program must use version 1");
	const normalized = await createProgram(program.interactions, hasher);
	if (normalized.programDigest !== program.programDigest) fail$3("PROGRAM_DIGEST_MISMATCH", "program.programDigest", "program digest does not match its interactions");
	return normalized;
}
async function composePrograms(programs, hasher = hashJson) {
	await Promise.all(programs.map((program) => validateProgram(program, hasher)));
	return createProgram(programs.flatMap((program) => [...program.interactions]), hasher);
}
function diffPrograms(previous, next) {
	const before = new Map(previous.interactions.map((interaction) => [interaction.contract.id, interaction.contractDigest]));
	const after = new Map(next.interactions.map((interaction) => [interaction.contract.id, interaction.contractDigest]));
	const ids = [.../* @__PURE__ */ new Set([...before.keys(), ...after.keys()])].sort(compareUtf8);
	const added = [];
	const removed = [];
	const changed = [];
	const unchanged = [];
	for (const id of ids) if (!before.has(id)) added.push(id);
	else if (!after.has(id)) removed.push(id);
	else if (before.get(id) !== after.get(id)) changed.push(id);
	else unchanged.push(id);
	return Object.freeze({
		added: Object.freeze(added),
		removed: Object.freeze(removed),
		changed: Object.freeze(changed),
		unchanged: Object.freeze(unchanged)
	});
}
//#endregion
//#region packages/core/program/src/delta.ts
/**
* Explain changes between validated, normalized contract snapshots. Arrays
* change as whole values; changes are ordered by UTF-8 path. This native review
* aid has no wire form or identity and makes no claim about realization behavior.
* Compatibility remains the same directional judgment used by Binding.
*/
function contractChanges(before, after) {
	const previous = interactionContractIdentity(before);
	const next = interactionContractIdentity(after);
	const changes = [];
	diff("", previous, next, changes);
	changes.sort((left, right) => compareUtf8(left.path, right.path));
	return Object.freeze({
		changes: Object.freeze(changes),
		existingCallers: Object.freeze(contractCompatibility(previous, next))
	});
}
function isObject(value) {
	return value !== null && typeof value === "object" && !Array.isArray(value);
}
function join(prefix, key) {
	return prefix ? `${prefix}.${key}` : key;
}
function diff(path, before, after, out) {
	if (isObject(before) && isObject(after)) {
		for (const [key, oldValue] of Object.entries(before)) {
			const nestedPath = join(path, key);
			if (Object.hasOwn(after, key)) diff(nestedPath, oldValue, after[key], out);
			else out.push(Object.freeze({
				path: nestedPath,
				kind: "removed",
				before: oldValue
			}));
		}
		for (const [key, newValue] of Object.entries(after)) if (!Object.hasOwn(before, key)) out.push(Object.freeze({
			path: join(path, key),
			kind: "added",
			after: newValue
		}));
	} else if (!jsonEquals(before, after)) out.push(Object.freeze({
		path,
		kind: "changed",
		before,
		after
	}));
}
//#endregion
//#region packages/core/program/src/catalog.ts
var REALIZATION_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u;
var CatalogError = class extends BoundaryErrorBase {
	constructor(code, path, message) {
		super(code, path, message);
		this.name = "CatalogError";
	}
};
function fail$2(code, path, message) {
	throw new CatalogError(code, path, message);
}
function requireObject(value, path, label) {
	if (value === null || typeof value !== "object" || Array.isArray(value)) fail$2("CATALOG_INVALID_AVAILABILITY", path, `${label} must be an object`);
	return value;
}
function requireExactKeys(value, path, required, optional = []) {
	const allowed = /* @__PURE__ */ new Set([...required, ...optional]);
	const extra = Object.keys(value).find((key) => !allowed.has(key));
	if (extra !== void 0) fail$2("CATALOG_INVALID_AVAILABILITY", `${path}.${extra}`, `${path} contains an unsupported field`);
	const missing = required.find((key) => !Object.hasOwn(value, key));
	if (missing !== void 0) fail$2("CATALOG_INVALID_AVAILABILITY", `${path}.${missing}`, `${path} requires ${missing}`);
}
function requireRealizationId(value, path) {
	if (typeof value !== "string" || !REALIZATION_ID_PATTERN.test(value)) fail$2("CATALOG_INVALID_REALIZATION_ID", path, "realizationId must be a non-empty stable ASCII token");
	return value;
}
function normalizeDirect(value, path) {
	const direct = requireObject(value, path, "direct mode");
	requireExactKeys(direct, path, ["realizationId"]);
	return Object.freeze({ realizationId: requireRealizationId(direct["realizationId"], `${path}.realizationId`) });
}
function normalizeRequest(value, path) {
	const request = requireObject(value, path, "request mode");
	requireExactKeys(request, path, [
		"realizationId",
		"controlDigest",
		"previewSchema"
	]);
	const controlDigest = request["controlDigest"];
	if (!isSha256Digest(controlDigest)) fail$2("CATALOG_INVALID_CONTROL_DIGEST", `${path}.controlDigest`, "controlDigest must be sha256:<64 lowercase hex>");
	const previewSchema = request["previewSchema"];
	if (previewSchema === null || typeof previewSchema !== "object" || Array.isArray(previewSchema)) fail$2("CATALOG_INVALID_PREVIEW_SCHEMA", `${path}.previewSchema`, "previewSchema must be a portable schema object");
	try {
		validatePortableSchema(previewSchema, `${path}.previewSchema`);
	} catch {
		fail$2("CATALOG_INVALID_PREVIEW_SCHEMA", `${path}.previewSchema`, "previewSchema must use the portable schema profile");
	}
	return Object.freeze({
		realizationId: requireRealizationId(request["realizationId"], `${path}.realizationId`),
		controlDigest,
		previewSchema
	});
}
function normalizeInteractions(program, source) {
	const safeSource = normalizeJson(source, "catalog.interactions");
	if (!Array.isArray(safeSource)) fail$2("CATALOG_INVALID_AVAILABILITY", "catalog.interactions", "catalog interactions must be an array of interaction entries");
	const programIds = new Set(program.interactions.map((interaction) => interaction.contract.id));
	const seenInteractions = /* @__PURE__ */ new Set();
	const seenRealizations = /* @__PURE__ */ new Set();
	const normalized = [];
	for (let index = 0; index < safeSource.length; index += 1) {
		const path = `catalog.interactions[${index}]`;
		const entry = requireObject(safeSource[index], path, "catalog entry");
		requireExactKeys(entry, path, ["interactionId"], ["direct", "request"]);
		const interactionId = entry["interactionId"];
		if (typeof interactionId !== "string" || !programIds.has(interactionId)) fail$2("CATALOG_UNKNOWN_INTERACTION", `${path}.interactionId`, `catalog cannot advertise interaction absent from program: ${String(interactionId)}`);
		if (seenInteractions.has(interactionId)) fail$2("CATALOG_DUPLICATE_INTERACTION", `${path}.interactionId`, `catalog contains duplicate interaction entry: ${interactionId}`);
		seenInteractions.add(interactionId);
		const direct = Object.hasOwn(entry, "direct") ? normalizeDirect(entry["direct"], `${path}.direct`) : void 0;
		const request = Object.hasOwn(entry, "request") ? normalizeRequest(entry["request"], `${path}.request`) : void 0;
		for (const [mode, realizationId] of [["direct", direct?.realizationId], ["request", request?.realizationId]]) {
			if (realizationId === void 0) continue;
			if (seenRealizations.has(realizationId)) fail$2("CATALOG_DUPLICATE_REALIZATION", `${path}.${mode}.realizationId`, "one realizationId cannot identify more than one interaction mode");
			seenRealizations.add(realizationId);
		}
		normalized.push(Object.freeze({
			interactionId,
			...direct === void 0 ? {} : { direct },
			...request === void 0 ? {} : { request }
		}));
	}
	for (const interactionId of [...programIds].sort(compareUtf8)) if (!seenInteractions.has(interactionId)) fail$2("CATALOG_MISSING_INTERACTION", "catalog.interactions", `catalog must declare availability for program interaction: ${interactionId}`);
	return Object.freeze(normalized.sort((left, right) => compareUtf8(left.interactionId, right.interactionId)));
}
function createCatalog(program, interactions) {
	if (program.version !== 1 || !isSha256Digest(program.programDigest)) fail$2("CATALOG_INVALID_PROGRAM_DIGEST", "catalog.programDigest", "catalog requires a valid program SHA-256 digest");
	return Object.freeze({
		version: 1,
		programDigest: program.programDigest,
		interactions: normalizeInteractions(program, interactions)
	});
}
/** Revalidate a received catalog against the exact program it claims to expose. */
function validateCatalog(program, catalog) {
	if (catalog.version !== 1 || !isSha256Digest(catalog.programDigest)) fail$2("CATALOG_INVALID_PROGRAM_DIGEST", "catalog.programDigest", "catalog must use version 1 with a valid program SHA-256 digest");
	if (catalog.programDigest !== program.programDigest) fail$2("CATALOG_PROGRAM_MISMATCH", "catalog.programDigest", "catalog was produced for a different program");
	return createCatalog(program, catalog.interactions);
}
//#endregion
//#region packages/core/program/src/draft.ts
/**
* The interaction Draft: a bot proposes a contract that does not exist yet.
*
* "Proposal" already names Control's pending effect, so a contract that does
* not yet exist gets its own word. A Draft wraps a FULL interaction contract —
* the entire declared identity in {@link InteractionContract}, never a
* fragment — because anything less would fork contract identity, which is
* the whole thing to avoid. It adds only what a proposal needs on top: the
* gap the contract would fill (`gap`), who proposed it (`proposer`, an
* opaque host-supplied string), and when (`createdAt`, a host-supplied
* ISO-8601 timestamp).
*
* A Draft is not a Program entry. {@link Program} never contains one, and
* nothing here is callable. It is an inert artifact: a person still reviews
* it and, if accepted, a host still declares the contract through the
* ordinary {@link InteractionContract} path. Declaration remains distinct from
* realization, and interfaces still narrow authority rather than invent it.
*
* Boundary never reads a clock internally; ambient time would be unreviewable,
* silently varying input, so `createdAt` is host-supplied and only checked
* for shape here.
*
* This is a from-scratch TypeScript port of the algorithm in
* `crates/boundary-core/src/program/draft.rs`. It must produce byte-identical
* digests for the same input; the shared conformance vector is the check,
* not this comment.
*/
/** Identity domain for a Draft. */
var INTERACTION_DRAFT_DOMAIN = "boundary.interaction-draft/v1";
/** A Draft that cannot be built, or a draft that failed to verify. */
var DraftError = class extends BoundaryErrorBase {
	constructor(code, path, message) {
		super(code, path, message);
		this.name = "DraftError";
	}
};
function fail$1(code, path, message) {
	throw new DraftError(code, path, message);
}
var TIMESTAMP_PATTERN = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(Z|[+-]\d{2}:\d{2})$/u;
var OFFSET_PATTERN = /^[+-](\d{2}):(\d{2})$/u;
function daysInMonth(year, month) {
	switch (month) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12: return 31;
		case 4:
		case 6:
		case 9:
		case 11: return 30;
		case 2: return isLeapYear(year) ? 29 : 28;
		default: return 0;
	}
}
function isLeapYear(year) {
	return year % 4 === 0 && year % 100 !== 0 || year % 400 === 0;
}
/**
* Validates the strict ISO-8601 shape a Draft's `createdAt` requires:
* `YYYY-MM-DDTHH:MM:SS[.f+](Z|(+|-)HH:MM)`, with calendar-aware
* day-of-month bounds and a leap-second allowance on the seconds field.
*
* This is a from-scratch port of `crates/boundary-core/src/program/timestamp.rs`.
*/
function isValidDraftTimestamp(value) {
	const match = TIMESTAMP_PATTERN.exec(value);
	if (match === null) return false;
	const [, yearText, monthText, dayText, hourText, minuteText, secondText, offset] = match;
	const year = Number(yearText);
	const month = Number(monthText);
	const day = Number(dayText);
	const hour = Number(hourText);
	const minute = Number(minuteText);
	const second = Number(secondText);
	if (month < 1 || month > 12) return false;
	if (day < 1 || day > daysInMonth(year, month)) return false;
	if (hour > 23) return false;
	if (minute > 59) return false;
	if (second > 60) return false;
	if (offset === "Z") return true;
	const offsetMatch = OFFSET_PATTERN.exec(offset ?? "");
	if (offsetMatch === null) return false;
	const [, offsetHourText, offsetMinuteText] = offsetMatch;
	return Number(offsetHourText) <= 23 && Number(offsetMinuteText) <= 59;
}
function draftIdentity(contract, gap, proposer, createdAt) {
	return {
		version: 1,
		contract: interactionContractIdentity(contract),
		gap,
		proposer,
		createdAt
	};
}
/**
* Builds and validates a Draft, computing its digest.
*
* @throws {DraftError} when `gap` or `proposer` is empty, or `createdAt` is
* not a valid ISO-8601 timestamp.
*/
async function createDraft(source, hasher = hashJson) {
	const gap = source.gap;
	if (gap.trim() === "") fail$1("EMPTY_GAP", "draft.gap", "a draft's gap explanation must not be empty");
	const proposer = source.proposer;
	if (proposer.trim() === "") fail$1("EMPTY_PROPOSER", "draft.proposer", "a draft's proposer must not be empty");
	const createdAt = source.createdAt;
	if (!isValidDraftTimestamp(createdAt)) fail$1("INVALID_CREATED_AT", "draft.createdAt", "a draft's createdAt must be a valid ISO-8601 timestamp");
	const contract = interactionContractIdentity(source.contract);
	const draftDigest = await hasher(INTERACTION_DRAFT_DOMAIN, draftIdentity(contract, gap, proposer, createdAt));
	return Object.freeze({
		version: 1,
		contract,
		gap,
		proposer,
		createdAt,
		draftDigest
	});
}
/**
* Recomputes and checks the digest of a Draft that crossed a boundary.
*
* @throws {DraftError} with code `DIGEST_MISMATCH` when the draft's recorded
* digest does not match its content.
*/
async function verifyDraft(draft, hasher = hashJson) {
	const recomputed = await hasher(INTERACTION_DRAFT_DOMAIN, draftIdentity(draft.contract, draft.gap, draft.proposer, draft.createdAt));
	if (recomputed !== draft.draftDigest) fail$1("DIGEST_MISMATCH", "draft.draftDigest", `draft digest mismatch: recorded ${draft.draftDigest}, recomputed ${recomputed}`);
}
//#endregion
//#region packages/core/program/src/observation.ts
/** Validate data received from a host-chosen observation channel. This does not authenticate its publisher. */
function validateInvocationObservation(value) {
	const event = normalizeJson(value);
	if (!event || Array.isArray(event) || typeof event !== "object") throw new TypeError("invalid invocation observation");
	const required = [
		"version",
		"bindingDigest",
		"projectionDigest",
		"installationId",
		"installationDigest",
		"interactionId",
		"expectedContractDigest",
		"actualContractDigest",
		"mode",
		"realizationId",
		"certainty",
		"resultKind",
		"reads",
		"changes"
	];
	if (required.some((key) => !Object.hasOwn(event, key)) || Object.keys(event).some((key) => !required.includes(key) && key !== "correlation")) throw new TypeError("invalid observation fields");
	for (const key of [
		"bindingDigest",
		"projectionDigest",
		"installationDigest",
		"expectedContractDigest",
		"actualContractDigest"
	]) if (!isSha256Digest(event[key])) throw new TypeError(`invalid observation ${key}`);
	for (const key of ["installationId", "realizationId"]) if (typeof event[key] !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u.test(event[key])) throw new TypeError(`invalid observation ${key}`);
	for (const key of ["reads", "changes"]) {
		const resources = event[key];
		if (!Array.isArray(resources) || resources.some((resource) => typeof resource !== "string" || resource.length === 0)) throw new TypeError(`invalid observation ${key}`);
	}
	const legal = event.resultKind === "fault" ? [
		"not-started",
		"not-completed",
		"unknown"
	].includes(String(event.certainty)) : event.resultKind === "proposed" ? event.mode === "request" && event.certainty === "not-started" : event.resultKind === "denied" ? event.certainty === "not-started" : ["returned", "declared-error"].includes(String(event.resultKind)) && event.mode === "direct" && event.certainty === "completed";
	if (event.version !== 1 || !isInteractionId(event.interactionId) || !["direct", "request"].includes(String(event.mode)) || !legal) throw new TypeError("invalid observation outcome");
	return event;
}
//#endregion
//#region packages/core/program/src/evidence.ts
var ExecutionEvidenceError = class extends BoundaryErrorBase {
	constructor(code, path, message) {
		super(code, path, message);
		this.name = "ExecutionEvidenceError";
	}
};
var kinds = [
	"evidence",
	"invocation",
	"subject",
	"attempt",
	"receipt"
];
var states = [
	"pending",
	"completed",
	"not-started",
	"not-completed",
	"uncertain"
];
var identifier = /^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u;
function fail(path, message) {
	throw new ExecutionEvidenceError("INVALID_EXECUTION_EVIDENCE", path, message);
}
function object(value, required, optional, path) {
	if (!value || typeof value !== "object" || Array.isArray(value)) fail(path, "expected an evidence object");
	const record = value;
	if (required.some((key) => !Object.hasOwn(record, key))) fail(path, "required evidence fields are missing");
	const extra = Object.keys(record).find((key) => !required.includes(key) && !optional.includes(key));
	if (extra !== void 0) fail(`${path}.${extra}`, "unknown evidence field");
	return record;
}
function reference(value, allowed, path) {
	const record = object(value, [
		"kind",
		"namespace",
		"id"
	], [], path);
	if (typeof record.kind !== "string" || !allowed.includes(record.kind)) fail(`${path}.kind`, "reference has the wrong entity kind");
	for (const key of ["namespace", "id"]) if (typeof record[key] !== "string" || !identifier.test(record[key])) fail(`${path}.${key}`, "reference identity must be 1-256 bounded ASCII identifier characters");
	return record;
}
function key(value) {
	return `${value.namespace}\0${value.id}`;
}
/** Strictly validate, clone and deeply freeze an execution evidence envelope. */
function validateExecutionEvidence(value) {
	const envelope = object(normalizeJson(value, "evidence"), [
		"version",
		"reference",
		"invocation"
	], [
		"subject",
		"parents",
		"children",
		"attempt",
		"receipt"
	], "evidence");
	if (envelope.version !== 1) fail("evidence.version", "unsupported execution evidence version");
	const own = reference(envelope.reference, ["evidence"], "evidence.reference");
	const invocation = object(envelope.invocation, ["reference", "observation"], [], "evidence.invocation");
	const invoked = reference(invocation.reference, ["invocation"], "evidence.invocation.reference");
	validateInvocationObservation(invocation.observation);
	const identities = /* @__PURE__ */ new Map();
	const remember = (ref, path) => {
		const previous = identities.get(key(ref));
		if (previous !== void 0 && previous !== ref.kind) throw new ExecutionEvidenceError("CONFLICTING_EVIDENCE_REFERENCE", path, "one namespace and ID cannot identify different entity kinds");
		identities.set(key(ref), ref.kind);
	};
	remember(own, "evidence.reference");
	remember(invoked, "evidence.invocation.reference");
	if (envelope.subject !== void 0) {
		const subject = object(envelope.subject, ["reference", "state"], [], "evidence.subject");
		remember(reference(subject.reference, ["subject"], "evidence.subject.reference"), "evidence.subject.reference");
		if (typeof subject.state !== "string" || !states.includes(subject.state)) fail("evidence.subject.state", "unsupported subject state");
	}
	for (const field of ["attempt", "receipt"]) if (envelope[field] !== void 0) remember(reference(envelope[field], [field], `evidence.${field}`), `evidence.${field}`);
	const linked = /* @__PURE__ */ new Map();
	for (const field of ["parents", "children"]) {
		const links = envelope[field];
		if (links === void 0) continue;
		if (!Array.isArray(links) || links.length > 128) fail(`evidence.${field}`, "causal links must be an array with at most 128 references");
		for (const [index, raw] of links.entries()) {
			const path = `evidence.${field}[${index}]`;
			const ref = reference(raw, kinds, path);
			remember(ref, path);
			if (key(ref) === key(own) || key(ref) === key(invoked)) throw new ExecutionEvidenceError("CONFLICTING_EVIDENCE_REFERENCE", path, "evidence and its invocation cannot be their own causal links");
			const previous = linked.get(key(ref));
			if (previous !== void 0) throw new ExecutionEvidenceError(previous === field ? "DUPLICATE_EVIDENCE_REFERENCE" : "CONFLICTING_EVIDENCE_REFERENCE", path, "causal references must be unique and cannot be both parents and children");
			linked.set(key(ref), field);
		}
	}
	return envelope;
}
//#endregion
//#region packages/core/program/src/binding-description.ts
/** Join declared pins from a checked manifest; this function does not authenticate its source. */
function bindingDescriptions(manifest) {
	const expected = new Map(manifest.expectedProgram.interactions.map((entry) => [entry.contract.id, entry]));
	const actual = new Map(manifest.actualProgram.interactions.map((entry) => [entry.contract.id, entry]));
	return Object.freeze(manifest.interactions.map((selection) => {
		const expectedDescriptor = expected.get(selection.interactionId);
		const actualDescriptor = actual.get(selection.interactionId);
		if (expectedDescriptor?.contractDigest !== selection.expectedContractDigest || actualDescriptor?.contractDigest !== selection.actualContractDigest) throw new TypeError("Binding description requires matching selected contract pins");
		return normalizeJson({
			...selection,
			expected: expectedDescriptor,
			actual: actualDescriptor
		});
	}));
}
//#endregion
//#region packages/core/program/src/invocation-fault.ts
/** The shared v1 stable fault law, used for retained native and Handoff outcomes. */
function isInvocationFaultLegal(mode, cause, certainty) {
	switch (cause) {
		case "invalid-input":
		case "revoked":
		case "admission-failed":
		case "invalid-invocation": return certainty === "not-started";
		case "request-failed": return mode === "request" && certainty === "not-started";
		case "invalid-realization-outcome": return mode === "direct" && certainty === "unknown";
		case "realization-failed": return certainty === "unknown" || mode === "direct" && (certainty === "not-started" || certainty === "not-completed");
		default: return false;
	}
}
//#endregion
export { BoundaryErrorBase, CatalogError, DraftError, ExecutionEvidenceError, INTERACTION_CONTRACT_DOMAIN, INTERACTION_DRAFT_DOMAIN, INTERACTION_ID_PATTERN, JsonError, PROGRAM_DOMAIN, PortableSchemaError, ProgramError, SchemaAdapterError, bindingDescriptions, canonicalJson, cloneJson, compareUtf8, compileSchema, composePrograms, contractChanges, contractCompatibility, createCatalog, createDraft, createInteractionDescriptor, createProgram, diffPrograms, digestInteractionContract, digestProgram, exactObject, hashJson, interactionContractIdentity, isInteractionId, isInvocationFaultLegal, isPortableSchema, isSha256Digest, isValidDraftTimestamp, jsonEquals, normalizeJson, portableSchema, programIdentity, sha256, snapshotJson, validateCatalog, validateExecutionEvidence, validateInvocationObservation, validatePortableSchema, validateProgram, validateSchemaValue, verifyDraft };
