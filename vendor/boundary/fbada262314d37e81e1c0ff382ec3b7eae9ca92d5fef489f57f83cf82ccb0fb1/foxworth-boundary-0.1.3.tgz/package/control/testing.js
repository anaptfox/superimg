import { a as controlError, t as controlReaderScopeIncludes } from "../chunks/readerScope-D1JnbSm8.js";
import { cloneJson, compareUtf8, jsonEquals } from "@foxworth/boundary/program";
//#region packages/core/control/src/testing.ts
function snapshot(value, path) {
	return cloneJson(value, path);
}
function result(kind, record, path) {
	return {
		kind,
		record: snapshot(record, path)
	};
}
function journalConflict(path, message) {
	throw controlError("CONTROL_JOURNAL_CONFLICT", path, message);
}
function assertUnusedId(records, kind, id) {
	if (records.has(id)) journalConflict(`${kind}.id`, `${kind} id already belongs to another record: ${id}`);
}
var immutableAttemptFields = [
	"version",
	"proposalId",
	"proposalDigest",
	"bindingDigest",
	"projectionDigest",
	"installationId",
	"installationDigest",
	"expectedProgramDigest",
	"actualProgramDigest",
	"programDigest",
	"grantId",
	"controlDigest",
	"interactionId",
	"expectedContractDigest",
	"contractDigest",
	"requestRealizationId",
	"executionRealizationId",
	"controlRealizationDigest",
	"createdAt"
];
/** Deterministic, independently incrementing identifiers for control fixtures. */
var TestIds = class {
	#counts = /* @__PURE__ */ new Map();
	#prefix;
	constructor(prefix = "test") {
		if (!prefix.trim()) throw new TypeError("TestIds prefix must be non-empty");
		this.#prefix = prefix;
	}
	nextId(kind) {
		const next = (this.#counts.get(kind) ?? 0) + 1;
		this.#counts.set(kind, next);
		return `${this.#prefix}-${kind}-${next}`;
	}
};
/** Mutable deterministic clock for control and lease tests. */
var TestClock = class TestClock {
	#current;
	constructor(initialNow = 0) {
		this.#current = TestClock.assertTime(initialNow, "initialNow");
	}
	now() {
		return this.#current;
	}
	set(value) {
		this.#current = TestClock.assertTime(value, "value");
		return this.#current;
	}
	advance(milliseconds) {
		if (!Number.isFinite(milliseconds) || milliseconds < 0) throw new RangeError("TestClock advance must be a finite, non-negative number");
		return this.set(this.#current + milliseconds);
	}
	static assertTime(value, path) {
		if (!Number.isFinite(value)) throw new RangeError(`TestClock ${path} must be finite`);
		return value === 0 ? 0 : value;
	}
};
/**
* Browser-safe, process-local control journal for deterministic tests.
*
* Every boundary returns a fresh, deeply frozen JSON snapshot. Create methods
* contain no suspension point, so their uniqueness checks and writes are one
* atomic JavaScript turn.
*/
var MemoryJournal = class {
	#ids;
	#proposals = /* @__PURE__ */ new Map();
	#proposalIdsByDigest = /* @__PURE__ */ new Map();
	#approvals = /* @__PURE__ */ new Map();
	#approvalIdsByProposal = /* @__PURE__ */ new Map();
	#grants = /* @__PURE__ */ new Map();
	#grantIdsByProposal = /* @__PURE__ */ new Map();
	#attempts = /* @__PURE__ */ new Map();
	#attemptIdsByProposal = /* @__PURE__ */ new Map();
	#receipts = /* @__PURE__ */ new Map();
	#receiptIdsByProposal = /* @__PURE__ */ new Map();
	constructor(ids = new TestIds()) {
		this.#ids = ids;
	}
	nextId(kind) {
		return this.#ids.nextId(kind);
	}
	async createProposal(proposal) {
		const candidate = snapshot(proposal, "proposal");
		const existingId = this.#proposalIdsByDigest.get(candidate.proposalDigest);
		if (existingId !== void 0) return result("existing", this.#proposals.get(existingId), "proposal");
		assertUnusedId(this.#proposals, "proposal", candidate.id);
		this.#proposals.set(candidate.id, candidate);
		this.#proposalIdsByDigest.set(candidate.proposalDigest, candidate.id);
		return result("created", candidate, "proposal");
	}
	async getProposal(id) {
		const record = this.#proposals.get(id);
		return record === void 0 ? void 0 : snapshot(record, "proposal");
	}
	async findProposalByDigest(digest) {
		const id = this.#proposalIdsByDigest.get(digest);
		return id === void 0 ? void 0 : snapshot(this.#proposals.get(id), "proposal");
	}
	async listProposals() {
		return snapshot([...this.#proposals.values()].sort((left, right) => compareUtf8(left.id, right.id)), "proposals");
	}
	async queryProposals(query) {
		return snapshot([...this.#proposals.values()].filter((row) => controlReaderScopeIncludes(query.scope, row) && (query.interactionId === void 0 || row.interactionId === query.interactionId) && (query.afterId === void 0 || compareUtf8(row.id, query.afterId) > 0)).sort((left, right) => compareUtf8(left.id, right.id)).slice(0, query.limit), "proposals");
	}
	async readStatusChains(digests) {
		return snapshot(digests.map((proposalDigest) => {
			const grantId = this.#grantIdsByProposal.get(proposalDigest);
			const attemptId = this.#attemptIdsByProposal.get(proposalDigest);
			const receiptId = this.#receiptIdsByProposal.get(proposalDigest);
			return {
				proposalDigest,
				...grantId === void 0 ? {} : { grant: this.#grants.get(grantId) },
				...attemptId === void 0 ? {} : { attempt: this.#attempts.get(attemptId) },
				...receiptId === void 0 ? {} : { receipt: this.#receipts.get(receiptId) }
			};
		}), "chains");
	}
	async createApproval(approval) {
		const candidate = snapshot(approval, "approval");
		const byActor = this.#approvalIdsByProposal.get(candidate.proposalDigest);
		const existingId = byActor?.get(candidate.approvedBy);
		if (existingId !== void 0) {
			const existing = this.#approvals.get(existingId);
			if (!jsonEquals(existing, candidate)) journalConflict(`approval.${candidate.id}`, "approval already exists for this proposal and actor with different content");
			return result("existing", existing, "approval");
		}
		assertUnusedId(this.#approvals, "approval", candidate.id);
		this.#approvals.set(candidate.id, candidate);
		const actorIndex = byActor ?? /* @__PURE__ */ new Map();
		actorIndex.set(candidate.approvedBy, candidate.id);
		if (byActor === void 0) this.#approvalIdsByProposal.set(candidate.proposalDigest, actorIndex);
		return result("created", candidate, "approval");
	}
	async listApprovals(proposalDigest) {
		const byActor = this.#approvalIdsByProposal.get(proposalDigest);
		if (byActor === void 0) return Object.freeze([]);
		return snapshot([...byActor.values()].map((id) => this.#approvals.get(id)).sort((left, right) => compareUtf8(left.approvedBy, right.approvedBy) || compareUtf8(left.id, right.id)), "approvals");
	}
	async getApproval(id) {
		const record = this.#approvals.get(id);
		return record === void 0 ? void 0 : snapshot(record, "approval");
	}
	async createGrant(grant) {
		const candidate = snapshot(grant, "grant");
		const existingId = this.#grantIdsByProposal.get(candidate.proposalDigest);
		if (existingId !== void 0) return result("existing", this.#grants.get(existingId), "grant");
		assertUnusedId(this.#grants, "grant", candidate.id);
		this.#grants.set(candidate.id, candidate);
		this.#grantIdsByProposal.set(candidate.proposalDigest, candidate.id);
		return result("created", candidate, "grant");
	}
	async getGrant(id) {
		const record = this.#grants.get(id);
		return record === void 0 ? void 0 : snapshot(record, "grant");
	}
	async findGrantByProposalDigest(digest) {
		const id = this.#grantIdsByProposal.get(digest);
		return id === void 0 ? void 0 : snapshot(this.#grants.get(id), "grant");
	}
	async createAttempt(attempt) {
		const candidate = snapshot(attempt, "attempt");
		const existingId = this.#attemptIdsByProposal.get(candidate.proposalDigest);
		if (existingId !== void 0) return result("existing", this.#attempts.get(existingId), "attempt");
		assertUnusedId(this.#attempts, "attempt", candidate.id);
		this.#attempts.set(candidate.id, candidate);
		this.#attemptIdsByProposal.set(candidate.proposalDigest, candidate.id);
		return result("created", candidate, "attempt");
	}
	async compareAndSwapAttempt(attempt, expectedRecordRevision) {
		const candidate = snapshot(attempt, "attempt");
		const current = this.#attempts.get(candidate.id);
		if (current === void 0 || current.recordRevision !== expectedRecordRevision) return false;
		if (!Number.isInteger(expectedRecordRevision) || candidate.recordRevision !== expectedRecordRevision + 1) journalConflict("attempt.recordRevision", `attempt revision must advance exactly from ${expectedRecordRevision} to ${expectedRecordRevision + 1}`);
		for (const field of immutableAttemptFields) if (candidate[field] !== current[field]) journalConflict(`attempt.${field}`, `attempt ${field} is immutable after creation`);
		this.#attempts.set(candidate.id, candidate);
		return true;
	}
	async getAttempt(id) {
		const record = this.#attempts.get(id);
		return record === void 0 ? void 0 : snapshot(record, "attempt");
	}
	async findAttemptByProposalDigest(digest) {
		const id = this.#attemptIdsByProposal.get(digest);
		return id === void 0 ? void 0 : snapshot(this.#attempts.get(id), "attempt");
	}
	async createReceipt(receipt) {
		const candidate = snapshot(receipt, "receipt");
		const existingId = this.#receiptIdsByProposal.get(candidate.proposalDigest);
		if (existingId !== void 0) return result("existing", this.#receipts.get(existingId), "receipt");
		assertUnusedId(this.#receipts, "receipt", candidate.id);
		this.#receipts.set(candidate.id, candidate);
		this.#receiptIdsByProposal.set(candidate.proposalDigest, candidate.id);
		return result("created", candidate, "receipt");
	}
	async getReceipt(id) {
		const record = this.#receipts.get(id);
		return record === void 0 ? void 0 : snapshot(record, "receipt");
	}
	async findReceiptByProposalDigest(digest) {
		const id = this.#receiptIdsByProposal.get(digest);
		return id === void 0 ? void 0 : snapshot(this.#receipts.get(id), "receipt");
	}
};
//#endregion
export { MemoryJournal, TestClock, TestIds };
