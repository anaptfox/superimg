import { a as controlError } from "../chunks/readerScope-D1JnbSm8.js";
import { A as targetForControl, P as PUBLIC_PROPOSAL_SCHEMA, k as requireResolvedControl, l as requestForControlRequester } from "../chunks/controller-DgpKVg4E.js";
import { cloneJson, exactObject, isInteractionId, isSha256Digest, validatePortableSchema } from "@foxworth/boundary/program";
import { createControlRequestContributions } from "@foxworth/boundary/host/control";
//#region packages/core/control/src/host.ts
function assertStaticControl(interaction, control, executionRealizationId, path) {
	const resolved = requireResolvedControl(control);
	if (interaction.interactionId !== resolved.identity.interactionId || interaction.contractDigest !== resolved.identity.contractDigest) throw controlError("CONTROL_INTEGRITY_MISMATCH", path, "request contribution interaction does not match the controlled realization");
	if (typeof executionRealizationId !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u.test(executionRealizationId) || !isSha256Digest(resolved.controlDigest) || !isSha256Digest(resolved.hook.realizationDigest)) throw controlError("CONTROL_INVALID_REALIZATION", path, "request contribution requires static control and execution realization identity");
	validatePortableSchema(resolved.previewSchema, `${path}.previewSchema`);
	return resolved;
}
function snapshotRequestPolicy(value, path) {
	let candidate;
	try {
		candidate = cloneJson(value, path);
	} catch (error) {
		throw controlError("CONTROL_INVALID_REALIZATION", path, error instanceof Error ? error.message : "request policy must be portable data", error);
	}
	const policy = exactObject(candidate, {
		path,
		keys: [
			"mode",
			"bindingDigest",
			"projectionDigest",
			"installationId",
			"installationDigest",
			"expectedProgramDigest",
			"actualProgramDigest",
			"installationProgramDigest",
			"interactionId",
			"expectedContractDigest",
			"actualContractDigest",
			"realizationId"
		],
		fail: (failure) => {
			throw controlError("CONTROL_INVALID_REALIZATION", failure.path, failure.message);
		}
	});
	if (policy.mode !== "request") throw controlError("CONTROL_INVALID_REALIZATION", `${path}.mode`, "request policy mode must be request");
	for (const field of [
		"bindingDigest",
		"projectionDigest",
		"installationDigest",
		"expectedProgramDigest",
		"actualProgramDigest",
		"installationProgramDigest",
		"expectedContractDigest",
		"actualContractDigest"
	]) if (!isSha256Digest(policy[field])) throw controlError("CONTROL_INVALID_REALIZATION", `${path}.${field}`, `${field} is invalid`);
	if (!isInteractionId(policy.interactionId)) throw controlError("CONTROL_INVALID_REALIZATION", `${path}.interactionId`, "interactionId is invalid");
	for (const field of ["installationId", "realizationId"]) if (typeof policy[field] !== "string" || !/^[A-Za-z0-9][A-Za-z0-9._~:/-]{0,255}$/u.test(policy[field])) throw controlError("CONTROL_INVALID_REALIZATION", `${path}.${field}`, `${field} is invalid`);
	return Object.freeze(policy);
}
function publicProposalSchema(previewSchema) {
	const base = cloneJson(PUBLIC_PROPOSAL_SCHEMA, "control.publicProposal");
	const properties = base.properties;
	const schema = cloneJson({
		...base,
		properties: {
			...properties,
			preview: previewSchema
		}
	}, "control.requestSchema");
	validatePortableSchema(schema, "control.requestSchema");
	return schema;
}
/**
* Project proposal creation into opaque Host request contributions.
*
* The returned bindings possess only an authentic `ControlRequester`; Reader
* and Admin are structurally absent. Under the Host-supplied request-only plan
* contract, each request performs one proposal-creation attempt and never
* approves, grants, executes, reconciles, retries, or replays.
*/
function contributeControlRequests(compiled, requester, contributions) {
	const requestProposal = requestForControlRequester(requester);
	if (!contributions || typeof contributions !== "object" || Array.isArray(contributions)) throw new TypeError("control request contributions must be a record");
	const requests = {};
	for (const [alias, contribution] of Object.entries(contributions)) {
		const path = `control.requests.${alias}`;
		if (!contribution || typeof contribution !== "object") throw new TypeError(`${path} must be an object`);
		const interaction = contribution.interaction;
		const control = contribution.control;
		const executionRealizationId = contribution.executionRealizationId;
		const actorForContext = contribution.actor;
		if (typeof actorForContext !== "function") throw new TypeError(`${path}.actor must be a function`);
		if (compiled.handles[alias] !== interaction) throw controlError("CONTROL_INTEGRITY_MISMATCH", `${path}.interaction`, "request contribution must use the authentic compiled handle for its alias");
		const resolved = assertStaticControl(interaction, control, executionRealizationId, path);
		const previewSchema = publicProposalSchema(resolved.previewSchema);
		const binding = Object.freeze({
			interaction,
			controlDigest: resolved.controlDigest,
			previewSchema,
			async request(input, context, policyValue) {
				const policy = snapshotRequestPolicy(policyValue, `${path}.policy`);
				if (policy.installationProgramDigest !== compiled.program.programDigest || policy.interactionId !== interaction.interactionId || policy.actualContractDigest !== interaction.contractDigest) throw controlError("CONTROL_INTEGRITY_MISMATCH", `${path}.policy`, "Host request policy does not match the compiled control contribution");
				const target = targetForControl(resolved, {
					bindingDigest: policy.bindingDigest,
					projectionDigest: policy.projectionDigest,
					installationId: policy.installationId,
					installationDigest: policy.installationDigest,
					expectedProgramDigest: policy.expectedProgramDigest,
					programDigest: policy.installationProgramDigest,
					actualProgramDigest: policy.actualProgramDigest,
					interactionId: policy.interactionId,
					expectedContractDigest: policy.expectedContractDigest,
					contractDigest: policy.actualContractDigest,
					requestRealizationId: policy.realizationId,
					executionRealizationId
				});
				const actor = await actorForContext(context);
				return requestProposal({
					actor,
					context,
					target,
					input
				});
			}
		});
		Object.defineProperty(requests, alias, {
			value: binding,
			enumerable: true,
			configurable: false,
			writable: false
		});
	}
	return createControlRequestContributions(compiled, Object.freeze(requests));
}
//#endregion
export { contributeControlRequests };
