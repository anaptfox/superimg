import { d as InteractionFault, i as defineInteraction, r as declaredInteractionError } from "./chunks/definitions-CFjJCGn-.js";
import { a as projectInteractions, o as direct } from "./chunks/projection-7MSieVvr.js";
import { digestInteractionContract, isSha256Digest, portableSchema, verifyDraft } from "@foxworth/boundary/program";
//#region packages/core/host/src/drafts/types.ts
var DRAFT_REJECT_REASONS = Object.freeze(["ordinary-code", "covered-by-existing"]);
function isDraftRejectReason(value) {
	return typeof value === "string" && DRAFT_REJECT_REASONS.includes(value);
}
//#endregion
//#region packages/core/host/src/drafts/definitions.ts
var SHA256_DIGEST_PATTERN = "^sha256:[0-9a-f]{64}$";
var DRAFT_SCHEMA = Object.freeze({
	type: "object",
	properties: {
		version: { const: 1 },
		contract: { type: "object" },
		gap: {
			type: "string",
			minLength: 1
		},
		proposer: {
			type: "string",
			minLength: 1
		},
		createdAt: { type: "string" },
		draftDigest: {
			type: "string",
			pattern: SHA256_DIGEST_PATTERN
		}
	},
	required: [
		"version",
		"contract",
		"gap",
		"proposer",
		"createdAt",
		"draftDigest"
	],
	additionalProperties: false
});
var PROPOSE_OUTPUT_SCHEMA = Object.freeze({
	type: "object",
	properties: { draftDigest: {
		type: "string",
		pattern: SHA256_DIGEST_PATTERN
	} },
	required: ["draftDigest"],
	additionalProperties: false
});
var DECISION_ACTOR_FIELDS = Object.freeze({
	decidedBy: {
		type: "string",
		minLength: 1
	},
	decidedAt: { type: "string" }
});
var ACCEPT_INPUT_SCHEMA = Object.freeze({
	type: "object",
	properties: {
		draftDigest: {
			type: "string",
			pattern: SHA256_DIGEST_PATTERN
		},
		...DECISION_ACTOR_FIELDS
	},
	required: [
		"draftDigest",
		"decidedBy",
		"decidedAt"
	],
	additionalProperties: false
});
var ACCEPT_OUTPUT_SCHEMA = Object.freeze({
	type: "object",
	properties: {
		contract: { type: "object" },
		contractDigest: {
			type: "string",
			pattern: SHA256_DIGEST_PATTERN
		}
	},
	required: ["contract", "contractDigest"],
	additionalProperties: false
});
var REJECT_REASON_SCHEMA = Object.freeze({
	type: "string",
	enum: [...DRAFT_REJECT_REASONS]
});
var REJECT_INPUT_SCHEMA = Object.freeze({
	type: "object",
	properties: {
		draftDigest: {
			type: "string",
			pattern: SHA256_DIGEST_PATTERN
		},
		reason: REJECT_REASON_SCHEMA,
		...DECISION_ACTOR_FIELDS
	},
	required: [
		"draftDigest",
		"reason",
		"decidedBy",
		"decidedAt"
	],
	additionalProperties: false
});
var REJECT_OUTPUT_SCHEMA = Object.freeze({
	type: "object",
	properties: {
		draftDigest: {
			type: "string",
			pattern: SHA256_DIGEST_PATTERN
		},
		reason: REJECT_REASON_SCHEMA
	},
	required: ["draftDigest", "reason"],
	additionalProperties: false
});
var NOT_FOUND_ERROR_SCHEMA = Object.freeze({
	type: "object",
	properties: { draftDigest: {
		type: "string",
		pattern: SHA256_DIGEST_PATTERN
	} },
	required: ["draftDigest"],
	additionalProperties: false
});
var INVALID_DRAFT_ERROR_SCHEMA = Object.freeze({
	type: "object",
	properties: { message: { type: "string" } },
	required: ["message"],
	additionalProperties: false
});
var INVALID_REASON_ERROR_SCHEMA = Object.freeze({
	type: "object",
	properties: { reason: { type: "string" } },
	required: ["reason"],
	additionalProperties: false
});
/**
* A worker proposes a full contract that does not exist yet. Direct mode:
* proposing never changes what is declared, so it stays ordinary and immediate.
*/
var draftsPropose = defineInteraction({
	id: "drafts.propose",
	input: portableSchema(DRAFT_SCHEMA, "drafts.propose.input"),
	output: portableSchema(PROPOSE_OUTPUT_SCHEMA, "drafts.propose.output"),
	errors: { invalidDraft: portableSchema(INVALID_DRAFT_ERROR_SCHEMA, "drafts.propose.errors.invalidDraft") },
	summary: "Persist a proposed interaction contract that does not exist yet.",
	description: "Verifies and stores a Draft through the host-supplied DraftStore. Never declares the drafted contract and never changes what the host serves."
});
/**
* An author accepts a Draft. Request mode by default: acceptance is a
* decision, distinct from the host's separate act of recompiling a Program
* that declares the accepted contract.
*/
var draftsAccept = defineInteraction({
	id: "drafts.accept",
	input: portableSchema(ACCEPT_INPUT_SCHEMA, "drafts.accept.input"),
	output: portableSchema(ACCEPT_OUTPUT_SCHEMA, "drafts.accept.output"),
	errors: { draftNotFound: portableSchema(NOT_FOUND_ERROR_SCHEMA, "drafts.accept.errors.draftNotFound") },
	summary: "Record that a proposed contract is accepted as a declared interaction.",
	description: "Returns the accepted contract and its digest and records the decision. Never mutates a live Program and never writes source files; the host separately recompiles a Program that declares the accepted contract."
});
/**
* An author rejects a Draft with a reason from a closed set. Request mode by
* default, for the same reason acceptance is: rejection is a decision.
*/
var draftsReject = defineInteraction({
	id: "drafts.reject",
	input: portableSchema(REJECT_INPUT_SCHEMA, "drafts.reject.input"),
	output: portableSchema(REJECT_OUTPUT_SCHEMA, "drafts.reject.output"),
	errors: {
		draftNotFound: portableSchema(NOT_FOUND_ERROR_SCHEMA, "drafts.reject.errors.draftNotFound"),
		invalidReason: portableSchema(INVALID_REASON_ERROR_SCHEMA, "drafts.reject.errors.invalidReason")
	},
	summary: "Record that a proposed contract is rejected.",
	description: "Takes a reason from a closed set: ordinary-code (a local helper, not an interaction) or covered-by-existing (existing interactions already do this)."
});
/** The closed set of Draft interactions, ready for `compileInteractions`. */
var draftsInteractions = Object.freeze({
	propose: draftsPropose,
	accept: draftsAccept,
	reject: draftsReject
});
//#endregion
//#region packages/core/host/src/drafts/service.ts
/**
* The business logic behind the three Draft interactions, factored out of
* `defineInteraction` wiring so a host can call it directly (as these tests
* do) or hand it to `implementInteractions`/a Control-style request
* contribution.
*
* Every function here talks to a host-supplied {@link DraftStore} and
* nothing else. None of them ever touches a Program, an Installation, or a
* source file: turning an accepted Draft into a declared interaction remains
* the host's separate, ordinary recompilation.
*/
function requireDraftDigest(value, fail) {
	if (!isSha256Digest(value)) fail(`draftDigest is not a valid digest: ${value}`);
	return value;
}
async function readFault(action, message) {
	try {
		return await action();
	} catch (cause) {
		throw new InteractionFault("realization-failed", "not-started", message, cause instanceof Error ? { message: cause.message } : null);
	}
}
async function writeFault(action, message) {
	try {
		await action();
	} catch (cause) {
		throw new InteractionFault("realization-failed", "unknown", message, cause instanceof Error ? { message: cause.message } : null);
	}
}
/**
* `drafts.propose`: verify and persist a Draft. Direct mode. Never reads or
* writes anything beyond `store.put`, and therefore never changes
* what is declared.
*/
async function proposeDraft(store, input) {
	const draftDigest = requireDraftDigest(input.draftDigest, (message) => {
		throw declaredInteractionError(draftsPropose, "invalidDraft", { message });
	});
	const draft = Object.freeze({
		version: 1,
		contract: input.contract,
		gap: input.gap,
		proposer: input.proposer,
		createdAt: input.createdAt,
		draftDigest
	});
	try {
		await verifyDraft(draft);
	} catch (cause) {
		throw declaredInteractionError(draftsPropose, "invalidDraft", { message: cause instanceof Error ? cause.message : "invalid draft" });
	}
	await writeFault(() => store.put(draft), "the draft store failed to persist a proposed draft");
	return Object.freeze({ draftDigest });
}
/**
* Looks up a Draft by digest and proves it is that Draft.
*
* A malformed digest and an absent digest are both reported through the same
* `draftNotFound` details: from the caller's side, an ill-formed reference
* and a missing one are indistinguishable.
*
* A Draft that is present but does not verify, or verifies as a *different*
* Draft, is neither of those. The store is host-supplied and the decisions
* are request mode, so what a person approved is a digest, not a contract.
* Verifying alone catches a tampered Draft but not a substituted one — a
* self-consistent Draft filed under someone else's digest verifies perfectly
* well. Both are faults rather than declared errors, and mirror
* `DraftFault::InvalidDraft` and `DraftFault::DraftSubstituted` in
* `crates/boundary-core/src/lifecycle/drafts.rs`.
*/
async function requireDraft(store, rawDraftDigest, fail) {
	if (!isSha256Digest(rawDraftDigest)) fail({ draftDigest: rawDraftDigest });
	const draft = await readFault(() => store.get(rawDraftDigest), "the draft store failed to look up a draft");
	if (draft === void 0) fail({ draftDigest: rawDraftDigest });
	try {
		await verifyDraft(draft);
	} catch (cause) {
		throw new InteractionFault("realization-failed", "not-started", `the stored draft ${rawDraftDigest} no longer verifies`, cause instanceof Error ? { message: cause.message } : null);
	}
	if (draft.draftDigest !== rawDraftDigest) throw new InteractionFault("realization-failed", "not-started", `draft ${rawDraftDigest} is stored as ${draft.draftDigest}; the approval names content it was never bound to`, {
		requested: rawDraftDigest,
		stored: draft.draftDigest
	});
	return draft;
}
/**
* `drafts.accept`: request mode by default. Returns the accepted contract
* and its digest and records the decision. It never mutates a live Program
* and never writes source files.
*/
async function acceptDraft(store, input) {
	const draft = await requireDraft(store, input.draftDigest, (details) => {
		throw declaredInteractionError(draftsAccept, "draftNotFound", details);
	});
	const contractDigest = await digestInteractionContract(draft.contract);
	await writeFault(() => store.recordDecision(Object.freeze({
		status: "accepted",
		draftDigest: draft.draftDigest,
		contractDigest,
		decidedBy: input.decidedBy,
		decidedAt: input.decidedAt
	})), "the draft store failed to record an acceptance decision");
	return Object.freeze({
		contract: draft.contract,
		contractDigest
	});
}
/**
* `drafts.reject`: request mode by default. Takes a reason from the closed
* set `ordinary-code` | `covered-by-existing` and records the decision.
*/
async function rejectDraft(store, input) {
	if (!isDraftRejectReason(input.reason)) throw declaredInteractionError(draftsReject, "invalidReason", { reason: input.reason });
	const reason = input.reason;
	const draft = await requireDraft(store, input.draftDigest, (details) => {
		throw declaredInteractionError(draftsReject, "draftNotFound", details);
	});
	await writeFault(() => store.recordDecision(Object.freeze({
		status: "rejected",
		draftDigest: draft.draftDigest,
		reason,
		decidedBy: input.decidedBy,
		decidedAt: input.decidedAt
	})), "the draft store failed to record a rejection decision");
	return Object.freeze({
		draftDigest: draft.draftDigest,
		reason
	});
}
//#endregion
//#region packages/core/host/src/drafts/projections.ts
/**
* Three Projection presets over the compiled Draft interactions, one per authority.
*
* A worker proposes. An author accepts or rejects. Neither implies the
* other, and a host that only needs to gate invocation of already-declared
* interactions needs neither: {@link runnerProjection} selects nothing at all.
* No preset here hands out every Draft capability; that convenience would
* erase the authority split the other two presets exist to express. A host
* that genuinely wants every capability composes its own Projection from
* `compiled.handles` directly — this module does not ship that shortcut.
*/
function requestOnly(handle) {
	return Object.freeze({
		interaction: handle,
		modes: Object.freeze(["request"])
	});
}
/** A worker's authority: propose only, direct mode. Never accept or reject. */
async function proposerProjection(compiled) {
	return projectInteractions(compiled, { propose: direct(compiled.handles.propose) });
}
/** An author's authority: accept and reject, request mode. Never propose. */
async function authorProjection(compiled) {
	return projectInteractions(compiled, {
		accept: requestOnly(compiled.handles.accept),
		reject: requestOnly(compiled.handles.reject)
	});
}
/**
* No Draft authority at all: neither propose, nor accept, nor reject. For
* a host that only needs to gate invocation of interactions already
* declared and must prove it grants no Draft-deciding capability at all.
*/
async function runnerProjection(compiled) {
	return projectInteractions(compiled, {});
}
//#endregion
export { DRAFT_REJECT_REASONS, acceptDraft, authorProjection, draftsAccept, draftsInteractions, draftsPropose, draftsReject, isDraftRejectReason, proposeDraft, proposerProjection, rejectDraft, runnerProjection };
