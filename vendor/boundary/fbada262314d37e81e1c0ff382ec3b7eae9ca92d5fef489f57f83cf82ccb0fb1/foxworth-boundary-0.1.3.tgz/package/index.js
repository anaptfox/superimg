import { d as InteractionFault, f as failHost, i as defineInteraction, r as declaredInteractionError, s as isDeclaredInteractionError, t as DeclaredInteractionError, u as HostError } from "./chunks/definitions-CFjJCGn-.js";
import { i as metadataForCompiled, n as composeCompiledInteractions, o as snapshotDefinitions, r as diffCompiledInteractions, t as compileInteractions } from "./chunks/compile-Dpp86NdO.js";
import { a as restrictBinding, i as bindProjection, l as implementInteractions, n as admitWhen, o as assessProjection, r as assertProjectionBinding, s as installInteractions, t as admitAll } from "./chunks/binding-DgXVPJI_.js";
import { a as projectInteractions, i as projectAllDirect, n as metadataForProjection, o as direct, r as pickProjection, s as directRealizationIds } from "./chunks/projection-7MSieVvr.js";
import { bindingDescriptions, compareUtf8, hashJson, normalizeJson, validateExecutionEvidence } from "@foxworth/boundary/program";
//#region packages/core/host/src/native-bindings.ts
/** Correlate each compiled alias with its native target and dispatch types. */
function bindNativeInteractions(compiled, targets, dispatchers) {
	metadataForCompiled(compiled);
	const aliases = Object.keys(compiled.handles);
	function properties(record, path) {
		if (record === null || typeof record !== "object" || Array.isArray(record)) failHost("INVALID_INSTALLATION", path, "native binding maps must be closed records");
		const keys = Reflect.ownKeys(record);
		if (keys.length !== aliases.length || keys.some((key) => {
			const property = Object.getOwnPropertyDescriptor(record, key);
			return typeof key !== "string" || !aliases.includes(key) || !property.enumerable || !("value" in property);
		})) failHost("INVALID_INSTALLATION", path, "native binding maps must contain exactly the compiled aliases as data properties");
	}
	properties(targets, "targets");
	properties(dispatchers, "dispatchers");
	function entry(alias) {
		const dispatch = dispatchers[alias];
		if (typeof dispatch !== "function") failHost("INVALID_INSTALLATION", `dispatchers.${String(alias)}`, "native dispatch must be a function");
		return Object.freeze({
			interaction: compiled.handles[alias],
			target: targets[alias],
			dispatch
		});
	}
	return Object.freeze(aliases.map((alias) => entry(alias)));
}
//#endregion
//#region packages/core/host/src/named-callers.ts
/** Build named methods over the authentic caller returned by a native Binding. */
function namedCallers(selections, projections, bindings) {
	const result = Object.create(null);
	for (const name of Object.keys(selections)) {
		const methods = Object.create(null);
		const projection = projections[name];
		const caller = bindings[name].connect();
		for (const alias of selections[name].direct) {
			const handle = Object.getOwnPropertyDescriptor(projection.handles, alias)?.value;
			if (handle === void 0) throw new TypeError(`Projected handle missing for ${alias}`);
			Object.defineProperty(methods, alias, {
				enumerable: true,
				configurable: false,
				writable: false,
				value: (...args) => caller.call(handle, ...args)
			});
		}
		result[name] = Object.freeze(methods);
	}
	return Object.freeze(result);
}
//#endregion
//#region packages/core/host/src/bind-interactions.ts
var BindInteractionsError = class extends Error {
	issues;
	constructor(issues) {
		super(`Could not bind ${issues.length} caller${issues.length === 1 ? "" : "s"}`);
		this.name = "BindInteractionsError";
		this.issues = Object.freeze(issues.map((issue) => Object.freeze({ ...issue })));
	}
};
function ownDataRecord(value, path) {
	if (value === null || typeof value !== "object" || Array.isArray(value)) throw new TypeError(`${path} must be a plain record`);
	const prototype = Object.getPrototypeOf(value);
	if (prototype !== Object.prototype && prototype !== null) throw new TypeError(`${path} must use a plain-object prototype`);
	const copy = Object.create(null);
	for (const key of Reflect.ownKeys(value)) {
		const descriptor = Object.getOwnPropertyDescriptor(value, key);
		if (typeof key !== "string" || descriptor === void 0 || !descriptor.enumerable || !("value" in descriptor)) throw new TypeError(`${path} must contain only enumerable string data properties`);
		Object.defineProperty(copy, key, {
			value: descriptor.value,
			enumerable: true,
			configurable: false,
			writable: false
		});
	}
	return Object.freeze(copy);
}
function exactKeys(record, expected, path) {
	const keys = Object.keys(record);
	if (keys.length !== expected.length || expected.some((key) => !keys.includes(key))) throw new TypeError(`${path} must contain exactly: ${expected.join(", ")}`);
}
function snapshotAliases(value, path) {
	if (!Array.isArray(value)) throw new TypeError(`${path} must be an array`);
	const keys = Reflect.ownKeys(value);
	if (keys.length !== value.length + 1 || keys.some((key) => key !== "length" && (typeof key !== "string" || !/^(0|[1-9][0-9]*)$/u.test(key)))) throw new TypeError(`${path} must be a dense array without extra properties`);
	const aliases = [];
	for (let index = 0; index < value.length; index += 1) {
		const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
		if (!descriptor || !descriptor.enumerable || !("value" in descriptor) || typeof descriptor.value !== "string") throw new TypeError(`${path}[${index}] must be an enumerable string data property`);
		if (aliases.includes(descriptor.value)) throw new TypeError(`${path} contains duplicate alias ${descriptor.value}`);
		aliases.push(descriptor.value);
	}
	return Object.freeze(aliases);
}
function snapshotCallers(value) {
	const callers = ownDataRecord(value, "callers");
	const snapshot = Object.create(null);
	const issues = [];
	for (const name of Object.keys(callers)) try {
		const config = ownDataRecord(callers[name], `callers.${name}`);
		exactKeys(config, ["direct", "admit"], `callers.${name}`);
		const direct = snapshotAliases(config.direct, `callers.${name}.direct`);
		if (typeof config.admit !== "function") throw new TypeError(`callers.${name}.admit must be a function`);
		Object.defineProperty(snapshot, name, {
			value: Object.freeze({
				direct,
				admit: config.admit
			}),
			enumerable: true,
			configurable: false,
			writable: false
		});
	} catch (cause) {
		issues.push(Object.freeze({
			caller: name,
			cause
		}));
	}
	return Object.freeze({
		callers: Object.freeze(snapshot),
		issues: Object.freeze(issues)
	});
}
function defineValue(record, key, value) {
	Object.defineProperty(record, key, {
		value,
		enumerable: true,
		configurable: false,
		writable: false
	});
}
async function bindInteractions(definitions, options) {
	const copiedOptions = ownDataRecord(options, "options");
	exactKeys(copiedOptions, [
		"installationId",
		"realizationVersion",
		"handlers",
		"callers"
	], "options");
	const installationId = copiedOptions.installationId;
	const realizationVersion = copiedOptions.realizationVersion;
	if (typeof installationId !== "string" || typeof realizationVersion !== "string") throw new TypeError("installationId and realizationVersion must be strings");
	const handlers = ownDataRecord(copiedOptions.handlers, "handlers");
	const callerSnapshot = snapshotCallers(copiedOptions.callers);
	const callerSnapshots = callerSnapshot.callers;
	const definitionSnapshot = snapshotDefinitions(definitions);
	const aliases = Object.keys(definitionSnapshot);
	const preflightIssues = [...callerSnapshot.issues];
	for (const [name, caller] of Object.entries(callerSnapshots)) for (const alias of caller.direct) if (!aliases.includes(alias)) {
		preflightIssues.push(Object.freeze({
			caller: name,
			cause: /* @__PURE__ */ new TypeError(`callers.${name}.direct contains unknown interaction alias ${alias}`)
		}));
		break;
	}
	const issues = [...preflightIssues, ...Object.entries(callerSnapshots).filter(([, caller]) => caller.direct.includes("then")).map(([name]) => ({
		caller: name,
		cause: /* @__PURE__ */ new TypeError("interaction alias \"then\" cannot be exposed as a named async method")
	}))];
	if (issues.length > 0) throw new BindInteractionsError(issues);
	const compiled = await compileInteractions(definitionSnapshot);
	const implementations = implementInteractions(definitionSnapshot, handlers);
	const installed = await installInteractions(compiled, {
		installationId,
		implementations,
		realizationIds: directRealizationIds(compiled, realizationVersion)
	});
	const projections = Object.create(null);
	const bindings = Object.create(null);
	const controllers = Object.create(null);
	try {
		const outcomes = await Promise.all(Object.entries(callerSnapshots).map(async ([name, caller]) => {
			try {
				const selection = Object.create(null);
				for (const alias of caller.direct) defineValue(selection, alias, Object.freeze({
					interaction: compiled.handles[alias],
					modes: Object.freeze(["direct"])
				}));
				const projection = await projectInteractions(compiled, selection);
				const bound = await bindProjection(projection, installed.installation, { admit: async ({ context }) => await caller.admit(context) === true ? { decision: "allow" } : {
					decision: "deny",
					reason: "denied"
				} });
				if (bound.status === "unrealized") return {
					name,
					projection,
					issue: bound.report
				};
				return {
					name,
					projection,
					binding: bound.binding,
					controller: bound.controller
				};
			} catch (cause) {
				return {
					name,
					cause
				};
			}
		}));
		for (const outcome of outcomes) if ("cause" in outcome) issues.push({
			caller: outcome.name,
			cause: outcome.cause
		});
		else if ("issue" in outcome) issues.push({
			caller: outcome.name,
			cause: outcome.issue
		});
		else {
			defineValue(projections, outcome.name, outcome.projection);
			defineValue(bindings, outcome.name, outcome.binding);
			defineValue(controllers, outcome.name, outcome.controller);
		}
		if (issues.length > 0) throw new BindInteractionsError(issues);
		const frozenProjections = Object.freeze(projections);
		const frozenBindings = Object.freeze(bindings);
		const frozenControllers = Object.freeze(controllers);
		const callers = namedCallers(callerSnapshots, frozenProjections, frozenBindings);
		return Object.freeze({
			compiled,
			installation: installed.installation,
			installationController: installed.controller,
			projections: frozenProjections,
			bindings: frozenBindings,
			bindingControllers: frozenControllers,
			callers
		});
	} catch (cause) {
		for (const controller of Object.values(controllers)) controller.revoke();
		installed.controller.revoke();
		throw cause;
	}
}
//#endregion
//#region packages/core/host/src/evidence.ts
/**
* Explicitly publish a host-selected envelope. Validation precedes delivery;
* delivery failure retains evidence and cannot rewrite execution/subject truth.
* No invocation hook, read token export, authentication or retry is implied.
*/
async function publishExecutionEvidence(publisher, value) {
	const evidence = validateExecutionEvidence(value);
	const publish = publisher?.publish;
	if (typeof publish !== "function") throw new TypeError("execution evidence publisher must provide publish()");
	try {
		await publish.call(publisher, evidence);
		return Object.freeze({
			status: "published",
			evidence
		});
	} catch (cause) {
		return Object.freeze({
			status: "delivery-failed",
			evidence,
			cause
		});
	}
}
//#endregion
//#region packages/core/host/src/presentation.ts
/** Derive schemas from the selected contract; presentation overrides cannot change execution facts. */
async function presentProjection(projection, overrides) {
	metadataForProjection(projection);
	const presentation = normalizeJson(overrides ?? {}, "presentation.overrides");
	if (!presentation || Array.isArray(presentation) || typeof presentation !== "object") return failHost("INVALID_ARTIFACT", "presentation.overrides", "overrides must be a record");
	for (const [alias, override] of Object.entries(presentation)) {
		if (!projection.manifest.interactions.some((interaction) => interaction.alias === alias)) return failHost("INVALID_ARTIFACT", alias, "presentation alias is not selected");
		if (!override || typeof override !== "object" || Array.isArray(override) || Object.entries(override).some(([key, value]) => !["title", "description"].includes(key) || typeof value !== "string")) return failHost("INVALID_ARTIFACT", alias, "only title and description may be overridden");
	}
	const descriptors = new Map(projection.program.interactions.map((descriptor) => [descriptor.contract.id, descriptor]));
	const interactions = [...projection.manifest.interactions].sort((left, right) => compareUtf8(left.alias, right.alias)).map((selected) => {
		const descriptor = descriptors.get(selected.interactionId);
		const { contract } = descriptor;
		return {
			alias: selected.alias,
			interactionId: selected.interactionId,
			contractDigest: selected.expectedContractDigest,
			inputArity: selected.inputArity,
			modes: selected.modes,
			title: presentation[selected.alias]?.title ?? descriptor.docs.summary ?? selected.alias,
			description: presentation[selected.alias]?.description ?? descriptor.docs.description ?? "",
			inputSchema: contract.inputSchema,
			...selected.modes.includes("direct") ? { directOutputSchema: contract.outputSchema } : {},
			...selected.modes.includes("direct") && contract.errorSchema !== void 0 ? { errorSchema: contract.errorSchema } : {},
			reads: contract.reads,
			changes: contract.changes
		};
	});
	const identity = normalizeJson({
		version: 1,
		projectionDigest: projection.projectionDigest,
		interactions
	});
	const presentationDigest = await hashJson("boundary.projection-presentation/v1", identity);
	return Object.freeze({
		...identity,
		presentationDigest
	});
}
//#endregion
//#region packages/core/host/src/description.ts
/** Snapshot only the selected public contracts of an authentic native Binding. */
function describeBinding(binding) {
	assertProjectionBinding(binding);
	return bindingDescriptions(binding.manifest);
}
//#endregion
export { BindInteractionsError, DeclaredInteractionError, HostError, InteractionFault, admitAll, admitWhen, assessProjection, bindInteractions, bindNativeInteractions, bindProjection, compileInteractions, composeCompiledInteractions, declaredInteractionError, defineInteraction, describeBinding, diffCompiledInteractions, direct, directRealizationIds, implementInteractions, installInteractions, isDeclaredInteractionError, pickProjection, presentProjection, projectAllDirect, projectInteractions, publishExecutionEvidence, restrictBinding };
