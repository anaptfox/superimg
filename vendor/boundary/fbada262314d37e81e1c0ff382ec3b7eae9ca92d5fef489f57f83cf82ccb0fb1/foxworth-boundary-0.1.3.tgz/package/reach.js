import { BoundaryErrorBase, compareUtf8, hashJson } from "@foxworth/boundary/program";
//#region packages/discovery/reach/src/transport.ts
/**
* One way to reach a surface.
*
* Kinds are closed in version 1. In-process reach needs no record, because a
* caller in the same process already holds the Binding; a record exists
* precisely to cross a boundary.
*
* This is a from-scratch TypeScript port of the algorithm in
* `crates/boundary-reach/src/record.rs`. It must sort and validate
* byte-identically to the Rust implementation; the shared conformance vector
* is the check, not this comment.
*/
/**
* Characters a transport address may carry beyond ASCII alphanumerics.
*
* A strict allowlist, not a denylist of what is dangerous today. A record is
* handed between applications and is unsigned in version 1, so whoever hands
* one over chooses the address a caller dials. Carriage return and line feed
* would split one HTTP request into two on the wire; a space would end the
* request line early; `?`, `#`, and `@` name url parts a Reach base has no
* business carrying. Listing what is allowed means a character nobody
* thought to deny cannot surprise a later sink.
*
* `%` stays in: a base path may be percent-encoded, and nothing here decodes
* it, so an encoded byte reaches the server as encoded text.
*/
var ADDRESS_ALLOWED = "-._~:/%";
/** Refuses any character outside {@link ADDRESS_ALLOWED} or ASCII alphanumerics. */
function characterViolation(field, value) {
	for (let index = 0; index < value.length; index += 1) {
		const character = value[index];
		if (/[A-Za-z0-9]/.test(character) || ADDRESS_ALLOWED.includes(character)) continue;
		return { reason: `${field} may not contain ${JSON.stringify(character)} at byte ${index}; an address is limited to ASCII alphanumerics and ${JSON.stringify(ADDRESS_ALLOWED)}` };
	}
}
/**
* Validates one transport's address shape.
*
* Returns the violation rather than throwing, so a caller can decide how to
* report it; {@link validateTransport} throws for callers who want that.
*/
function transportViolation(transport) {
	if (transport.kind === "unix") {
		if (!transport.path.startsWith("/")) return { reason: `unix socket path must be absolute, got ${JSON.stringify(transport.path)}` };
		const path = characterViolation("unix socket path", transport.path);
		if (path !== void 0) return path;
		return baseViolation(transport.base);
	}
	if (!transport.url.startsWith("http://") && !transport.url.startsWith("https://")) return { reason: `http url must name a scheme, got ${JSON.stringify(transport.url)}` };
	if (transport.url.endsWith("/")) return { reason: "http url must not end with a slash; the routes supply it" };
	return characterViolation("http url", transport.url);
}
function baseViolation(base) {
	const characters = characterViolation("base path", base);
	if (characters !== void 0) return characters;
	if (!base.startsWith("/")) return { reason: `base path must be absolute, got ${JSON.stringify(base)}` };
	if (base === "/") return { reason: "base path must not claim the application root" };
	if (base.endsWith("/")) return { reason: "base path must not end with a slash" };
}
/** A stable sort key: unix ranks 0, http ranks 1. */
function sortKey(transport) {
	return transport.kind === "unix" ? [
		0,
		transport.path,
		transport.base
	] : [
		1,
		transport.url,
		""
	];
}
/**
* A stable ordering, so a record's digest does not depend on the order a
* host happened to list its transports.
*/
function compareTransports(left, right) {
	const [leftRank, leftPrimary, leftSecondary] = sortKey(left);
	const [rightRank, rightPrimary, rightSecondary] = sortKey(right);
	if (leftRank !== rightRank) return leftRank - rightRank;
	const primary = compareUtf8(leftPrimary, rightPrimary);
	if (primary !== 0) return primary;
	return compareUtf8(leftSecondary, rightSecondary);
}
/** Structural equality, for collapsing adjacent duplicates once sorted. */
function transportsEqual(left, right) {
	if (left.kind !== right.kind) return false;
	return left.kind === "unix" ? left.path === right.path && left.base === right.base : left.url === right.url;
}
/**
* Sorts transports by their stable key and drops adjacent duplicates, the
* same way a Rust host does after `sort_by` + `dedup`.
*/
function sortAndDedupeTransports(transports) {
	const sorted = [...transports].sort(compareTransports);
	const out = [];
	for (const transport of sorted) {
		const previous = out[out.length - 1];
		if (previous !== void 0 && transportsEqual(previous, transport)) continue;
		out.push(transport);
	}
	return out;
}
//#endregion
//#region packages/discovery/reach/src/record.ts
/**
* The Reach record: where a Binding can be reached.
*
* Binding identity deliberately excludes routes and transport, so moving a
* deployment must not change what was pinned. That leaves a gap: something
* has to say where a surface actually is. A Reach record fills it without
* reopening identity. It *references* a binding digest and is reissued when
* a deployment moves; the Binding manifest never learns it exists.
*
* A Reach record is not authority. Holding one lets a caller find a surface
* and fetch its manifest; the caller still binds atomically against that
* manifest, and the host still admits every invocation. Nothing here carries
* context, credentials, admission policy, or a grant. Handing someone a
* Reach record is closer to giving out an address than a key.
*
* Records are unsigned in version 1. The signature field is reserved so
* adding one later does not change the shape, and it is excluded from the
* digest because a signature signs a digest and cannot be part of what it
* signs.
*
* This is a from-scratch TypeScript port of the algorithm in
* `crates/boundary-reach/src/record.rs`. It must produce byte-identical
* digests for the same input; the shared conformance vector is the check,
* not this comment.
*/
/** Identity domain for a Reach record. */
var REACH_DOMAIN = "boundary.reach/v1";
/** A Reach record that cannot be built, or a record that failed to verify. */
var ReachError = class ReachError extends BoundaryErrorBase {
	/** The offending field. `EMPTY` only. */
	field;
	/** What was wrong with a transport address. `TRANSPORT` only. */
	reason;
	/** The digest recorded on the record. `DIGEST_MISMATCH` only. */
	recorded;
	/** The digest recomputed from the record's content. `DIGEST_MISMATCH` only. */
	recomputed;
	constructor(code, path, message, options = {}) {
		super(code, path, message);
		this.name = "ReachError";
		if (options.field !== void 0) this.field = options.field;
		if (options.reason !== void 0) this.reason = options.reason;
		if (options.recorded !== void 0) this.recorded = options.recorded;
		if (options.recomputed !== void 0) this.recomputed = options.recomputed;
	}
	/** A required field was empty. */
	static empty(field) {
		return new ReachError("EMPTY", field, `reach record field ${JSON.stringify(field)} must not be empty`, { field });
	}
	/** A record listed no way to reach anything, once sorted and deduplicated. */
	static noTransports() {
		return new ReachError("NO_TRANSPORTS", "transports", "a reach record must list at least one transport");
	}
	/** A transport address was not the shape its kind requires. */
	static transport(reason) {
		return new ReachError("TRANSPORT", "transports", `transport address is invalid: ${reason}`, { reason });
	}
	/** A record's recorded digest does not match its recomputed content. */
	static digestMismatch(recorded, recomputed) {
		return new ReachError("DIGEST_MISMATCH", "reachDigest", `reach digest mismatch: recorded ${recorded}, recomputed ${recomputed}`, {
			recorded,
			recomputed
		});
	}
};
function transportToJson(transport) {
	return transport.kind === "unix" ? {
		kind: transport.kind,
		path: transport.path,
		base: transport.base
	} : {
		kind: transport.kind,
		url: transport.url
	};
}
/**
* Hashes the identity-bearing fields.
*
* The signature is excluded, because a signature signs a digest and cannot
* be part of what it signs.
*/
function computeReachDigest(bindingDigest, installationId, transports) {
	return hashJson(REACH_DOMAIN, {
		version: 1,
		bindingDigest,
		installationId,
		transports: transports.map(transportToJson)
	});
}
/**
* Builds and validates a Reach record, computing its digest.
*
* Transports are sorted, so two hosts listing the same addresses in a
* different order produce the same record.
*
* @throws {ReachError} when a field is empty, no transport is listed, or an
* address is malformed.
*/
async function createReachRecord(bindingDigest, installationId, transports) {
	if (bindingDigest.trim() === "") throw ReachError.empty("bindingDigest");
	if (installationId.trim() === "") throw ReachError.empty("installationId");
	for (const transport of transports) {
		const violation = transportViolation(transport);
		if (violation !== void 0) throw ReachError.transport(violation.reason);
	}
	const sorted = sortAndDedupeTransports(transports);
	if (sorted.length === 0) throw ReachError.noTransports();
	const reachDigest = await computeReachDigest(bindingDigest, installationId, sorted);
	return Object.freeze({
		version: 1,
		bindingDigest,
		installationId,
		transports: sorted,
		reachDigest
	});
}
/**
* Recomputes and checks the digest of a record that crossed a boundary.
*
* @throws {ReachError} with code `DIGEST_MISMATCH` when the record's
* recorded digest does not match its content.
*/
async function verifyReachRecord(record) {
	const recomputed = await computeReachDigest(record.bindingDigest, record.installationId, record.transports);
	if (recomputed !== record.reachDigest) throw ReachError.digestMismatch(record.reachDigest, recomputed);
}
//#endregion
export { ReachError, compareTransports, createReachRecord, sortAndDedupeTransports, transportViolation, transportsEqual, verifyReachRecord };
