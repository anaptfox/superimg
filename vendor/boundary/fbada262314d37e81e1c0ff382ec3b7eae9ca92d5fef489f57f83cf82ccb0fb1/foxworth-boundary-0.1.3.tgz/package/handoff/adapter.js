import { a as snapshotProjectedHandle, c as RemoteExecutionError, d as RemoteProtocolRejection, f as isDomainErrorFor, i as modeForHandle, l as RemoteInvocationError, n as compileProjectionResolution, o as AdapterError, r as interactionKey, s as RemoteDomainError, t as compileBindingResolution, u as RemoteProtocolError } from "../chunks/resolution-DipfP_4a.js";
import { a as faultResult, c as sanitizedInternalResult, i as executeSerializedInvocation, l as statusForRemoteResult, n as compileHandoffExposure, o as invokePreparedInteraction, r as executeExposedInteraction, s as prepareExposedInteraction, t as compileExposure } from "../chunks/remote-BuX2MHpJ.js";
import { PortableSchemaError, normalizeJson, validatePortableSchema, validateSchemaValue } from "@foxworth/boundary/program";
//#region packages/core/handoff/src/adapter/schema.ts
function portableSchema$1(schema, path) {
	try {
		const normalized = normalizeJson(schema, path);
		if (normalized === null || typeof normalized !== "object" || Array.isArray(normalized)) throw new AdapterError("UNSUPPORTED_SCHEMA", path, "a portable schema must be a JSON object");
		const object = normalized;
		validatePortableSchema(object, path);
		return object;
	} catch (error) {
		if (error instanceof AdapterError) throw error;
		if (error instanceof PortableSchemaError) throw new AdapterError("UNSUPPORTED_SCHEMA", error.path, error.message);
		throw new AdapterError("UNSUPPORTED_SCHEMA", path, "schema is not portable JSON");
	}
}
/** Normalize and validate one value against Program's canonical schema profile. */
function validatePortableValue(schema, value, path = "value") {
	const normalizedSchema = portableSchema$1(schema, `${path}.schema`);
	let normalized;
	try {
		normalized = normalizeJson(value, path);
	} catch {
		throw new AdapterError("SCHEMA_MISMATCH", path, "value is not portable JSON");
	}
	const issues = validateSchemaValue(normalizedSchema, normalized, path);
	if (issues.length > 0) throw new AdapterError("SCHEMA_MISMATCH", issues[0].path, issues[0].message);
	return normalized;
}
//#endregion
export { AdapterError, RemoteDomainError, RemoteExecutionError, RemoteInvocationError, RemoteProtocolError, RemoteProtocolRejection, compileBindingResolution, compileExposure, compileHandoffExposure, compileProjectionResolution, executeExposedInteraction, executeSerializedInvocation, faultResult, interactionKey, invokePreparedInteraction, isDomainErrorFor, modeForHandle, prepareExposedInteraction, sanitizedInternalResult, snapshotProjectedHandle, statusForRemoteResult, validatePortableValue };
