import { f as snapshotJson, n as compileSchema, x as BoundaryErrorBase } from "../chunks/schema-D84XUXTj.js";
import { z } from "zod";
//#region packages/core/program/src/zodValidate.ts
var PORTABLE_ZOD_CHECKS = /* @__PURE__ */ new Set([
	"greater_than",
	"less_than",
	"length_equals",
	"max_length",
	"min_length",
	"multiple_of",
	"number_format",
	"string_format"
]);
function validateZodNode(schema, path, active = /* @__PURE__ */ new WeakSet()) {
	if (active.has(schema)) throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", path, "recursive schemas are not in Boundary' portable schema profile");
	active.add(schema);
	try {
		validateActiveZodNode(schema, path, active);
	} finally {
		active.delete(schema);
	}
}
function validateActiveZodNode(schema, path, active) {
	const internals = schema._zod;
	const def = internals?.def;
	if (!def) throw new SchemaCompilationError("SCHEMA_UNKNOWN_ZOD_NODE", path, "schema internals are unavailable");
	const bag = internals?.bag;
	if (typeof bag?.validator === "function" && typeof bag.fallbackRun === "function") throw new SchemaCompilationError("SCHEMA_RUNTIME_TRANSFORM", path, "attached Zod parser equivalence is unproven; compile the original declarative schema");
	const metadata = z.globalRegistry.get(schema);
	if (metadata !== void 0) jsonValue(metadata, `${path}.metadata`);
	const type = def.type;
	if (type === "default" || type === "transform" || type === "pipe" || type === "catch" || type === "prefault" || type === "readonly") throw new SchemaCompilationError("SCHEMA_RUNTIME_TRANSFORM", path, `Zod ${String(type)} semantics are not portable`);
	if (type === "any" || type === "unknown" || type === "custom" || type === "date" || type === "bigint" || type === "file" || type === "map" || type === "set" || type === "function" || type === "promise" || type === "symbol" || type === "undefined" || type === "void" || type === "nan" || type === "success") throw new SchemaCompilationError("SCHEMA_NON_JSON_TYPE", path, `Zod ${String(type)} is not JSON portable`);
	if (def.coerce === true) throw new SchemaCompilationError("SCHEMA_RUNTIME_TRANSFORM", path, "Zod coercion is not portable");
	const checks = Array.isArray(def.checks) ? def.checks : [];
	for (const check of checks) {
		const checkDef = check._zod?.def;
		const checkKind = checkDef?.check;
		if (checkKind === "custom" || checkKind === "overwrite") throw new SchemaCompilationError("SCHEMA_RUNTIME_TRANSFORM", path, `Zod ${String(checkKind)} semantics are not portable`);
		if (typeof checkKind !== "string" || !PORTABLE_ZOD_CHECKS.has(checkKind)) throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", path, `Zod ${String(checkKind)} checks are not in Boundary' portable schema profile`);
		if (checkDef?.format === "regex" && checkDef.pattern instanceof RegExp && checkDef.pattern.flags !== "u") throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", path, "regular expressions must use exactly the Unicode flag to match JSON Schema pattern semantics");
		if (checkDef?.check === "string_format" && checkDef.format === "includes" && checkDef.position !== void 0) throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", path, "Zod includes(position) cannot be represented faithfully by JSON Schema pattern");
		if (checkDef?.check === "multiple_of") throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", path, "Zod multipleOf uses floating tolerance that JSON Schema does not define");
	}
	const child = (value, segment) => {
		if (value && typeof value === "object" && "_zod" in value) validateZodNode(value, `${path}.${segment}`, active);
	};
	const children = (value, segment) => {
		if (!Array.isArray(value)) return;
		value.forEach((item, index) => child(item, `${segment}${index}`));
	};
	switch (type) {
		case "string":
		case "number":
		case "int":
		case "boolean":
		case "null":
		case "never":
		case "enum":
		case "literal": break;
		case "array":
			child(def.element, "items");
			break;
		case "object": {
			const shape = def.shape;
			if (shape && typeof shape === "object") for (const [name, value] of Object.entries(shape)) child(value, name);
			child(def.catchall, "catchall");
			break;
		}
		case "union":
			if (def.inclusive === false) throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", path, "exclusive Zod unions are not represented faithfully by JSON Schema oneOf");
			children(def.options, "option");
			break;
		case "intersection": throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", path, "Zod intersection object merging is not equivalent to JSON Schema allOf");
		case "tuple": throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", path, "Zod tuple arity is not represented faithfully by its JSON Schema output");
		case "record":
			child(def.keyType, "key");
			child(def.valueType, "value");
			break;
		case "optional":
		case "nullable":
		case "nonoptional":
			child(def.innerType, "inner");
			break;
		case "template_literal": throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", path, "Zod template literals do not preserve Unicode regular-expression semantics");
		case "lazy": throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", path, "Zod lazy schemas are not in Boundary' portable schema profile");
		default: throw new SchemaCompilationError("SCHEMA_UNKNOWN_ZOD_NODE", path, `Zod ${String(type)} is not in Boundary' portable schema profile`);
	}
}
//#endregion
//#region packages/core/program/src/zod.ts
var SchemaCompilationError = class extends BoundaryErrorBase {
	constructor(code, path, message) {
		super(code, path, message);
		this.name = "SchemaCompilationError";
	}
};
var ASSERTION_KEYS = /* @__PURE__ */ new Set([
	"type",
	"properties",
	"required",
	"additionalProperties",
	"items",
	"prefixItems",
	"enum",
	"const",
	"anyOf",
	"oneOf",
	"allOf",
	"not",
	"minimum",
	"maximum",
	"exclusiveMinimum",
	"exclusiveMaximum",
	"multipleOf",
	"minLength",
	"maxLength",
	"pattern",
	"minItems",
	"maxItems",
	"uniqueItems",
	"minProperties",
	"maxProperties"
]);
var ANNOTATION_KEYS = /* @__PURE__ */ new Set([
	"title",
	"description",
	"examples",
	"deprecated",
	"readOnly",
	"writeOnly",
	"role",
	"control"
]);
function isPlainObject(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	try {
		const prototype = Object.getPrototypeOf(value);
		return prototype === Object.prototype || prototype === null;
	} catch {
		return false;
	}
}
function jsonValue(value, path) {
	return snapshotJson(value, {
		path,
		fail: (failure) => {
			throw new SchemaCompilationError(failure.code === "JSON_NON_FINITE_NUMBER" ? "SCHEMA_NON_FINITE_NUMBER" : "SCHEMA_NON_JSON_VALUE", failure.path, failure.message);
		}
	});
}
/**
* Strip only Zod's non-enumerable Standard Schema implementation property.
* Not routed through `exactObject`: that kernel has no "drop exactly this one
* non-enumerable key, then strictly walk the rest" mode, and adding one for a
* single third-party quirk doesn't belong in a general-purpose walker.
*/
function generatedSchemaValue(value, path) {
	if (!isPlainObject(value)) return jsonValue(value, path);
	let keys;
	try {
		keys = Reflect.ownKeys(value);
	} catch {
		throw new SchemaCompilationError("SCHEMA_NON_JSON_VALUE", path, "schema properties could not be inspected");
	}
	const visible = {};
	for (const key of keys) {
		if (typeof key === "symbol") throw new SchemaCompilationError("SCHEMA_NON_JSON_VALUE", path, "schema contains a symbol-keyed property");
		const isEnum = Object.prototype.propertyIsEnumerable.call(value, key);
		if (key === "~standard" && !isEnum) continue;
		if (!isEnum) throw new SchemaCompilationError("SCHEMA_NON_JSON_VALUE", `${path}.${key}`, "schema properties must be enumerable");
		visible[key] = value[key];
	}
	return jsonValue(visible, path);
}
function splitSchema(value, path) {
	if (Array.isArray(value)) {
		const children = value.map((item, index) => splitSchema(item, `${path}[${index}]`));
		return {
			contract: children.map((child) => child.contract ?? null),
			...children.some((child) => child.annotations !== void 0) ? { annotations: children.map((child) => child.annotations ?? null) } : {}
		};
	}
	if (!isPlainObject(value)) return { contract: jsonValue(value, path) };
	const contract = {};
	const annotations = {};
	for (const [key, item] of Object.entries(value)) {
		const itemPath = `${path}.${key}`;
		if (key === "$schema") continue;
		if (key === "format" || key === "$ref" || key === "$defs") throw new SchemaCompilationError("SCHEMA_UNSUPPORTED_KEYWORD", itemPath, `${key} is not in the portable schema profile`);
		if (ANNOTATION_KEYS.has(key)) {
			annotations[key] = jsonValue(item, itemPath);
			continue;
		}
		if (!ASSERTION_KEYS.has(key)) throw new SchemaCompilationError("SCHEMA_UNSUPPORTED_KEYWORD", itemPath, `${key} is not in the portable schema profile`);
		if (key === "properties" && isPlainObject(item)) {
			const contractProperties = {};
			const annotationProperties = {};
			for (const [name, property] of Object.entries(item)) {
				const split = splitSchema(property, `${itemPath}.${name}`);
				if (split.contract !== void 0) contractProperties[name] = split.contract;
				if (split.annotations !== void 0) annotationProperties[name] = split.annotations;
			}
			contract.properties = contractProperties;
			if (Object.keys(annotationProperties).length > 0) annotations.properties = annotationProperties;
			continue;
		}
		const split = splitSchema(item, itemPath);
		if (split.contract !== void 0) contract[key] = split.contract;
		if (split.annotations !== void 0) annotations[key] = split.annotations;
	}
	if (Array.isArray(contract.type)) {
		const types = contract.type;
		const supported = /* @__PURE__ */ new Set([
			"string",
			"number",
			"integer",
			"boolean",
			"array",
			"object",
			"null"
		]);
		if (types.length === 0 || types.some((type) => typeof type !== "string" || !supported.has(type)) || new Set(types).size !== types.length) throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", `${path}.type`, "generated type arrays must contain distinct supported JSON type names");
		delete contract.type;
		const alternatives = types.map((type) => ({ type }));
		if (contract.anyOf === void 0) contract.anyOf = alternatives;
		else {
			if (contract.allOf !== void 0 && !Array.isArray(contract.allOf)) throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", `${path}.allOf`, "generated allOf must remain an array of schemas");
			contract.allOf = [...contract.allOf ?? [], { anyOf: alternatives }];
		}
	}
	return {
		contract,
		...Object.keys(annotations).length === 0 ? {} : { annotations }
	};
}
function compileZod(schema, context) {
	validateZodNode(schema, context.path);
	let generated;
	try {
		generated = z.toJSONSchema(schema, { io: "output" });
	} catch (error) {
		const message = error instanceof Error ? error.message : String(error);
		throw new SchemaCompilationError("SCHEMA_NOT_PORTABLE", context.path, message);
	}
	const split = splitSchema(generatedSchemaValue(generated, context.path), context.path);
	if (!isPlainObject(split.contract)) throw new SchemaCompilationError("SCHEMA_NOT_OBJECT", context.path, "compiled schema must be an object");
	return {
		contract: split.contract,
		annotations: isPlainObject(split.annotations) ? split.annotations : {}
	};
}
/** Built-in browser-safe adapter for Zod 4 schemas. */
var zodSchemaAdapter = Object.freeze({
	compile: compileZod,
	supports(value) {
		return value !== null && typeof value === "object" && "_zod" in value;
	}
});
function compileZodSchema(schema, role, path) {
	return compileSchema(schema, zodSchemaAdapter, {
		role,
		path
	});
}
//#endregion
export { SchemaCompilationError, compileZodSchema, jsonValue, zodSchemaAdapter };
